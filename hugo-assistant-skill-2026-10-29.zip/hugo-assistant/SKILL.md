---
name: hugo-assistant
description: Build a grounded, voice-capable AI assistant ("a Hugo") into a server-backed app, one that answers questions about the app's own data, cites the records it used, refuses to make things up, speaks and listens, and stays inside a spend cap. Use when adding a natural-language assistant to an app, when its answers must be trusted, or when adding voice to one.
---

# Hugo assistant

Hugo is the assistant in NATO VENDOR RADAR. Operators ask it questions about thousands of records, by keyboard or by
voice, on a desktop or a phone. This skill is the generic pattern, taken from the shipped code. File references point
at the source app so the pattern can be checked; replace them with your own.

## The one idea

**The model never answers from memory. It answers from tools, and the server checks every answer against what the
tools returned before the user sees it.** Everything else (voice, the Orb, the caps) is built around that loop.

## Architecture

```
Browser (Orb or rail)
  │  typed turn: POST /api/<app>/hugo/agent (NDJSON stream)
  │  voice: WebSocket relay or WebRTC session, both through YOUR server
  ▼
Server (role check → rate tier → daily spend cap)
  ▼
Agent loop: model ⇄ read-only tools (bounded steps, calls, time)
  │  every tool result folded into a per-turn LEDGER (ids, names, numbers, links)
  ▼
Verifier: every citation, link, id, entity and figure in the answer must be in the ledger
  │  fail → one corrective retry → fail again → return only the records the tools found
  ▼
Answer + citations + per-turn cost → client renders citation chips ONLY from server-admitted citations
```

### 1. The agent loop (server)

● A function-calling loop with hard caps: steps (12), tool calls (24), wall time (75 s), answer length (4,000
  characters). If every step went on tools, make one closing call with tools switched off, so the turn never ends empty.
● A 45-second deadline on every model request.
● History from the client is sanitised: user and assistant turns only (a client can never send a system turn), a cap on
  turns (24) and on characters per turn (4,000).
● Stream progress as NDJSON: one line per finished tool (name and ok only), the checked answer last.
● The model closes with structured JSON: `{answer, cited, entities, numbers}`, records cited as `[R1]`.

### 2. Tools: read-only or confirm-first

● One provider-neutral tool set. Source app examples: `query_records`, `count_records`, `get_record`,
  `find_similar`, `record_provenance`, `explain_match`, `web_lookup`, `search_help`, `describe_app`, `app_state`,
  `recent_history`.
● Anything that changes data is a PROPOSAL tool (`propose_update`, `propose_scan`, `propose_view`): it returns a
  proposal the user confirms in the interface. A proposal never applies itself.
● Cap rows per call (50) and sanitise every string a tool returns.
● Validate tool arguments with the same normaliser the app's own filters use, so the model cannot query what a user
  could not.

### 3. Grounding and the verifier (the part that makes it trustworthy)

● The ledger holds every id, name, number and URL the tools returned in this turn.
● The verifier checks every `[Rn]`, every http(s) link, every cited id, every declared entity and every figure about
  records against the ledger. Match URLs case-insensitively (a fabricated `HTTPS://` link once slipped past a
  case-sensitive pattern).
● Scope the figure check to RECORD claims. Checking every number withdrew true answers about the app itself ("7
  domains").
● An empty answer is never marked verified.
● Fail closed: one corrective retry, then answer only with the records the tools returned.
● A deterministic floor: with no model, or when the provider fails, answer from the tools alone and say why
  (`providerFailed` with a reason).
● Streamed (spoken) answers cannot be stopped mid-sentence, so check them when they finish: withdraw a failed typed
  answer, flag a failed spoken one.

### 4. Security

● Keys are server-side only, read once, trimmed (an untrimmed key showed as configured and failed with 401). Log the
  length, never the value.
● The browser never talks to the model provider directly: the voice relay is same-origin, and the WebRTC offer is
  posted to your server, which builds the whole session. The browser can change nothing about it.
● The relay forwards a SAFELIST of client events (audio append, commit, clear, a user text turn rebuilt from text alone)
  and drops everything else, notably `session.update` and `response.*`.
● Web text is untrusted: normalise (NFKC), strip control and format characters, drop instruction-shaped sentences, and
  report what was removed.
● Every Hugo route needs an authenticated role. The WebSocket upgrade refuses, in order and before dialling upstream:
  wrong path, cross-site origin, missing scope, unpriced model, missing role, daily cap reached.
● The client renders citation chips only from the server's `citations` list, drops an unadmitted `[Rn]`, and escapes
  all text.
● Provider error prose is redacted and goes to an admin fault log, never to the user.
● Audit each turn (scope, turn count, door, steps, hosts reached on the web, read from the ledger) but NEVER the user's
  words. Keep read-action audit rows for a fixed period (30 days).

### 5. Cost and abuse

● One UTC-day spend ledger shared by every paid call, with a daily cap from the environment. Unset or 0 means off.
● It fails closed: if the ledger cannot be read, no paid call runs. A model with no price row is not offered under a cap.
● Check the cap before the call, before dialling voice, at the WebSocket upgrade and again before each voice response.
● Give the assistant its OWN rate tier (30 turns a minute in the source app). Putting it on a strict 3-a-minute scan tier
  refused the 4th message in a minute, and the client told the user they had hit the day's cap.
● Every refusal names its limit (per-minute tier or daily cap); only the daily cap says "try tomorrow".
● Per-request bounds: web lookups per turn (3), results per lookup (5), page text (4,000 characters), tool output to a
  voice model (12,000 characters), client frame (1 MB), voice session body (80 KB), concurrent voice sessions (40, one
  per user and tab), voice session create timeout (15 s), voice session length (120 minutes, configurable).
● Show each turn's cost to the user and today's spend against the cap in Settings.

### 6. Voice

● Order of preference: a native realtime voice session (WebRTC), then a WebSocket relay to a realtime model, then the
  browser's `SpeechRecognition` / `webkitSpeechRecognition` as the free fallback (it also powers a "Hey Hugo" wake phrase).
● Hold to talk: a press of 450 ms or more talks; a shorter press opens the typing box.
● The listening ring turns green only when the microphone is actually open, driven by audio events, never by the press.
  A polite live region says "Microphone on. Hugo is listening."
● **iOS and Safari refuse a microphone requested outside a user gesture.** Create the AudioContext and call
  `getUserMedia` inside the press handler itself, then hand that stream to the voice session; release it on a short tap.
● Name a refusal precisely: the error type, the Permissions API state, and whether the app is in a frame.
● Never hide Talk silently: when it cannot run, show it disabled with the reason and the fix.
● A probe route (`GET .../hugo/voice`) reports configured, realtime, live, listener, fault and canFix, so the interface
  can explain itself.
● Send the bearer token for the WebSocket in a subprotocol (never an empty entry: one broke Talk).

### 7. Interface (the Orb)

● One module for phone and desktop. On a phone the assistant can be the whole app.
● A scope picker as a modal sheet (`role="dialog"`, `aria-modal`, `aria-pressed` choices, background inert, focus
  returned on close). Default scope: everything.
● Starter chips built from loaded data, never invented figures.
● Answer states (streaming, checking, verified, withdrawn) carried in words, not only colour; a progress line names the
  tools while a turn runs; record citations are buttons that open the record.
● Accessibility: animation only under `prefers-reduced-motion: no-preference`; visible focus; aria labels that change
  with state; Escape must close only the Orb's own dialogs (it once swallowed Escape across the page).

## Tests and evals that must exist

● The loop against a scripted model: caps, closing call, retry, fail-closed.
● The route in-process, including the stream.
● The verifier: invented id, invented link (including upper-case scheme), invented figure, app facts allowed, empty answer.
● Streamed answer check: withdrawn when typed, flagged when spoken.
● Rate tier: its own tier, named refusals, the 4th turn in a minute passes.
● Spend cap: refuses at the cap, fails closed on an unreadable ledger, unpriced model not offered.
● Relay safelist and the server-built session; each upgrade refusal and its order.
● The Orb: ring follows the microphone, the press requests the microphone, Talk never hidden silently.
● Evals: deterministic tasks (query, refusal, injection phrasing); poisoned web pages; a model suite with a
  fabrication trap, replayed from recordings (record them with a live key before release, or the suite reads NOT RUN).
● A browser pass on a real phone before calling voice done (the source app has not yet done this: an open residual).
