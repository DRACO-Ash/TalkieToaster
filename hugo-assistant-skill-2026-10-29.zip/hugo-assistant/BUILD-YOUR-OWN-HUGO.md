# Build your own Hugo

Hugo is the assistant inside NATO VENDOR RADAR: an operator asks a question in plain English, by keyboard or by voice,
and Hugo answers from the app's own data, cites every record it used, and refuses to invent anything. The owner's verdict,
29 October 2026: "HUGO is truly IMMENSE!"

This is the checklist for putting one into your own app. The pattern, with the reasons behind each rule, is the
`hugo-assistant` skill in this pack (`skills/hugo-assistant/SKILL.md`). Hand both to the developer.

## 1. What to ask for (decisions and accounts, before any code)

| Ask | From whom | Why |
|---|---|---|
| An account and API key with a model provider offering function calling, hosted web search and realtime voice | Your organisation's AI or procurement lead | The source app uses OpenAI for Hugo (chat, realtime relay, WebRTC voice) and Anthropic for its separate market search. Model ids change often: choose current ones, `TBC, re-verify` |
| Approval for model and voice traffic, and for web lookups, under your data-handling rules | Security or data owner | User questions and record extracts leave your boundary; voice audio too |
| A daily spend limit in your currency | The budget holder | Set as an environment variable; the assistant stops at it |
| Who may use the assistant (a role) | The product owner | Every assistant route checks it |
| Whether the assistant may change data | The product owner | The safe default: it only PROPOSES changes, the user confirms |
| Whether the platform passes WebSocket upgrades and allows the microphone | Your hosting or platform team | Voice needs both |

## 2. What to enable (platform and configuration)

● **HTTPS.** Browsers allow the microphone only in a secure context.
● **WebSocket upgrades** to the assistant's realtime path through any proxy or ingress.
● **Permissions-Policy:** `microphone=(self)`, and switch off what you do not use (`camera=()`, `geolocation=()`).
● **Content-Security-Policy:** keep `default-src 'self'`, `script-src 'self'`, `connect-src 'self'`, `frame-ancestors
  'none'`. The browser talks only to your server; your server talks to the provider.
● **Environment variables** (names from the source app; use your own scheme):

| Variable | Purpose | Source app default |
|---|---|---|
| `OPENAI_API_KEY` | Enables the assistant's model, voice and web lookup | none, assistant off |
| `OPENAI_HUGO_MODEL` | Chat model | set in code, `TBC, re-verify` for your provider |
| `OPENAI_REALTIME_MODEL` | Realtime voice model for the relay | set in code |
| `OPENAI_LIVE_MODEL`, `OPENAI_LIVE_BRAIN_MODEL` | WebRTC voice model and the model it delegates reasoning to | set in code |
| `HUGO_TALK_SESSION_MINUTES` | Longest voice session | 120 |
| `HUGO_TALK_MAX_OUTPUT_TOKENS` | Cap on a spoken reply | unlimited |
| `HUGO_GUIDE_DIR` | Folder of the user guide the help tool searches | unset, in-app help only |
| `DEEP_SEARCH_MAX_DAILY_USD` | ONE daily cap for every paid call, the assistant included | unset or 0, off |

● **Rate limits** are constants in code: give the assistant its own tier (the source app allows 30 turns a minute).

## 3. What to engineer, in build order

The figures in brackets are the source app's settings, a sound starting point. Build time depends on your data model
and is unscoped here: allow a scoping session first.

1. **Read-only tools over your data.** List, count, get one record, find similar, explain a match, provenance, app help,
   app state. Validate arguments with your app's own filter normaliser; cap rows (50); sanitise strings.
2. **The agent loop** with caps (12 steps, 24 tool calls, 75 seconds, 4,000 characters), a 45-second request deadline, a
   closing call without tools, and an NDJSON stream of tool progress.
3. **The ledger and the verifier.** Citations, links (case-insensitive), ids, entities and record figures all checked
   against what the tools returned; one retry; fail closed to the tools' records; never mark an empty answer verified.
4. **The deterministic floor**: answer from tools alone when the model is missing or fails, and say so.
5. **The spend ledger and the rate tier.** One UTC-day ledger, fail closed, checked before every paid call; named
   refusals; today's spend in Settings; each turn's cost on the answer.
6. **Proposal tools** for anything that changes data, confirmed in the interface.
7. **Web lookup** (optional): hosted search, at most 3 lookups a turn, injection stripping on every page.
8. **The interface**: the Orb (one module, phone and desktop), a scope sheet defaulting to everything, starter chips
   from real data, answer states in words, citation chips only from server-admitted citations.
9. **Voice**, last and in this order: browser speech recognition (free), a same-origin WebSocket relay with an event
   safelist, then server-built WebRTC sessions. Request the microphone INSIDE the press handler (iOS refuses it
   otherwise); the ring goes green only on an open microphone; Talk is never hidden silently.
10. **Audit**: scope, steps, hosts reached; never the user's words.

## 4. How to prove it before release

● The test list in the skill's "Tests and evals" section, each seen to fail before it passes.
● An eval suite: deterministic questions, refusals, injection phrasing, poisoned web pages, and a fabrication trap run
  against the real model and recorded.
● A browser pass on a real phone and a real desktop: hold to talk, ring, a refused microphone, a cap reached.

## 5. Mistakes the source app made, so yours does not

● Typed turns silently answered from tools alone, with no model, until a later release noticed: assert the model is in
  the loop.
● The figure check withdrew true answers about the app itself: scope it to record claims.
● A 12-step cap ended in an empty answer marked verified: add the closing call, never verify empty.
● The assistant shared a 3-a-minute scan tier, and the 4th message was reported as the day's cap: own tier, named limits.
● The ring lit on the press, not on the microphone: drive it from audio events.
● iOS refused a microphone requested from a timer: request it in the press.
● A fabricated `HTTPS://` link passed a case-sensitive check.
● An untrimmed key showed as configured and failed with 401.
● An empty bearer entry in the WebSocket subprotocol list broke voice.
● The assistant could search the web but sat off the paid tier.
