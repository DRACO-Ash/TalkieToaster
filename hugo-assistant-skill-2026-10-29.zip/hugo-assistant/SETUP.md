# Hugo: requirements, setup and configuration

How to stand up a Hugo of your own. Read `SKILL.md` first for the pattern and why each rule exists; this file is the
practical checklist. `reference/` holds the shipped app's Hugo source, tests and evals (Node, server archetype) as a
working example: copy the shape, replace the app-specific parts (section 6).

Figures in brackets are the source app's settings, a sound starting point. Model names change often: every model id
here is the source app's choice on 29 October 2026, `TBC, re-verify` against your provider before you use it.

## 1. Requirements

### Accounts and approvals (ask for these first)

| Need | Ask | Why |
|---|---|---|
| A model provider account and API key with function calling, hosted web search and realtime voice | Your AI or procurement lead | The source app uses OpenAI for all of Hugo: chat, the realtime voice relay and WebRTC voice. Its separate market search uses Anthropic, not Hugo |
| Data-handling approval | Your security or data owner | User questions, record extracts and voice audio leave your boundary for the provider |
| A daily spend limit, in dollars | The budget holder | Hugo refuses every paid call once it is reached (the source app runs at $100 a day) |
| A user role allowed to use Hugo | The product owner | Every Hugo route checks it (the source app's role is `agent`) |
| Whether Hugo may change data | The product owner | Safe default: it only PROPOSES changes and a person confirms each one |
| WebSocket upgrades and microphone permission through your hosting | Your platform team | Voice needs both |

### Platform

● A server-side application with authentication and a database you can query by tool (the source app: Node, a
  `createApp` factory, PostgreSQL).
● HTTPS: browsers allow the microphone only in a secure context.
● An ingress or proxy that passes WebSocket upgrades to Hugo's realtime path.
● Outbound HTTPS from the server to the model provider. The browser never calls the provider.

### Browsers

● Typed Hugo: any current browser.
● Voice: a browser with `getUserMedia`. WebRTC voice needs `RTCPeerConnection`; the free fallback needs
  `SpeechRecognition` or `webkitSpeechRecognition`. iOS and Safari give the microphone only from inside a user gesture
  (SKILL.md, Voice).

## 2. Configuration

### Environment variables

Copy `env.example`, fill the key in your platform's secret store (never in a file in the repository), and leave the rest
at their defaults until you have a reason to move them.

| Variable | Required | What it controls | Default in the source app |
|---|---|---|---|
| `OPENAI_API_KEY` | Yes | Turns Hugo on: chat, voice, realtime, web lookup. Read once and trimmed; only its length is logged | none, so Hugo is off |
| `OPENAI_HUGO_MODEL` | No | The chat model for typed answers | `gpt-6-astra`, TBC, re-verify |
| `OPENAI_REALTIME_MODEL` | No | The realtime voice model behind the WebSocket relay | `gpt-realtime-2`, TBC, re-verify |
| `OPENAI_LIVE_MODEL` | No | The WebRTC voice model | `gpt-live-1`, TBC, re-verify |
| `OPENAI_LIVE_BRAIN_MODEL` | No | The model WebRTC voice delegates reasoning and tools to | `gpt-6-astra`, TBC, re-verify |
| `HUGO_TALK_SESSION_MINUTES` | No | The longest voice session; an invalid value falls back with a warning | 120 |
| `HUGO_TALK_MAX_OUTPUT_TOKENS` | No | The cap on a spoken reply | `inf` |
| `HUGO_GUIDE_DIR` | No | The folder of the user guide Hugo's help tool searches | unset, in-app help only |
| `DEEP_SEARCH_MAX_DAILY_USD` | Strongly advised | ONE daily cap shared by every paid call, Hugo included; resets 00:00 UTC; unset or 0 means no cap | unset |
| `ALLOWED_ORIGIN` | If you use a cross-origin front end | The origin the realtime upgrade's cross-site check accepts | TBC, re-verify in `extracts/src_index.js.L830-960.txt` |

### Settings that live in code (change them there, with a test)

| Setting | Source app value | Where in `reference/` |
|---|---|---|
| Hugo's own rate tier | 30 turns a minute per key | `extracts/src_app.js.L90-125.txt` |
| Loop caps | 12 steps, 24 tool calls, 75 s, 4,000 answer characters | `src/hugo/agent.js` |
| Request deadline | 45 s per model request | `src/hugo/openai-chat.js` |
| History caps | 24 turns, 4,000 characters each, user and assistant only | `extracts/src_api-v3.js.L1480-1830.txt` |
| Rows per tool call | 50 | `src/hugo/tools.js` |
| Web lookups | 3 a turn, 5 results each, 4,000 characters of page text | `src/hugo/web-lookup.js` |
| Voice bounds | 12,000 characters of tool output, 1 MB frame, 80 KB body, 40 sessions, one per user and tab, 15 s create timeout | `src/hugo/openai-realtime.js`, `src/hugo/live-route.js`, `src/hugo/live-session.js` |
| Hold to talk | 450 ms | `public/views/hugo-phone.js` |
| Price rows per model | per million tokens or per minute | the source app's `src/scan/cost.js` (not shipped here: replace with your provider's prices) |

### Response headers

```
Permissions-Policy: microphone=(self), camera=(), geolocation=()
Content-Security-Policy: default-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; ...
```

The browser talks only to your server, so `connect-src 'self'` holds. The source app notes that no shipping browser
applies `connect-src` to WebRTC media (`extracts/src_static.js.L100-125.txt`); that is `TBC, re-verify` for your browsers.

## 3. Setup, step by step

1. **Read-only tools over your data**: list, count, get one record, find similar, explain a match, provenance, app help,
   app state. Reference: `src/hugo/tools.js`, `src/hugo/registry.js`.
2. **The agent route**, `POST /api/<app>/hugo/agent`: role check, rate tier, daily cap, sanitised history, NDJSON
   stream. Reference: `extracts/src_api-v3.js.L1480-1830.txt`.
3. **The loop, the ledger and the verifier.** Reference: `src/hugo/agent.js`, `src/hugo/stream-check.js`.
4. **The deterministic floor** for no model or a failed provider. Reference: `src/hugo/deterministic.js`.
5. **The persona**: your app's name, rules and vocabulary. Reference: `src/hugo/persona.js`.
6. **The spend ledger and the cap**, checked before every paid call. Reference: `extracts/src_index.js.L540-660.txt`,
   `extracts/src_boot.js.L155-180.txt`.
7. **Proposal tools** (update, scan, view) confirmed in the interface. Reference: `src/hugo/view-intent.js`,
   `public/views/hugo-update.js`.
8. **Web lookup** (optional) with injection stripping. Reference: `src/hugo/web-lookup.js`, `src/domain/injection.js`.
9. **The interface**: the Orb, the scope sheet (default: everything), starter chips from real data, answer states in
   words, citation chips only from server-admitted citations. Reference: `public/views/hugo-phone.js`,
   `public/views/hugo-rail.js`, `public/views/hugo-starters.js`, `public/views/agent-answer.js`,
   `extracts/public_styles.css.L9600-9625.txt`.
10. **Voice, last**: browser speech recognition, then the same-origin WebSocket relay with its event safelist, then
    server-built WebRTC sessions; the microphone requested in the press handler; the probe route. Reference:
    `src/hugo/openai-realtime.js`, `src/hugo/realtime-upgrade-gate.js`, `src/hugo/live-route.js`,
    `src/hugo/live-session.js`, `public/views/hugo-live.js`, `public/views/hugo-talk-state.js`,
    `extracts/public_app-v3.js.L10360-11200.txt`.
11. **Audit**: scope, steps, hosts reached on the web; never the user's words.

## 4. Verify before you release

● **Tests**: `reference/test/` holds the source app's (Node's built-in `node:test`). The list in SKILL.md says what each
  must prove; see each test fail before it passes.
● **Evals**: `reference/eval/hugo/` (deterministic tasks, a model suite with a fabrication trap, and a SYNTHETIC fixture
  dataset: every company in it is a named fixture, none is real) and `reference/eval/injection/pages/` (poisoned pages).
  Record the model suite with a live key before release, or it reads NOT RUN.
● **Browser passes**: `reference/e2e/` (Playwright). Then a real phone and a real desktop by hand: hold to talk, the
  ring, a refused microphone, the cap reached.
● **Smoke check after deploy**: `GET /api/<app>/hugo/voice` reports configured, realtime, live, listener, fault and
  canFix; ask one question with a known answer and check its citation opens the right record.

## 5. Troubleshooting (each one happened in the source app)

| Symptom | Cause | Fix |
|---|---|---|
| Hugo shows as configured but every call fails 401 | The key had a trailing space or newline | Trim the key once at read |
| "Daily limit reached" after 4 quick messages | Hugo shared a 3-a-minute tier | Give Hugo its own tier and name each limit in the refusal |
| The microphone "is disabled" on an iPhone though settings allow it | The microphone was requested outside the press | Request it inside the press handler |
| The ring is green but nothing is heard | The ring followed the press, not the microphone | Drive the ring from audio events |
| Talk does not start at all | An empty bearer entry in the WebSocket subprotocol list | Never send an empty subprotocol |
| Answers about the app itself ("7 domains") are withdrawn | The figure check covered every number | Check record claims only |
| An empty answer shows as verified | A step cap ended the turn on tools | A closing call with no tools; never verify empty |
| A fabricated link got through | A case-sensitive URL pattern missed `HTTPS://` | Match case-insensitively |
| Typed answers come from tools alone | The model was silently cut out of the path | A test that the model is in the loop |

## 6. What you must replace

The source app is a vendor-tracking app with 7 domains. Replace:
● the domain model and the record schema (`RECORD_FIELDS` in `src/hugo/tools.js`);
● the persona's rules and the app name (`src/hugo/persona.js`);
● the deterministic resolver's vocabulary (`src/hugo/deterministic.js`, `src/hugo/families.js`, `src/hugo/query-plan.js`);
● the record-id pattern and the "record words" the verifier keys on (`src/hugo/agent.js`);
● the help corpus (`src/hugo/knowledge.js`);
● app-specific tools: `country-settle.js` and `cross-domain-rank.js` are this app's features, not part of the pattern;
● the authentication roles, the price rows and the database access.

`reference/extracts/` are line ranges cut from the source app's large shared files, so they start and end mid-file:
read them for the wiring, not as runnable code. `reference/SOURCE-COMMIT.txt` names the commit they came from.
