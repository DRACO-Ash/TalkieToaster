// VH-765, THE PHONE'S HUGO (the owner's approved "Orb"): at 640 pixels and narrower the app opens on Hugo alone. Driven
// at 390 wide: the domain sheet is modal and every close path frees the screen; a scope chosen is the scope asked; each
// answer keeps the scope it was asked under (2.12.0 engineering round three); a tap types, a hold listens through a
// stand-in speech service and asks what it heard; a refused answer is said. A PHONE SHOWS HUGO ONLY (VH-811): there is
// no Full app control, a record opens over the phone screen, Escape and a reload keep it, and a wider screen or a mouse
// gives the full app back. A phone is a narrow screen with a touch pointer, so this pass turns the browser's touch
// emulation on for itself. The page is put back at its own width and pointer afterwards. Exported so a probe can drive it.

import { makeChecker } from './v27-sweep.mjs';

const AGENT = '**/api/v3/hugo/agent';

/** A phone's touch pointer, on or off, through Chromium's own emulation; `(pointer: coarse)` follows it on a live page. One
 * session per page, kept open: the emulation lasts only as long as the session that set it. */
const touchSessions = new WeakMap();
export async function phoneTouch(page, on) {
  if (!touchSessions.has(page)) touchSessions.set(page, await page.context().newCDPSession(page));
  await touchSessions.get(page).send('Emulation.setTouchEmulationEnabled', { enabled: on, maxTouchPoints: on ? 5 : 1 });
}
// What the phone screen and the full app read: the Orb, the shell's class, any Full app control, and the full app drawn.
const phoneState = (page) => page.evaluate(() => ({
  orb: Boolean(document.querySelector('#hugo-rail.orb-ui .orb-screen')),
  phoneOnly: document.getElementById('app')?.classList.contains('phone-only') === true,
  fullApp: [...document.querySelectorAll('button, a')].some((b) => b.offsetParent !== null && /full app/i.test((b.getAttribute('aria-label') || '') + b.textContent)),
  shown: ['header', 'hugo-collapse'].map((id) => document.getElementById(id)).map((n) => Boolean(n?.offsetParent) && getComputedStyle(n).display !== 'none'),
  main: getComputedStyle(document.querySelector('.shell-main')).display,
}));

// A stand-in for the browser's speech service, present only while this pass sets its flag, so no later step meets it.
function standInSpeech() {
  try { if (sessionStorage.getItem('vh_sweep_speech') !== '1') return; } catch { return; }
  globalThis.SpeechRecognition = class {
    start() { setTimeout(() => { this.onresult?.({ results: [[{ transcript: 'vendors in Norway' }]] }); this.onend?.(); }, 50); }
    stop() { this.onend?.(); }
  };
}

const read = (page) => page.evaluate(() => ({
  sheet: Boolean(document.querySelector('.orb-sheet-host')),
  inert: [document.querySelector('.orb-read')?.inert, document.querySelector('.orb-reach')?.inert],
  focus: document.activeElement?.dataset.phoneAct || document.activeElement?.dataset.phoneScope || document.activeElement?.tagName,
  pressed: document.activeElement?.getAttribute('aria-pressed'),
}));
const tags = (page) => page.$$eval('#hugo-review .orb-scope-tag', (n) => n.map((t) => t.textContent.trim()));
const lastTurn = (page) => page.evaluate(() => [...document.querySelectorAll('#hugo-review .hugo-turn')].at(-1)?.textContent.replaceAll(/\s+/g, ' ').trim() || '');

// VH-811, A PHONE SHOWS HUGO ONLY: a record opens over the phone screen; Escape and a reload keep it; a wider screen or a
// mouse gives the full app back, and a phone's width with touch mounts Hugo again. Run on a phone screen with an answer up.
async function phoneOnlyChecks(page, check) {
  // A record from an answer opens over the phone screen, and closing it is back on Hugo (VH-811).
  const record = await page.$('[data-phone-record]');
  check(Boolean(record), 'an answer offers a record to open');
  if (record) {
    // Sent to the control itself: in the sweep the answer's cards may still be moving when it is pressed.
    await record.evaluate((n) => n.click());
    const opens = await page.waitForSelector('#drawer:not([hidden])', { timeout: 10000 }).then(() => true, () => false);
    const over = await phoneState(page);
    check(opens && over.orb && over.phoneOnly && over.main === 'none', 'a record opens over the phone screen, which stays', { opens, ...over });
    await page.keyboard.press('Escape');
    await page.waitForSelector('#drawer', { state: 'hidden', timeout: 5000 }).catch(() => {});
    const back = await phoneState(page);
    check(back.orb && back.phoneOnly, 'closing the record is back on Hugo', back);
  }

  // Escape on the phone screen and a reload both keep it (VH-811).
  await page.keyboard.press('Escape');
  const kept = await phoneState(page);
  check(kept.orb && kept.phoneOnly, 'Escape does not leave the phone screen', kept);
  await page.reload();
  const reloaded = await page.waitForSelector('#hugo-rail.orb-ui [data-phone-act="orb"]', { timeout: 10000 }).then(() => true, () => false);
  const afterReload = await phoneState(page);
  check(reloaded && afterReload.phoneOnly && afterReload.main === 'none', 'a reload never lands in the full app', afterReload);

  // A wider screen gives the full app back, and a phone's width mounts Hugo again, with no reload (VH-811).
  await page.setViewportSize({ width: 1280, height: 900 });
  const wide = await page.waitForFunction(() => !document.querySelector('#hugo-rail.orb-ui .orb-screen'), null, { timeout: 5000 }).then(() => true, () => false);
  const wider = await phoneState(page);
  check(wide && !wider.phoneOnly && wider.main !== 'none', 'widening past a phone takes the phone screen down', wider);
  await page.setViewportSize({ width: 390, height: 844 });
  const narrow = await page.waitForSelector('#hugo-rail.orb-ui .orb-screen', { timeout: 10000 }).then(() => true, () => false);
  check(narrow && (await phoneState(page)).phoneOnly, 'narrowing to a phone mounts Hugo again');
  // The same width with a mouse is a desktop window, which keeps the full app, so a magnifier loses nothing (1.4.10).
  await phoneTouch(page, false);
  const mouse = await page.waitForFunction(() => !document.querySelector('#hugo-rail.orb-ui .orb-screen'), null, { timeout: 5000 }).then(() => true, () => false);
  check(mouse && !(await phoneState(page)).phoneOnly, 'the same width with a mouse keeps the full app');
  await phoneTouch(page, true);
}

export async function phoneHugoPass(page) {
  const { check, failures } = makeChecker('VH-765 phone Hugo');
  const asked = [];
  const onRequest = (r) => { if (r.method() === 'POST' && /\/api\/v3\/hugo\/agent/.test(r.url())) asked.push(r.postDataJSON?.()?.domain); };
  const askedMore = async (n) => {
    for (let i = 0; i < 60 && asked.length < n; i++) { await page.waitForTimeout(100); }
    return asked.length >= n;
  };
  const answered = async (n) => {
    for (let i = 0; i < 60 && (await tags(page)).length < n; i++) { await page.waitForTimeout(100); }
    return tags(page);
  };
  const was = page.viewportSize();
  page.on('request', onRequest);
  try {
    await page.addInitScript(standInSpeech);
    await page.evaluate(() => { sessionStorage.setItem('vh_sweep_speech', '1'); });
    await phoneTouch(page, true);
    await page.setViewportSize({ width: 390, height: 844 });
    await page.reload();
    // VH-811: a phone always opens on Hugo, with no way into the full app and nothing of it drawn underneath. Said, not
    // thrown, so a phone that opens on the full app is named; the rest of the pass needs the phone screen, so it stops.
    const mounted = await page.waitForSelector('#hugo-rail.orb-ui [data-phone-act="orb"]', { timeout: 10000 }).then(() => true, () => false);
    const first = await phoneState(page);
    if (!mounted) { check(false, 'a phone opened on the full app, not on Hugo', first); return failures; }
    check(first.orb && first.phoneOnly && !first.fullApp && first.shown.every((x) => !x) && first.main === 'none',
      'a phone opens on Hugo alone: no Full app control, no rail, no view', first);

    // The sheet is modal: it opens on the chosen scope with what lies behind it inert, and Escape, Close and the scrim
    // each close it, free the screen and hand focus back to the scope control.
    await page.click('[data-phone-act="scope"]');
    const open = await read(page);
    check(open.sheet && open.pressed === 'true' && open.inert.every((x) => x === true), 'the sheet opens on the chosen scope, the screen behind it inert', open);
    await page.keyboard.press('Escape');
    const esc = await read(page);
    check(!esc.sheet && esc.focus === 'scope' && esc.inert.every((x) => x === false), 'Escape closes it, frees the screen and returns focus', esc);
    // The scrim lies under the sheet where the sheet is drawn, so a tap on it is sent to the scrim itself.
    for (const [how, sel] of [['Close', '.orb-close'], ['the scrim', '.orb-scrim']]) {
      await page.click('[data-phone-act="scope"]');
      await page.$eval(sel, (n) => n.click());
      const s = await read(page);
      check(!s.sheet && s.inert.every((x) => x === false), how + ' closes it and frees the screen', s);
    }

    // A scope chosen is the scope asked, from a starter.
    await page.click('[data-phone-act="scope"]');
    await page.click('[data-phone-scope="space"]');
    const cap = await page.textContent('[data-phone-cap]');
    check(/Space/.test(cap), 'choosing Space says so', cap);
    await page.click('[data-phone-ask]');
    check(await askedMore(1) && asked.at(-1) === 'space', 'a starter under Space asks Space', asked);
    await answered(1);

    // Tap to type, under all 7 domains; the first answer keeps its Space tag.
    await page.click('[data-phone-act="scope"]');
    await page.click('[data-phone-scope="all"]');
    await page.click('[data-phone-act="orb"]');
    await page.fill('#hugo-input', 'vendors not in the GDM');
    await page.keyboard.press('Enter');
    check(await askedMore(2) && asked.at(-1) === 'all', 'a typed question under all domains asks all', asked);
    const two = await answered(2);
    check(two.length >= 2 && /Space/.test(two[0]) && !/Space/.test(two.at(-1)), 'each answer keeps the scope it was asked under', two);

    // Hold to talk: what the stand-in hears is asked.
    await page.hover('[data-phone-act="orb"]');
    await page.mouse.down();
    const heard = await askedMore(3);
    await page.mouse.up();
    check(heard, 'a hold listens and asks what it heard', asked);
    await answered(3);
    // The press that listened ends in a click too, and that click must not open the box (VH-776).
    const shut = await page.evaluate(() => !document.querySelector('.orb-screen')?.classList.contains('is-typing'));
    check(shut, 'a hold that listened leaves the box shut', { typing: !shut });

    // A hold slid off the orb ends with no click on the orb, and the tap after it still opens the box (2.13.0 engineering
    // round one).
    await page.hover('[data-phone-act="orb"]');
    await page.mouse.down();
    await askedMore(4);
    await page.mouse.move(5, 5);
    await page.mouse.up();
    await answered(4);

    // A refused answer is said in the conversation.
    await page.route(AGENT, (r) => r.fulfill({ status: 500, contentType: 'application/json', body: '{"error":"x"}' }), { times: 1 });
    await page.click('[data-phone-act="orb"]');
    const opened = await page.evaluate(() => document.querySelector('.orb-screen')?.classList.contains('is-typing') === true);
    check(opened, 'a tap after a hold slid off the orb opens the box', { opened });
    await page.fill('#hugo-input', 'vendors in Canada');
    await page.keyboard.press('Enter');
    await askedMore(5);
    let refused = '';
    for (let i = 0; i < 40 && !/failed on the server/.test(refused); i++) { refused = await lastTurn(page); await page.waitForTimeout(100); }
    check(/Hugo failed on the server\. The cause is in Settings, under Debug and faults\./.test(refused), 'a refused answer is said', refused);

    // The other ways an answer fails, each said in the conversation: the AI service refusing (with its reason), an empty
    // answer (its scope and no cards), and the network gone.
    const failed = async (fulfil, question, re) => {
      const before = asked.length;
      await page.route(AGENT, fulfil, { times: 1 });
      await page.click('[data-phone-act="orb"]');
      await page.fill('#hugo-input', question);
      await page.keyboard.press('Enter');
      await askedMore(before + 1);
      let said = '';
      for (let i = 0; i < 40 && !re.test(said); i++) { said = await lastTurn(page); await page.waitForTimeout(100); }
      return said;
    };
    const declined = await failed((r) => r.fulfill({ status: 502, contentType: 'application/json', body: '{"error":"the AI service said no"}' }),
      'vendors in Peru', /AI service refused/);
    check(/Hugo's AI service refused the request\. the AI service said no/.test(declined), 'an AI service refusal is said, with its reason', declined);
    const empty = await failed((r) => r.fulfill({ status: 200, contentType: 'application/json',
      body: JSON.stringify({ answer: '', citations: [], steps: [], verification: { ok: true }, scope: 'all' }) }), 'vendors in Chile', /All 7 domains/);
    const emptyCards = await page.$$eval('#hugo-review .hugo-turn', (n) => n.at(-1)?.nextElementSibling?.classList.contains('orb-card') === true);
    check(/All 7 domains/.test(empty) && !emptyCards, 'an empty answer says its scope and draws no cards', { empty, emptyCards });
    const offline = await failed((r) => r.abort(), 'vendors in Mali', /offline/);
    check(/You appear to be offline\. Reconnect and try again\./.test(offline), 'a network error says to reconnect', offline);

    await phoneOnlyChecks(page, check);

    // The phone screen's module refused: the phone stays the full app rather than a blank screen.
    const screen = (url) => url.pathname === '/views/hugo-phone.js';
    await page.route(screen, (r) => r.abort());
    try {
      await page.reload();
      await page.waitForSelector('#app:not([hidden])', { timeout: 20000 });
      await page.waitForTimeout(800);
      const stayed = await page.evaluate(() => !document.querySelector('#hugo-rail.orb-ui') && !document.getElementById('app').classList.contains('phone-only'));
      check(stayed, 'with the phone screen refused, the phone stays the full app rather than a blank screen');
    } finally { await page.unroute(screen); }
  } finally {
    page.off('request', onRequest);
    await page.unroute(AGENT).catch(() => {});
    await page.evaluate(() => { sessionStorage.removeItem('vh_sweep_speech'); }).catch(() => {});
    await phoneTouch(page, false).catch(() => {});
    await page.setViewportSize(was || { width: 1440, height: 900 });
    await page.reload();
    await page.waitForSelector('#app:not([hidden])');
  }
  return failures;
}
