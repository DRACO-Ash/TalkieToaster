// `node e2e/probe.mjs e2e/probes/hugo-live.mjs`: Hugo's voice on GPT-Live in a real browser (VH-777 Lane V), in seconds.
import { hugoLivePass } from '../hugo-live-pass.mjs';

export default async function hugoLiveProbe({ page, fail }) {
  await hugoLivePass({ page, fail });
}
