// Run the SHIPPED Hugo connection-check and hand-over assertions in seconds: `node e2e/probe.mjs e2e/probes/hugo-check.mjs`
// (VH-777). Same module the browser coverage sweep runs.

import { hugoCheckPass } from '../hugo-check-pass.mjs';

export default async function hugoCheckProbe({ page, fail }) {
  await hugoCheckPass({ page, fail });
  console.log('hugo check pass complete');
}
