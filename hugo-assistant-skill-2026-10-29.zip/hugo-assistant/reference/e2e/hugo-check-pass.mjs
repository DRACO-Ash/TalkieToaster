// VH-777, EVERY LINK HUGO USES, DRIVEN FOR REAL. "Check Hugo's connection" against a routed diagnosis and a routed live
// socket: the check socket's one frame reads as this browser reaching Hugo's live link, and a refused socket is named.
// Then a typed turn whose live socket will not open is answered on the typed route, not left as an error line. The
// seeded app has no OpenAI key, so the diagnosis and the voice probe are routed, as the Talk pass routes them, and the
// typed route answers from the real server's floor. Run by `e2e/collect-coverage.mjs`, and in seconds by
// `node e2e/probe.mjs e2e/probes/hugo-check.mjs`. Exported so a probe can drive it.

import { chooseDomainIfNone, hugoBox } from './harness.mjs';
import { openSettingsSections } from './folds.mjs';

const RELAY = /\/api\/v3\/hugo\/realtime/;
const DIAGNOSE = '**/api/v3/hugo/diagnose';
const VOICE = '**/api/v3/hugo/voice';
const AGENT = /\/api\/v3\/hugo\/agent/;
const LINKS = { ok: true, configured: true, kind: '', model: 'gpt-6-astra', latencyMs: 12,
  links: { tools: { ok: true, latencyMs: 5 }, realtime: { ok: true, model: 'gpt-realtime-2', latencyMs: 7 } } };

export async function hugoCheckPass({ page, fail }) {
  const check = (ok, what) => { if (!ok) fail('hugo check: ' + what); };
  const relay = { live: true, check: 'answer', checks: 0, turns: 0 };
  const asked = [];
  const onRequest = (r) => { if (r.method() === 'POST' && AGENT.test(r.url())) asked.push(r.postDataJSON?.()?.domain); };
  // A WebSocket route cannot be removed, so once the pass is over it hands every socket to the real server.
  await page.routeWebSocket(RELAY, (ws) => {
    if (!relay.live) { ws.connectToServer(); return; }
    if (/mode=check/.test(ws.url())) {
      relay.checks += 1;
      if (relay.check === 'answer') ws.send(JSON.stringify({ type: 'vh.check', ok: true }));
      else ws.close({ code: 1011 });
      return;
    }
    relay.turns += 1;
    ws.close({ code: 1011 }); // a typed turn's live socket that will not open
  });
  await page.route(VOICE, (r) => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ configured: true, realtime: true }) }));
  await page.route(DIAGNOSE, (r) => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(LINKS) }));
  page.on('request', onRequest);
  try {
    await page.reload();
    await page.waitForSelector('#app:not([hidden])');
    await chooseDomainIfNone(page);

    // The check: every link named, this browser's live link reached, then refused. In Settings, Hugo's voice, since the
    // desktop's Hugo became the Orb (VH-777; owner, 26 October 2026).
    await page.click('.nav-btn[data-view="settings"]');
    await openSettingsSections(page);
    await page.waitForSelector('#settings-hugo-slot #hugo-preflight-run', { timeout: 10000 });
    const ran = async () => {
      await page.click('#hugo-preflight-run');
      await page.waitForFunction(() => !document.getElementById('hugo-preflight-run')?.disabled && document.getElementById('hugo-preflight-out')?.textContent !== 'Checking…', null, { timeout: 15000 });
      return page.evaluate(() => { const o = document.getElementById('hugo-preflight-out'); return { text: o.textContent, good: o.classList.contains('is-good') }; });
    };
    const reached = await ran();
    check(/His tools answered in 5ms\. His speech service \(gpt-realtime-2\) answered in 7ms, and this browser reached his live link\./.test(reached.text) && reached.good, 'a good check read ' + JSON.stringify(reached));
    relay.check = 'refuse';
    const refused = await ran();
    check(/could not open his live link \(it was refused\)/.test(refused.text) && !refused.good, 'a refused live link read ' + JSON.stringify(refused));
    check(relay.checks === 2, 'the check opened ' + relay.checks + ' live links, not 2');

    await page.click('.nav-btn[data-view="master"]');
    // A typed turn whose live socket will not open goes to the typed route and is answered there. On one domain, chosen on
    // the Orb's own scope sheet: across all domains a typed turn takes the typed route first (VH-777).
    if (!(await page.$('#hugo-rail.is-expanded'))) await page.click('#hugo-btn');
    await page.click('#hugo-rail.orb-ui [data-phone-act="scope"]');
    await page.click('.orb-sheet-host [data-phone-scope="space"]');
    const before = asked.length;
    await hugoBox(page);
    await page.fill('#hugo-input', 'hey hugo');
    await page.click('#hugo-send');
    await page.waitForFunction(() => /Hello, I am Hugo\./.test([...document.querySelectorAll('#hugo-review .hugo-turn-hugo')].at(-1)?.textContent || ''), null, { timeout: 15000 })
      .catch(() => {});
    const last = await page.evaluate(() => [...document.querySelectorAll('#hugo-review .hugo-turn-hugo')].at(-1)?.textContent.replaceAll(/\s+/g, ' ').trim() || '');
    check(relay.turns >= 1, 'the typed turn never tried the live socket');
    check(asked.length === before + 1, 'the typed route was asked ' + (asked.length - before) + ' times, not once');
    check(/Hello, I am Hugo\. My AI service is not answering just now/.test(last), 'the handed-over turn read ' + JSON.stringify(last.slice(0, 200)));
  } finally {
    relay.live = false;
    page.off('request', onRequest);
    await page.unroute(VOICE).catch(() => {});
    await page.unroute(DIAGNOSE).catch(() => {});
    await page.reload();
    await page.waitForSelector('#app:not([hidden])');
  }
}
