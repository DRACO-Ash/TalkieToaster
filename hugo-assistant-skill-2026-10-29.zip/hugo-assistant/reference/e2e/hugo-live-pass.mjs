// VH-777 LANE V, HUGO'S VOICE ON GPT-LIVE, DRIVEN IN A REAL BROWSER. Chromium's own RTCPeerConnection makes the offer;
// the routed `/api/v3/hugo/live` hands it to a SECOND peer in the same page, standing in for OpenAI, whose answer comes
// back as the route's reply. So the offer, the answer, ICE and the `oai-events` data channel are all real; only the far
// end is ours. The stand-in then speaks on the channel as Live does (input and output transcript deltas), and the rail
// shows both sides. Then the check, green and then amber naming the link; a refused Live falling back to the relay; a
// refused microphone; and the phone Orb's hold to talk. The seeded app has no OpenAI key, so the voice probe and the
// diagnosis are routed. Run by `e2e/collect-coverage.mjs`, and in seconds by `node e2e/probe.mjs e2e/probes/hugo-live.mjs`.

import { chooseDomainIfNone } from './harness.mjs';
import { openSettingsSections } from './folds.mjs';
import { phoneTouch } from './phone-hugo-pass.mjs';

const VOICE = '**/api/v3/hugo/voice';
const DIAGNOSE = '**/api/v3/hugo/diagnose';
const LIVE = '**/api/v3/hugo/live';
const LIVE_CHECK = '**/api/v3/hugo/live/check';
const LIVE_END = '**/api/v3/hugo/live/end';
const RELAY = /\/api\/v3\/hugo\/realtime/;
const LINKS = { ok: true, configured: true, kind: '', model: 'gpt-6-astra', latencyMs: 12, links: {
  tools: { ok: true, latencyMs: 5 }, realtime: { ok: true, model: 'gpt-realtime-2', latencyMs: 7 },
  models: { ok: true, reached: ['gpt-live-1', 'gpt-6-astra', 'gpt-realtime-2.1'], missing: [] },
  live: { ok: true, model: 'gpt-live-1', brain: 'gpt-6-astra' } } };
const json = (r, status, body) => r.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });

// In the page: a microphone with no device behind it, and the far peer that answers an offer. Present only while this
// pass sets its flag, because an init script cannot be removed and no later step may meet it.
function installStandIns() {
  try { if (sessionStorage.getItem('vh_sweep_live') !== '1') return; } catch { return; }
  navigator.mediaDevices.getUserMedia = async () => {
    if (globalThis.__vhMicRefused) throw Object.assign(new Error('refused'), { name: 'NotAllowedError' });
    return new AudioContext().createMediaStreamDestination().stream;
  };
  globalThis.__vhAnswer = async (offer) => {
    const far = new globalThis.RTCPeerConnection();
    globalThis.__vhFar = far;
    far.ondatachannel = (e) => { globalThis.__vhChannel = e.channel; };
    await far.setRemoteDescription({ type: 'offer', sdp: offer });
    await far.setLocalDescription(await far.createAnswer());
    if (far.iceGatheringState !== 'complete') {
      await new Promise((resolve) => { far.addEventListener('icegatheringstatechange', () => { if (far.iceGatheringState === 'complete') resolve(); }); setTimeout(resolve, 3000); });
    }
    return far.localDescription.sdp;
  };
  // Every <audio> the page makes, so a step can read whether Hugo's player was muted.
  const make = document.createElement.bind(document);
  globalThis.__vhAudios = [];
  document.createElement = (tag, ...rest) => {
    const made = make(tag, ...rest);
    if (String(tag).toLowerCase() === 'audio') globalThis.__vhAudios.push(made);
    return made;
  };
  globalThis.__vhSay = (events) => { for (const e of events) globalThis.__vhChannel?.send(JSON.stringify(e)); };
}

export async function hugoLivePass({ page, fail }) {
  const check = (ok, what) => { if (!ok) fail('hugo live: ' + what); };
  const state = { open: 'answer', opens: [], answered: 0, ends: 0, checks: 0, relay: 0, live: true };
  const until = async (ok, ms = 10000) => {
    for (let i = 0; i < ms / 100 && !ok(); i++) { await page.waitForTimeout(100); }
    return ok();
  };
  // The relay: its check socket answers (the fallback transport is reachable), and a Talk socket is counted and refused.
  await page.routeWebSocket(RELAY, (ws) => {
    if (!state.live) { ws.connectToServer(); return; }
    if (/mode=check/.test(ws.url())) { ws.send(JSON.stringify({ type: 'vh.check', ok: true })); return; }
    state.relay += 1;
    ws.close({ code: 1011 });
  });
  await page.route(VOICE, (r) => json(r, 200, { configured: true, realtime: true, live: true }));
  await page.route(DIAGNOSE, (r) => json(r, 200, LINKS));
  await page.route(LIVE, async (r) => {
    const body = r.request().postDataJSON();
    state.opens.push({ domain: body.domain, check: body.check, voice: body.voice });
    if (state.open === 'refuse') { await json(r, 502, { error: 'live handshake failed', link: 'handshake', kind: 'model', code: 'model_not_found' }); return; }
    if (state.open === 'sideband') { await json(r, 502, { error: 'live sideband failed', link: 'sideband', kind: 'refused' }); return; }
    let sdp = '';
    try {
      sdp = await page.evaluate((offer) => globalThis.__vhAnswer(offer), body.sdp);
    } catch (err) {
      // A page that navigated while answering: said by name rather than thrown out of the route handler.
      fail('hugo live: the stand-in could not answer (' + String(err?.message || err).slice(0, 120) + ') at ' + page.url());
      await json(r, 502, { error: 'stand-in failed', link: 'handshake', kind: 'other' }).catch(() => {});
      return;
    }
    await json(r, 201, { sessionId: 'live_e2e_' + state.opens.length, sdp, model: 'gpt-live-1', brain: 'gpt-6-astra' });
    state.answered += 1;
  });
  await page.route(LIVE_CHECK, (r) => { state.checks += 1; return json(r, 200, { delegation: { ok: true, tool: 'count_records', latencyMs: 640 } }); });
  await page.route(LIVE_END, (r) => { state.ends += 1; return json(r, 200, { ended: true }); });
  const toast = () => page.evaluate(() => [...document.querySelectorAll('.toast-item, .toast')].map((t) => t.textContent).join(' | '));
  const was = page.viewportSize();
  // The desktop's Hugo is the Orb (owner, 26 October 2026): Talk is a hold on the orb and a tap ends it.
  const orb = '#hugo-rail.orb-ui [data-phone-act="orb"]';
  const holdOrb = async () => {
    await page.hover(orb);
    await page.mouse.down();
    await page.waitForTimeout(700);
    await page.mouse.up();
  };
  const talking = () => page.evaluate((sel) => document.querySelector(sel)?.classList.contains('is-listening') === true, orb);
  try {
    await page.addInitScript(installStandIns);
    await page.evaluate(() => sessionStorage.setItem('vh_sweep_live', '1'));
    await page.reload();
    await page.waitForSelector('#app:not([hidden])');
    await chooseDomainIfNone(page);
    if (!(await page.$('#hugo-rail.is-expanded'))) await page.click('#hugo-btn');
    await page.waitForSelector(orb, { timeout: 10000 });

    // TALK ON LIVE: a hold on the orb opens a real WebRTC link, Hugo's captions reach the reading pane, a tap ends it.
    let answered = state.answered;
    await holdOrb();
    await until(() => state.answered > answered, 15000);
    await page.waitForTimeout(400);
    const opened = state.opens.at(-1);
    // The desktop's Orb asks the domain on screen (VH-777), Space here; the phone asks all, below.
    check(opened?.check === false && opened?.domain === 'space', 'Talk offered ' + JSON.stringify(opened));
    check(await talking(), 'the orb does not show Talk running');
    await page.evaluate(() => globalThis.__vhSay([
      { type: 'session.input_transcript.delta', delta: 'How many vendors ' },
      { type: 'session.input_transcript.delta', delta: 'are there?' },
      { type: 'session.output_transcript.delta', delta: 'There are ' },
      { type: 'session.output_transcript.delta', delta: 'forty-two.' },
    ]));
    await page.waitForFunction(() => /There are forty-two\./.test(document.getElementById('hugo-review')?.textContent || ''), null, { timeout: 5000 }).catch(() => {});
    const rail = await page.evaluate(() => document.getElementById('hugo-review')?.textContent.replaceAll(/\s+/g, ' ') || '');
    check(/How many vendors are there\?/.test(rail), 'the operator\'s words never reached the rail: ' + rail.slice(-200));
    check(/There are forty-two\./.test(rail), 'Hugo\'s words never reached the rail: ' + rail.slice(-200));
    const endsBefore = state.ends;
    await page.click(orb);
    await until(() => state.ends > endsBefore, 5000);
    check(state.ends === endsBefore + 1 && !(await talking()), 'a tap ended ' + (state.ends - endsBefore) + ' server sessions, not 1');

    // THE SERVER ENDS IT: session.closed on the channel ends Talk with a notice.
    answered = state.answered;
    await holdOrb();
    await until(() => state.answered > answered, 15000);
    await page.waitForTimeout(400);
    await page.evaluate(() => globalThis.__vhSay([{ type: 'session.closed', reason: 'daily_cap_reached' }]));
    await page.waitForTimeout(600);
    check(!(await talking()), 'a closed session left Talk running');

    // A REFUSED LIVE FALLS BACK TO THE RELAY, and says so.
    state.open = 'refuse';
    const relayBefore = state.relay;
    await holdOrb();
    await page.waitForTimeout(1500);
    check(/using the app's own link/.test(await toast()), 'a refused Live said ' + JSON.stringify(await toast()));
    check(state.relay > relayBefore, 'a refused Live never tried the relay');
    if (await talking()) await page.click(orb);

    // A REFUSED MICROPHONE is said, and nothing falls back (the relay would need the same microphone).
    state.open = 'answer';
    await page.evaluate(() => { globalThis.__vhMicRefused = true; });
    const relayMic = state.relay;
    await holdOrb();
    await page.waitForTimeout(800);
    // VH-906: named by its cause, which a headless browser reports as allowed or unknown, never as denied.
    check(/Hugo could not use the microphone/.test(await toast()), 'a refused microphone said ' + JSON.stringify(await toast()));
    check(state.relay === relayMic, 'a refused microphone fell back to the relay');
    await page.evaluate(() => { globalThis.__vhMicRefused = false; });

    // THE CHECK, from Settings, Hugo's voice (the Orb has no settings section of its own; owner, 26 October 2026): green with every
    // Live link named, then amber naming the sideband.
    await page.click('#hugo-collapse');
    await page.click('.nav-btn[data-view="settings"]');
    await openSettingsSections(page);
    await page.waitForSelector('#settings-hugo-slot #hugo-preflight-run', { timeout: 10000 });
    const voice = await page.evaluate(() => Boolean(document.querySelector('#settings-hugo-slot #hugo-voice')) && Boolean(document.querySelector('#settings-hugo-slot #hugo-mute')));
    check(voice, 'Settings does not hold Hugo\'s voice choice and mute');
    const ran = async () => {
      await page.click('#hugo-preflight-run');
      await page.waitForFunction(() => !document.querySelector('#hugo-preflight-run')?.disabled && !['', 'Checking…'].includes(document.getElementById('hugo-preflight-out')?.textContent || ''), null, { timeout: 20000 });
      return page.evaluate(() => { const o = document.getElementById('hugo-preflight-out'); return { text: o.textContent, good: o.classList.contains('is-good'), bad: o.classList.contains('is-bad') }; });
    };
    const green = await ran();
    check(green.good && /His live voice \(gpt-live-1 with gpt-6-astra\) connected in \d+ms, ICE (connected|completed), and a spoken turn ran count_records in 640ms\./.test(green.text), 'a good check read ' + JSON.stringify(green));
    check(state.opens.at(-1)?.check === true && state.checks === 1, 'the check did not run its delegated turn');
    state.open = 'sideband';
    const amber = await ran();
    check(amber.bad && !amber.good && /control link/.test(amber.text) && /Hugo is connected/.test(amber.text), 'a failed sideband read ' + JSON.stringify(amber));
    state.open = 'answer';
    // MUTE (VH-838): ticked in Settings, Hugo's spoken replies are silent on the next Talk.
    await page.check('#settings-hugo-slot #hugo-mute');
    await page.click('.nav-btn[data-view="master"]');
    await page.click('#hugo-btn');
    const answeredMute = state.answered;
    await holdOrb();
    await until(() => state.answered > answeredMute, 15000);
    await page.waitForTimeout(300);
    const muted = await page.evaluate(() => ({ audios: globalThis.__vhAudios?.length ?? -1, muted: globalThis.__vhAudios?.at(-1)?.muted, box: document.getElementById('hugo-mute')?.checked, open: Boolean(document.querySelector('#hugo-rail.is-expanded')) }));
    check(muted.muted === true, 'with Mute ticked, Hugo\'s player was not muted: ' + JSON.stringify({ ...muted, answered: state.answered - answeredMute }));
    await page.click(orb);
    await page.click('.nav-btn[data-view="settings"]');
    await page.uncheck('#settings-hugo-slot #hugo-mute');
    await page.click('.nav-btn[data-view="master"]');

    // THE PHONE ORB SPEAKS (VH-777): a hold starts a Live conversation, the orb shows it, and a tap ends it.
    // A phone is a narrow screen with a touch pointer (VH-811).
    await phoneTouch(page, true);
    await page.setViewportSize({ width: 390, height: 844 });
    await page.reload();
    await page.waitForSelector(orb, { timeout: 10000 });
    const opensBefore = state.opens.length;
    const answeredBefore = state.answered;
    const phoneEnds = state.ends;
    await holdOrb();
    await until(() => state.answered > answeredBefore, 15000);
    await page.waitForTimeout(300);
    const phone = await page.evaluate((sel) => ({ on: document.querySelector(sel)?.classList.contains('is-listening'), label: document.querySelector(sel)?.getAttribute('aria-label'), typing: document.querySelector('.orb-screen')?.classList.contains('is-typing') }), orb);
    check(state.opens.length === opensBefore + 1 && state.opens.at(-1).domain === 'all', 'a hold on the phone orb opened ' + (state.opens.length - opensBefore) + ' Live sessions on ' + state.opens.at(-1)?.domain);
    check(phone.on && /Tap to stop/.test(phone.label || '') && !phone.typing, 'the phone orb while talking read ' + JSON.stringify(phone));
    await page.click(orb);
    await until(() => state.ends > phoneEnds, 5000);
    check(state.ends === phoneEnds + 1, 'a tap on the talking phone orb ended ' + (state.ends - phoneEnds) + ' sessions, not 1');
  } finally {
    state.live = false;
    await page.evaluate(() => { sessionStorage.removeItem('vh_sweep_live'); }).catch(() => {});
    await phoneTouch(page, false).catch(() => {});
    await page.setViewportSize(was || { width: 1440, height: 900 });
    for (const route of [VOICE, DIAGNOSE, LIVE, LIVE_CHECK, LIVE_END]) await page.unroute(route).catch(() => {});
    await page.reload();
    await page.waitForSelector('#app:not([hidden])');
  }
}
