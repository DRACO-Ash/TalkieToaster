// HUGO'S LIVE VOICE ROUTES (VH-777 Lane V). Three authenticated routes, agent role, judged cross-site as every
// mutating request is (src/app.js, src/csrf.js), each a POST:
//  ● `/api/v3/hugo/live`: the browser's WebRTC offer in, OpenAI's answer out. The server builds the whole session
//    (instructions, voice, tools, the brain behind it) and the browser can change none of it; the server then attaches
//    its sideband BEFORE answering, so no session ever runs without the server holding its tools, its meter and its
//    off switch. With `check: true` the sideband also runs one delegated turn that must call a tool, read back by:
//  ● `/api/v3/hugo/live/check`: that turn's result, for the connection check.
//  ● `/api/v3/hugo/live/end`: the operator left; the session is closed, and its spend flushed.
// One session per operator: opening another closes the first, so a reloaded page never leaves one orphaned.
//
// The order of refusals is the relay's (`realtime-upgrade-gate.js`): role, then off, then the request, then the daily
// cap, all before anything is dialled.

import { readJsonBody } from '../http-body.js';
import { sendJson } from '../http-util.js';
import { hasRole } from '../auth.js';
import { domainIds } from '../domain/descriptor.js';
import { attachSideband } from './live-sideband.js';
import { liveSessionIdValid } from './live-session.js';

export const LIVE_ROUTE = '/api/v3/hugo/live';
export const LIVE_CHECK_ROUTE = '/api/v3/hugo/live/check';
export const LIVE_END_ROUTE = '/api/v3/hugo/live/end';
export const LIVE_BODY_MAX_BYTES = 80 * 1024; // the SDP cap plus room for the three short fields beside it
export const MAX_LIVE_SESSIONS = 40;
const CHECK_KEEP_MS = 2 * 60 * 1000;

// The operator a session belongs to; a principal with no subject owns nothing (an empty id matches no stored session).
const subjectOf = (principal) => (typeof principal?.subject === 'string' ? principal.subject : '');
// ONE SESSION PER OPERATOR AND TAB, NOT PER SUBJECT (2.20.0 round one, security MINOR 4): on the shared team token every
// operator is the same subject, so keyed by subject alone one operator's Talk closed another's. The browser sends a
// per-tab id; a request without a valid one is keyed by its subject alone, as before.
const TAB_ID = /^[\w-]{8,64}$/;
export const liveKeyOf = (principal, tab) => subjectOf(principal) + '\u0000' + (typeof tab === 'string' && TAB_ID.test(tab) ? tab : '');

/** A registered domain id, 'all', or '' (refused). */
export function liveDomain(raw) {
  if (typeof raw !== 'string') return '';
  const id = raw.trim().toLowerCase().replaceAll('-', '_');
  if (id === 'all') return 'all';
  return domainIds().includes(id) ? id : '';
}

// The class of a failure, named by the link it broke, never by the provider's prose (which can quote a credential).
export function liveFailure(err) {
  if (err?.timedOut) return { status: 504, kind: 'timeout' };
  if (err?.egress) return { status: 502, kind: 'egress' };
  if (err?.refused) return { status: 502, kind: 'refused' };
  const s = Number(err?.providerStatus);
  if (s === 401) return { status: 502, kind: 'auth', code: err.providerCode };
  if (s === 403) return { status: 502, kind: 'permission', code: err.providerCode };
  if (s === 404) return { status: 502, kind: 'model', code: err.providerCode };
  if (s === 429) return { status: 502, kind: 'rate_limit', code: err.providerCode };
  if (s >= 500) return { status: 502, kind: 'provider', code: err.providerCode };
  if (s === 400 || s === 413) return { status: 502, kind: 'refused', code: err.providerCode };
  return { status: 502, kind: 'other', ...(err?.providerCode ? { code: err.providerCode } : {}) };
}

/**
 * The live service, built once at the composition root. Everything it touches is injected.
 * `offReason` is '' when Live may open, else why not ('not_configured', 'no_store', 'unpriced').
 */
export function createLiveService({ client, apiKey, wsFactory, spendGuards, runnerFor, toolDefs, audit = async () => {}, log = () => {}, offReason = '', maxSessionMs = 0, now = Date.now, setTimer = setTimeout, clearTimer = clearTimeout }) {
  const sessions = new Map(); // sessionId -> { subject, sideband, check }
  const byKey = new Map(); // subject and tab -> sessionId
  const turnAllowed = async () => { await spendGuards.flushSpendToLedger(); return spendGuards.paidCallAllowed(); };

  function forget(sessionId) {
    const s = sessions.get(sessionId);
    if (!s) return;
    sessions.delete(sessionId);
    if (byKey.get(s.key) === sessionId) byKey.delete(s.key);
  }

  async function open({ principal, sdp, domain, voice, check = false, tab }) {
    const subject = subjectOf(principal);
    const key = liveKeyOf(principal, tab);
    const previous = byKey.get(key);
    if (previous) sessions.get(previous)?.sideband.close('replaced');
    if (sessions.size >= MAX_LIVE_SESSIONS) throw Object.assign(new Error('too many live sessions'), { statusCode: 503 });
    const runner = runnerFor(domain === 'all' ? 'space' : domain);
    const created = await client.create({ sdp, voice, tools: toolDefs(), scope: domain });
    const sideband = attachSideband({
      apiKey, sessionId: created.sessionId, wsFactory, liveModel: created.model, brainModel: created.brain,
      // Lane T's registry runs each call id once; the sideband also answers each once (`live-sideband.js`).
      runTool: (name, args, callId) => runner.runCall({ callId, name, args }),
      onUsage: spendGuards.noteUsage, turnAllowed,
      onTurn: () => { runner.newTurn?.(); audit(subject, { domain: 'voice', turns: 1, via: 'live' }).catch(() => {}); },
      onClose: (reason, detail) => {
        forget(created.sessionId);
        log({ event: 'live-closed', reason, ...detail });
        spendGuards.flushSpendToLedger().catch(() => {});
      },
      maxSessionMs, setTimer, clearTimer, now,
    });
    const entry = { subject, key, sideband, check: null };
    sessions.set(created.sessionId, entry);
    byKey.set(key, created.sessionId);
    try {
      await sideband.ready;
    } catch (err) {
      sideband.close('sideband_failed');
      throw Object.assign(new Error('hugo live sideband failed'), { statusCode: 502, link: 'sideband', timedOut: err?.timedOut, refused: err?.refused });
    }
    if (check) {
      entry.check = sideband.probeTurn();
      // A check session ends itself: it must never hold a paid session open on a page that has moved on.
      setTimer(() => sideband.close('check_done'), CHECK_KEEP_MS)?.unref?.();
    }
    audit(subject, { domain: 'voice', turns: 0, via: check ? 'live-check' : 'live' }).catch(() => {});
    log({ event: 'live-open', model: created.model, brain: created.brain, check: Boolean(check) });
    // The session's length travels to the browser too, which ends its own audio link at it (2.20.0 security gate): the
    // server's limit lives on the sideband, and a link that dropped holds no limit at all.
    return { sessionId: created.sessionId, sdp: created.sdp, model: created.model, brain: created.brain, ...(maxSessionMs > 0 ? { maxSessionMs } : {}) };
  }

  /** The delegated turn's result for a check session the caller owns, or null when there is none. */
  async function checkResult({ principal, sessionId }) {
    const s = sessions.get(sessionId);
    return s?.check && s.subject === subjectOf(principal) ? s.check : null;
  }

  function end({ principal, sessionId }) {
    const s = sessions.get(sessionId);
    if (s?.subject !== subjectOf(principal)) return false;
    s.sideband.close('operator_left');
    return true;
  }

  function closeAll(reason = 'shutdown') {
    for (const s of sessions.values()) s.sideband.close(reason);
  }

  return { configured: offReason === '', offReason, model: client.model, brain: client.brain, open, end, checkResult, closeAll, reachableModels: () => client.reachableModels(), count: () => sessions.size };
}

const refuse = (res, status, body) => { sendJson(res, status, body); return true; };

const LIVE_PATHS = new Set([LIVE_ROUTE, LIVE_CHECK_ROUTE, LIVE_END_ROUTE]);

// The two session-id routes: the caller's own session ended, or its check read back.
async function sessionRoute(res, path, body, { principal, hugoLive }) {
  if (!liveSessionIdValid(body?.sessionId)) return refuse(res, 400, { error: 'sessionId is required' });
  if (path === LIVE_END_ROUTE) return refuse(res, 200, { ended: hugoLive.end({ principal, sessionId: body.sessionId }) });
  const result = await hugoLive.checkResult({ principal, sessionId: body.sessionId });
  return result ? refuse(res, 200, { delegation: result }) : refuse(res, 404, { error: 'no check for that session' });
}

// A failed open, named by the link that broke and its class, with the provider's prose only on the admin fault ring.
function openFailed(res, err, ctx) {
  if (err?.statusCode === 400) return refuse(res, 400, { error: 'invalid sdp offer' });
  if (err?.statusCode === 503) return refuse(res, 503, { error: 'live voice busy', link: 'capacity' });
  const link = err?.link || 'handshake';
  const f = liveFailure(err);
  ctx.faults?.record?.('hugo-live', err?.ringDetail || err?.message || 'live failed');
  return refuse(res, f.status, { error: 'live ' + link + ' failed', link, kind: f.kind, ...(f.code ? { code: f.code } : {}) });
}

/** The route handler; false when the request is not one of these routes. */
export async function tryHugoLive(req, res, ctx) {
  const { method, path, principal, hugoLive } = ctx;
  if (method !== 'POST' || !LIVE_PATHS.has(path)) return false;
  if (!hasRole(principal, 'agent')) throw Object.assign(new Error('forbidden: this sign-in needs the agent role'), { statusCode: 403, role: 'agent' });
  if (!hugoLive?.configured) return refuse(res, 503, { error: 'live voice not configured', link: 'config', reason: hugoLive?.offReason || 'not_configured' });
  const body = await readJsonBody(req, LIVE_BODY_MAX_BYTES);
  if (path !== LIVE_ROUTE) return sessionRoute(res, path, body, ctx);
  const domain = liveDomain(body?.domain);
  if (!domain) return refuse(res, 400, { error: 'a domain is required' });
  if (typeof body?.sdp !== 'string' || !body.sdp) return refuse(res, 400, { error: 'an sdp offer is required' });
  if (!(await ctx.paidCallAllowed?.())) return refuse(res, 429, { error: 'daily_cap_reached', limit: 'daily spend cap' });
  try {
    return refuse(res, 201, await hugoLive.open({ principal, sdp: body.sdp, domain, voice: body.voice, check: body.check === true, tab: body.tab }));
  } catch (err) {
    return openFailed(res, err, ctx);
  }
}
