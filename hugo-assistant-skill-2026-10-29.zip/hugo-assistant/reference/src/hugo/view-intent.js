// The Hugo ViewIntent normaliser (docs/PLAN-hugo-query-drive.md, item A). Hugo turns an operator's free-text
// request ("show me the C-UAS vendors in the UK that are not in the GDM") into a validated ViewIntent that
// both FILTERS the dataset and DRIVES a view. This module is the deterministic core of that pipeline, the
// exact counterpart to src/scan/scan-design.js for the scan compiler: it takes a RAW parsed object (from the
// deterministic resolver, or from the model, or from the confirm surface) plus the active domain descriptor,
// and returns a validated ViewIntent whose every controlled-value clause contains ONLY values that exist in
// the descriptor's vocabulary and the country canon. Anything else is collected into `unmapped` and shown to
// the operator, never invented and never silently kept (measured-or-marked). Pure and fail-closed: no model
// call, no I/O; a malformed raw or descriptor yields an empty, safe intent rather than throwing.
//
// The hard rule the shape enforces, the same one that governs the scan compiler (plan Part 4.1): free text
// can NARROW a query, never widen policy. Nothing here can set eligibility or reach an excluded class; the
// eligibility gate governs what may surface regardless of anything in a ViewIntent. Explicit "not in the GDM"
// needs no negation flag: the gdm vocabulary carries "Not in GDM" as a first-class value, so the operator's
// negation resolves to that value directly, the same one a manual GDM filter sets. Family "excluding X"
// negation is a later refinement and is deliberately not carried here yet.

import { canonicalCountry, isRecognisedCountry } from '../domain/country-canon.js';
import { resolveAreaName, areaCountrySet } from '../domain/areas.js';
import { GDM_PIPELINE_STAGES, BLOCKER_KINDS, GDM_PRIORITY } from '../domain/gdm-pipeline.js';
import { hugoFamilyKeys } from './families.js';
import { allFacets } from '../domain/descriptor.js';
import { missionNamesFor } from '../domain/mission-alignment.js';

// The vocabulary name Hugo reads a mission against: each domain's Mission Alignment list (VH-801).
const JCO_MISSIONS = 'jco_missions';

// The views a ViewIntent may drive, and the caps that bound a hostile or runaway raw input at the boundary
// (defence in depth; model output is token-bounded upstream, deterministic input is operator text).
// `pipeline` joins the three (V1.77 W1-3): the GDM onboarding pipeline is a view an operator asks for by
// name ("show me what is stuck in contracting"), and without it every pipeline question had to be answered on
// the board.
export const VIEWS = Object.freeze(['board', 'map', 'analytics', 'pipeline']);
// The confidence is a display-only hint the model may set; it is validated against this closed set so a
// model-controlled string can never reach the client unchecked (it cannot affect filtering, but every value
// crossing the boundary is validated, not just capped).
const CONFIDENCE = Object.freeze(['low', 'medium', 'high']);
const CAP = { phrase: 400, value: 200 };
const MAX_LIST = 40;
const MAX_RAW_ITEMS = 500;

// Which ViewIntent filter clause reads which descriptor vocabulary. A clause is only admitted when the
// descriptor declares that axis (a non-readiness domain has no `grade`, a domain without the GDM overlay no
// `gdm`), so a query for an axis the domain does not carry routes to `unmapped` rather than silently applying.
const VOCAB_CLAUSES = Object.freeze([
  { clause: 'gdm', vocab: 'gdm', needs: 'hasGdm' },
  { clause: 'sections', vocab: 'section' },
  // VH-801: a mission is one of the domain's Mission Alignment missions, not the old per-vendor vocabulary.
  { clause: 'missions', vocab: JCO_MISSIONS },
  // VH-706: the Data type/value chain clause admits either vocabulary, so Hugo finds a role under the one name.
  { clause: 'productTypes', vocab: ['product_types', 'chain'] },
]);

/**
 * THE PIPELINE CLAUSES (V1.77 W1-3, the V1.75 deferral).
 *
 * Each reads a CLOSED vocabulary from `src/domain/gdm-pipeline.js`, the schema authority the migrations'
 * CHECK lists are generated from, so a value admitted here is a value the column accepts and there is no
 * second copy of any list in this file.
 *
 * `owners` is deliberately NOT vocabulary-validated: an owner is a person's identifier, not a controlled
 * value, so it is length-capped and passed through as text and bound as a parameter downstream. The one
 * magic word is 'me', which this module keeps verbatim: resolving it needs the caller's identity, which a
 * pure normaliser does not have and must not guess. The route resolves it (`resolveOwners`) and a 'me' that
 * reaches the query builder unresolved matches nothing, which is the fail-closed direction.
 */
const PIPELINE_VOCAB_CLAUSES = Object.freeze([
  { clause: 'stages', values: GDM_PIPELINE_STAGES },
  { clause: 'blockerKinds', values: BLOCKER_KINDS },
  { clause: 'priorities', values: GDM_PRIORITY },
]);

const str = (v, cap) => (typeof v === 'string' ? v.trim().slice(0, cap) : '');
const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const dedupe = (list) => [...new Set(list)];

// Coerce a value to an array of trimmed non-empty strings, bounded before iterating. Never throws.
function asStringArray(v) {
  let list = [];
  if (Array.isArray(v)) list = v.slice(0, MAX_RAW_ITEMS);
  else if (typeof v === 'string') list = [v];
  const out = [];
  for (const item of list) {
    const s = str(item, CAP.value);
    if (s) out.push(s);
  }
  return out;
}

function vocabHas(descriptor, name, val) {
  if (name === JCO_MISSIONS) return missionNamesFor(descriptor?.id).includes(val);
  const set = descriptor?.vocab?.[name];
  if (set instanceof Set) return set.has(val);
  if (Array.isArray(set)) return set.includes(val);
  return false;
}

// Read a clause from either a nested `filterSpec` object or the top level, so the resolver, the model and the
// confirm form can all feed this without a shape mismatch (the same tolerance scan-design.js gives fields).
function readClause(raw, name) {
  const nested = isPlainObject(raw.filterSpec) ? raw.filterSpec[name] : undefined;
  return nested === undefined ? raw[name] : nested;
}

// Filter a raw clause against a descriptor vocabulary, routing unknown values to `unmapped`. The `vocab` name
// is the descriptor key to look up; the `clause` name is what an unmapped entry reports, so every unmapped
// entry names a ViewIntent filterSpec clause (countries, sections, grades, ...) consistently, whichever path
// dropped it, and the confirm surface can group them by the clause the operator was filtering on.
function filterToVocab(descriptor, vocab, clause, rawList, unmapped) {
  const kept = [];
  for (const val of asStringArray(rawList)) {
    if ([vocab].flat().some((v) => vocabHas(descriptor, v, val))) kept.push(val);
    else unmapped.push({ field: clause, value: val });
  }
  return dedupe(kept).slice(0, MAX_LIST);
}

// Canonicalise a country clause through the SAME canon the rest of the app uses, so Hugo's "UK" and a manual
// "United Kingdom" filter are byte-identical. An unrecognised country goes to `unmapped`, never guessed.
function normaliseCountries(rawList, unmapped) {
  const kept = [];
  for (const val of asStringArray(rawList)) {
    if (isRecognisedCountry(val)) kept.push(canonicalCountry(val));
    else unmapped.push({ field: 'countries', value: val });
  }
  return dedupe(kept).slice(0, MAX_LIST);
}

// Validate a capability-family clause against the family keys in force (EO, SAR, ..., and any an admin added). Unknown keys go to
// `unmapped`. The resolver and the model are expected to emit KEYS (mapping "electro-optical" -> "EO" is the
// resolver's job); this validator is the enforcement, so it accepts only keys. A key any domain holds is kept, even on a
// domain that does not hold it (each domain holds its own families): the store then expands it in its own families and,
// holding none of its types, says the clause was not applied, rather than answering every record unfiltered.
function normaliseFamilies(rawList, unmapped) {
  const kept = [];
  const keys = hugoFamilyKeys('all');
  for (const val of asStringArray(rawList)) {
    const key = val.toUpperCase();
    if (keys.includes(key)) kept.push(key);
    else unmapped.push({ field: 'families', value: val });
  }
  return dedupe(kept).slice(0, MAX_LIST);
}


/**
 * THE AREAS CLAUSE (V1.83, backlog 11a F1 and F6): "show me the NATO vendors".
 *
 * IT EXPANDS TO COUNTRIES HERE, at normalisation, rather than becoming a clause of its own in the SQL.
 * That is the whole design decision and it is worth stating: an area IS a set of countries, the Space
 * store, every domain store, the map and the analytics denominators all already filter by country, and a
 * separate `areas` clause would mean five more places to teach and five more places to disagree. Expanded
 * here, one filterSpec reaches all of them and nothing downstream changes at all.
 *
 * NATO and CSpO need no new data: both are seeded, sourced and dated in the locked registry. The three JCO
 * zones are deliberately EMPTY - their membership "is not a fact this app may invent" - so naming one adds
 * no countries and is reported through `unmapped` as the zone it is, rather than silently filtering to
 * nothing or, worse, being guessed at. That is owner decision D1 and this code does not pre-empt it.
 *
 * An area that adds countries the caller ALSO named by hand is a union, de-duplicated: asking for "NATO and
 * France" is asking for NATO.
 */
function applyAreas(r, filterSpec, unmapped) {
  const named = asStringArray(readClause(r, 'areas'));
  if (named.length === 0) return;
  const applied = [];
  const countries = new Set(filterSpec.countries);
  for (const name of named) {
    const area = resolveAreaName(name);
    if (!area) { unmapped.push({ field: 'areas', value: name }); continue; }
    if (area.countries.length === 0) {
      // Recognised, but this application does not know who is in it. Reported so the confirm surface can
      // say "JCO PACIFIC has no members yet" instead of showing an empty board.
      unmapped.push({ field: 'areas', value: area.label });
      continue;
    }
    applied.push(area.key);
    for (const c of areaCountrySet(area.countries)) countries.add(c);
  }
  filterSpec.countries = [...countries].slice(0, MAX_LIST);
  // Kept on the spec so the confirm surface can say "NATO (32 countries)" rather than listing 32 chips, and
  // so a saved view records what the operator ASKED for, not only what it expanded to.
  if (applied.length > 0) filterSpec.areas = dedupe(applied).slice(0, MAX_LIST);
}

/**
 * Normalise a raw ViewIntent object against a domain descriptor. Returns { intent, unmapped } where `intent`
 * carries only descriptor-valid controlled values, canonical countries and known family keys, and `unmapped`
 * lists every dropped { field, value }. Pure and fail-closed.
 *
 * @param raw        the parsed object (resolver / model / form)
 * @param descriptor the active domain descriptor (getDescriptor(id))
 * @param opts.domainIds  the set of registered domain ids, to validate `domain`
 * @param opts.crossDomain  whether the query spans every domain (owner: cross-domain from the start)
 */
// Coerce the caller's domainIds (a Set, an array, or nothing) to a Set for the `domain` check.
function toIdSet(v) {
  if (v instanceof Set) return v;
  return new Set(Array.isArray(v) ? v : []);
}

// The requested domain if it is registered, else the active descriptor's own id (fail-safe, never blank when
// a descriptor is present).
function resolveDomain(rawDomain, ids, descriptor) {
  if (ids.has(rawDomain)) return rawDomain;
  return typeof descriptor?.id === 'string' ? descriptor.id : '';
}

// Build the whole filterSpec: countries via the canon, families via the key set, and each vocab clause against
// the descriptor, with an axis the domain does not carry surfaced to `unmapped` rather than silently applied.
function buildFilterSpec(r, descriptor, unmapped) {
  const filterSpec = { countries: normaliseCountries(readClause(r, 'countries'), unmapped) };
  applyAreas(r, filterSpec, unmapped);
  for (const { clause, vocab, needs } of VOCAB_CLAUSES) {
    const rawList = readClause(r, clause);
    if (needs && !descriptor?.[needs]) {
      for (const val of asStringArray(rawList)) unmapped.push({ field: clause, value: val });
      filterSpec[clause] = [];
    } else {
      filterSpec[clause] = filterToVocab(descriptor, vocab, clause, rawList, unmapped);
    }
  }
  filterSpec.families = normaliseFamilies(readClause(r, 'families'), unmapped);
  addFacetClauses(r, descriptor, filterSpec, unmapped);
  addPipelineClauses(r, filterSpec, unmapped);
  addSearchClause(r, filterSpec, unmapped);
  return filterSpec;
}

/**
 * EACH DOMAIN'S OWN CAPABILITY FACETS (VH-263): Space's orbital regime, the capability class, Maritime's target
 * stratum and observation mode, Natural Resources' resource class. Each is a clause named by its own key and
 * validated against that facet's vocabulary on the descriptor the question is read against, so a single store
 * keeps only its own facets' values and a cross-domain question (read against the union) keeps every store's.
 * A facet the descriptor does not carry is NEVER silently dropped: its values go to `unmapped` under its key, so
 * "the LEO providers" asked of Maritime says it was not understood rather than returning the whole store.
 */
function addFacetClauses(r, descriptor, filterSpec, unmapped) {
  const own = (Array.isArray(descriptor?.capabilityFacets) ? descriptor.capabilityFacets : [])
    .map((f) => f?.key).filter((k) => typeof k === 'string' && k);
  for (const key of dedupe([...own, ...allFacets().map((f) => f.key)])) {
    const raw = readClause(r, key);
    if (own.includes(key)) filterSpec[key] = filterToVocab(descriptor, key, key, raw, unmapped);
    else for (const val of asStringArray(raw)) unmapped.push({ field: key, value: val });
  }
}

/**
 * THE TYPED-NAME CLAUSE (VH-181): "show me Flightradar24", "the one called Airbus". A company name is not a
 * controlled value, so no vocabulary can admit it, and until this clause Hugo had no way to narrow a view to
 * one: every name an operator typed was dropped and the whole domain came back. It is the same free text the
 * board's own search box sends, matched by every store over the record it holds (Space over its folded
 * record, the six product-line stores over the provider, its lines and its overlay), so a name Hugo applies
 * finds exactly what typing it into the board would.
 *
 * NARROWS, NEVER WIDENS: it is ANDed with every other clause and can only remove rows. It is text, so it is
 * bounded, stripped of control characters and folded to single spaces here, and bound as a parameter
 * downstream, never interpolated. `name` is read as a synonym because that is the word a model reaches for;
 * a value that is not a string is reported in `unmapped`, never coerced into one.
 */
const SEARCH_CAP = 120;
// Every C0 control character and DEL, by code point rather than as a regex class, so no control character
// appears in this source either.
const isControl = (ch) => { const c = ch.codePointAt(0); return c < 32 || c === 127; };
function addSearchClause(r, filterSpec, unmapped) {
  const named = readClause(r, 'search');
  const raw = named === undefined || named === null || named === '' ? readClause(r, 'name') : named;
  if (raw === undefined || raw === null || raw === '') return;
  if (typeof raw !== 'string') {
    unmapped.push({ field: 'search', value: String(raw).slice(0, CAP.value) });
    return;
  }
  const text = [...raw].map((ch) => (isControl(ch) ? ' ' : ch)).join('').replaceAll(/\s+/g, ' ').trim().slice(0, SEARCH_CAP).trim();
  if (text) filterSpec.search = text;
}

// A closed-vocabulary pipeline clause: only values the column's own CHECK list accepts, everything else to
// `unmapped`. Case is normalised for the two lower_snake vocabularies and matched exactly for the priority
// list, which is title case in the schema.
function pipelineVocabList(rawList, values, clause, unmapped) {
  const kept = [];
  const lowerFirst = values.every((v) => v === v.toLowerCase());
  for (const val of asStringArray(rawList)) {
    const candidate = lowerFirst ? val.toLowerCase() : val;
    if (values.includes(candidate)) kept.push(candidate);
    else unmapped.push({ field: clause, value: val });
  }
  return dedupe(kept).slice(0, MAX_LIST);
}

/**
 * `blocked`, `due` and `ageing`: the three pipeline clauses that are not lists of controlled values.
 *
 * ● `blocked` is a TRISTATE and the third state matters: absent means "do not filter on it", true means
 *   blocked, false means explicitly not blocked. A boolean field with a false default would make "not
 *   blocked" the permanent state of every query, which is why this is `true | false | undefined` and why
 *   only a real boolean or the two exact strings set it.
 * ● `due` is a closed set of relative windows rather than a date, because Hugo is asked "what is overdue",
 *   never "what is due on the 14th": a date would have to be resolved against a clock this pure module does
 *   not read.
 * ● `ageing` is a whole number of days in the current stage, capped, because "stuck for weeks" is the
 *   question and an unbounded number is a hostile input.
 */
export const DUE_WINDOWS = Object.freeze(['overdue', 'today', 'week', 'month', 'none']);
const AGEING_MAX_DAYS = 3650;

function addPipelineClauses(r, filterSpec, unmapped) {
  for (const { clause, values } of PIPELINE_VOCAB_CLAUSES) {
    filterSpec[clause] = pipelineVocabList(readClause(r, clause), values, clause, unmapped);
  }
  // An owner is an identity, not a vocabulary: capped and kept, never invented. 'me' rides through for the
  // route to resolve (see PIPELINE_VOCAB_CLAUSES above).
  filterSpec.owners = dedupe(asStringArray(readClause(r, 'owners')).map((v) => str(v, CAP.value)).filter(Boolean)).slice(0, MAX_LIST);
  const rawDue = str(readClause(r, 'due'), CAP.value).toLowerCase();
  if (rawDue) {
    if (DUE_WINDOWS.includes(rawDue)) filterSpec.due = rawDue;
    else unmapped.push({ field: 'due', value: rawDue });
  }
  const rawBlocked = readClause(r, 'blocked');
  if (rawBlocked === true || rawBlocked === 'true') filterSpec.blocked = true;
  else if (rawBlocked === false || rawBlocked === 'false') filterSpec.blocked = false;
  else if (rawBlocked !== undefined && rawBlocked !== null && rawBlocked !== '') {
    unmapped.push({ field: 'blocked', value: String(rawBlocked).slice(0, CAP.value) });
  }
  const rawAgeing = readClause(r, 'ageing');
  // `Number`, NOT `Number.parseInt`, and the difference is a decision rather than a detail: parseInt reads
  // "1.5" as 1, so a fractional day from a model would have been silently truncated to a whole one while the
  // NUMBER 1.5 was refused - the same value accepted or rejected depending on which of the three callers
  // sent it. Neither is a day an operator asked for, so both are now refused and reported.
  const days = typeof rawAgeing === 'number' ? rawAgeing : Number(String(rawAgeing ?? '').trim());
  if (Number.isInteger(days) && days > 0) filterSpec.ageingDays = Math.min(days, AGEING_MAX_DAYS);
  else if (rawAgeing !== undefined && rawAgeing !== null && rawAgeing !== '') {
    unmapped.push({ field: 'ageing', value: String(rawAgeing).slice(0, CAP.value) });
  }
}

export function normaliseViewIntent(raw, descriptor, opts = {}) {
  const r = isPlainObject(raw) ? raw : {};
  const unmapped = [];
  const domain = resolveDomain(str(r.domain, CAP.value), toIdSet(opts.domainIds), descriptor);
  const filterSpec = buildFilterSpec(r, descriptor, unmapped);
  const rawView = str(r.view, CAP.value);
  const view = VIEWS.includes(rawView) ? rawView : '';

  const intent = {
    domain,
    crossDomain: Boolean(opts.crossDomain ?? r.crossDomain),
    filterSpec,
    view,
    question: str(r.question ?? r.intent, CAP.phrase),
    confidence: CONFIDENCE.includes(str(r.confidence, CAP.value).toLowerCase())
      ? str(r.confidence, CAP.value).toLowerCase() : '',
  };
  intent.unmapped = unmapped;
  return { intent, unmapped };
}

/**
 * True when a ViewIntent carries at least one filter clause. An intent that maps to no filter (the operator's
 * phrase resolved to nothing) is honestly empty rather than "show everything"; the caller decides whether to
 * confirm, ask again, or fall back to the manual filters.
 */
export function intentHasFilter(intent) {
  const f = intent?.filterSpec;
  if (!isPlainObject(f)) return false;
  if (Object.values(f).some((v) => Array.isArray(v) && v.length > 0)) return true;
  // THE SCALAR PIPELINE CLAUSES COUNT TOO (V1.77 W1-3). This tested arrays only, which was complete while
  // every clause was a list; `due`, `blocked` and `ageingDays` are not lists, so an intent whose ONLY filter
  // was "show me what is blocked" would have reported itself as having no filter, and the caller would have
  // fallen back to "show everything" - the widest possible answer to the narrowest possible question.
  if (typeof f.due === 'string' && f.due) return true;
  // The typed name (VH-181) is a string too, and an intent whose only clause is a name is a narrowing.
  if (typeof f.search === 'string' && f.search) return true;
  if (f.blocked === true || f.blocked === false) return true;
  return Number.isInteger(f.ageingDays) && f.ageingDays > 0;
}

/**
 * Resolve the 'me' owner token against the calling actor. Separate from the normaliser because it needs the
 * caller's identity, which a pure validator does not have and must not guess.
 *
 * 'me' with no actor is DROPPED rather than kept: an unresolved 'me' reaching the query builder would be
 * matched literally against the owner column, and while that matches nothing today (no owner is stored as
 * the word "me"), relying on that is relying on an accident. Dropping it is the fail-closed direction, and
 * the caller can tell it happened because the returned list is shorter than the one it passed.
 */
export function resolveOwners(owners, actor) {
  const list = Array.isArray(owners) ? owners : [];
  const me = typeof actor === 'string' ? actor.trim() : '';
  const out = [];
  for (const raw of list) {
    const value = typeof raw === 'string' ? raw.trim() : '';
    if (!value) continue;
    if (value.toLowerCase() !== 'me') { out.push(value); continue; }
    if (me) out.push(me);
  }
  return dedupe(out);
}
