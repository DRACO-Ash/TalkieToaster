// GROUNDING UNDER STREAMING (VH-318-E, owner decision 2026-09-29: stream with a visible "checking" mark; answers
// only from tool results; a failed check flags or withdraws the answer).
//
// The agent loop checked an answer BEFORE the operator saw it. A streamed answer is seen as it is produced, so the
// check runs beside it, on the finished text, against the same session ledger the tools fill
// (`src/hugo/tools.js` createLedger), and its verdict follows the answer to the rail: verified, or WITHDRAWN for a
// typed answer (the text is taken off the rail), or FLAGGED for a spoken one (audio already played cannot be
// unsaid, so the transcript is marked and Hugo says a short correction).
//
// What it checks, reusing `verifyAnswer` so the rules are the agent's own: every `[Rn]` reference, every link and
// every figure in the text must be one a tool returned. Streamed prose declares no ids and no entity list, so the
// declared-id half does not apply; names are read from the prose instead, narrowly: a name carrying a legal
// suffix ("Norss Ltd", "Acme GmbH") must be one a tool returned, with or without its suffix. A name with no
// suffix is not caught, which is the same gap the agent path records for an undeclared name.

import { verifyAnswer } from './agent.js';

// Two to seven capitalised words; the last is then tested against the legal-form suffixes. Bounded quantifiers, so
// the pattern is linear over model output, and the suffix list is a set rather than an alternation in the pattern.
const CAPITALISED_RUN = /\b(?:[A-Z][\w&'.-]{0,40}\s){1,6}[A-Z][A-Za-z]{0,11}\b/g;
const ORG_SUFFIXES = new Set(['Ltd', 'Limited', 'plc', 'PLC', 'Inc', 'LLC', 'LLP', 'GmbH', 'AG', 'SA', 'SAS', 'SpA', 'BV', 'NV', 'AB', 'AS', 'ASA', 'Oy', 'Corp', 'Corporation', 'Pty']);
/** The longest streamed answer the check reads; the session's output cap bounds it well below this. */
export const STREAM_CHECK_MAX_CHARS = 20_000;

/**
 * The organisation names with a legal suffix in a piece of prose: `{ written, words, suffix }`, the words before
 * the suffix kept apart so a leading "The" or "Both" can be dropped when the name is looked up.
 */
export function suffixedNamesIn(text) {
  const out = [];
  for (const m of String(text || '').slice(0, STREAM_CHECK_MAX_CHARS).matchAll(CAPITALISED_RUN)) {
    const words = m[0].trim().split(/\s+/);
    // The suffix is the last word; a run whose last word is not one, or that is a suffix alone, names nothing.
    const at = words.findLastIndex((w) => ORG_SUFFIXES.has(w));
    if (at < 1) continue;
    out.push({ written: words.slice(0, at + 1).join(' '), words: words.slice(0, at), suffix: words[at] });
  }
  return out;
}

// A suffixed name is known when the ledger holds it, with or without its suffix, after dropping any number of
// leading words: "The Norss Ltd" is known if "Norss Ltd" or "Norss" was returned.
function nameKnown({ words, suffix }, ledger) {
  for (let k = 0; k < words.length; k += 1) {
    const bare = words.slice(k).join(' ');
    if (ledger.hasName(bare + ' ' + suffix) || ledger.hasName(bare)) return true;
  }
  return false;
}

/**
 * Check one finished streamed answer against the session ledger. Returns `{ ok, violations }` in the agent
 * verifier's own sentences.
 */
export function checkStreamedAnswer(text, ledger) {
  const answer = String(text || '').slice(0, STREAM_CHECK_MAX_CHARS);
  const verdict = verifyAnswer({ answer, cited: [], entities: [], numbers: [] }, ledger);
  const names = suffixedNamesIn(answer)
    .filter((name) => !nameKnown(name, ledger))
    .map((name) => `"${name.written}" was not returned by any tool`);
  const violations = [...new Set([...verdict.violations, ...names])].slice(0, 20);
  return { ok: violations.length === 0, violations };
}
