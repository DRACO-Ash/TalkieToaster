// HUGO'S AGENT LOOP (V1.77 D6, PLAN-V1.77 W2-3): a function-calling loop on the configured Hugo model over
// the tool layer, with step, wall-clock and tool-call caps, and a final answer the SERVER verifies before
// the operator sees it.
//
// THE VERIFICATION IS THE FEATURE. The model is asked to close with one JSON object: the answer text, the
// record ids it cited, the organisations it named, the figures it used. Each is checked against the tool
// ledger (src/hugo/tools.js): an id the tools never returned, a name the tools never showed, a number that
// appears in no tool result, or a `[Rn]` reference past the ledger, is a fabrication. The numbers in the
// answer TEXT are checked too, not only the ones the model declared, because a model asked to list its
// figures may leave one out. One corrective retry names every violation; a second failure fails CLOSED: the
// operator is told what could not be verified and given the verified part only. Where the model is not
// configured or the call fails, `deterministicAnswer` answers from the tools alone with no model at all.
//
// The model call and the clock are injected, so every branch here runs in a unit test without a network.

import { resolveDeterministic } from './deterministic.js';
import { getDescriptor } from '../domain/descriptor.js';
import { withFamilyScope } from '../domain/family-scope.js';
import { hugoFamilyKeys } from './families.js';

/**
 * WHAT ONE TURN MAY SPEND, raised for depth and for investigation (owner, 2026-09-19).
 *
 * The old figures - 6 steps, 10 tool calls, 30 seconds - were the arithmetic behind two separate
 * complaints. "Not in depth enough": answering a capability question record-by-record needs one call per
 * record, so thirty vendors could not be reached inside ten calls whatever the model did. And "willing to
 * investigate using the internet": a real look-up is a search, two pages read and a cross-check against
 * the dataset, which is most of a ten-call budget before the dataset is touched at all.
 *
 * The ceiling that actually protects the bill is the SPEND CAP, which is unchanged and enforced per turn
 * elsewhere. These numbers govern how much work one question may do under that cap, not how much money it
 * may cost, and they were the wrong lever to hold tight.
 *
 * `wallMs` rises with them because a turn that is allowed twice the calls and is then cut off by the clock
 * has been given nothing: it would spend the extra calls and return the half-finished answer it was about
 * to improve.
 */
export const AGENT_CAPS = Object.freeze({ maxSteps: 12, maxToolCalls: 24, wallMs: 75_000, answerMaxChars: 4000 });

const REF_RE = /\[R(\d{1,3})\]/g;
const NUMBER_RE = /-?\d+(?:\.\d+)?/g;
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

// The one tool-free call at the step cap, its usage counted with the turn's.
async function closingAnswer(chat, system, transcript, usage) {
  const closing = await chat.chatOnce({ system, messages: [...transcript, { role: 'user', content: STEP_CAP_CLOSING }], tools: [] });
  usage.input_tokens += closing.usage?.input_tokens || 0;
  usage.output_tokens += closing.usage?.output_tokens || 0;
  return closing.message?.content || '';
}

// What the loop asks when every step went on tools and no answer came (VH-777 Lane T).
const STEP_CAP_CLOSING = 'You have used every step this turn allows. Do not call tools. Reply now with ONE JSON object answering from what the tools have returned, and say plainly what you could not finish.';

/** The closing instruction: how the final answer must be shaped so it can be verified. */
export const FINAL_ANSWER_RULES = 'When you have what you need, reply with ONE JSON object and nothing else: '
  + '{"answer": "<your reply in plain UK English, everyday words and no jargon, citing records as [R1], [R2] using the ref numbers the tools returned>", '
  + '"cited": ["<record id>", ...], "entities": ["<every organisation you name>", ...], "numbers": [<every figure you state about records>, ...]}. '
  + 'Cite only records a tool returned this turn; name only organisations a tool returned; a figure about records (how many companies, a record\'s own values) must appear in a tool result. '
  // VH-777 Lane T: the app and its help are answered freely, and said where they came from.
  + 'Questions about the app itself, how to use it and what its screens and terms mean are answered from search_help, describe_app and app_state, saying which help entry or guide section the answer came from, or from what you know, plainly marked as general knowledge. '
  + 'If the tools returned nothing that answers the question, say so in the answer rather than answering from memory. '
  + 'A propose_scan, propose_update or propose_view result is a PROPOSAL for the operator to confirm on screen; never say it has run or been applied. '
  // The offer is worth nothing if the prose then says "press Apply on the board": the operator sees ONE
  // popup, so the answer has to read as an offer, not as an instruction to go and find a control.
  + 'After a propose_view, write the answer as prose that stands on its own and mention that you can show it; the app raises the consent popup itself. '
  // The web half of the contract, and it is enforced rather than asked: an unsourced link fails verification.
  + 'Anything you learned from web_lookup must be attributed IN THE ANSWER to the source url the lookup '
  + 'returned, quoted exactly, and must never be stated as the dataset\'s own figure. Do not write a url that '
  + 'no lookup returned.';

// Parse the model's final text as the structured answer, or fold plain prose into the shape with nothing
// declared (which the verifier then checks from the text alone).
export function parseFinal(text) {
  const raw = String(text || '').trim();
  const obj = jsonObjectIn(raw);
  if (obj && typeof obj.answer === 'string') {
    return {
      answer: obj.answer.slice(0, AGENT_CAPS.answerMaxChars),
      cited: stringList(obj.cited),
      entities: stringList(obj.entities),
      numbers: (Array.isArray(obj.numbers) ? obj.numbers : []).map(Number).filter(Number.isFinite).slice(0, 50),
      structured: true,
    };
  }
  return { answer: raw.slice(0, AGENT_CAPS.answerMaxChars), cited: [], entities: [], numbers: [], structured: false };
}

// The first `{...}` span of the text parsed as a JSON object, or null. Tolerates prose around the object.
function jsonObjectIn(raw) {
  const start = raw.indexOf('{');
  const end = raw.lastIndexOf('}');
  if (start < 0 || end <= start) return null;
  try {
    const obj = JSON.parse(raw.slice(start, end + 1));
    return isObj(obj) ? obj : null;
  } catch { return null; }
}
const stringList = (v) => (Array.isArray(v) ? v : []).filter((x) => typeof x === 'string').slice(0, 50);

// The http(s) links in the answer, trimmed of the punctuation that ends a sentence. Deliberately narrow:
// only a full absolute url counts, because that is what a lookup returns and what the operator can check.
// CASE-INSENSITIVE, and a security gate proved why with one probe: without the `i` flag `urlsInText` cannot
// see `HTTPS://evil.example/fabricated`, so `verifyAnswer` reported no violation and a fabricated source
// reached the operator presented as checked, while the lowercase form was caught. A scheme is
// case-insensitive per RFC 3986, so the pattern has to be too.
const URL_RE = /https?:\/\/[^\s<>"')\]]+/gi;
function urlsInText(answer) {
  // The trailing-punctuation trim is BOUNDED: `[.,;:!?]+$` on an unbounded string backtracks, which is a
  // super-linear pattern over model output, and nothing real ends a url with eight punctuation marks.
  return [...new Set([...String(answer || '').matchAll(URL_RE)].map((m) => m[0].replace(/[.,;:!?]{1,8}$/, '')))];
}

// A FIGURE ABOUT RECORDS (VH-777 Lane T): a figure in a sentence citing a record, or one followed within four words by
// a word for records. "12 vendors", "3 Space companies", "40% of the companies" and "9 in GDM" are record figures;
// "7 domains", "4.5:1 contrast" and "1 of 4 formats" are about the app and are answered freely.
const RECORD_WORDS = new Set(['vendor', 'vendors', 'company', 'companies', 'record', 'records', 'supplier', 'suppliers', 'provider',
  'providers', 'organisation', 'organisations', 'firm', 'firms', 'match', 'matches', 'gdm', 'result', 'results']);
const RECORD_WINDOW = 4;
// A figure at the start of a word, thousands commas and all ("1,204"); the commas are dropped before it is read.
const FIGURE = /^-?\d[\d,]*(?:\.\d+)?/;
const RECORD_ID = /\b[A-Z]{1,4}-\d{2,6}\b/;

/** The figures about records in an answer's text, each once per mention, in order. */
export function recordFiguresInText(answer) {
  const text = String(answer || '').replaceAll(URL_RE, ' ');
  const out = [];
  for (const sentence of text.split(/[.!?]\s+|\n+/)) {
    const citing = /\[R\d{1,3}\]/.test(sentence) || RECORD_ID.test(sentence);
    const tokens = sentence.replaceAll(REF_RE, ' ').replaceAll(/\b[A-Z]{1,4}-\d{2,6}\b/g, ' ').split(/\s+/).filter(Boolean);
    tokens.forEach((token, i) => {
      const m = FIGURE.exec(token);
      if (!m) return;
      const near = tokens.slice(i + 1, i + 1 + RECORD_WINDOW).some((w) => RECORD_WORDS.has(w.toLowerCase().replaceAll(/[^a-z]/g, '')));
      if (citing || near) out.push(Number(m[0].replaceAll(',', '')));
    });
  }
  return out.filter(Number.isFinite);
}

/**
 * Verify a parsed final answer against the ledger. Returns `{ ok, violations }`, each violation a plain
 * sentence the model can act on and the operator can read. References, cited ids and figures are read from
 * the answer TEXT as well as the declared lists; names are read from the declared `entities` list only, so a
 * name in the prose that the model left undeclared is not caught here (V1.77 security gate MINOR, recorded
 * in docs/RESIDUALS.md for V1.78).
 */
export function verifyAnswer(parsed, ledger) {
  const violations = [];
  for (const m of parsed.answer.matchAll(REF_RE)) {
    if (!ledger.hasRef(Number(m[1]))) violations.push(`reference [R${m[1]}] was not returned by any tool`);
  }
  // A LINK IS A CLAIM (V1.79). Hugo can now reach the web, and the whole point of requiring a source url in
  // a web answer is defeated if the model can write a plausible one. Every http(s) link in the answer has to
  // be one a TOOL returned. Read from the TEXT, because that is where the operator will click it. An answer
  // carrying no link is checked in zero iterations, which is every dataset-only turn, so this costs nothing
  // on the ordinary path - the previous comment here claimed a conditional skip that was never in the code,
  // corrected after an engineering gate read the two against each other.
  //
  // `hasLink`, NOT `hasSource`: the link set holds every url ANY tool returned, the source set only the ones
  // a web lookup returned. The verifier's question is "did a tool show you this", so it is the link set; the
  // audit row's question is "which hosts did this turn reach", so that is the source set. Conflating them
  // failed an honest answer that quoted a record's own `evidence` url. `hasSource` is the fallback so a
  // hand-rolled ledger in a test is still checked rather than silently waved through.
  const linkKnown = (url) => (typeof ledger.hasLink === 'function' ? ledger.hasLink(url) : ledger.hasSource?.(url) === true);
  for (const url of urlsInText(parsed.answer)) {
    if (!linkKnown(url)) violations.push(`the source ${url} was not returned by any tool`);
  }
  for (const id of parsed.cited) if (!ledger.hasId(id)) violations.push(`record ${id} was not returned by any tool`);
  for (const name of parsed.entities) if (!ledger.hasName(name)) violations.push(`"${name}" was not returned by any tool`);
  // Every figure the model declares, and every figure ABOUT RECORDS in the text (VH-777 Lane T); a figure about the app
  // or how to use it is answered freely, from the help and the app's own tools or from what Hugo knows.
  for (const n of [...parsed.numbers, ...recordFiguresInText(parsed.answer)]) {
    if (!ledger.hasNumber(n)) violations.push(`the figure ${n} appears in no tool result`);
  }
  return { ok: violations.length === 0, violations: [...new Set(violations)].slice(0, 20) };
}

// A bounded, operator-readable summary of one tool step for the trail.
function stepSummary(call, outcome) {
  const args = JSON.stringify(call.args).slice(0, 300);
  const result = outcome.ok ? JSON.stringify(outcome.result).slice(0, 300) : outcome.error;
  return { tool: call.name, args, ok: outcome.ok, result };
}

// The model's tool calls, parsed: name and arguments (arguments arrive as a JSON string).
function parseToolCalls(message) {
  return (message?.tool_calls || []).map((tc) => {
    let args = {};
    try { args = JSON.parse(tc?.function?.arguments || '{}'); } catch { args = {}; }
    return { id: String(tc?.id || ''), name: String(tc?.function?.name || ''), args: isObj(args) ? args : {} };
  });
}

/**
 * Run the loop. `chat.chatOnce` is the model; `runner` the bound tool layer. Returns
 * `{ answer, steps, citations, verification, usage, model: true, fallback: false }`. Never throws on a
 * verification failure; a provider throw propagates so the route can fall back deterministically.
 */
export async function runHugoAgent({ chat, runner, system, messages, caps = AGENT_CAPS, now = Date.now, onEvent = null }) {
  const startedAt = now();
  const transcript = [...messages];
  const steps = [];
  const usage = { input_tokens: 0, output_tokens: 0 };
  let toolCalls = 0;
  let finalText = '';
  // The LAST confirm-first proposal of the turn, surfaced structurally rather than left buried in `steps`
  // for a client to parse. The last one wins deliberately (owner decision, V1.79): a second offer REPLACES
  // the first, because two consent popups stacked over one another is how an operator taps the wrong one.
  let proposal = null;
  for (let step = 0; step < caps.maxSteps; step += 1) {
    const outOfTime = now() - startedAt > caps.wallMs;
    const allowTools = !outOfTime && toolCalls < caps.maxToolCalls;
    const turn = await chat.chatOnce({ system, messages: transcript, tools: allowTools ? runner.defs : [], toolChoice: 'auto' });
    usage.input_tokens += turn.usage?.input_tokens || 0;
    usage.output_tokens += turn.usage?.output_tokens || 0;
    const calls = parseToolCalls(turn.message);
    if (calls.length === 0) { finalText = turn.message.content; break; }
    transcript.push({ role: 'assistant', content: turn.message.content || null, tool_calls: turn.message.tool_calls });
    const ran = await runToolCalls(calls, { runner, caps, transcript, steps, spent: toolCalls, onEvent });
    toolCalls = ran.spent;
    if (ran.proposal) proposal = ran.proposal;
  }
  // THE STEP CAP NEVER ENDS IN SILENCE (VH-777 Lane T). A turn that spent every step on tools used to reach `finalise`
  // with no text, which parsed to an EMPTY answer and was marked verified. It now asks once more, with no tools, for the
  // answer from what the tools returned.
  if (!finalText) finalText = await closingAnswer(chat, system, transcript, usage);
  return { ...(await finalise({ chat, runner, system, transcript, finalText, steps, usage })), proposal };
}

/**
 * Run one turn's tool calls: each result is summarised into `steps` and appended to `transcript` as its
 * `tool` turn, so the next model turn is well formed. Returns the running tool-call count and the last
 * confirm-first proposal among them.
 *
 * Split from the loop above for the complexity budget, and it reads better as its own unit: the loop's job
 * is the conversation, this function's job is the calls.
 */
// One progress event to a listener that may be absent or may throw; a listener never fails the turn.
function notify(onEvent, event) {
  if (typeof onEvent !== 'function') return;
  try { onEvent(event); } catch { /* the turn goes on */ }
}

// THE TOOLS THAT NUMBER RECORDS RUN IN THE MODEL'S ORDER (VH-777 Lane T). Each enters the records it returns in the
// ledger, which numbers them [R1], [R2] in the order they arrive; run together, the numbers would follow whichever read
// finished first, so the same question could cite different numbers, and the eval's recorded replays would miss.
const ORDERED_TOOLS = new Set(['query_records', 'get_record', 'find_similar', 'explain_match']);

/**
 * Run one turn's calls TOGETHER (VH-777 Lane T): a turn asking for the help, a count and the web waits for the slowest
 * of them, not their sum. The tools that number records run one after another, in the model's order, alongside the
 * rest. A call past the turn's tool budget is refused. Each outcome is then recorded in the model's order.
 */
function runTogether(calls, runner, firstNumber, budget) {
  let ordered = Promise.resolve();
  return Promise.all(calls.map((call, i) => {
    if (firstNumber + i > budget) return { ok: false, error: 'tool budget for this turn is spent' };
    if (!ORDERED_TOOLS.has(call.name)) return runner.run(call.name, call.args);
    const run = ordered.then(() => runner.run(call.name, call.args));
    ordered = run;
    return run;
  }));
}

async function runToolCalls(calls, { runner, caps, transcript, steps, spent, onEvent = null }) {
  let proposal = null;
  const outcomes = await runTogether(calls, runner, spent + 1, caps.maxToolCalls);
  for (const [i, call] of calls.entries()) {
    const outcome = outcomes[i];
    steps.push(stepSummary(call, outcome));
    // THE TURN SAYS WHAT IT IS DOING AS IT GOES (VH-777 Lane T): the tool and whether it answered, never a result, so a
    // streamed turn shows progress while the answer itself is still checked before anyone sees it.
    notify(onEvent, { type: 'step', tool: call.name, ok: outcome.ok === true });
    if (isProposal(runner, call.name, outcome)) proposal = { tool: call.name, ...outcome.result };
    transcript.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(outcome.ok ? outcome.result : { error: outcome.error }) });
  }
  return { spent: spent + calls.length, proposal };
}

/**
 * Whether one tool outcome is a confirm-first PROPOSAL the client should raise for consent.
 *
 * Both halves are required, and neither is redundant: the tool has to be one this layer annotates as
 * `confirm` (so a read tool cannot become a consent prompt by returning the right-looking key), and the
 * result has to actually carry `requiresConfirmation` (so a confirm tool that failed, or that answered
 * something else, does not raise a popup over nothing).
 */
function isProposal(runner, name, outcome) {
  return outcome?.ok === true
    && runner.modeOf?.(name) === 'confirm'
    && isObj(outcome.result)
    && outcome.result.requiresConfirmation === true;
}

// Parse, verify, retry once with the violations named, then fail closed.
async function finalise({ chat, runner, system, transcript, finalText, steps, usage }) {
  let parsed = parseFinal(finalText);
  // An empty answer is never a verified one (VH-777 Lane T): nothing was said, so there is nothing to vouch for.
  const verify = (p) => (p.answer.trim() ? verifyAnswer(p, runner.ledger) : { ok: false, violations: ['the answer was empty'] });
  let check = verify(parsed);
  let retried = false;
  if (!check.ok) {
    retried = true;
    const correction = 'Your answer could not be verified against the tool results: ' + check.violations.join('; ')
      + '. Reply again with ONE JSON object, correcting or removing each item above. Do not call tools.';
    const turn = await chat.chatOnce({ system, messages: [...transcript, { role: 'assistant', content: finalText || '' }, { role: 'user', content: correction }], tools: [] });
    usage.input_tokens += turn.usage?.input_tokens || 0;
    usage.output_tokens += turn.usage?.output_tokens || 0;
    parsed = parseFinal(turn.message.content);
    check = verify(parsed);
  }
  const citations = runner.ledger.refs.filter((r) => parsed.answer.includes(`[R${r.ref}]`) || parsed.cited.includes(r.id));
  // `sources` IS FOR THE AUDIT ROW (V1.79 engineering gate). The route used to regex hosts out of the step
  // trail, whose result strings are truncated to 300 characters, so a search citation was cut away and
  // recorded as no host at all while any url inside a fetched page's prose was recorded as a host Hugo
  // reached. Wrong in both directions on the only record of the reach. The ledger already holds exactly the
  // right set: the urls a web lookup returned, and nothing else.
  const sources = runner.ledger.sourceList;
  if (check.ok) {
    return { answer: parsed.answer, steps, citations, sources, verification: { ok: true, retried, violations: [] }, usage, model: true, fallback: false };
  }
  // FAIL CLOSED: nothing unverified reaches the operator. What the tools did return is offered in its place.
  const verified = runner.ledger.refs.slice(0, 10).map((r) => `${r.name || r.id} [R${r.ref}]`).join(', ');
  const answer = 'I could not verify part of that answer against the dataset, so I have not given it. '
    + (verified ? 'What the lookup did return: ' + verified + '.' : 'The lookup returned no records to answer from.');
  return { answer, steps, citations: runner.ledger.refs.slice(0, 10), sources, verification: { ok: false, retried, violations: check.violations }, usage, model: true, fallback: false };
}

// A CONVERSATIONAL FLOOR (VH-777). With no model, "hey hugo" was answered "I could not read that as a question about
// the dataset", which read as Hugo not working at all (the owner, 2026-10-20). A greeting, thanks or "what can you do"
// is now answered as Hugo would answer it, and says what still works. Only a message that is wholly one of these:
// "hi, vendors in Sweden" is still a dataset question. The examples are questions the resolver reads.
const SMALL_TALK = [
  ['greeting', /^(hi|hello|hey|hiya|hey there|hello there|good (morning|afternoon|evening)|morning|evening|how are you( doing)?|are you there)$/],
  ['thanks', /^(thanks|thank you|thanks a lot|thank you very much|cheers|ta)$/],
  ['about', /^(who are you|what are you|what can you do|what do you do|help|can you help( me)?|how do i use (you|this)|what is this)$/],
];

function smallTalkKind(question) {
  const text = String(question || '').toLowerCase().replaceAll(/[^a-z ]+/g, ' ').replaceAll(/\bhugo\b/g, ' ').replaceAll(/\s+/g, ' ').trim();
  return SMALL_TALK.find(([, re]) => re.test(text))?.[0] || null;
}

function smallTalkAnswer(kind, scope) {
  if (kind === 'thanks') return 'You are welcome. Ask me about the companies in ' + scope + ' whenever you like.';
  const lead = kind === 'greeting' ? 'Hello, I am Hugo.' : 'I am Hugo, the data co-pilot for this app.';
  return lead + ' My AI service is not answering just now, so I cannot chat freely, but I can still find companies in ' + scope
    + ' by country, GDM state, section or mission. For example, "companies in Sweden" or "scoped vendors not in the GDM".';
}

/**
 * The deterministic fallback: no model. The question is resolved with the same deterministic resolver the
 * chat grounding uses; when it reads as a dataset question the query tool runs and the answer is built from
 * its rows with references; otherwise the answer says so. Same result shape as the loop.
 */
export async function deterministicAnswer({ runner, question, domain }) {
  // No Space fallback (VH-280): the route names the domain, and a question read against the wrong domain's
  // vocabulary would be answered from the wrong store.
  const descriptor = getDescriptor(domain);
  if (!descriptor) throw new TypeError('deterministicAnswer needs the domain the question is asked in');
  const steps = [];
  const talk = smallTalkKind(question);
  if (talk) {
    return { answer: smallTalkAnswer(talk, descriptor.label), steps, citations: [], verification: { ok: true, retried: false, violations: [] }, usage: { input_tokens: 0, output_tokens: 0 }, model: false, fallback: true, proposal: null };
  }
  // The question's family words are read in this domain's own families (VH-785).
  const { raw, resolved, outOfData } = withFamilyScope(domain, () => resolveDeterministic(question, descriptor));
  // VH-608: a price question is refused for its real reason, so the operator is not told to rephrase a
  // question no rephrasing can answer from this data.
  const unreadable = outOfData === 'price'
    ? 'The dataset holds no prices or costs, so that question has no answer in it. Hugo can list the companies offering a capability, by country, GDM state or mission.'
    : 'I could not read that as a question about the dataset, and Hugo\'s model is not available to interpret it. Try naming a country, a GDM state, a section or a mission.';
  if (!resolved) {
    return { answer: unreadable, steps, citations: [], verification: { ok: true, retried: false, violations: [] }, usage: { input_tokens: 0, output_tokens: 0 }, model: false, fallback: true, proposal: null };
  }
  const call = { name: 'query_records', args: { domain: raw.domain || domain, filter: raw.filterSpec, limit: 10 } };
  const outcome = await runner.run(call.name, call.args);
  steps.push(stepSummary(call, outcome));
  if (!outcome.ok) {
    return { answer: 'The dataset lookup did not complete, so I have no records to answer from.', steps, citations: [], verification: { ok: true, retried: false, violations: [] }, usage: { input_tokens: 0, output_tokens: 0 }, model: false, fallback: true, proposal: null };
  }
  // THE OFFER SURVIVES WITH NO MODEL (owner decision, V1.79). The resolver already read a view cue ("on a
  // map") and a filter out of the sentence, so the same consent popup the model path raises is available
  // here, which is what lets the panel drop its separate compile-and-Apply buttons without taking the
  // board-driving away from a deployment that has no model key. It goes through `propose_view` rather than
  // building a proposal by hand, so it is the same validation and the same count as every other offer.
  const offered = await runner.run('propose_view', {
    view: raw.view || 'board', domain: raw.domain || domain, filter: raw.filterSpec, reason: '',
  });
  const proposal = offered.ok && offered.result?.requiresConfirmation === true ? { tool: 'propose_view', ...offered.result } : null;
  return { answer: describeRows(outcome.result), steps, citations: runner.ledger.refs, verification: { ok: true, retried: false, violations: [] }, usage: { input_tokens: 0, output_tokens: 0 }, model: false, fallback: true, proposal };
}

/**
 * THE SAME ANSWER ACROSS EVERY DOMAIN (VH-765; the owner's rule for the phone: "a HUGO interface that allows questions to
 * be asked across all domains", and his brief: "short, plain English"). The question is read against each domain's own
 * vocabulary, in registry order, and looked up in every domain it reads in. One runner, so references are numbered once
 * across the whole answer and each carries its domain; the phone groups them by it. VH-280 still holds: "all" reaches
 * here only when a caller named it, never as the default for a missing domain.
 */
export async function deterministicAnswerAll({ runner, question, domains }) {
  const steps = [];
  const found = [];
  const failed = [];
  let readable = false;
  const base = { steps, verification: { ok: true, retried: false, violations: [] }, usage: { input_tokens: 0, output_tokens: 0 }, model: false, fallback: true, proposal: null, scope: 'all' };
  const talk = smallTalkKind(question);
  if (talk) return { ...base, answer: smallTalkAnswer(talk, 'all ' + domains.length + ' domains'), citations: [] };
  const reads = domains.map((domain) => readQuestion(question, domain));
  if (reads.some((r) => r.price)) return { ...base, answer: 'The dataset holds no prices or costs, so that has no answer in it.', citations: [] };
  const asked = askedFamilies(reads);
  const noFamily = [];
  for (const read of reads) {
    const part = await answerOneDomain({ runner, read, asked, steps });
    if (part.unreadable) continue;
    readable = true;
    if (part.noFamily) noFamily.push(part.label);
    else if (part.failed) failed.push(part.label);
    else if (part.total > 0) found.push(part);
  }
  if (!readable) {
    return { ...base, answer: 'I could not read that as a question about the dataset. Try a country, a GDM state or a mission.', citations: [] };
  }
  return { ...base, answer: allDomainsText(found, failed, domains.length, noFamily), citations: runner.ledger.refs };
}

// What one domain makes of the question, in its own vocabulary and its own families (VH-785), with the family keys it holds.
function readQuestion(question, domain) {
  const descriptor = getDescriptor(domain);
  if (!descriptor) return { unreadable: true };
  return withFamilyScope(domain, () => {
    const { raw, resolved, outOfData } = resolveDeterministic(question, descriptor);
    return { domain, label: descriptor.label, raw, resolved, price: outOfData === 'price', held: hugoFamilyKeys() };
  });
}

// THE FAMILIES THE QUESTION NAMES IN ANY DOMAIN, by key (VH-785; Backlog for the owner, 2026-10-21 00:46). Each domain reads
// the question in its own families, so a family only Space holds is read only by Space. Every domain holding one of the
// keys is asked for it, by key; a domain holding none answers none and says so, rather than answering the rest of the
// question as if no family had been asked.
const askedFamilies = (reads) => [...new Set(reads.flatMap((r) => r.raw?.filterSpec?.families || []))];

// One domain's part of an all-domains answer, from its reading of the question: its own records answer it.
async function answerOneDomain({ runner, read, asked, steps }) {
  if (read.unreadable || (!read.resolved && asked.length === 0)) return { unreadable: true };
  const families = asked.filter((key) => read.held.includes(key));
  if (asked.length && families.length === 0) return { label: read.label, noFamily: true };
  const filter = asked.length ? { ...read.raw.filterSpec, families } : read.raw.filterSpec;
  // Counted first when a family is asked: a store that files none of its types under it answers none, as a cross-domain
  // query does (`storePart` in src/api-v3.js), and a count enters no record in the references the answer cites.
  if (asked.length) {
    const count = { name: 'count_records', args: { domain: read.domain, filter } };
    const counted = await runner.run(count.name, count.args);
    steps.push(stepSummary(count, counted));
    if (!counted.ok) return { label: read.label, failed: true };
    if ((counted.result.notApplied || []).includes('families')) return { label: read.label, noFamily: true };
  }
  const call = { name: 'query_records', args: { domain: read.domain, filter, limit: 10 } };
  const outcome = await runner.run(call.name, call.args);
  steps.push(stepSummary(call, outcome));
  if (!outcome.ok) return { label: read.label, failed: true };
  return { label: read.label, total: outcome.result.total, refs: outcome.result.records.map((r) => r.ref) };
}

// The all-domains answer in short sentences: the total, then each domain with its count and references, then the rest,
// then the domains that hold no such family.
function allDomainsText(found, failed, count, noFamily = []) {
  const unread = failed.length ? ' ' + failed.join(', ') + ' could not be read.' : '';
  const verb = noFamily.length === 1 ? ' holds' : ' hold';
  const none = noFamily.length ? ' ' + noFamily.join(', ') + verb + ' no such family.' : '';
  if (!found.length) return 'No companies match in any of the ' + count + ' domains.' + none + unread;
  const sum = found.reduce((n, f) => n + f.total, 0);
  const parts = found.map((f) => f.label + ': ' + f.total + (f.refs.length < f.total ? ' (showing ' + f.refs.length + ')' : '')
    + ' ' + f.refs.map((r) => '[R' + r + ']').join(' '));
  const others = count - found.length - failed.length - noFamily.length;
  const noun = others === 1 ? ' domain has none.' : ' domains have none.';
  const rest = others > 0 ? ' The other ' + others + noun : '';
  const head = sum === 1 ? '1 company matches. ' : sum + ' companies match. ';
  return head + parts.join('. ') + '.' + rest + none + unread;
}

// The fallback's answer text from a query_records result: the count, the clauses that applied, and the
// listed records with their references.
function describeRows({ total, records, applied }) {
  const scope = applied.length ? ' (' + applied.join(', ') + ')' : '';
  if (total === 0) return `No records match${scope}.`;
  const listed = records.map((r) => {
    const where = r.country ? ' (' + r.country + ')' : '';
    return `${r.name || r.id}${where} [R${r.ref}]`;
  }).join('; ');
  const noun = total === 1 ? 'record matches' : 'records match';
  const partial = records.length < total ? ', showing ' + records.length : '';
  return `${total} ${noun}${scope}${partial}: ${listed}.`;
}
