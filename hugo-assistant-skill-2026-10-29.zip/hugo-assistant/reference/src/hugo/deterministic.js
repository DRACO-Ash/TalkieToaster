// The deterministic-first ViewIntent resolver (docs/PLAN-hugo-query-drive.md, item B). Before any model call,
// Hugo resolves the COMMON phrasings offline: it reads the operator's free text against the active domain's
// controlled vocabulary, the country canon and the family taxonomy, and emits a raw ViewIntent the validator
// (view-intent.js) then normalises. The common cases ("the SAR vendors in the UK not in the GDM, on a map")
// resolve here with NO egress and NO cost; the model is reached only for the messy middle (a later unit), and
// its output is validated through the exact same normaliser, so the deterministic and model paths cannot
// diverge on what is admissible.
//
// This is a first pass, not a parser: it is deliberately liberal, because the owner's decision is CONFIRM
// FIRST (the operator reviews the interpreted intent before it ever touches the live filters), so a slightly
// greedy match costs a glance, never a wrong view. It never widens policy and never invents a value; every
// value it emits is checked again by the validator against the descriptor, so a stray match is dropped there,
// not honoured.

import { isRecognisedCountry, isIsoFillName, canonicalCountry, canonicalCountries } from '../domain/country-canon.js';
import { resolveAreaName } from '../domain/areas.js';
import { familiesInText } from './families.js';
import { missionNamesFor } from '../domain/mission-alignment.js';

// The vocabulary name Hugo reads a mission against: each domain's Mission Alignment list (VH-801).
const JCO_MISSIONS = 'jco_missions';
const CAP_TEXT = 2000;

/**
 * READING A MISSPELT PLACE NAME (owner, 2026-09-19: Hugo "can't accept poor spelling").
 *
 * TRIGRAM JACCARD WAS THE OBVIOUS TOOL AND THE MEASUREMENT REJECTED IT. The duplicate detector matches
 * misspelt COMPANY names that way and does it well, so reusing it here looked like free work. Measured on
 * this canon: "Germny" against "Germany" scores 0.29 while "Niger" against "Nigeria" scores 0.60. Any
 * threshold low enough to read the typo would fold two real countries together, which is the one outcome
 * worth being strict about - answering confidently about the wrong country is worse than answering about
 * none. Trigrams need length, and country names are short.
 *
 * EDIT DISTANCE INSTEAD, and what keeps a REAL country from being read as a different real country is
 * NEAREST-WINS: a recognised name is distance 0 from itself, and no other candidate can beat that. The
 * canon holds pairs one edit apart - Ireland/Iceland, Nigeria/Niger - and every one of them is safe for
 * that reason. (This note claimed the protection came from trying the canon first. It does not: removing
 * exact-first was measured and changed no verdict, because distance 0 still won. Exact-first stays because
 * it is cheaper and because a multi-word name should not be re-guessed, not because it is the guard.)
 *
 * The two guards that DO change verdicts:
 *  1 THE BEST MATCH MUST BE UNIQUE. A token equally close to two countries is a question, not an answer.
 *    Measured: "panada" is one edit from Canada and one from Panama, and resolves to neither. ("banada"
 *    looks like the same case and is not - one edit from Canada, two from Panama, so Canada rightly wins.)
 *  2 LENGTH AND BOUND. Nothing shorter than five characters is guessed at, because at four characters one
 *    edit is most of the word; the bound is one edit at five characters and two beyond. Six-and-two was
 *    measured wrong and corrected: "Frnace" is six characters and two edits from France, so the tighter
 *    bound silently refused the most ordinary transposition there is.
 *
 * Measured, not remembered: Germny->Germany is 1, Polnd->Poland 1, Frnace->France 2, Untied Kingdom->
 * United Kingdom 2, and the pairs guard 1 excludes (Iran/Iraq 1, Niger/Nigeria 2) never arrive.
 *
 * AND A FUZZY HIT IS NEVER SILENT. `resolveDeterministic` returns what it read and what it read it from,
 * so the confirm surface says "read as Germany" instead of pretending the operator typed it.
 */
const MIN_FUZZY_LENGTH = 5;
const fuzzyBound = (word) => (word.length <= 5 ? 1 : 2);

/** Levenshtein distance, bounded: returns `cap + 1` as soon as it cannot come in at or under `cap`. */
function editDistance(a, b, cap) {
  if (Math.abs(a.length - b.length) > cap) return cap + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i += 1) {
    const cur = [i];
    let best = i;
    for (let j = 1; j <= b.length; j += 1) {
      cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      if (cur[j] < best) best = cur[j];
    }
    if (best > cap) return cap + 1; // no completion of this row can still come in under the bound
    prev = cur;
  }
  return prev[b.length];
}

/**
 * The one country a misspelt token unambiguously means, or ''.
 * @param {string} token the operator's word, already known NOT to be a recognised country
 * @param {string[]} canon every canonical country name
 */
export function closestCountry(token, canon) {
  // A non-string is not a word: refused, not coerced. Same shape that failed the V1.98 upload.
  const word = (typeof token === 'string' ? token : '').trim().toLowerCase();
  if (word.length < MIN_FUZZY_LENGTH) return '';
  const cap = fuzzyBound(word);
  let best = '';
  let bestAt = cap + 1;
  let tied = false;
  for (const country of canon) {
    const d = editDistance(word, country.toLowerCase(), cap);
    if (d > cap) continue;
    if (d < bestAt) { bestAt = d; best = country; tied = false; } else if (d === bestAt) tied = true;
  }
  return tied ? '' : best; // guard 2: ambiguity is a question, not an answer
}

/**
 * The one name a misspelt search phrase unambiguously means, or '' (VH-146). The SAME matcher and the SAME
 * bounds as `closestCountry` above: nothing shorter than five characters is guessed at, one edit at five and
 * two beyond, and a tie is a question rather than an answer. A phrase is compared with every run of the same
 * number of consecutive words in each name, so "nordic radr" meets "nordic radar" inside "Nordic Radar AB".
 * The caller OFFERS the result; it never searches with it silently.
 * @param {string} phrase the operator's search text, which matched nothing
 * @param {string[]} names every searchable organisation name
 */
export function closestName(phrase, names) {
  const words = (typeof phrase === 'string' ? phrase : '').trim().toLowerCase().split(/\s+/).filter(Boolean);
  const text = words.join(' ');
  if (text.length < MIN_FUZZY_LENGTH) return '';
  const cap = fuzzyBound(text);
  let best = '';
  let bestAt = cap + 1;
  let tied = false;
  for (const name of Array.isArray(names) ? names : []) {
    if (typeof name !== 'string' || name === '') continue;
    const d = bestWindowDistance(text, words.length, name.toLowerCase().split(/\s+/).filter(Boolean), cap);
    if (d > cap) continue;
    if (d < bestAt) { bestAt = d; best = name; tied = false; } else if (d === bestAt && name.toLowerCase() !== best.toLowerCase()) tied = true;
  }
  return tied ? '' : best;
}

function bestWindowDistance(text, width, tokens, cap) {
  let best = cap + 1;
  for (let i = 0; i + width <= tokens.length; i += 1) {
    const d = editDistance(text, tokens.slice(i, i + width).join(' '), cap);
    if (d < best) best = d;
  }
  return best;
}

// Clause -> descriptor vocabulary. gdm is handled separately (it has natural-language negation, "not in the
// GDM"); the rest are matched by looking for the controlled value itself in the text.
//
// `grades` left this table in V1.80 with the readiness axis. It mattered here more than anywhere: this
// resolver reads any mention of a controlled value as a filter, so an injection carrying the words
// "In JCO" became a grade narrowing. The Hugo eval suite measured that as its one altered query, and
// removing the vocabulary took injection resistance from 0.50 to 1.00.
const VOCAB_CLAUSES = Object.freeze([
  { clause: 'sections', vocab: 'section' },
  // VH-801: a mission is one of the domain's Mission Alignment missions, not the old per-vendor vocabulary.
  { clause: 'missions', vocab: JCO_MISSIONS },
  { clause: 'productTypes', vocab: 'product_types' },
]);

// View cues, ordered so a geographic or distribution cue wins over a bare "show me". A query with no view cue
// resolves to '' and the caller picks a sensible default by query shape.
const VIEW_RULES = Object.freeze([
  [/\bon (?:a|the) map\b|\bmap\b|\bwhere (?:are|is)\b|\bwhich countries\b|\blocated?\b|\bby country\b/i, 'map'],
  [/\bgaps?\b|\bcoverage\b|\bbreakdown\b|\bchart\b|\bhow many\b|\bdistribution\b|\btrend|\bgrowth\b|\bagainst\b/i, 'analytics'],
  // The pipeline view (V1.77 W1-3), ahead of `board` and behind `analytics`: "how many are stuck" is a
  // distribution question and belongs on Analytics, while "what is stuck" is a work queue. A pipeline cue
  // beats a bare "list" because the pipeline view IS a list, and a better one for these questions.
  [/\bpipeline\b|\bonboarding\b|\bstages?\b|\bstuck\b|\bblocked\b|\boverdue\b|\bmy plate\b|\bwork next\b/i, 'pipeline'],
  [/\blist\b|\btable\b|\bboard\b|\bspreadsheet\b/i, 'board'],
]);

/**
 * THE PIPELINE PHRASES (V1.77 W1-3). The clauses landed in the query plan and the validator first; without
 * these an operator could reach them through the API and the confirm surface but not by asking.
 *
 * Two rules shape this table. The FIRST is that a stage is matched by the words people use, not by the
 * schema's identifier: nobody types "technical_evaluation". The second is that a phrase resolves to the
 * schema value, so the validator's vocabulary check still governs and a phrase whose value later leaves the
 * schema stops resolving rather than silently filtering on a value the column refuses.
 *
 * Deliberately liberal, like the rest of this pass, because the owner's decision is CONFIRM FIRST: a greedy
 * match costs a glance at the review, never a wrong query.
 */
const STAGE_PHRASES = Object.freeze([
  [/\bunengaged\b|\bnot (?:yet )?(?:been )?(?:approached|contacted)\b|\buntouched\b/i, 'unengaged'],
  [/\bidentified\b|\bon the (?:long ?list|radar)\b/i, 'identified'],
  [/\bcontacted\b|\breached out\b|\bin conversation\b/i, 'contacted'],
  [/\bnda\b|\bnon-disclosure\b/i, 'nda'],
  [/\btechnical evaluation\b|\btech(?:nical)? eval\b|\bunder evaluation\b|\bbeing evaluated\b/i, 'technical_evaluation'],
  [/\bdata contract\b|\bdata agreement\b/i, 'data_contract'],
  [/\bcontracting\b|\bin contract\b|\bwith legal\b/i, 'contracting'],
  [/\blive\b|\bonboarded\b|\bin (?:the )?gdm already\b|\bdelivering\b/i, 'live'],
  [/\bpaused\b|\bon hold\b/i, 'paused'],
  [/\bdeclined\b|\bsaid no\b|\bturned (?:us )?down\b/i, 'declined'],
  [/\boffboarded\b|\bleft the gdm\b|\bremoved from the gdm\b/i, 'offboarded'],
]);

// The blocker kinds, by the words a lead uses for them rather than the schema key.
const BLOCKER_PHRASES = Object.freeze([
  [/\bunresponsive\b|\bnot (?:replying|responding)\b|\bno (?:reply|response)\b|\bghosted\b/i, 'vendor_unresponsive'],
  [/\blegal\b|\bcounsel\b|\bcontract review\b/i, 'legal'],
  [/\bsecurity\b|\bvetting\b|\bclearance\b/i, 'security'],
  // NOT followed by "eval": "in technical evaluation" is a STAGE, and matching the technical BLOCKER on it
  // narrowed the query to blocked-on-technical vendors, which is not what was asked. Measured on
  // "who has been in technical evaluation over 60 days", which returned both readings.
  [/\btechnical\b(?!\s+eval)|\bintegration\b|\bapi\b/i, 'technical'],
  [/\bcommercial\b|\bpricing\b|\bcost\b|\bbudget\b/i, 'commercial'],
  [/\bexport control\b|\bitar\b|\bear\b|\blicence\b|\blicense\b/i, 'export_control'],
  [/\bcapacity\b|\bresourcing\b|\bour (?:own )?side\b/i, 'internal_capacity'],
]);

const PRIORITY_PHRASES = Object.freeze([
  [/\bhigh priority\b|\btop priority\b|\burgent\b/i, 'High'],
  [/\bmedium priority\b/i, 'Medium'],
  [/\blow priority\b/i, 'Low'],
]);

// A relative due window. `none` is "nobody has scheduled it", which is a different question from "not
// overdue" and is asked as often.
const DUE_PHRASES = Object.freeze([
  [/\boverdue\b|\bpast due\b|\blate\b|\bslipped\b/i, 'overdue'],
  [/\bdue today\b|\btoday\b/i, 'today'],
  [/\bthis week\b|\bdue (?:in|within) (?:a|the|7) ?(?:week|days)\b|\bnext 7 days\b/i, 'week'],
  [/\bthis month\b|\bdue (?:in|within) (?:a|the) month\b|\bnext month\b/i, 'month'],
  [/\bno due date\b|\bunscheduled\b|\bnot scheduled\b|\bno date\b/i, 'none'],
]);

// "blocked" and "not blocked" are the same word with a negation in front of it, so the negative is tested
// FIRST: testing the positive first would match "not blocked" as blocked, which is the opposite filter.
const NOT_BLOCKED_RE = /\b(?:not|un)[- ]?blocked\b|\bnothing blocking\b|\bno blockers?\b/i;
const BLOCKED_RE = /\bblocked\b|\bstuck\b|\bblockers?\b|\bheld up\b/i;

// "for more than N days/weeks/months in the same stage". The unit is converted here so the clause is always
// days, which is what the query plan binds.
const AGEING_RE = /\b(?:more than|over|longer than|at least|for)\s+(\d{1,4})\s*(day|week|month)s?\b/i;
const AGEING_UNIT_DAYS = Object.freeze({ day: 1, week: 7, month: 30 });

// The first phrase whose pattern matches, or ''. Ordered tables, so an earlier entry wins deliberately.
function firstPhrase(text, table) {
  for (const [re, value] of table) {
    if (re.test(text)) return value;
  }
  return '';
}

// EVERY phrase whose pattern matches, deduped: "paused or declined" is one question with two stages in it.
function allPhrases(text, table) {
  const out = [];
  for (const [re, value] of table) {
    if (re.test(text) && !out.includes(value)) out.push(value);
  }
  return out;
}

/**
 * Read the pipeline clauses out of free text into a raw filterSpec. Written onto the spec the caller already
 * holds rather than returned, so the caller's `anyFilter` check sees them without a second merge step.
 */
function addPipelinePhrases(text, filterSpec) {
  filterSpec.stages = allPhrases(text, STAGE_PHRASES);
  filterSpec.blockerKinds = allPhrases(text, BLOCKER_PHRASES);
  filterSpec.priorities = allPhrases(text, PRIORITY_PHRASES);
  const due = firstPhrase(text, DUE_PHRASES);
  if (due) filterSpec.due = due;
  // "my", "mine", "on my plate": the token the route resolves against the caller.
  if (/\bmy\b|\bmine\b|\bassigned to me\b|\bon my (?:plate|list)\b/i.test(text)) filterSpec.owners = ['me'];
  if (NOT_BLOCKED_RE.test(text)) filterSpec.blocked = false;
  else if (BLOCKED_RE.test(text)) filterSpec.blocked = true;
  const ageing = AGEING_RE.exec(text);
  if (ageing) {
    const n = Number(ageing[1]);
    const unit = AGEING_UNIT_DAYS[ageing[2].toLowerCase()] || 1;
    if (n > 0) filterSpec.ageing = n * unit;
  }
}

// Whether one filterSpec clause carries anything: a non-empty array, a non-empty string, a real boolean, or
// a positive number. Written once because the resolver and the validator both need the same answer.
function clausePopulated(v) {
  if (Array.isArray(v)) return v.length > 0;
  if (typeof v === 'boolean') return true;
  if (typeof v === 'number') return Number.isFinite(v) && v > 0;
  return typeof v === 'string' && v !== '';
}

const escapeRe = (s) => s.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);

// True when `phrase` appears in `text` delimited by a non-alphanumeric or a string boundary, case-insensitive.
// Whole-token-ish so "PAIR" does not fire on "repair"; tolerant of the punctuation real vocab carries
// (P&D SDA, TacSRT-adjacent, 5000+). Values under three characters are skipped by the caller to avoid noise.
function mentions(text, phrase) {
  const re = new RegExp('(?<![A-Za-z0-9])' + escapeRe(phrase) + '(?![A-Za-z0-9])', 'i');
  return re.test(text);
}

function vocabValues(descriptor, name) {
  if (name === JCO_MISSIONS) return [...missionNamesFor(descriptor?.id)];
  const set = descriptor?.vocab?.[name];
  if (set instanceof Set) return [...set];
  if (Array.isArray(set)) return set;
  return [];
}

// VH-706: the Data type/value chain clause also reads a role, but WITHOUT THE MODEL only a role of two or more words.
// A one-word role ("Data", "Test", "Ground") is an ordinary word in a question, and reading it narrowed "show SAR
// imagery data in Germany" on Space to the vendors whose role is "Data" (measured before this rule). A one-word role
// still reaches the filter through the model, whose intent admits either vocabulary (`view-intent.js`).
const rolesInText = (text, descriptor) => matchVocab(text, descriptor, 'chain').filter((role) => /\s/.test(role.trim()));

function matchVocab(text, descriptor, name) {
  const found = [];
  for (const val of vocabValues(descriptor, name)) {
    if (typeof val === 'string' && val.length >= 3 && mentions(text, val)) found.push(val);
  }
  return found;
}

// Resolve the GDM clause from natural language. The gdm vocabulary carries "Not in GDM" as a first-class
// value, so a negation ("not in the GDM", "outside the GDM") resolves straight to it, the same value a manual
// filter sets. Order matters: the negation test runs before the affirmative so "not in the GDM" is not read
// as "in the GDM".
function resolveGdm(text, descriptor) {
  if (!descriptor?.hasGdm) return [];
  if (/\b(?:not in|outside|missing from|absent from|excluded from)\s+(?:the\s+)?gdm\b/i.test(text)) return ['Not in GDM'];
  if (/\bonboard/i.test(text)) return ['Onboarding'];
  if (/\b(?:in|on)\s+(?:the\s+)?gdm\b|\bgdm member\b|\bin gdm\b/i.test(text)) return ['In GDM'];
  return [];
}

// Scan the text for country mentions using the app's own canon. Candidate 1-3 word n-grams are tested; a
// 2-3 character token is accepted only when it is UPPERCASE in the source (so "UK"/"USA" match but the words
// "us"/"in"/"or" do not), while longer tokens and multi-word names ("United Kingdom", "Germany") match in any
// case. Every hit is canonicalised, so Hugo's "UK" and a manual "United Kingdom" filter are byte-identical.
// The exact country a run of words starting at `i` names, or '' - the 1-to-3 word n-gram walk, extracted so
// `resolveCountries` stays inside the cognitive-complexity ceiling the SonarQube ruleset enforces.
function exactCountryAt(words, i) {
  for (let n = 3; n >= 1; n -= 1) {
    if (i + n > words.length) continue;
    const gram = words.slice(i, i + n).join(' ');
    const shortCode = gram.length <= 3 && n === 1;
    if (shortCode && gram !== gram.toUpperCase()) continue;
    // A name only the ISO fill holds is a place in a field, not in a question (owner decision, VH-005 part 2).
    if (isRecognisedCountry(gram) && !isIsoFillName(gram)) return canonicalCountry(gram);
  }
  return '';
}

function resolveCountries(text, readings) {
  const words = text.split(/[^A-Za-z]+/).filter(Boolean);
  const found = new Set();
  const unmatched = [];
  for (let i = 0; i < words.length; i += 1) {
    const exact = exactCountryAt(words, i);
    // Exact first: a word the canon recognises is taken at face value and not re-guessed. This is a cost
    // and clarity measure rather than a safety one - see `closestCountry`, where nearest-wins is what
    // actually keeps Ireland from being read as Iceland.
    if (exact) found.add(exact); else unmatched.push(words[i]);
  }
  if (!unmatched.length) return [...found];

  // THE SECOND PASS, over what the canon did not recognise. It runs only when the exact pass left
  // something over, so an ordinary question pays nothing for it.
  const canon = canonicalCountries();
  for (const word of unmatched) {
    const guess = closestCountry(word, canon);
    if (!guess || found.has(guess)) continue;
    found.add(guess);
    // NEVER SILENT. The caller hands these to the confirm surface so the operator sees "read Germny as
    // Germany" and can reject it, rather than a filter appearing with a country they did not type.
    if (Array.isArray(readings)) readings.push({ typed: word, read: guess, kind: 'country' });
  }
  return [...found];
}


/**
 * The named areas a sentence mentions: the alliances and zones in `src/domain/areas.js`, matched as whole
 * word runs the same way `resolveCountries` matches country names.
 *
 * SHORT KEYS ARE UPPER-CASE ONLY, exactly as the country matcher requires for a three-letter code, so the
 * word "eu" inside ordinary prose cannot turn a question about Europe's vendors into an EU membership
 * filter, while "EU" as typed does.
 */
function resolveAreas(text) {
  const words = text.split(/[^A-Za-z]+/).filter(Boolean);
  const found = new Set();
  for (let i = 0; i < words.length; i += 1) {
    for (let n = 3; n >= 1; n -= 1) {
      if (i + n > words.length) continue;
      const gram = words.slice(i, i + n).join(' ');
      if (gram.length <= 3 && n === 1 && gram !== gram.toUpperCase()) continue;
      const area = resolveAreaName(gram);
      if (area) { found.add(area.key); break; }
    }
  }
  return [...found];
}

/**
 * A NAME THE OPERATOR TYPED (VH-181), read without the model where the sentence marks it: quoted ("show me
 * "Flightradar24""), or after "named" or "called" as a run of capitalised words ("the firm called Open Sky
 * Network"). A bare capitalised word is NOT read as a name, because "show me the UK vendors" and "list the SAR
 * ones" are full of them; an unmarked name is the model's to read, and the confirm surface shows either.
 * Returns the name, or '' when the sentence marks none.
 */
const QUOTED_NAME_RE = /["\u201C\u201D\u2018\u2019]([^"\u201C\u201D\u2018\u2019]{2,120})["\u201C\u201D\u2018\u2019]/;
const CALLED_NAME_RE = /\b(?:named|called)\s+([A-Z0-9][\w&.-]*(?:\s+[A-Z0-9][\w&.-]*){0,5})/;
function resolveTypedName(text) {
  const quoted = QUOTED_NAME_RE.exec(text);
  if (quoted) return quoted[1].trim();
  const called = CALLED_NAME_RE.exec(text);
  return called ? called[1].trim() : '';
}

function resolveView(text) {
  // `String(view)` so the return type is unambiguously a string (S3800): VIEW_RULES is an array of
  // `[RegExp, string]` tuples, from which the destructured `view` is inferred as `RegExp | string`, and a
  // bare `return view` beside `return ''` then reads as two return types. The values are already strings, so
  // the coercion changes nothing at runtime; it states the contract the function has always kept.
  for (const [re, view] of VIEW_RULES) {
    if (re.test(text)) return String(view);
  }
  return '';
}

/**
 * THE OUT-OF-DATA GUARD (VH-608). The dataset holds no price, so a price or cost QUESTION has no answer in it.
 * Without this the liberal pass read "what is the radar price of a satellite" as a Radar filter and "how much
 * does a GNSS receiver cost" as a GNSS filter (plus a commercial blocker, since "cost" is also a blocker
 * word), and a filtered list in reply reads as an answer to a question nobody can answer from this data. Only
 * the QUESTION shapes are matched, so "blocked on pricing" stays a blocker clause the dataset does hold.
 */
const PRICE_QUESTION_RES = Object.freeze([
  /\bhow much (?:does|do|did|is|are|would|will|for)\b/i,
  /\b(?:price|prices|cost|costs)\s+(?:of|for)\b/i,
  /\bwhat (?:does|do|would|will)\b.*\bcost\b/i,
  /\bwhat(?:'s| is| are)\b.*\bprices?\b/i,
]);

/**
 * Resolve free text to a raw ViewIntent (to be normalised by normaliseViewIntent). Returns
 * { raw, resolved } where `resolved` is true when the pass found at least one filter clause or a view cue, so
 * the caller can decide whether the model is needed for the messy middle. Pure: no I/O, no model, no egress.
 */
export function resolveDeterministic(text, descriptor) {
  const t = typeof text === 'string' ? text.slice(0, CAP_TEXT) : '';
  if (PRICE_QUESTION_RES.some((re) => re.test(t))) {
    // Refused before any clause is read, so no caller can act on a half-read filter. `outOfData` names why,
    // for a reply that says what the dataset does not hold rather than that the question was unreadable.
    const domain = typeof descriptor?.id === 'string' ? descriptor.id : '';
    return { raw: { domain, filterSpec: {}, view: '', question: t }, resolved: false, readings: [], outOfData: 'price' };
  }
  // What the pass GUESSED at, as opposed to what it read exactly. Collected rather than returned inline so
  // `filterSpec` keeps the shape the validator already knows.
  const readings = [];
  const filterSpec = {
    countries: resolveCountries(t, readings),
    // AREAS, WITHOUT THE MODEL (V1.83, backlog 11a F6). "show me the NATO vendors" is as ordinary a
    // question as "show me the French ones", and it used to need a model round trip because no
    // deterministic rule knew what NATO was. `normaliseViewIntent` expands these to their member
    // countries, so nothing downstream learns a new clause.
    areas: resolveAreas(t),
    gdm: resolveGdm(t, descriptor),
    // The descriptor's own domain's families, or every domain's for a question across them (Families per domain).
    families: familiesInText(t, typeof descriptor?.id === 'string' ? descriptor.id : undefined),
    search: resolveTypedName(t),
  };
  for (const { clause, vocab } of VOCAB_CLAUSES) filterSpec[clause] = matchVocab(t, descriptor, vocab);
  filterSpec.productTypes = [...filterSpec.productTypes, ...rolesInText(t, descriptor)];
  // EACH DOMAIN'S OWN CAPABILITY FACETS (VH-263), read the way every other controlled value is: "the AIS
  // providers" on Maritime, "the LEO ones" on Space, without the model.
  for (const f of Array.isArray(descriptor?.capabilityFacets) ? descriptor.capabilityFacets : []) {
    if (typeof f?.key === 'string' && f.key) filterSpec[f.key] = matchVocab(t, descriptor, f.key);
  }
  addPipelinePhrases(t, filterSpec);

  const view = resolveView(t);
  // `.length > 0` was complete while every clause was an array. The pipeline clauses include three SCALARS
  // (`due`, `blocked`, `ageing`), and `undefined.length` would throw while `false.length` is undefined and
  // reads as no filter - so "show me what is not blocked" would have resolved to nothing and gone to the
  // model. The same defect `intentHasFilter` carried, in the module one step upstream of it.
  const anyFilter = Object.values(filterSpec).some(clausePopulated);
  const raw = {
    domain: typeof descriptor?.id === 'string' ? descriptor.id : '',
    filterSpec,
    view,
    question: t,
  };
  // `readings` rides beside the intent rather than inside it: the validator normalises `filterSpec` and
  // must not have to learn a new clause, while the confirm surface needs to know which values were guessed
  // at so it can show them as guesses. Empty on every question with no misspelling in it.
  return { raw, resolved: anyFilter || view !== '', readings };
}
