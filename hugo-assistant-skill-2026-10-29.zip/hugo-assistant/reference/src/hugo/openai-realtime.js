// Hugo's real-time VOICE front door (owner: the flagship speech-to-speech agent, "the best model available by
// OpenAI"). A server-side bridge between a same-origin browser WebSocket and OpenAI's Realtime API
// (`gpt-realtime-2`). The browser never talks to OpenAI directly: it opens a WebSocket to THIS server, the
// server opens the upstream Realtime socket with the API key, and events are relayed both ways. That keeps the
// key server-side and the locked `connect-src 'self'` Content-Security-Policy unchanged (the browser's only
// socket is same-origin), the same posture the STT/TTS voice proxy already holds.
//
// GOVERNANCE, mirrored from the other Hugo paths and enforced HERE, on the relay, not trusted to the client:
//  ● The session instructions (Hugo's persona) and the tool set are set by the SERVER on the upstream
//    `session.update`; a client-sent `session.update` (or any other configuration event) is DROPPED, so a
//    caller cannot re-instruct the model or widen its tools. Only a safelist of interaction events (audio
//    append, commit and clear, and a typed turn) is forwarded upstream. The client cannot send any `response.*`
//    event at all: the relay asks for every response itself, once the daily cap has answered for it.
//  ● Usage is read from the upstream `response.done` events and handed to `onUsage` in the same
//    `{ input_tokens, output_tokens }` shape the daily spend ledger accumulates, so voice spend is metered and
//    capped exactly like every other paid path.
//  ● Each frame is size-capped before forwarding, and a non-JSON or oversized client frame is dropped.
//
// `wsFactory` and the clock are INJECTED so the whole relay is unit-tested against a fake socket pair with no
// network and no audio. The live OpenAI socket is exercised at deployment (the build environment has no key and
// cannot reach the endpoint), the same verified-at-deploy line as the existing voice provider call.
//
// THE GENERALLY AVAILABLE INTERFACE (VH-318-B, owner 2026-10-01: Talk "does not work, or drops out"). The relay
// spoke the beta interface (the `OpenAI-Beta: realtime=v1` header, `modalities`, `input_audio_format`, a
// top-level `input_audio_transcription`), which the `openai` package marks deprecated and keeps only under its
// `beta/` path. The shapes below are read from `openai` 7.23.0's `resources/realtime/realtime.d.ts`: no beta
// header, a `session.type` of `realtime`, `output_modalities`, the audio settings under `audio.input` and
// `audio.output`, and server events renamed to `response.output_audio.delta` and
// `response.output_audio_transcript.delta`. Two relay faults went with it: client audio sent while the
// upstream was still connecting ended the session at once (the `ws` client throws on a send before open), and a
// tool answer asked for a new response while the one that made the call was still active, which the types say
// the server allows only one at a time. Whether the live service behaves as the types say is verified at
// deploy, with the key.

const REALTIME_BASE = 'wss://api.openai.com/v1/realtime';
const MAX_FRAME_BYTES = 1_000_000; // a single client frame (a base64 audio chunk) is bounded
const MAX_PENDING_BYTES = 1_000_000; // client frames held while the upstream connects, about 15s of 24kHz PCM16
const TOOL_OUTPUT_MAX = 12_000; // a tool result handed back to the realtime model is bounded too (V1.77 D6)
const AUDIO_FORMAT = Object.freeze({ type: 'audio/pcm', rate: 24000 }); // the only PCM rate the API takes

// THE SESSION CAPS (VH-318-I), OPERATOR SETTINGS SINCE THE OWNER'S RULINGS OF 2026-10-07. A realtime session had
// no bound but the operator closing it: an open microphone left on a desk kept a paid session alive. Neither
// setting depends on a price; the daily spend cap, which does, is asked before every response the relay requests.
//  ● REPLY LENGTH ("Setting, default the API maximum"): `max_output_tokens` takes "an integer between 1 and 4096
//    to limit output tokens, or `inf` for the maximum available tokens for a given model. Defaults to `inf`"
//    (openai 7.30.0 realtime.d.ts:2615-2619, and the same words in OpenAI's Realtime reference, read through
//    WebSearch 2026-10-07). So the default is 'inf', set by HUGO_TALK_MAX_OUTPUT_TOKENS. A longer reply costs
//    more, but every reply's usage is booked on the ledger and the daily cap is asked before the next one.
//  ● SESSION LENGTH ("default to 2hrs with a popup that allows a continuation of 2hrs at a time, with no upper
//    limit to extensions"): HUGO_TALK_SESSION_MINUTES, 120 by default. Before it ends the relay offers the
//    browser one more session length (`vh.session.expiring`); a `vh.session.extend` answer adds it, as often
//    as the operator likes; no answer ends the session on time with REALTIME_CAP_CLOSE_CODE, as before.
//    OPENAI'S OWN LIMIT IS SHORTER: "The maximum duration of a Realtime session is 60 minutes" (OpenAI's
//    realtime conversations guide, read through WebSearch 2026-10-07; its page is not reachable from this build).
//    So the relay ROLLS OVER (owner, 2026-10-07: "Build it in V2.8"): 55 minutes after an upstream was dialled, at
//    the first quiet moment, it opens a fresh one under the same browser socket and replays the conversation
//    (`createConversationRecord`); the browser sees no close. The 5 minutes of margin is room for a quiet moment
//    (any gap between a finished reply and the operator's next words), never mid-reply; a reply still running at
//    60 minutes is ended by the provider, and that early end is recovered by the same rollover, once.
export const REALTIME_MAX_OUTPUT_TOKENS = 'inf';
export const REALTIME_MAX_OUTPUT_TOKENS_LIMIT = 4096;
export const DEFAULT_TALK_SESSION_MINUTES = 120;
export const REALTIME_SESSION_MAX_MS = DEFAULT_TALK_SESSION_MINUTES * 60 * 1000;
export const REALTIME_CAP_CLOSE_CODE = 4008;
export const PROVIDER_SESSION_MAX_MS = 60 * 60 * 1000;
export const ROLLOVER_AFTER_MS = PROVIDER_SESSION_MAX_MS - 5 * 60 * 1000;
// How long a dial may take to open before it is treated as failed: 15 seconds, the span the held audio covers
// (MAX_PENDING_BYTES, about 15 seconds of the browser's microphone), so a hung dial is given up at about the point the
// held frames would start to drop. How long OpenAI's handshake takes is not measured from this build (no key); TBC,
// re-verify at deploy, where the close evidence (`openTimeoutMs`) says whether it was ever reached.
export const UPSTREAM_OPEN_TIMEOUT_MS = 15_000;
// The error the provider is reported to send at its limit ("session_expired", OpenAI's community forum, read through
// WebSearch 2026-10-07). It is not relied on alone: the close that follows it, or any close the relay did not ask
// for, is recovered the same way.
const sessionExpired = (event) => event?.type === 'error' && event.error?.code === 'session_expired';
// HOW LONG BEFORE THE END THE OFFER IS MADE: 5 minutes, or half the session when that is shorter. WCAG 2.2
// success criterion 2.2.1 (Timing Adjustable) asks for at least 20 seconds to extend with a simple action; 5
// minutes also lets an operator who has stepped away from the desk, or is hearing a long answer, see it in time.
// At the shortest session the setting allows, 1 minute, half is 30 seconds, still over the 20.
export const REALTIME_EXPIRY_WARNING_MS = 5 * 60 * 1000;
export const expiryLeadMs = (sessionMs) => Math.min(REALTIME_EXPIRY_WARNING_MS, Math.floor(sessionMs / 2));
// The longest session a timer can hold: a delay over 2^31 - 1 ms fires at once (Node's timers), which would end the
// session at the moment it was meant to go on. An extension arms the end for what is left (at most the warning lead,
// since the offer is made then) plus a whole session, so the setting leaves the lead's room under the limit: 35,786
// minutes, about 24 days (VH-602; 35,791 let an extension arm 2,147,760,000 ms, measured in the W37 pre-review).
export const TALK_SESSION_MINUTES_MAX = Math.floor((2 ** 31 - 1 - REALTIME_EXPIRY_WARNING_MS) / 60_000);
// The relay's own frames to the browser and the one control it takes back. They are the relay's: an upstream
// event in this namespace is dropped, and the control is handled on the relay, never forwarded.
export const SESSION_EXPIRING_TYPE = 'vh.session.expiring';
export const SESSION_EXTENDED_TYPE = 'vh.session.extended';
export const SESSION_EXTEND_TYPE = 'vh.session.extend';
// A REPLY THE UPSTREAM CUT OFF (V2.8 W40). An unasked end recovered by the rollover replaced the upstream mid-reply and
// told the browser nothing, so the cut turn never ended there: the next reply was appended into it and took its verdict.
// This frame says the reply in flight will never finish, naming the response ids that had streamed (`cut`); the browser
// settles that turn as it stands and ends a typed turn waiting on it. Sent only when a reply was in flight, never on a
// quiet rollover.
export const SESSION_RESUMED_TYPE = 'vh.session.resumed';
// Whether a frame type is the relay's own: `vh.` (the grounding verdict and the session frames) or the proposal
// frame. The browser cannot tell who sent a frame, so an upstream event of one of these types is not forwarded.
const relayFrame = (type) => typeof type === 'string' && (type.startsWith('vh.') || type === PROPOSAL_FRAME_TYPE);

// Read the two Talk settings from the environment, once at boot. A value that cannot be honoured falls back to
// the default with a warning the caller logs, so a typo never fails the boot and never goes unsaid. The warning
// names the setting and the rule, never the value.
export function realtimeTalkSettings(env = process.env) {
  const warnings = [];
  const minutes = talkMinutesFrom(env.HUGO_TALK_SESSION_MINUTES);
  if (!minutes.ok) warnings.push({ setting: 'HUGO_TALK_SESSION_MINUTES', reason: 'not a whole number of minutes from 1 to ' + TALK_SESSION_MINUTES_MAX + '; using ' + DEFAULT_TALK_SESSION_MINUTES });
  const tokens = talkTokensFrom(env.HUGO_TALK_MAX_OUTPUT_TOKENS);
  if (!tokens.ok) warnings.push({ setting: 'HUGO_TALK_MAX_OUTPUT_TOKENS', reason: 'not "inf" or a whole number from 1 to ' + REALTIME_MAX_OUTPUT_TOKENS_LIMIT + '; using "inf"' });
  return { sessionMinutes: minutes.value, sessionMs: minutes.value * 60_000, maxOutputTokens: tokens.value, warnings };
}
const unset = (raw) => raw === undefined || String(raw).trim() === '';
function talkMinutesFrom(raw) {
  const n = Number(raw);
  const ok = Number.isInteger(n) && n >= 1 && n <= TALK_SESSION_MINUTES_MAX;
  return { ok: ok || unset(raw), value: ok ? n : DEFAULT_TALK_SESSION_MINUTES };
}
function talkTokensFrom(raw) {
  const said = String(raw ?? '').trim().toLowerCase();
  const n = Number(said);
  const ok = Number.isInteger(n) && n >= 1 && n <= REALTIME_MAX_OUTPUT_TOKENS_LIMIT;
  return { ok: ok || said === 'inf' || unset(raw), value: ok ? n : REALTIME_MAX_OUTPUT_TOKENS };
}
// The most of one answer the relay keeps for the check; the per-response output cap keeps an answer well inside it.
const ANSWER_KEEP_CHARS = 20_000;
// What Hugo is told to say when a SPOKEN answer fails the check (VH-318-E): audio already played cannot be unsaid,
// so the correction is spoken. Server-built, like the session itself; the client cannot send instructions.
export const SPOKEN_CORRECTION_INSTRUCTIONS = 'In one short sentence, tell the operator that part of your last answer '
  + 'could not be checked against the dataset, so they should disregard it, and offer to look it up properly. '
  + 'Do not repeat any part of that answer.';
// The models a session names, from the deployment's settings: the realtime model (owner, 2026-10-06:
// gpt-realtime-2.1 is set through OPENAI_REALTIME_MODEL, reversible without a release) and the model that
// transcribes the operator's speech, which is billed at ITS rate, not the realtime model's.
export const DEFAULT_REALTIME_MODEL = 'gpt-realtime-2';
// WHISPER IS RETIRED (VH-318-F, owner decision 2026-10-06): the operator's speech is transcribed by
// gpt-live-transcribe, falling back to gpt-transcribe if the key cannot use it. Both take `keywords`
// (openai 7.28.0 realtime.d.ts:25-29), so "Hugo" is named as a word to expect, which is what a wake word needs.
export const DEFAULT_TRANSCRIPTION_MODEL = 'gpt-live-transcribe';
export const FALLBACK_TRANSCRIPTION_MODEL = 'gpt-transcribe';
const WAKE_KEYWORDS = Object.freeze(['Hugo', 'Hey Hugo']);
const transcriptionOf = (model) => ({ model, keywords: [...WAKE_KEYWORDS] });
export function realtimeModels(env = process.env) {
  return { model: env.OPENAI_REALTIME_MODEL || DEFAULT_REALTIME_MODEL, transcriptionModel: DEFAULT_TRANSCRIPTION_MODEL };
}

// Hugo's spoken persona and its grounding live with the typed one in `persona.js` (VH-777 Lane T, one persona), and
// every session is briefed from `hugoInstructions`. Set server-side on every session; the client cannot change it.
import { domainIds } from '../domain/descriptor.js';
import { hugoInstructions } from './persona.js';

// The client interaction events the relay forwards upstream. Everything else (notably `session.update` and
// `session.create`) is dropped, so the client cannot re-instruct the model or widen its tools.
const CLIENT_EVENT_ALLOW = new Set([
  // A TYPED TURN (VH-318-C), rebuilt by `textTurnItem` into a user text message and nothing else.
  'conversation.item.create',
  'input_audio_buffer.append',
  'input_audio_buffer.commit',
  'input_audio_buffer.clear',
  // NOT `response.create` OR `response.cancel` (the V2.8 security gate, round two). The relay asks for every response
  // itself, after a typed turn or a committed spoken one, which is where the daily cap is checked; a client-sent
  // `response.create` bought another response with no turn and so no cap check, as often as the client liked. The
  // shipped client sends neither.
]);

export function clientEventAllowed(type) {
  return CLIENT_EVENT_ALLOW.has(type);
}

// Reduce a safelisted client event to what is SAFE to forward upstream, dropping any field that would override
// the server-set session. The client cannot send a `response.*` event at all (the safelist above refuses it before
// this runs), so no client field can re-instruct the model or widen its tools for a reply. `input_audio_buffer.append`
// keeps just its base64 `audio`, a typed turn is rebuilt by `textTurnItem`, and the others carry only their type,
// so a `session` field on any of them is dropped. Returns the event to send.
export function sanitiseClientEvent(event) {
  const type = event.type;
  if (type === 'input_audio_buffer.append') {
    return typeof event.audio === 'string' ? { type, audio: event.audio } : null;
  }
  if (type === 'conversation.item.create') return textTurnItem(event);
  // input_audio_buffer.commit / .clear: forward the type alone, so no client-supplied field reaches the model.
  return { type };
}

// THE TYPED TURN (VH-318-C): typed Hugo goes through the same Realtime session as Talk, as a user text item,
// instead of the request-and-response agent loop. The item is REBUILT here from the client's text alone: a user
// `message` with one `input_text` part (openai 7.28.0 realtime.d.ts:1454-1513). Any other role (a forged
// `system` or `assistant` turn), any other item type (a forged `function_call_output`), a position
// (`previous_item_id`, which could splice a turn into the history) and every other field are dropped. The
// text is bounded like the typed route's. Returns the item event, or null when there is no text to send.
export const TEXT_TURN_MAX_CHARS = 4000;
export function textTurnItem(event) {
  const item = event?.item;
  if (item?.type !== 'message' || item.role !== 'user' || !Array.isArray(item.content)) return null;
  const text = item.content
    .filter((part) => part?.type === 'input_text' && typeof part.text === 'string')
    .map((part) => part.text)
    .join('\n')
    .trim()
    .slice(0, TEXT_TURN_MAX_CHARS);
  if (!text) return null;
  return { type: 'conversation.item.create', item: { type: 'message', role: 'user', content: [{ type: 'input_text', text }] } };
}

// THE CONVERSATION A ROLLOVER CARRIES (owner, 2026-10-07: "Build it in V2.8"). A fresh upstream knows nothing, so the
// relay keeps the TEXT of the turns so far and replays it there as items it builds itself: what the operator typed, as
// `textTurnItem` rebuilt it, and what they said, as the provider transcribed it, each a user `input_text` message; and
// Hugo's answers, ONLY those the grounding check verified, each an assistant `output_text` message (realtime.d.ts
// 1281-1331). Nothing the client sent is kept as it arrived: no frame, no field, no audio. Nothing the check refused
// (a withdrawn or flagged answer) is carried over, and tool calls and their results are not replayed: the model sees
// what it said about them, and the session's grounding ledger (`checkAnswer`) still holds every result.
// THE BOUND: the most recent REPLAY_MAX_ITEMS turns within REPLAY_MAX_CHARS characters, each turn cut at
// TEXT_TURN_MAX_CHARS, oldest dropped first and whole. 24,000 characters is about 6,000 tokens on OpenAI's own rule of
// thumb of about 4 characters a token, under a fifth of the smallest context window published for a Realtime model
// (32,000 tokens, read through WebSearch 2026-10-07; gpt-realtime-2's is given as 128,000 on OpenAI's page and 32,000
// elsewhere), so the replay leaves the instructions, the tools and the conversation that follows their room. Replayed
// text is billed as input of the next reply (about $0.024 at gpt-realtime-2's $4 a million text tokens) and booked
// from that reply's usage like any other. The record is held to the same bound as it grows, so a long session's
// memory does not grow with it.
export const REPLAY_MAX_ITEMS = 60;
export const REPLAY_MAX_CHARS = 24_000;
const replayText = (text) => String(text ?? '').trim().slice(0, TEXT_TURN_MAX_CHARS);
const replayItem = (turn) => ({
  type: 'conversation.item.create',
  item: turn.role === 'user'
    ? { type: 'message', role: 'user', content: [{ type: 'input_text', text: turn.text }] }
    : { type: 'message', role: 'assistant', content: [{ type: 'output_text', text: turn.text }] },
});
// AN UNANSWERED QUESTION IS NOT REPLAYED (V2.8 W40). Each operator turn is OPEN until a reply asked after it finishes
// (`answered(through)`, `through` being the `seq()` read when that reply was asked), and a reply cut off by the upstream
// drops the turns still open (`dropOpen`). The browser has just told the operator that question went unanswered, so
// they ask it again; kept here as well, the retry would reach the fresh upstream twice. Removed rather than marked,
// because nothing else reads the record and a removed turn cannot be replayed by mistake later.
export function createConversationRecord({ maxItems = REPLAY_MAX_ITEMS, maxChars = REPLAY_MAX_CHARS } = {}) {
  const turns = [];
  let seq = 0;
  const trim = () => {
    let chars = turns.reduce((n, t) => n + t.text.length, 0);
    while (turns.length > maxItems || chars > maxChars) chars -= turns.shift().text.length;
  };
  const add = (role, text, key = '') => { seq += 1; turns.push({ role, text: replayText(text), key, seq, open: role === 'user' }); trim(); };
  return {
    seq: () => seq,
    answered: (through) => { for (const t of turns) if (t.seq <= through) t.open = false; },
    dropOpen: () => { for (let i = turns.length - 1; i >= 0; i -= 1) if (turns[i].open) turns.splice(i, 1); },
    user: (text) => add('user', text),
    // A spoken turn takes its place when it is committed, and its words when the transcript lands, which can be after
    // Hugo has begun to answer it, so the replay keeps the order the turns were taken in.
    spoken: (key) => add('user', '', String(key || '')),
    heard: (key, text) => {
      const turn = key ? turns.find((t) => t.key === String(key) && t.role === 'user' && !t.text) : null;
      const words = replayText(text);
      // AN EMPTY TRANSCRIPT IS A TURN WITH NO WORDS, NOT ONE STILL WAITING (V2.8 round one): left keyed and empty it
      // held `awaiting` true and so stopped every planned rollover for the rest of the upstream. It leaves, as a failed
      // transcription does; an unkeyed empty one is never added.
      if (!words) {
        if (turn) { turns.splice(turns.indexOf(turn), 1); }
        return;
      }
      if (!turn) { add('user', text); return; }
      turn.text = words;
      trim();
    },
    // A spoken turn whose transcription failed will never be filled, so it gives up its place (VH-602).
    unheard: (key) => {
      const at = key ? turns.findIndex((t) => t.key === String(key) && t.role === 'user' && !t.text) : -1;
      if (at >= 0) turns.splice(at, 1);
    },
    // Whether a spoken turn is still waiting for its words: a rollover then would replay the conversation without them.
    awaiting: () => turns.some((t) => t.role === 'user' && t.key && !t.text),
    // At a rollover the old upstream's transcripts are ignored, so a turn still waiting for its words never gets them;
    // left in place it would hold `awaiting` true and stop every planned rollover after it (V2.8 merge of W40 and VH-602).
    dropUnheard: () => { for (let i = turns.length - 1; i >= 0; i -= 1) if (turns[i].role === 'user' && turns[i].key && !turns[i].text) turns.splice(i, 1); },
    assistant: (text) => add('assistant', text),
    items: () => turns.filter((t) => t.text).map(replayItem),
  };
}

// THE VOICES TALK MAY USE (VH-318-C, owner 2026-10-06: "the picker offers only voices Realtime supports, Talk
// honours the pick, default marin"). The built-in Realtime voices, openai 7.28.0 realtime.d.ts:1107-1115, which
// recommends marin and cedar "for best quality". The voice is fixed when the session opens (the types say it
// cannot change once the model has spoken), so it rides on the upgrade URL and is validated here: anything off
// the list is the default, never forwarded.
export const REALTIME_VOICES = Object.freeze(['marin', 'cedar', 'alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse']);
export const DEFAULT_REALTIME_VOICE = 'marin';
export function realtimeVoiceFromUrl(url) {
  let asked = '';
  try { asked = new URL(String(url || ''), 'http://localhost').searchParams.get('voice') || ''; } catch { asked = ''; }
  const voice = asked.trim().toLowerCase();
  return REALTIME_VOICES.includes(voice) ? voice : DEFAULT_REALTIME_VOICE;
}

// The realtime WebSocket subprotocol the browser uses to carry its bearer token, since the WebSocket API
// cannot set an Authorization header. The browser opens `new WebSocket(url, [REALTIME_SUBPROTOCOL, token])`;
// the server reads the token off the `Sec-WebSocket-Protocol` header and verifies it exactly as a Bearer.
export const REALTIME_SUBPROTOCOL = 'vh.bearer';

// Extract the bearer token an upgrade request carries in its `Sec-WebSocket-Protocol` header, or '' when it is
// absent or malformed. The header is a comma-separated list; a valid request offers our subprotocol first and
// the token second. Only the token is returned, for the caller to verify through the normal auth seam.
export function realtimeUpgradeToken(req) {
  const header = req?.headers?.['sec-websocket-protocol'];
  if (typeof header !== 'string') return '';
  const parts = header.split(',').map((s) => s.trim());
  if (parts.length < 2 || parts[0] !== REALTIME_SUBPROTOCOL) return '';
  return parts[1] || '';
}


// The server-set session configuration sent to the upstream on open. Audio in and out as 24kHz PCM16, server-side
// voice-activity turn detection (so the operator just talks), and the fixed persona. Tools are passed through
// when supplied, so the realtime model can call back for data (the reasoning/tool tier behind the voice).
// The generally available shape (openai 7.23.0 `RealtimeSessionCreateRequest`): `output_modalities` is `audio`
// alone, because the types say audio already carries its transcript and text with audio cannot be asked for.
// THE VOICE DETECTION ENDS A TURN BUT DOES NOT REPLY (V2.8 round three): `create_response` is "Whether or not to
// automatically generate a response when a VAD stop event occurs", and with it false "the model will never respond
// automatically but VAD events will still be emitted" (openai 7.30.0 realtime.d.ts:1193-1202, OpenAI's VAD guide
// through WebSearch 2026-10-07). Left on, the provider opened a spoken turn's reply itself, so the daily cap could
// only be asked beside it; off, the relay asks for the reply on `input_audio_buffer.committed`, after the cap.
// Whether the live service commits as the types say is verified at deploy, with the key.
export function buildSessionUpdate({ instructions = hugoInstructions({ channel: 'spoken' }), tools = [], voice = DEFAULT_REALTIME_VOICE, transcriptionModel = DEFAULT_TRANSCRIPTION_MODEL, maxOutputTokens = REALTIME_MAX_OUTPUT_TOKENS } = {}) {
  return {
    type: 'session.update',
    session: {
      type: 'realtime',
      output_modalities: ['audio'],
      instructions,
      max_output_tokens: maxOutputTokens,
      audio: {
        input: {
          format: { ...AUDIO_FORMAT },
          transcription: transcriptionOf(transcriptionModel),
          turn_detection: { type: 'server_vad', create_response: false },
        },
        output: { format: { ...AUDIO_FORMAT }, voice },
      },
      tools,
      tool_choice: tools.length ? 'auto' : 'none',
    },
  };
}

// THE ALWAYS-ON LISTENER'S SESSION (VH-318-F): a Realtime TRANSCRIPTION session, not a model session. Its URL
// carries `intent=transcription` rather than a model (openai 7.28.0 realtime/internal-base.js:97-101), and its
// configuration is `type: 'transcription'` (realtime.d.ts:3061-3078): it hears and transcribes, it never
// replies, so no model tokens are spent while it listens. Server voice detection sends only the speech it hears.
export function buildTranscriptionSessionUpdate({ transcriptionModel = DEFAULT_TRANSCRIPTION_MODEL } = {}) {
  return {
    type: 'session.update',
    session: {
      type: 'transcription',
      audio: {
        input: {
          format: { ...AUDIO_FORMAT },
          transcription: transcriptionOf(transcriptionModel),
          turn_detection: { type: 'server_vad' },
          noise_reduction: { type: 'far_field' },
        },
      },
    },
  };
}

// Whether an upstream error refused the TRANSCRIPTION model, so the session should try the fallback. Read from the
// error's `param` (a path naming the transcription setting) or a model-not-found code. Which exact shape the live
// service sends for a model the key cannot use is not measured here: it needs a live key and a refused model, and
// OpenAI's pages do not print that error (searched 2026-10-07). TBC, re-verify at deploy.
export function transcriptionRefused(event) {
  if (event?.type !== 'error') return false;
  const param = String(event.error?.param || '');
  const code = String(event.error?.code || '');
  return param.includes('transcription') || code === 'model_not_found';
}

// Map an upstream event's usage (present on `response.done`) to the ledger shape, or null when the event
// carries none. OpenAI reports { input_tokens, output_tokens } on the realtime response usage already, but
// older shapes used prompt/completion; both are handled. The audio share rides along (`audioTokensOf` below).
// A TRANSCRIPTION CAN BILL BY TIME (VH-318-I): `{ type: 'duration', seconds }` (openai 7.28.0
// realtime.d.ts:315-363). That shape has no token field, so it returned null and the call booked NOTHING, a
// spend control failing open. It now books its seconds.
export function usageFromEvent(event) {
  const u = event?.response?.usage || event?.usage;
  if (!u) return null;
  if (u.type === 'duration') {
    const seconds = Number(u.seconds);
    return Number.isFinite(seconds) && seconds >= 0 ? { input_tokens: 0, output_tokens: 0, audio_seconds: seconds } : null;
  }
  const input = Number(u.input_tokens ?? u.prompt_tokens);
  const output = Number(u.output_tokens ?? u.completion_tokens);
  if (!Number.isFinite(input) && !Number.isFinite(output)) return null;
  return {
    input_tokens: input || 0,
    output_tokens: output || 0,
    audio_input_tokens: audioTokensOf(input || 0, u.input_token_details),
    audio_output_tokens: audioTokensOf(output || 0, u.output_token_details),
  };
}

// A REPLY CUT OFF BY AN UPSTREAM END IS BOOKED AT ITS CEILING (VH-602): the `response.done` that carries its usage
// never arrives, so the ledger would have charged nothing for it. The ceiling is the configured reply length, or the
// API's maximum when that is unlimited, at the audio rate, the dearer one, as a total with no breakdown is.
function cutReplyCeiling(maxOutputTokens) {
  const n = maxOutputTokens === REALTIME_MAX_OUTPUT_TOKENS ? REALTIME_MAX_OUTPUT_TOKENS_LIMIT : Number(maxOutputTokens);
  return { input_tokens: 0, output_tokens: n, audio_input_tokens: 0, audio_output_tokens: n };
}

// AUDIO TOKENS ARE BOOKED AT THE AUDIO RATE (V2.8, owner ruling 2026-10-07). The share of a total the ledger
// books as audio: every token NOT reported as text in the usage details (`input_token_details` and
// `output_token_details` carry `text_tokens` and `audio_tokens`, OpenAI's Realtime reference, read 2026-10-07).
// A total with no breakdown is booked as audio throughout, because the dearer rate is the only honest ceiling
// when the provider does not say, and an image token, which the relay never sends, would book there too.
function audioTokensOf(total, details) {
  const text = Number(details?.text_tokens);
  return Number.isFinite(text) ? Math.max(0, total - Math.max(0, text)) : total;
}

// The model an event's usage is billed at (VH-318-I). Transcription of the operator's speech is "billed
// according to the ASR model's pricing rather than the realtime model's" (openai 7.28.0 realtime.d.ts:296-299),
// and it was booked at the realtime model's rate; every other usage is the session model's.
export function meteredModel(event, { model, transcriptionModel }) {
  return String(event?.type || '').includes('input_audio_transcription') ? transcriptionModel : model;
}

// Parse a client frame to a plain event object, or null when it is oversized or not JSON. Buffers (binary
// frames) are rejected: the browser client sends JSON events with base64 audio, never raw binary.
function parseClientFrame(data) {
  if (Buffer.isBuffer(data)) return null; // binary frames are rejected; the client sends JSON with base64 audio
  const text = typeof data === 'string' ? data : String(data ?? '');
  if (Buffer.byteLength(text, 'utf8') > MAX_FRAME_BYTES) return null;
  try {
    const event = JSON.parse(text);
    return event && typeof event.type === 'string' ? event : null;
  } catch { return null; }
}

// TOOL EXECUTION ON THE RELAY (V1.77 D6). When the upstream reports a completed function call, the relay
// runs it SERVER-side through `onToolCall(name, args)` (the same bound tool layer the agent route uses, with
// the caller's principal) and answers the model with a `function_call_output` item, then asks for the
// response to continue. The browser sees the tool-call events as it sees everything else, but never
// executes one: a client that forged a function_call_output would be dropped by the safelist. A tool
// that throws answers the model with the error text, so a failed lookup is reported, never invented
// around. Bounded output, because it goes back into the model's context.
// The tool starts as soon as its arguments are complete, but its answer and the request to continue wait for that
// response's `response.done` (VH-318-B): the types allow one response at a time on the conversation, so a
// `response.create` sent while the calling response is still open asks for a second one. Resolves to
// `{ item, frame }`: the `conversation.item.create` event to send upstream, and the proposal frame for the
// browser ('' when the call was not a proposal). Never rejects.
async function runToolCall(event, onToolCall) {
  const name = String(event?.name || '');
  let args = {};
  try { args = JSON.parse(event?.arguments || '{}'); } catch { args = {}; }
  let output;
  let frame = '';
  try {
    const out = await onToolCall(name, args && typeof args === 'object' ? args : {});
    output = JSON.stringify(out?.ok === false ? { error: out.error } : (out?.result ?? out ?? null)).slice(0, TOOL_OUTPUT_MAX);
    frame = proposalFrame(name, out);
  } catch (err) {
    output = JSON.stringify({ error: String(err?.message || err).slice(0, 300) });
  }
  return { item: { type: 'conversation.item.create', item: { type: 'function_call_output', call_id: String(event?.call_id || ''), output } }, frame };
}

// A SPOKEN PROPOSAL REACHES THE RAIL (VH-318-H). The browser sees every upstream event, so it sees a tool call's
// ARGUMENTS, but a tool's RESULT goes upstream only, so the proposal the server built (the validated view intent
// and its count, the compiled scan design, the previewed record diff) never reached the screen and a spoken change
// could not be confirmed. This is the one frame added for it, and it is the narrowest that carries the proposal:
// only for the three confirm-first tools, only for a result the tool runner returned as `ok` and marked
// `requiresConfirmation`, built from that SERVER result rather than from the model's arguments, with the tool name
// set by the server, and bounded. The client validates it again and escapes every value it renders
// (public/views/hugo-rail.js). Nothing is applied by it: the rail's card opens the existing confirmation surface.
const PROPOSAL_TOOLS = new Set(['propose_view', 'propose_update', 'propose_scan']);
const PROPOSAL_FRAME_MAX = 24_000;
export const PROPOSAL_FRAME_TYPE = 'hugo.proposal';
export function proposalFrame(name, out) {
  const result = out?.ok === true ? out.result : null;
  if (!PROPOSAL_TOOLS.has(name) || !result || typeof result !== 'object' || Array.isArray(result)) return '';
  if (result.requiresConfirmation !== true) return '';
  const text = JSON.stringify({ type: PROPOSAL_FRAME_TYPE, proposal: { ...result, tool: name } });
  return Buffer.byteLength(text, 'utf8') <= PROPOSAL_FRAME_MAX ? text : '';
}

// THE EVIDENCE A CLOSED SESSION CARRIES (VH-318-B), because what fails on the deployed app is not measured: the
// upstream close code, an HTTP status from a refused handshake, the socket error code, and the type, code and
// param of the last upstream `error` event. Codes and field names only, never message text, so nothing the
// provider echoes back (a masked key, the operator's words) reaches a log.
const DIAG_TOKEN = /^[\w.:-]{1,80}$/;
const diagToken = (v) => (typeof v === 'string' && DIAG_TOKEN.test(v) ? v : undefined);
function upstreamErrorDetail(err) {
  const status = /Unexpected server response: (\d{3})/.exec(String(err?.message || ''))?.[1];
  return { upstreamStatus: status ? Number(status) : undefined, socketError: diagToken(err?.code) };
}
function noteUpstreamError(diag, event) {
  diag.errorType = diagToken(event.error?.type);
  diag.errorCode = diagToken(event.error?.code);
  diag.errorParam = diagToken(event.error?.param);
}

// Build the bridge. Returns { configured, connect }. `connect(clientSocket, { tools, onEvent })` opens the
// upstream Realtime socket, wires the relay, and returns a handle with `.close()`. Nothing is called when
// unconfigured (the caller answers 503/closes first).
export function createRealtimeBridge({
  apiKey, model = realtimeModels().model, transcriptionModel = realtimeModels().transcriptionModel, wsFactory, onUsage = () => {}, base = REALTIME_BASE,
  maxSessionMs = REALTIME_SESSION_MAX_MS, maxOutputTokens = REALTIME_MAX_OUTPUT_TOKENS, setTimer = setTimeout, clearTimer = clearTimeout, now = Date.now,
} = {}) {
  // The upstream factory is injected: index.js passes the `ws` client (which can set the auth header, unlike
  // Node's built-in global WebSocket); tests pass a fake. Unconfigured without a key OR without a factory, so
  // the caller closes the client socket with a 1011/503 rather than dialling out.
  const makeSocket = wsFactory;
  const configured = Boolean(apiKey) && typeof makeSocket === 'function';

  function connect(clientSocket, { tools = [], onToolCall = null, onClose = () => {}, onUserTurn = () => {}, turnAllowed = null, voice = DEFAULT_REALTIME_VOICE, checkAnswer = null, mode = 'talk' } = {}) {
    // `listen` is the always-on wake-word session (VH-318-F): transcription only, audio in, no replies, no tools.
    const listen = mode === 'listen';
    const url = listen ? base + '?intent=transcription' : base + '?model=' + encodeURIComponent(model);
    let hearing = transcriptionModel;
    const sessionUpdate = () => (listen
      ? buildTranscriptionSessionUpdate({ transcriptionModel: hearing })
      : buildSessionUpdate({ tools, transcriptionModel: hearing, maxOutputTokens, voice: REALTIME_VOICES.includes(voice) ? voice : DEFAULT_REALTIME_VOICE }));
    // THE UPSTREAM CAN BE REPLACED (the rollover, owner 2026-10-07). `generation` names the current one; an event from
    // a replaced one is ignored, except its usage, which is booked whichever socket reports it.
    let upstream = null;
    let generation = 0;
    let closed = false;
    const diag = {};
    let capTimer = null;
    let offerTimer = null;
    let rolloverTimer = null;
    let openTimer = null;
    const clearTimers = () => {
      if (offerTimer) clearTimer(offerTimer);
      if (rolloverTimer) clearTimer(rolloverTimer);
      if (openTimer) clearTimer(openTimer);
      if (capTimer) clearTimer(capTimer);
      offerTimer = null;
      rolloverTimer = null;
      openTimer = null;
      capTimer = null;
    };
    const closeBoth = (reason, clientCode) => {
      if (closed) return;
      closed = true;
      clearTimers();
      try { upstream?.close(); } catch { /* already gone */ }
      try { if (clientCode) clientSocket.close(clientCode, reason); else clientSocket.close(); } catch { /* already gone */ }
      const detail = Object.fromEntries(Object.entries(diag).filter(([, v]) => v !== undefined));
      onClose(reason, detail);
    };
    const sendUpstream = (event) => {
      if (closed) return;
      try { upstream.send(JSON.stringify(event)); } catch { closeBoth('upstream-send-failed'); }
    };
    const sendClient = (frame) => {
      try { clientSocket.send(JSON.stringify(frame)); } catch { closeBoth('client-send-failed'); }
    };

    // CLIENT FRAMES WAIT FOR THE UPSTREAM (VH-318-B). The browser starts streaming the moment its same-origin
    // socket opens, about 170ms of audio per frame, while the upstream dial to the provider is still in its
    // handshake, and the `ws` client throws on a send before open: the first frame ended the session. Frames
    // are held, bounded, and sent after the server's session.update, so the session is configured first. The same
    // hold covers a rollover: the microphone audio and any typed turn that arrive while the fresh upstream is
    // dialled are HELD AND FORWARDED once it is configured and the conversation replayed, within the same bound
    // (MAX_PENDING_BYTES, about 15 seconds of audio); past it a frame is dropped, as at the first dial.
    let upstreamOpen = false;
    let pending = [];
    let pendingBytes = 0;
    let replayNext = [];
    const record = createConversationRecord();
    // THE SESSION LENGTH (owner, 2026-10-07). The wall clock runs from the dial, so a session that never opens is
    // bounded too. A Talk session is offered one more session length `expiryLeadMs` before it ends; the browser's
    // `vh.session.extend` takes it up, once per offer however often it is sent, and any number of offers may be
    // taken. The listener (`listen`) is never made an offer, so an extend from it finds none open and does nothing.
    let endsAt = now() + maxSessionMs;
    let offerOpen = false;
    const leadMs = expiryLeadMs(maxSessionMs);
    const offerExtension = () => {
      if (closed) return;
      offerOpen = true;
      sendClient({ type: SESSION_EXPIRING_TYPE, ends_at: new Date(endsAt).toISOString(), extend_minutes: maxSessionMs / 60_000 });
    };
    const armSessionTimers = (leftMs) => {
      if (offerTimer) clearTimer(offerTimer);
      if (capTimer) clearTimer(capTimer);
      if (!listen) { offerTimer = setTimer(offerExtension, Math.max(0, leftMs - leadMs)); offerTimer?.unref?.(); }
      capTimer = setTimer(() => closeBoth('session-cap', REALTIME_CAP_CLOSE_CODE), leftMs);
      capTimer?.unref?.();
    };
    const extendSession = () => {
      if (!offerOpen || closed) return;
      offerOpen = false;
      endsAt += maxSessionMs;
      armSessionTimers(Math.max(0, endsAt - now()));
      sendClient({ type: SESSION_EXTENDED_TYPE, ends_at: new Date(endsAt).toISOString() });
    };

    // Send now, or hold (bounded) until the upstream has opened and been configured. `onSent` runs once the frame is
    // handed to an upstream, now or when the held frames are flushed, and never for a frame dropped past the bound.
    const forward = (event, onSent) => {
      if (upstreamOpen) { sendUpstream(event); onSent?.(); return; }
      const text = JSON.stringify(event);
      const bytes = Buffer.byteLength(text, 'utf8');
      if (pendingBytes + bytes > MAX_PENDING_BYTES) return; // beyond the bound the frame is dropped, not held
      pending.push({ text, onSent });
      pendingBytes += bytes;
    };

    // ONE RESPONSE AT A TIME (VH-318-C). The types allow one active response per conversation, and a typed turn
    // can arrive while Hugo is still speaking or still calling a tool, so the relay asks for a response only when
    // none is active and otherwise asks once the active one is done. A TYPED turn's responses, its tool
    // continuations included, ask for text alone (`output_modalities: ['text']`, realtime.d.ts:2067), so the
    // rail streams `response.output_text.delta`; a spoken turn's keep the session's audio.
    let responseActive = false;
    let responseWanted = false;
    let capAsking = false;
    // A cut removed the question a running cap check was asked for (V2.8 W40 with VH-602), so its answer buys nothing.
    let capDropped = false;
    // THE PROVIDER WAS SENT THE REPLY (VH-661). The slot is held from the ask, but a response.create may still be held
    // while an upstream dials, or dropped past the bound, and a dial that then fails never delivered it. So this is set
    // when the current upstream is handed the response.create, or reports a response it opened, and a fresh upstream
    // starts without it. The send, not `response.created`: a reply the provider has may be billed before that arrives.
    let replySent = false;
    const replyReached = () => { replySent = true; };
    let turnModality = 'audio';
    const responseCreate = () => (turnModality === 'text'
      ? { type: 'response.create', response: { output_modalities: ['text'] } }
      : { type: 'response.create' });
    // THE DAILY CAP HOLDS A SESSION, NOT ONLY ITS START (V2.8). Once the voice models were priced, Talk opens
    // under a daily cap, and the cap was checked only at the upgrade, so one session could run past it.
    // `turnAllowed` (the caller flushes the ledger and asks the same gate every paid path asks) is asked BEFORE
    // EVERY RESPONSE THE RELAY REQUESTS (V2.8 round three, owner "fix in 2.8"): a typed turn's, a spoken turn's (the
    // provider no longer opens one itself, `create_response: false` above), a tool continuation and the spoken
    // correction. Nothing is sent upstream until the check has answered true, so a spent day buys no response;
    // round three measured two bought while the check ran beside the turn. FAILS CLOSED: a check that throws or
    // answers anything but true closes the session with the cap code, as the wall-clock cap does. The slot is
    // held while the check runs, so a second request waits rather than racing it. A rollover asks for no reply.
    const closeOnCap = () => closeBoth('daily-cap', REALTIME_CAP_CLOSE_CODE);
    const askResponse = (event) => {
      responseActive = true;
      if (typeof turnAllowed !== 'function') { forward(event, replyReached); return; }
      capAsking = true;
      Promise.resolve().then(() => turnAllowed())
        .then((ok) => {
          capAsking = false;
          if (ok !== true) { closeOnCap(); return; }
          if (!capDropped) { forward(event, replyReached); return; }
          // The slot the dropped check held is free, so a turn taken since is asked for now.
          capDropped = false;
          responseActive = false;
          if (responseWanted) { responseWanted = false; requestResponse(); }
        })
        .catch(closeOnCap);
    };
    // The operator turns the reply now asked for answers: those taken so far (`record.answered`, at its finish).
    let answering = 0;
    const requestResponse = () => {
      if (responseActive || capAsking) { responseWanted = true; return; }
      answering = record.seq();
      askResponse(responseCreate());
    };
    let correctedThisTurn = false;
    // The response a correction opens is never itself corrected, whatever turn has started meanwhile.
    let correctionAsked = false;
    const corrections = new Set();
    // THE LISTENER'S CAP (VH-318-F). A transcription session has no response to hold back: what it hears is billed
    // as it is transcribed, so its check runs at each turn the voice detection commits, beside the transcription.
    const checkListenerCap = () => {
      if (typeof turnAllowed !== 'function') return;
      Promise.resolve().then(() => turnAllowed())
        .then((ok) => { if (ok !== true) closeOnCap(); })
        .catch(closeOnCap);
    };
    const startTurn = (modality) => {
      turnModality = modality;
      correctedThisTurn = false;
      try { onUserTurn(); } catch { /* a budget must never break the relay */ }
    };
    // A SPOKEN TURN ENDS (VH-318-G): the voice detection committed what the operator said, so per-turn budgets (the web
    // lookup's) renew here, as they do per request on the typed route, and the relay asks for the reply.
    const onCommitted = (event) => {
      startTurn('audio');
      if (listen) { checkListenerCap(); return; }
      record.spoken(event.item_id);
      requestResponse();
    };

    // GROUNDING UNDER STREAMING (VH-318-E). Each response's words are kept as they stream (the text of a typed
    // answer, the transcript of a spoken one), and when it finishes with no tool call they are checked against
    // the session's tool results by `checkAnswer` (`src/hugo/stream-check.js`). The verdict goes to the browser
    // as a server-made `vh.grounding` frame: `verified`, or `withdrawn` for a typed answer (the rail takes the
    // text down), or `flagged` for a spoken one, which Hugo then corrects aloud, once per turn so a correction
    // cannot loop. FAILS CLOSED: no checker, or a checker that throws, is a failed check, never a pass. Only a
    // verified answer joins the conversation a rollover replays.
    const answers = new Map();
    const noteAnswer = (event) => {
      const id = String(event.response_id || '');
      const kept = answers.get(id) || { text: '', spoken: false };
      kept.text = (kept.text + String(event.delta || '')).slice(0, ANSWER_KEEP_CHARS);
      if (event.type === 'response.output_audio_transcript.delta') kept.spoken = true;
      answers.set(id, kept);
    };
    const verdictOf = (text) => {
      if (typeof checkAnswer !== 'function') return { ok: false, violations: ['no check is configured for this session'] };
      try {
        const v = checkAnswer(text);
        return { ok: v?.ok === true, violations: Array.isArray(v?.violations) ? v.violations.map(String).slice(0, 5) : [] };
      } catch {
        return { ok: false, violations: ['the check could not run'] };
      }
    };
    // Returns true when it asked for a spoken correction, which then holds the one response slot.
    const groundResponse = (event) => {
      const id = String(event.response?.id || '');
      const kept = answers.get(id);
      answers.delete(id);
      const output = Array.isArray(event.response?.output) ? event.response.output : [];
      if (!kept?.text.trim() || output.some((o) => o?.type === 'function_call')) return false;
      const verdict = verdictOf(kept.text);
      let state = 'verified';
      if (!verdict.ok) state = kept.spoken ? 'flagged' : 'withdrawn';
      sendClient({ type: 'vh.grounding', response_id: id, modality: kept.spoken ? 'audio' : 'text', state, violations: verdict.ok ? [] : verdict.violations });
      if (state === 'verified') record.assistant(kept.text);
      if (state !== 'flagged' || correctedThisTurn || corrections.has(id)) return false;
      correctedThisTurn = true;
      correctionAsked = true;
      askResponse({ type: 'response.create', response: { instructions: SPOKEN_CORRECTION_INSTRUCTIONS, tool_choice: 'none' } });
      return true;
    };

    // Tool answers waiting for their response's `response.done`, keyed by response id (see runToolCall).
    const toolCalls = new Map();
    let toolsAnswering = 0;
    const queueToolCall = (event) => {
      const responseId = String(event.response_id || '');
      if (!toolCalls.has(responseId)) toolCalls.set(responseId, []);
      toolCalls.get(responseId).push(runToolCall(event, onToolCall));
    };
    const answerToolCalls = (responseId) => {
      const calls = toolCalls.get(responseId);
      if (!calls) return false;
      toolCalls.delete(responseId);
      const asked = generation;
      toolsAnswering += 1;
      Promise.all(calls).then((answers) => {
        toolsAnswering -= 1;
        // An upstream replaced meanwhile never made these calls: their ids mean nothing to the fresh one.
        if (asked !== generation) return;
        for (const { item, frame } of answers) {
          sendUpstream(item);
          if (frame && !closed) { try { clientSocket.send(frame); } catch { closeBoth('client-send-failed'); } }
        }
        requestResponse();
      }).catch(() => closeBoth('upstream-send-failed'));
      return true;
    };
    const onResponseCreated = (event) => {
      responseActive = true;
      replySent = true;
      if (correctionAsked) { correctionAsked = false; corrections.add(String(event.response?.id || '')); }
    };
    const onResponseDone = (event) => {
      responseActive = false;
      recoveries = 0; // a finished reply shows the upstream is sound
      // A reply that ends with no tool call has answered the turns it was asked for, whatever its verdict.
      const output = Array.isArray(event.response?.output) ? event.response.output : [];
      if (!output.some((o) => o?.type === 'function_call')) record.answered(answering);
      if (groundResponse(event)) return;
      if (answerToolCalls(String(event.response?.id || ''))) return;
      if (responseWanted) { responseWanted = false; requestResponse(); }
    };

    // THE ROLLOVER (owner, 2026-10-07: "Build it in V2.8"). The provider ends a session at 60 minutes, so the relay
    // starts a fresh upstream before then, at a QUIET MOMENT: no reply running or waiting, no cap check or tool
    // answer in flight, and the operator not mid-speech. Never mid-reply. The fresh upstream gets the same
    // server-built `session.update`, then the conversation replayed (`record`, bounded), then the frames held while it
    // dialled; the browser keeps its socket and sees no close. A rollover asks for no reply, so the daily cap is
    // asked before the next one as always. An UNEXPECTED END (`session_expired`, or a close or error the relay did not
    // ask for) is recovered by the same rollover, ONCE: a second failure before a reply has finished on the fresh
    // upstream closes the browser's socket exactly as an upstream end did before. A first dial that never opened is
    // not retried: the provider refused the session, and the evidence says why.
    let speaking = false;
    let rolloverDue = false;
    let recoveries = 0;
    const settled = () => !responseActive && !responseWanted && !capAsking && toolCalls.size === 0 && toolsAnswering === 0 && !speaking;
    // A planned rollover also waits for a spoken turn's words (`record.awaiting`, VH-602), so the replay keeps the question.
    const quiet = () => settled() && !record.awaiting();
    // A ROLLOVER THAT IS NOT SETTLED CUT A REPLY OFF (V2.8 W40): only an unasked end recovers that way, since a planned one
    // waits for quiet. The cut reply will never finish, so the browser is told (SESSION_RESUMED_TYPE, after the dial, so
    // a failed send closes the fresh upstream too) and the question it was answering leaves the replay, with a turn
    // waiting behind it and a reply still at its cap check: the operator asks again. A transcript still on its way is
    // not a reply, so it is not a cut; the old upstream will never deliver it, so its turn leaves the record.
    const rollOver = () => {
      const old = upstream;
      const cut = settled() ? null : [...answers.keys()];
      rolloverDue = false;
      diag.rollovers = (diag.rollovers || 0) + 1;
      if (cut) { record.dropOpen(); responseWanted = false; capDropped = capAsking; }
      record.dropUnheard();
      replayNext = listen ? [] : record.items();
      // What belonged to the old upstream's conversation goes with it: a reply it cut off and calls it made.
      upstreamOpen = false;
      replySent = false;
      // A cap check still running holds the slot until it answers (for the reply it is about to ask for, or, after a cut,
      // for none), so a turn arriving meanwhile waits for it rather than sending a second response.create (VH-602). So
      // does a response.create still held for the fresh upstream, which sends it on open and so is booked if cut (VH-661).
      responseActive = capAsking || pending.some((frame) => frame.onSent === replyReached);
      correctionAsked = false;
      speaking = false;
      answers.clear();
      toolCalls.clear();
      dial();
      try { old?.close(); } catch { /* already gone */ }
      if (cut) sendClient({ type: SESSION_RESUMED_TYPE, cut });
    };
    const maybeRollover = () => {
      if (rolloverDue && !closed && upstreamOpen && quiet()) rollOver();
    };
    // A reply cut off by an upstream end is booked at its ceiling (`cutReplyCeiling`, VH-602); a reply still waiting
    // on the cap check was never asked for, and one held or dropped while the upstream dialled was never sent
    // (`replySent`, VH-661), so neither books anything.
    const onUpstreamEnd = (gen, reason) => {
      if (gen !== generation || closed) return;
      if (responseActive && replySent && !capAsking && !listen) { try { onUsage(cutReplyCeiling(maxOutputTokens), model); } catch { /* metering must never break the relay */ } }
      if ((generation === 1 && !upstreamOpen) || recoveries >= 1) { closeBoth(reason); return; }
      recoveries += 1;
      rollOver();
    };

    // Upstream -> client: forward every server event verbatim (audio deltas, transcripts, tool calls, errors),
    // and meter usage off response.done. The client renders/plays; the relay never interprets audio. An event in
    // the relay's own namespace (`relayFrame`) is metered and then dropped, never forwarded; so is the provider's
    // `session_expired`, which the relay answers with a rollover rather than passing on.
    const onUpstreamMessage = (gen) => (data) => {
      const text = typeof data === 'string' ? data : data?.toString?.('utf8') ?? '';
      let event = null;
      try { event = JSON.parse(text); } catch { /* forward opaque anyway */ }
      const usage = event && usageFromEvent(event);
      if (usage) { try { onUsage(usage, meteredModel(event, { model, transcriptionModel: hearing })); } catch { /* metering must never break the relay */ } }
      if (gen !== generation || closed) return;
      if (relayFrame(event?.type)) return; // only the relay speaks in its own namespace
      if (sessionExpired(event)) { noteUpstreamError(diag, event); onUpstreamEnd(gen, 'upstream-closed'); return; }
      try { clientSocket.send(text); } catch { closeBoth('client-send-failed'); }
      if (event) onUpstreamEvent(event);
      maybeRollover();
    };
    // A REFUSED TRANSCRIBER SENDS NO WORDS (VH-647): a spoken turn waiting on it is released, as a failed transcription
    // releases it, or it held every planned rollover until the provider's own end. THE FALLBACK TRANSCRIBER, once:
    // gpt-live-transcribe refused, so the session is reconfigured on gpt-transcribe; a refusal of that releases too.
    const onTranscriberRefused = () => {
      record.dropUnheard();
      if (hearing === FALLBACK_TRANSCRIPTION_MODEL) return;
      hearing = FALLBACK_TRANSCRIPTION_MODEL;
      sendUpstream(sessionUpdate());
    };
    // A spoken turn's words. A transcript that is not a string is no words at all (VH-647), so its turn leaves as a
    // failed one does, rather than wait for words that will never come.
    const onTranscription = (event) => {
      if (listen) return;
      const completed = event.type === 'conversation.item.input_audio_transcription.completed';
      if (completed && typeof event.transcript === 'string') record.heard(event.item_id, event.transcript);
      else if (completed || event.type === 'conversation.item.input_audio_transcription.failed') record.unheard(event.item_id);
    };
    // What the relay itself acts on, by event type; everything was already forwarded above.
    const onUpstreamEvent = (event) => {
      if (event.type === 'error') noteUpstreamError(diag, event);
      if (transcriptionRefused(event)) onTranscriberRefused();
      // The operator is mid-speech from the voice detection's start until their words are COMMITTED (not merely
      // stopped), and their turn waits for its transcript after that (`record.awaiting`), so a rollover never falls
      // between the two and loses what they just said.
      if (event.type === 'input_audio_buffer.speech_started') speaking = true;
      if (event.type === 'input_audio_buffer.committed') { speaking = false; onCommitted(event); }
      onTranscription(event);
      // An active response is learned as well as asked, so the slot holds whoever opened it.
      if (event.type === 'response.created') onResponseCreated(event);
      if (event.type === 'response.output_text.delta' || event.type === 'response.output_audio_transcript.delta') noteAnswer(event);
      if (event.type === 'response.function_call_arguments.done' && typeof onToolCall === 'function') queueToolCall(event);
      if (event.type === 'response.done') onResponseDone(event);
    };
    // On open: the server's session first, then (after a rollover) the conversation, then what the browser sent
    // meanwhile, so the session is configured and carries its history before anything new reaches it.
    const onUpstreamOpen = (gen) => () => {
      if (gen !== generation || closed) return;
      if (openTimer) clearTimer(openTimer);
      openTimer = null;
      sendUpstream(sessionUpdate());
      const replay = replayNext;
      replayNext = [];
      for (const item of replay) sendUpstream(item);
      const held = pending;
      pending = [];
      pendingBytes = 0;
      for (const { text, onSent } of held) {
        if (closed) return;
        try { upstream.send(text); } catch { closeBoth('upstream-send-failed'); return; }
        onSent?.();
      }
      upstreamOpen = true;
    };
    // No `OpenAI-Beta` header: that selects the deprecated beta interface (VH-318-B).
    function dial() {
      generation += 1;
      const gen = generation;
      upstream = makeSocket(url, { headers: { authorization: 'Bearer ' + apiKey } });
      upstream.on('open', onUpstreamOpen(gen));
      upstream.on('message', onUpstreamMessage(gen));
      upstream.on('close', (code) => {
        if (gen === generation && !closed && Number.isInteger(code)) diag.upstreamClose = code;
        onUpstreamEnd(gen, 'upstream-closed');
      });
      upstream.on('error', (err) => {
        if (gen === generation && !closed) Object.assign(diag, upstreamErrorDetail(err));
        onUpstreamEnd(gen, 'upstream-error');
      });
      if (rolloverTimer) clearTimer(rolloverTimer);
      rolloverTimer = setTimer(() => {
        if (gen !== generation) return;
        recoveries = 0; // it lived its hour
        rolloverDue = true;
        maybeRollover();
      }, ROLLOVER_AFTER_MS);
      rolloverTimer?.unref?.();
      // A DIAL THAT NEITHER OPENS NOR FAILS is a failure after UPSTREAM_OPEN_TIMEOUT_MS: the first connection closes
      // with its evidence, a rollover's or a recovery's takes the same once-only rule as any other unexpected end,
      // and either way the hung socket is closed (by `closeBoth` or by the rollover that replaces it).
      if (openTimer) clearTimer(openTimer);
      openTimer = setTimer(() => {
        if (gen !== generation || closed || upstreamOpen) return;
        diag.openTimeoutMs = UPSTREAM_OPEN_TIMEOUT_MS;
        onUpstreamEnd(gen, 'upstream-open-timeout');
      }, UPSTREAM_OPEN_TIMEOUT_MS);
      openTimer?.unref?.();
    }

    // Client -> upstream: forward ONLY the safelisted interaction events; drop configuration events, binary,
    // oversized and non-JSON frames. This is where a client cannot override the persona or widen the tools.
    clientSocket.on('message', (data) => {
      const event = parseClientFrame(data);
      if (!event) return;
      // THE RELAY'S OWN CONTROL, handled here and NEVER forwarded: nothing on it reaches the provider, whatever
      // else the frame carries. A listener is never made an offer, so its extend does nothing.
      if (event.type === SESSION_EXTEND_TYPE) { extendSession(); return; }
      if (!clientEventAllowed(event.type)) return;
      if (listen && event.type !== 'input_audio_buffer.append') return; // a listener only streams the microphone
      // Forward a SERVER-reconstructed event, never the client's object, so no `session` override can reach the
      // model. The client cannot send a `response.*` event at all: the safelist refused it above.
      const safe = sanitiseClientEvent(event);
      if (!safe) return;
      forward(safe);
      // A typed turn is a new turn, and the relay, not the browser, asks for its text response. Its REBUILT text is
      // what the conversation record keeps.
      if (safe.type === 'conversation.item.create') {
        record.user(safe.item.content[0].text);
        startTurn('text');
        requestResponse();
      }
    });
    clientSocket.on('close', () => closeBoth('client-closed'));
    clientSocket.on('error', () => closeBoth('client-error'));

    dial();
    armSessionTimers(maxSessionMs);
    return { close: () => closeBoth('handle-closed') };
  }

  // THE CONNECTION CHECK'S DIAL (VH-777). The upstream Talk dials, opened and closed with nothing asked of it, so
  // "does the speech service answer this key and model" is measured without spending a token: the check used to try
  // the HTTP model alone, and Talk could be dead with it green. Resolves `{ ok, latencyMs }` once the service opens a
  // session, else `{ ok: false, latencyMs, timedOut?, upstreamStatus?, socketError? }`, codes only, for the caller to name.
  function probe({ timeoutMs = UPSTREAM_OPEN_TIMEOUT_MS } = {}) {
    if (!configured) return Promise.resolve({ ok: false, latencyMs: 0, notConfigured: true });
    const startedAt = now();
    return new Promise((resolve) => {
      let ws = null;
      let timer = null;
      let done = false;
      const finish = (out) => {
        if (done) return;
        done = true;
        clearTimer(timer);
        try { ws?.close(); } catch { /* already gone */ }
        resolve({ ...out, latencyMs: now() - startedAt });
      };
      timer = setTimer(() => finish({ ok: false, timedOut: true }), timeoutMs);
      try { ws = makeSocket(base + '?model=' + encodeURIComponent(model), { headers: { authorization: 'Bearer ' + apiKey } }); } catch (err) { finish({ ok: false, ...upstreamErrorDetail(err) }); return; }
      ws.on('message', (data) => {
        let event = null;
        try { event = JSON.parse(String(data)); } catch { event = null; }
        if (event?.type === 'session.created') finish({ ok: true });
        else if (event?.type === 'error') finish({ ok: false, upstreamCode: diagToken(event.error?.code) });
      });
      ws.on('error', (err) => finish({ ok: false, ...upstreamErrorDetail(err) }));
      ws.on('close', (code) => finish({ ok: false, upstreamClose: Number.isInteger(code) ? code : undefined }));
    });
  }

  return { configured, model, transcriptionModel, connect, probe };
}

/**
 * Which session an upgrade asks for: `listen` for the always-on wake-word listener (VH-318-F), `talk` otherwise.
 * @param {string} url the upgrade request's URL, path and query
 * @returns {'listen' | 'talk'}
 */
export function realtimeModeFromUrl(url) {
  let asked = '';
  try { asked = new URL(String(url || ''), 'http://localhost').searchParams.get('mode') || ''; } catch { asked = ''; }
  if (asked === 'listen' || asked === 'check') return asked;
  return 'talk';
}

/**
 * The domain a voice session looks up by default (VH-233). The browser names the domain on screen in the
 * upgrade URL; before this, voice lookups defaulted to Space whatever the operator was looking at. Only a
 * registered id is taken (a hyphenated spelling folds to its underscore form); anything else is '', and the
 * caller refuses the upgrade on it (VH-280), because a voice session told nothing is not a Space session.
 * @param {string} url the upgrade request's URL, path and query
 * @returns {string}
 */
export function realtimeDomainFromUrl(url) {
  let asked = '';
  try { asked = new URL(String(url || ''), 'http://localhost').searchParams.get('domain') || ''; } catch { asked = ''; }
  const id = asked.trim().toLowerCase().replaceAll('-', '_');
  return domainIds().includes(id) ? id : '';
}
