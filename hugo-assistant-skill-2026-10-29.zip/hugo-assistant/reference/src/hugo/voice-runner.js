// THE TOOLS BEHIND HUGO'S REALTIME SESSION (V1.77 D6, VH-318-G). The same bound tool layer the typed route
// uses (`src/hugo/tools.js`), built per connection so every lookup runs with the caller's own principal, and
// executed on the relay rather than in the browser. Lifted out of the composition root in `src/index.js` so the
// runner the relay calls is the runner the tests drive.
//
// THE WEB, which the voice runner never had (VH-318-G). The runner was built with no `webLookup`, so every
// spoken web question answered "web lookup is not available on this deployment" while the same question typed
// was looked up. It now takes the SAME builder the typed route uses (`hugoWebLookup`), so the two halves (the
// guarded page reader and the provider's hosted search) are identical on both paths.
//
// THE BUDGET IS PER TURN ON BOTH PATHS. The typed route builds its lookup per request, which is per turn. A
// realtime session is one connection carrying many turns, so a lookup built once per connection would spend
// its three lookups on the first questions and fail every web question after them. `newTurn()` renews it; the
// relay calls it when the operator starts a turn.

import { createToolRunner } from './tools.js';
import { hugoWebLookup } from './web-lookup.js';
import { realtimeModels } from './openai-realtime.js';
import { unpricedUnderCap } from '../scan/cost.js';
import { checkStreamedAnswer } from './stream-check.js';

/**
 * The models a realtime session would bill at whose price is not read, where a daily cap depends on them
 * (VH-318-I). Empty means the session may open; anything named means the cap cannot hold it and the path is
 * refused. Both models count: the realtime model and the one transcribing the operator's speech.
 * @param {{ dailyCapUsd?: number, env?: object }} args
 * @returns {string[]}
 */
export function voiceSessionUnpriced({ dailyCapUsd = 0, env = process.env } = {}) {
  const { model, transcriptionModel } = realtimeModels(env);
  return unpricedUnderCap({ models: [model, transcriptionModel], dailyCapUsd });
}

/**
 * The query runner a realtime session uses: Space through the master, a domain through its own store,
 * nothing cross-domain from a spoken question. An unwired domain store answers an empty page rather than
 * throwing, as it did in the composition root.
 */
export function voiceQueryRunner({ vendorRepo, domainRepoFor }) {
  return async (intent, page) => {
    if (intent.domain === 'space') return vendorRepo.queryByIntent(intent.filterSpec, page);
    const repo = typeof domainRepoFor === 'function' ? domainRepoFor(intent.domain) : null;
    return repo ? repo.queryProviders(intent.filterSpec, page) : { rows: [], total: 0, applied: [], notApplied: [] };
  };
}

/**
 * Bind the tool layer for one realtime session in `defaultDomain`.
 * @returns {{ run: Function, ledger: object, newTurn: () => void, check: (text: string) => { ok: boolean, violations: string[] } }}
 */
export function createVoiceRunner({ vendorRepo, domainRepoFor, provenanceRepo, pipelineRepo, erRepo, compileScan, webFetchDocument, hugoChat, defaultDomain, alignment } = {}) {
  let web = hugoWebLookup({ webFetchDocument, hugoChat });
  const webLookup = { lookup: (args) => web.lookup(args) };
  const runner = createToolRunner({
    runQuery: voiceQueryRunner({ vendorRepo, domainRepoFor }),
    vendorRepo, domainRepoFor, provenanceRepo, pipelineRepo, erRepo, compileScan, webLookup, defaultDomain, alignment,
  });
  return {
    run: runner.run,
    ledger: runner.ledger,
    newTurn() { web = hugoWebLookup({ webFetchDocument, hugoChat }); },
    // A finished streamed answer, checked against everything the session's tools returned (VH-318-E).
    check: (text) => checkStreamedAnswer(text, runner.ledger),
  };
}
