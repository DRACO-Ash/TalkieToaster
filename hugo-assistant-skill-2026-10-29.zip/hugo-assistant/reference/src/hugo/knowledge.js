// WHAT HUGO KNOWS ABOUT THE APP ITSELF (VH-777 Lane T, owner, 2026-10-26: "able to talk freely and naturally about what it
// knows (with regards the app - everything from database, to help files)"). Before this, every tool Hugo had read the
// dataset or the web, so a question about the app had nothing to answer from and its verifier withdrew the answer.
//
// Four read-only sources, each returned with where it came from so the answer can say so:
//   ● the in-app help (`public/help-content.js`), the same task cards, concepts, troubleshooting and per-view notes the
//     help panel draws, and the user guide's chapters where the image says they are (`HUGO_GUIDE_DIR`);
//   ● the app's shape: its domains, their capability facets, its views and what each is for;
//   ● the app's state: the running version and how many records each domain holds;
//   ● the recent history: what changed, by which action, on which record and when, never the change's values.
// Nothing here reads a secret, a passcode's value or a setting's value.

import { readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { readFile, readdir } from 'node:fs/promises';
import { VIEWS, TASK_CARDS, CONCEPTS, TROUBLESHOOTING, RIGHT_NOW } from '../../public/help-content.js';
import { domainIds, getDescriptor } from '../domain/descriptor.js';
import { APP_NAME } from '../brand.js';

const PASSAGE_CHARS = 1200;
const RESULTS_MAX = 5;
const HISTORY_MAX = 25;
// Words too common to say anything about which passage answers.
const STOP = new Set(['the', 'and', 'for', 'how', 'what', 'does', 'can', 'with', 'this', 'that', 'into', 'from', 'are', 'you',
  'your', 'its', 'which', 'when', 'where', 'why', 'who', 'there', 'about', 'have', 'has', 'was', 'were', 'will', 'app', 'hugo']);

const clip = (text, max = PASSAGE_CHARS) => (text.length > max ? text.slice(0, max - 1).trimEnd() + '…' : text);
const words = (text) => String(text || '').toLowerCase().match(/[a-z0-9]+/g) || [];
const join = (...parts) => parts.flat().filter((p) => typeof p === 'string' && p.trim()).join(' ');

/** The help panel's own entries as passages: `{ source, title, text }`. */
export function helpPassages() {
  const out = [];
  for (const c of TASK_CARDS) {
    const route = (c.route || []).map((r) => join(r.control, r.where ? '(' + r.where + ')' : '', r.note));
    out.push({ source: 'In-app help, task: ' + c.title, title: c.title, text: join(c.goal, 'How:', route, c.doIt, c.changes, c.ifStuck) });
  }
  for (const c of CONCEPTS) out.push({ source: 'In-app help, concept: ' + c.term, title: c.term, text: join(c.short, c.long) });
  for (const t of TROUBLESHOOTING) out.push({ source: 'In-app help, troubleshooting: ' + t.symptom, title: t.symptom, text: join('Likely:', t.likely, 'Do:', t.action) });
  for (const [view, v] of Object.entries(RIGHT_NOW)) {
    out.push({ source: 'In-app help, the ' + view + ' view', title: view, text: join(v.where, (v.common || []).map((c) => c.label + '.'), v.traps) });
  }
  return out;
}

/** A guide chapter in passages, one per heading. */
export function guidePassages(file, markdown) {
  const out = [];
  let title = '';
  let lines = [];
  const flush = () => {
    const text = lines.join(' ').replaceAll(/\s+/g, ' ').trim();
    if (title && text) out.push({ source: 'User guide, ' + file + ': ' + title, title, text });
  };
  for (const line of String(markdown).split('\n')) {
    const head = /^#{1,4} /.test(line) ? line.replace(/^#+/, '').trim() : '';
    if (head) { flush(); title = head; lines = []; } else lines.push(line);
  }
  flush();
  return out;
}

// The guide's chapters, read once per folder; a missing folder is no guide, never an error.
const guideRead = new Map();
async function guide(dir) {
  try {
    const files = (await readdir(dir)).filter((f) => f.endsWith('.md')).toSorted((a, b) => a.localeCompare(b));
    const chapters = await Promise.all(files.map(async (f) => guidePassages(f, await readFile(new URL(f, dir), 'utf8'))));
    return chapters.flat();
  } catch {
    return [];
  }
}
// WHERE THE GUIDE IS, SAID BY THE IMAGE (`HUGO_GUIDE_DIR`, the Dockerfile), read at call time. Named there rather than
// here, so the many tests that reach this module through Hugo's tools do not count as readers of the release records
// (`scripts/gate-lib.mjs`, VH-420); without it Hugo searches the in-app help alone.
function guideDirFromEnv() {
  const dir = process.env.HUGO_GUIDE_DIR;
  if (!dir) return null;
  return pathToFileURL(dir.endsWith('/') ? dir : dir + '/');
}

/** Score passages against a question: each distinct question word a passage holds counts, its title three times over. */
export function rankPassages(question, passages, max = RESULTS_MAX) {
  const asked = [...new Set(words(question).filter((w) => w.length > 2 && !STOP.has(w)))];
  if (!asked.length) return [];
  return passages.map((p) => {
    const title = new Set(words(p.title));
    const body = new Set(words(p.text));
    const score = asked.reduce((n, w) => n + (title.has(w) ? 3 : 0) + (body.has(w) ? 1 : 0), 0);
    return { p, score };
  }).filter((x) => x.score > 0).toSorted((a, b) => b.score - a.score).slice(0, max)
    .map(({ p }) => ({ source: p.source, title: p.title, text: clip(p.text) }));
}

/** `search_help`: the help and guide passages that answer a question, each with its source. */
export async function searchHelp(question, { guideDir = guideDirFromEnv() } = {}) {
  let chapters = [];
  if (guideDir) {
    if (!guideRead.has(guideDir.href)) guideRead.set(guideDir.href, guide(guideDir));
    chapters = await guideRead.get(guideDir.href);
  }
  const passages = [...helpPassages(), ...chapters];
  const found = rankPassages(question, passages);
  return { question: String(question || '').slice(0, 300), passages: found, searched: passages.length };
}

/** `describe_app`: the app's name, its domains with their capability facets, and its views with what each is for. */
export function describeApp() {
  return {
    name: APP_NAME,
    domains: domainIds().map((id) => {
      const d = getDescriptor(id);
      return { id, label: d?.label || id, capabilityFacets: (d?.capabilityFacets || []).map((f) => f.label || f.key) };
    }),
    views: VIEWS.map((view) => ({ view, purpose: RIGHT_NOW[view]?.where || '' })),
    source: 'The domain registry and the in-app help',
  };
}

/**
 * `app_state`: the running version and each domain's record count, read through `countDomain(id)`, which answers a
 * number or null when that store cannot be read (said, never shown as 0).
 */
let runningVersion = null;
const packageVersion = () => (runningVersion ??= String(JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')).version || ''));

// HUGO'S OWN VOICE ON THIS DEPLOYMENT (VH-865). Asked why Talk was missing, Hugo answered "Voice is available in some setups,
// but not all", because the help says only that Talk shows "where this deployment has voice". The process publishes what
// it knows (src/index.js), the same three facts the Talk control reads, and `app_state` says them in words, with the
// setting's NAME where one fixes it, never its value.
let voiceStateOf = () => null;
/** @param {() => ({ configured: boolean, live: boolean, realtime: boolean } | null)} read */
export function publishVoiceState(read) {
  voiceStateOf = typeof read === 'function' ? read : () => null;
}
/** The voice state in words, or null when the process has published none. */
export function voiceStateWords(v) {
  if (!v || typeof v !== 'object') return null;
  if (v.configured !== true) {
    return 'Hugo\'s voice is not set up on this app: OPENAI_API_KEY is not set. An administrator sets it in the App Store environment and applies it; until then Talk shows, disabled, with that reason.';
  }
  if (v.live === true) {
    return 'Talk is on: press Talk beside Send in Hugo\'s panel. It runs over his live voice (WebRTC) on any current browser with a microphone. If Talk is disabled, the line beneath it says why and the one step that fixes it.';
  }
  if (v.realtime === true) {
    return 'Talk runs over the app\'s own link on this app, which needs the App Store route to let WebSocket upgrades through to /api/v3/hugo/realtime and a sign-in that carries an app token. If Talk is disabled, the line beneath it says why.';
  }
  return 'Hugo\'s live voice is off on this app. An administrator can run Check Hugo\'s connection, under Settings, Hugo\'s voice, to see why.';
}

export async function appState({ version = packageVersion(), countDomain }) {
  const counts = await Promise.all(domainIds().map(async (id) => {
    let n = null;
    try { n = await countDomain(id); } catch { n = null; }
    return { domain: id, label: getDescriptor(id)?.label || id, records: Number.isSafeInteger(n) ? n : null };
  }));
  const voice = voiceStateWords(voiceStateOf());
  return { version: String(version || ''), domains: counts, ...(voice ? { voice } : {}), source: 'The running app' };
}

/**
 * `recent_history`: the latest changes across the dataset, each by when, who, what action, on which store and record.
 * The change's own values are left out; the record's history in the app holds them.
 */
export async function recentHistory(vendorRepo, { domain, limit } = {}) {
  if (typeof vendorRepo?.datasetHistory !== 'function') return { rows: [], available: false };
  const n = Math.min(HISTORY_MAX, Math.max(1, Number.parseInt(limit, 10) || 10));
  const entity = domainIds().includes(domain) && domain !== 'space' ? domain : undefined;
  const page = await vendorRepo.datasetHistory({ entity, limit: n, offset: 0 });
  return {
    rows: (page?.rows || []).map((r) => ({ when: r.occurred_at, actor: r.actor, action: r.action, store: r.entity, record: r.entity_id, name: r.name || '' })),
    total: page?.total ?? null,
    source: 'The audit history',
  };
}
