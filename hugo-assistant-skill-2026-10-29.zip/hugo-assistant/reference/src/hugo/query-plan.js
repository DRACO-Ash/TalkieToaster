// The Hugo query plan (docs/PLAN-hugo-query-drive.md item E, the database filter surface). Turns a VALIDATED
// ViewIntent filterSpec into a parameterised WHERE clause over the vendor_core row, so "the correct filters
// in the database" is real: an exact, bound, injection-safe server-side query, not a client-side sieve over a
// full fetch. Pure and self-contained: it returns { sql, params, applied, notApplied } and touches no I/O, so
// it is unit-tested without a database and the repo method that runs it stays thin.
//
// EVERY VALUE IS ALREADY DESCRIPTOR-VALID. This builder is only reached with a filterSpec that has passed
// normaliseViewIntent (controlled vocab, canonical countries, known family keys), so a value here cannot be
// hostile; even so, nothing is interpolated - every value is a bound array parameter, matching buildVendorWhere.
//
// SUPPORTED CLAUSES over the vendor row are the ones that map to the mirror columns and JSONB paths the board
// already queries: countries, gdm, sections, missions (grades went with the readiness axis in V1.80). V1.77 (W1-3) adds the PIPELINE clauses -
// stages, blockerKinds, priorities, owners, due, blocked and ageingDays - as correlated EXISTS subqueries
// over `gdm_pipeline`; see the note above `PIPELINE_DERIVED_STAGE` for the one thing about them that is not
// obvious. The remaining clauses (families, size bands, export-control status, releasability, product types)
// are REPORTED in `notApplied` rather than silently dropped, so the confirm surface can tell the operator
// which parts of their request the database cannot yet filter on. Families in particular need the
// product_type -> family mapping wired server-side, a later unit.

import { SPACE_DESCRIPTOR, allFacets } from '../domain/descriptor.js';
import { productTypesForFamilies, listOf } from './families.js';
import { DISPOSITIONS, isExcluded } from '../domain/eligibility.js';
import { SPACE_SHOWN_GDM_SQL } from '../db/gdm-membership.js';
import { spaceMissionSql } from '../db/mission-relevance.js';
import { searchFoldPredicate, foldParam } from '../db/search-sql.js';

const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const stringsOf = (v) => (Array.isArray(v) ? v.filter((s) => typeof s === 'string' && s) : []);

// The eligibility dispositions that must never surface through Hugo, taken from the one gate rather than
// re-listed here (so the policy cannot drift). A row is dropped when it is EXPLICITLY tagged with one of
// these, or is quarantined. An ABSENT tag admits: the vendor core is JCO/GDM readiness tracking, not an
// eligibility-gated product line, so absence means "not an eligibility subject", not "unverifiable" - the
// product-line store applies the full fail-closed classification at its own write boundary. This guard is
// the governance backstop (H-4): an excluded-tagged or quarantined row can never be read out through Hugo.
const EXCLUDED_DISPOSITIONS = Object.freeze(DISPOSITIONS.filter(isExcluded));

// SPACE'S OWN CAPABILITY FACET (VH-263): the orbital regime list on the record, matched as any of the values asked
// for. The key is the descriptor's constant, never a caller's. Every other domain's facet is reported below.
const SPACE_FACETS = Object.freeze((SPACE_DESCRIPTOR?.capabilityFacets || []).map((f) => f.key));
const OTHER_FACETS = Object.freeze(allFacets().map((f) => f.key).filter((k) => !SPACE_FACETS.includes(k)));

// The clauses this cut can express server-side, each as a builder from its 1-based parameter index. The value
// is always pushed as a text[] and bound; the SQL never carries a client value.
const SUPPORTED = Object.freeze([
  { key: 'countries', build: (n) => `data->>'country' = ANY($${n}::text[])` },
  // The band the ROW SHOWS, folded, as the board's own GDM control reads it (the roster and the other
  // catalogues included), so Hugo's "the In GDM vendors" is the set the strip counts.
  { key: 'gdm', expand: (values) => values.map((v) => v.trim().toLowerCase()), build: (n) => `lower(btrim(${SPACE_SHOWN_GDM_SQL})) = ANY($${n}::text[])` },
  { key: 'sections', build: (n) => `section = ANY($${n}::text[])` },
  // A mission is Mission Alignment's (VH-801): a data type the record supplies carries it, the board's own rule
  // (`spaceMissionSql`), matched by name in lower case. The record's stored mission list is no longer read.
  { key: 'missions', expand: (values) => values.map((v) => v.trim().toLowerCase()), build: (n) => spaceMissionSql('data', '$' + n) },
  // THE CAPABILITY CLAUSES (V1.82, RT-Q4). These five were resolved by the deterministic layer, listed as
  // DEFERRED below, and never turned into SQL, so "show me the SAR vendors" and "the ITAR-controlled vendors"
  // filtered nothing while the confirm surface said what had been understood. Each reads the record where the
  // value actually lives. Size band, control status and releasability were retired in VH-824. A FAMILY is expanded to the product types it covers at plan time, from the Space vocabulary in Space's own
  // families (each domain holds its own), so the SQL binds plain labels and no regex crosses into the database.
  // VH-706: "Data type/value chain", so a value matches the record's data types or its roles (owner, 09:52 UTC).
  { key: 'productTypes', build: (n) => `(data->'product_types' ?| $${n} or data->'chain' ?| $${n})` },
  { key: 'families', expand: (keys) => productTypesForFamilies(keys, spaceProductTypes(), 'space'), build: (n) => `data->'product_types' ?| $${n}` },
  ...SPACE_FACETS.map((key) => ({ key, build: (n) => `data->'${key}' ?| $${n}` })),
]);
// Present in a ViewIntent but not yet expressible in the database here; reported, never silently applied.
// Empty since RT-Q4 closed the five above; the mechanism stays for the next clause that arrives before its SQL.
const DEFERRED = Object.freeze([]);

// The Space product-type vocabulary the families clause expands into, read per plan from the live Set (VH-623): it was
// copied once at load, so "the SAR vendors" missed a SAR type the owner ruled in until restart.
const spaceProductTypes = () => listOf(SPACE_DESCRIPTOR?.vocab?.product_types);

/**
 * THE PIPELINE CLAUSES (V1.77 W1-3), as correlated EXISTS subqueries over `gdm_pipeline`.
 *
 * THE THING THAT MAKES THIS NON-OBVIOUS: A MEMBER WITH NO PIPELINE ROW STILL HAS A STAGE. `lazyBase` in
 * `src/db/pipeline-repo.js` treats a member with no stored row as holding a row DERIVED from the coarse band
 * the vendor already carries: In GDM reads as `live`, Onboarding as `identified`, anything else as
 * `unengaged`. So a stage filter that looked only at stored rows would silently omit every member the
 * pipeline has never been touched for, which on this dataset is most of them. The derivation is a pure
 * function of `vendor.gdm`, so it is expressed here as the same three cases, in the same order, and the
 * `stages` clause is EXACT rather than partial.
 *
 * The other clauses need no derived branch, and that is a property of the data rather than a simplification:
 * a derived row carries `owner: null`, `priority: null`, `due: null`, `blocked: false` and `blockers: []`, so
 * no member without a stored row can match an owner, a priority, a due window or a blocker kind. Each of
 * those clauses is therefore exact over stored rows alone. `blocked: false` is the one that would have been
 * wrong: it is written as `not exists (a blocked row)` rather than `exists (a row with blocked = false)`, so
 * it admits the members with no row at all, which are not blocked.
 *
 * `ageingDays` is the single approximation, and it is stated rather than hidden: it measures from
 * `stage_entered_at` on a stored row and falls back to `vendor.updated_at` where there is none, which is what
 * `lazyBase` itself does for the Not-in-GDM and Onboarding cases. It does NOT reproduce lazyBase's preference
 * for a parsed `gdm_onboarded_at` on an In-GDM member, because that value is free text in JSONB and casting
 * it inside a filter predicate would throw the whole query on one malformed date. A derived In-GDM member's
 * age therefore reads from its last update rather than its onboarding date. Recorded here, and in
 * `docs/RESIDUALS.md`, rather than left for someone to discover.
 */
const PIPELINE_DERIVED_STAGE = "case coalesce(nullif(vendor.gdm, ''), 'Not in GDM') "
  + "when 'In GDM' then 'live' when 'Onboarding' then 'identified' else 'unengaged' end";

/**
 * WHICH STORE THE PIPELINE CLAUSES ARE WRITTEN FOR (VH-261). The same seven clauses serve the Space master and
 * the six product-line stores, and only three things differ between them: the column holding the member id the
 * pipeline row is keyed on, the band a member with no stored row derives its stage from, and the timestamp its
 * age is read from where there is no stored entry. Each is `lazyBase`'s own reading for that store
 * (`memberSql` in `src/db/pipeline-repo.js`), so the clause and the row the pipeline would create agree.
 * `offset` is how many parameters the caller bound before these, so a store that numbers from a later `$n` gets
 * indices that line up. Every name here is this module's or a validated table identifier, never a caller's.
 */
export const SPACE_PIPELINE_SHAPE = Object.freeze({
  member: 'vendor.vendor_id', derivedStage: PIPELINE_DERIVED_STAGE, derivedSince: 'vendor.updated_at', offset: 0,
});

// One correlated subquery, so the join key is written once. The domain's parameter index travels on the shape
// rather than being fixed at $1: a bind parameter the SQL never references is a Postgres error ("bind message
// supplies N parameters, but prepared statement requires M"), so the domain is pushed only when a pipeline
// clause is actually present, and its index depends on what came before it. The alias is `pl`, not `p`,
// because the product-line stores already read the shared identity as `p`.
const pipelineExists = (shape, predicate) => `exists (select 1 from gdm_pipeline pl where pl.domain = $${shape.domainIdx} `
  + `and pl.member_id = ${shape.member} and ${predicate})`;

// The relative due windows, as SQL over the `due` date column. `none` is "no due date set", which is a
// question an operator asks ("what has nobody scheduled") and is not the same as "not overdue".
const DUE_SQL = Object.freeze({
  overdue: 'pl.due is not null and pl.due < current_date',
  today: 'pl.due = current_date',
  week: "pl.due is not null and pl.due >= current_date and pl.due < current_date + interval '7 days'",
  month: "pl.due is not null and pl.due >= current_date and pl.due < current_date + interval '1 month'",
  none: 'pl.due is null',
});

/**
 * Build the WHERE clause and bound params for a ViewIntent filterSpec. Returns { sql, params, applied,
 * notApplied }. `applied` names the clauses that became SQL; `notApplied` names clauses the operator asked for
 * that this cut cannot filter on (so the confirm surface is honest). Live rows only (merged and soft-deleted
 * excluded) unless includeMerged. Pure.
 */
/**
 * THE SAME H-4 STOP FOR ONE SPACE RECORD, in JavaScript, for a read by id (V2.3 re-cut, security gate). The
 * set reads apply it in SQL above; `get_record` reads one record by its id and applied nothing, so an excluded
 * or quarantined Space row reached the model. The two agree term for term: an excluded disposition compared
 * exactly, as `= ANY` does, and the closed falsy KEEP list for `quarantined`, lower-cased as `lower()` does.
 * An untagged row (no disposition) admits, as it does in SQL.
 */
const QUARANTINE_KEEP = new Set(['', 'false', 'f', '0', 'no', 'n']);
export function spaceRecordIsHeld(record) {
  const r = isPlainObject(record) ? record : {};
  const eligibility = r.line_eligibility === undefined || r.line_eligibility === null ? '' : String(r.line_eligibility);
  const quarantined = r.quarantined === undefined || r.quarantined === null ? '' : String(r.quarantined).toLowerCase();
  return EXCLUDED_DISPOSITIONS.includes(eligibility) || !QUARANTINE_KEEP.has(quarantined);
}

// A LIKE pattern for a typed name, folded to lower case with the wildcards escaped, the way the board's own
// search escapes them, so a `%` or `_` an operator types matches itself and nothing else. A callback rather
// than a replacement string, so no backslash sequence has to be read twice to be believed.
const likePattern = (text) => '%' + text.toLowerCase().replaceAll(/[\\%_]/g, (ch) => '\\' + ch) + '%';

export function buildIntentWhere(filterSpec, { includeMerged = false, pipelineDomain = 'space', storedFold = false } = {}) {
  const f = isPlainObject(filterSpec) ? filterSpec : {};
  const clauses = [];
  const params = [];
  const applied = [];
  const notApplied = [];
  if (!includeMerged) clauses.push("coalesce(lifecycle_status, 'active') not in ('merged', 'deleted')");
  // Eligibility backstop (H-4), always applied: a row tagged with an excluded disposition, or quarantined,
  // never leaves through Hugo. Bound as a text[] so the disposition list is never interpolated; an untagged
  // row (empty coalesce) is not in the set and admits.
  params.push(EXCLUDED_DISPOSITIONS);
  // The quarantined stop is fail-CLOSED across encodings (W5): a row is kept only when its `quarantined` is
  // absent or an explicit falsy value; a JSON boolean true (`'true'`), a number `1`, `'t'`, `'yes'`, or any
  // unexpected value all exclude. The controlled writer stores a boolean, but a security stop must not admit a
  // row on a stray encoding, so the KEEP set is the closed falsy list rather than a single `<> 'true'`.
  clauses.push(
    `not (coalesce(data->>'line_eligibility', '') = ANY($${params.length}::text[]))`,
    "coalesce(lower(data->>'quarantined'), '') in ('', 'false', 'f', '0', 'no', 'n')",
  );
  for (const { key, build, expand } of SUPPORTED) {
    const values = stringsOf(f[key]);
    if (values.length === 0) continue;
    // A family that covers no product type in this vocabulary is reported, never bound as an empty list
    // that would match nothing and say nothing.
    const bound = expand ? expand(values) : values;
    if (bound.length === 0) { notApplied.push(key); continue; }
    params.push(bound);
    clauses.push(build(params.length));
    applied.push(key);
  }
  // THE TYPED NAME (VH-181), over the same folded whole-record text the Space board's search box reads, through
  // the stored fold where the deployment has it, so a name Hugo applies finds what typing it there finds.
  const search = typeof f.search === 'string' ? f.search.trim() : '';
  if (search) {
    params.push(likePattern(search));
    clauses.push(`${searchFoldPredicate(storedFold)} like ${foldParam('$' + params.length)}`);
    applied.push('search');
  }
  addPipelineSql(f, { clauses, params, applied }, pipelineDomain, SPACE_PIPELINE_SHAPE);
  for (const key of [...DEFERRED, ...OTHER_FACETS]) {
    if (stringsOf(f[key]).length > 0) notApplied.push(key);
  }
  return { sql: clauses.length ? 'where ' + clauses.join(' and ') : '', params, applied, notApplied };
}

/**
 * Append the pipeline clauses. Mutates the three accumulators, because the parameter indices depend on
 * everything pushed before this point and threading them back would be worse than the mutation.
 *
 * Nothing is pushed at all when no pipeline clause is present, including the domain parameter: see
 * `pipelineExists` for why an unreferenced bind parameter is an error rather than a waste.
 */
// "the stored row satisfies it, OR there is no stored row and the derived one satisfies it". Written once
// because both clauses that need it would otherwise carry the same three-part expression inline.
function storedOrDerived(shape, storedPredicate, derivedPredicate) {
  return '(' + pipelineExists(shape, storedPredicate)
    + ' or (not ' + pipelineExists(shape, 'true') + ' and ' + derivedPredicate + '))';
}

// The four LIST clauses. `priorities` and `owners` share the shape (`pl.<column> = ANY($n)`) and are driven
// from one table; `stages` needs the derived branch and `blockerKinds` reads inside a JSONB array, so each
// keeps its own build.
const PIPELINE_COLUMN_LISTS = Object.freeze([
  { key: 'priorities', column: 'pl.priority' },
  { key: 'owners', column: 'pl.owner' },
]);

// The `$n` the value just pushed is bound to, counting whatever the caller bound before this builder ran.
const lastIndex = (acc, shape) => shape.offset + acc.params.length;

function addPipelineListSql(f, acc, shape) {
  const stages = stringsOf(f.stages);
  if (stages.length) {
    acc.params.push(stages);
    const match = 'pl.stage = ANY($' + lastIndex(acc, shape) + '::text[])';
    const derived = shape.derivedStage + ' = ANY($' + lastIndex(acc, shape) + '::text[])';
    // The stored row OR the derived one, which is what makes this exact rather than a query over the
    // minority of members the pipeline has been touched for.
    acc.clauses.push(storedOrDerived(shape, match, derived));
    acc.applied.push('stages');
  }
  const blockerKinds = stringsOf(f.blockerKinds);
  if (blockerKinds.length) {
    acc.params.push(blockerKinds);
    // A blocker is an object in the `blockers` array; its `kind` is what the closed vocabulary names. Read as
    // an existence over the array's elements rather than through a JSONB path operator, so a blocker carrying
    // extra keys still matches on its kind alone.
    acc.clauses.push(pipelineExists(shape,
      "exists (select 1 from jsonb_array_elements(pl.blockers) b where b->>'kind' = ANY($"
      + lastIndex(acc, shape) + '::text[]))'));
    acc.applied.push('blockerKinds');
  }
  for (const { key, column } of PIPELINE_COLUMN_LISTS) {
    const values = stringsOf(f[key]);
    if (values.length === 0) continue;
    acc.params.push(values);
    acc.clauses.push(pipelineExists(shape, column + ' = ANY($' + lastIndex(acc, shape) + '::text[])'));
    acc.applied.push(key);
  }
}

// The three SCALAR clauses: a due window, the blocked tristate and the ageing threshold.
function addPipelineScalarSql(f, acc, shape) {
  const due = typeof f.due === 'string' && Object.hasOwn(DUE_SQL, f.due) ? f.due : '';
  if (due) {
    acc.clauses.push(pipelineExists(shape, DUE_SQL[due]));
    acc.applied.push('due');
  }
  if (f.blocked === true || f.blocked === false) {
    // `false` as a NEGATED existence, so a member with no pipeline row reads as not blocked, which it is.
    const blockedRow = pipelineExists(shape, 'pl.blocked');
    acc.clauses.push(f.blocked ? blockedRow : 'not ' + blockedRow);
    acc.applied.push('blocked');
  }
  if (Number.isInteger(f.ageingDays) && f.ageingDays > 0) {
    acc.params.push(f.ageingDays);
    // `make_interval(days => $n)` rather than string concatenation into an interval literal: the value is a
    // bound integer parameter and never becomes SQL text.
    const cut = 'now() - make_interval(days => $' + lastIndex(acc, shape) + '::int)';
    acc.clauses.push(storedOrDerived(shape, 'pl.stage_entered_at <= ' + cut, shape.derivedSince + ' <= ' + cut));
    acc.applied.push('ageingDays');
  }
}

/** Whether any pipeline clause is present at all, which decides whether the domain parameter is pushed. */
export function wantsPipeline(f) {
  const lists = ['stages', 'blockerKinds', 'priorities', 'owners'];
  if (lists.some((key) => stringsOf(f?.[key]).length > 0)) return true;
  if (typeof f?.due === 'string' && Object.hasOwn(DUE_SQL, f.due)) return true;
  if (f?.blocked === true || f?.blocked === false) return true;
  return Number.isInteger(f?.ageingDays) && f.ageingDays > 0;
}

/**
 * The pipeline clauses for ANY store (VH-261): Space through `SPACE_PIPELINE_SHAPE`, a product-line store
 * through the shape it passes. Appends to `acc` ({ clauses, params, applied }) and returns nothing.
 * @param {object} f the validated filterSpec
 * @param {{clauses: string[], params: unknown[], applied: string[]}} acc
 * @param {string} pipelineDomain the `gdm_pipeline.domain` the rows are keyed under
 * @param {{member: string, derivedStage: string, derivedSince: string, offset: number}} shape
 */
export function addPipelineSql(f, acc, pipelineDomain, shape) {
  if (!wantsPipeline(f)) return;
  acc.params.push(pipelineDomain);
  const bound = { ...shape, domainIdx: lastIndex(acc, shape) };
  addPipelineListSql(f, acc, bound);
  addPipelineScalarSql(f, acc, bound);
}
