// HUGO SETTLES A COUNTRY THE APP WILL NOT GUESS (VH-840 part B; owner, 2026-10-26: "instead of pushing to a human - they
// simply use the AI that is embedded - to do a better job at searching, a short internet search could solve this").
//
// WHAT IT DOES. One record whose country is the unknown marker, a bare `NA`, or a bare code that could be a country or a
// US state (CLAUDE.md, "Countries and localities") is put to Hugo's hosted web search as one question: where is this
// company headquartered. The answer settles the country only when all of these hold, and otherwise the record stays on
// the list with the reason:
//   ● the search came back with at least one citable source (`createWebLookup` already refuses one that did not);
//   ● the answer's opening, up to its first full stop, names a country the canon recognises, so a stranger's page can
//     only ever choose among real country names, never write free text (the lookup's scrub folds newlines to spaces, so
//     a first line would not survive it);
//   ● for an ambiguous code, that country is one of the code's two readings (`CA` is Canada or the United States, and
//     nothing else), so the search resolves the ambiguity rather than replacing the record.
// It never writes. A person accepts what it found (owner, 2026-10-26, by popup: "One click to confirm"), and the accept
// route checks the country and the source again (`acceptableCountry`, `acceptableSource`) before the record's own sourced
// edit writes them.

import { CODE_TO_NAME, canonicalSpelling, headOfficeHead, isRecognisedCountry } from '../domain/country-canon.js';
import { isAmbiguousBareCode, isNotAvailableCode } from '../db/normaliser.js';

const UNKNOWN_COUNTRY = 'tbc, re-verify';
const QUESTION_CHARS = 400;

/**
 * The countries a stored value may settle to: `null` when it needs no settling, `[]` when any recognised country may
 * stand (the marker, or `NA`, which may mean "not available"), or the two readings of an ambiguous code.
 * @returns {string[] | null}
 */
export function countryCandidates(raw) {
  const value = typeof raw === 'string' ? raw.trim() : '';
  if (!value) return null;
  if (value.toLowerCase() === UNKNOWN_COUNTRY) return [];
  const head = headOfficeHead(value) || value;
  if (isNotAvailableCode(head)) return [];
  if (isAmbiguousBareCode(head)) return [CODE_TO_NAME.get(head.toUpperCase()), 'United States'].filter(Boolean);
  return null;
}

/** The one question put to the search, bounded to what the search accepts. */
export function settleQuestion({ name, website, country }) {
  const site = typeof website === 'string' && website.trim() ? ' (website ' + website.trim().slice(0, 120) + ')' : '';
  const said = typeof country === 'string' && country.trim() ? ' Its record says "' + country.trim().slice(0, 40) + '".' : '';
  return ('In which country is the company "' + String(name || '').trim().slice(0, 160) + '"' + site + ' headquartered?' + said
    + ' Start the answer with the country name alone and a full stop, then say where that is stated.').slice(0, QUESTION_CHARS);
}

/** The country the answer opens with, up to its first full stop, in the canon's spelling, or '' when that is not one. */
export function answeredCountry(summary) {
  const first = (typeof summary === 'string' ? summary : '').trim().split(/[.\n]/)[0];
  const line = first.replace(/^\W*(country|answer)\s*:\s*/i, '').replaceAll(/[*_`]/g, '').trim();
  if (line.length === 0 || line.length > 60 || !isRecognisedCountry(line)) return '';
  return canonicalSpelling(line);
}

/**
 * Settle one record's country through `lookup` (a `createWebLookup().lookup`). Never throws.
 * @returns {Promise<{ settled: true, country: string, source: string, sources: object[] } | { settled: false, reason: string }>}
 */
export async function settleCountry(record, lookup) {
  const candidates = countryCandidates(record?.country);
  if (candidates === null) return { settled: false, reason: 'This country is already settled.' };
  if (typeof lookup !== 'function') return { settled: false, reason: 'Web search is not available on this deployment.' };
  const out = await lookup({ question: settleQuestion(record) });
  if (!out?.ok) return { settled: false, reason: 'Hugo could not search: ' + String(out?.error || 'no answer') + '.' };
  const sources = Array.isArray(out.result?.sources) ? out.result.sources : [];
  if (!sources.length) return { settled: false, reason: 'The search found nothing with a source.' };
  const country = answeredCountry(out.result?.summary);
  if (!country) return { settled: false, reason: 'The search did not name one country.' };
  if (candidates.length && !candidates.includes(country)) {
    return { settled: false, reason: 'The search named ' + country + ', which is not ' + candidates.join(' or ') + '.' };
  }
  return { settled: true, country, source: sources[0].url, sources };
}

/** The canon's spelling of a country a person accepted for a record holding `stored`, or '' when it cannot stand. */
export function acceptableCountry(stored, raw) {
  const candidates = countryCandidates(stored);
  const country = typeof raw === 'string' && raw.length <= 60 && isRecognisedCountry(raw) ? canonicalSpelling(raw) : '';
  if (candidates === null || !country) return '';
  return candidates.length && !candidates.includes(country) ? '' : country;
}

// A WHOLE web address, as the lookup's own citation gate requires: no whitespace, quotes or angle brackets, nothing in the
// Unicode format category, and no credentials in the authority, normalised by the parser.
const STRICT_URL = /^https?:\/\/[^\s<>"'`\\{}|^\p{C}]{1,490}$/u;
/** The normalised source a person accepted, or '' when it is not a plain http or https address. */
export function acceptableSource(raw) {
  if (typeof raw !== 'string' || !STRICT_URL.test(raw)) return '';
  try {
    const u = new URL(raw);
    return u.username || u.password ? '' : u.toString().slice(0, 500);
  } catch {
    return '';
  }
}
