// HUGO'S TOOL LAYER (V1.77 D6, PLAN-V1.77 W2-3): one provider-neutral set of tools the agent loop, the
// realtime relay and the deterministic fallback all call through, every one of them READ-ONLY or
// CONFIRM-FIRST. A read tool queries the operator's own dataset with the operator's own principal and
// returns a bounded, sanitised result; a confirm-first tool (`propose_scan`, `propose_update`) returns
// what WOULD happen and marks it `requiresConfirmation`, and nothing here starts a run or writes a record.
//
// THE LEDGER is the point of the layer. Every result a tool returns is folded into a session ledger of
// the row ids, the names and the numbers the model has actually been shown, and the agent's final answer
// is verified against that ledger SERVER-side (`src/hugo/agent.js`): a row id the tools never returned, a
// company the model DECLARES that the tools never named, a figure that appears in no tool result, is a
// fabrication and is refused. Names are checked from the answer's declared `entities` list, not by scanning
// the prose for proper nouns (figures in the prose ARE scanned); an organisation the model names in the prose
// and omits from the list passes, which is recorded in docs/RESIDUALS.md for V1.78. The ledger is what makes
// "never invent" a check rather than an instruction.
//
// Every argument is validated here: a filter goes through the same `normaliseViewIntent` the confirm-first
// Apply uses, so only descriptor-valid values reach a query; an id is a bounded string; a limit is clamped.
// A tool the model names that does not exist, or arguments it cannot use, come back as `{ ok: false }`
// with a reason the model can read, never as a throw that ends the turn.

import { normaliseViewIntent, intentHasFilter, VIEWS } from './view-intent.js';
import { hugoFamilyKeys } from './families.js';
import { familiesIn } from '../../public/views/fingerprint-glyph.js';
import { withFamilyScope } from '../domain/family-scope.js';
import { getDescriptor, SPACE_DESCRIPTOR, domainIds, intentDescriptor } from '../domain/descriptor.js';
// `RECORD_FIELDS` is the AUTHORITATIVE schema set - what `validateTrackerRecord` accepts and what the store
// holds. The export catalogue was the first candidate and was measured as the wrong source: it has 41
// columns and `product_types` is not among them, so deriving from it would have widened Hugo's view while
// still hiding the field the Sovereignty panel and half the owner's capability questions turn on.
import { RECORD_FIELDS } from '../domain/tracker.js';
import { contactsCell, reachCell } from '../domain/reach.js';
import { sanitiseUntrustedText } from '../domain/injection.js';
import { compareRecords, scorePair, decidePair, markNoneShared, LABELLED_WEIGHTS, LABELLED_PRIOR } from '../domain/er-model.js';
// THE HELD-LINE AND HELD-RECORD RULES, imported rather than restated (V2.3 re-cut, security gate): the store's
// set reads and this read by id must hold exactly the same lines and rows, and a second copy is how they drift.
import { lineIsHeld } from '../db/domain-repo.js';
import { spaceRecordIsHeld } from './query-plan.js';
import { missionReader, lineTypesOf } from '../db/mission-alignment-repo.js';
import { searchHelp, describeApp, appState, recentHistory } from './knowledge.js';

/**
 * THE ROW CEILING, raised from 10 to 50 (owner, 2026-09-19).
 *
 * Ten was the number that made "which UK vendors are ready" a sampling exercise dressed as an answer: a
 * 200-row question came back as ten rows with nothing saying so. Fifty is not "enough for every question"
 * and is not meant to be - it is the point past which an operator wants a COUNT or a narrowed filter rather
 * than a list, which is what `count_records` is for and what the briefing now tells the model to reach for.
 * The guard against a runaway bill is the spend cap, which is unchanged and still bounds the turn.
 */
export const TOOL_MAX_ROWS = 50;
const SIMILAR_CANDIDATES = 50;
const SIMILAR_TOP = 5;
const TEXT_CAP = 160;
/**
 * The per-FIELD cap, and the per-RECORD ceiling that bounds the whole row.
 *
 * `TEXT_CAP` (160) stays for identity-ish values, but it was ALSO the cap on `capability` - the one field
 * that carries what a vendor actually does - so a capability sentence arrived cut mid-word and the model
 * was asked to reason about the half it got. `FIELD_CAP` gives a content field room to be a sentence.
 * `RECORD_CHARS` then bounds the row as a whole, so widening the field list cannot let one pathological
 * record eat the turn: fields are emitted in catalogue order and the ceiling truncates the tail, never the
 * identity.
 */
const FIELD_CAP = 600;
// ONE RECORD, READ WHOLE (VH-199): `get_record` answers about a single record, so it may carry every field and
// every product line; the per-row RECORD_CHARS cap stays for the set reads, where fifty rows share a turn.
const DETAIL_CHARS = 8000;
const RECORD_CHARS = 2000;
// One limit for a record key on all 7 domains, the match route's (VH-278 F4): a key can be an identity such as a web
// address, which any store can carry since B2, and 80 cut some short so the record could not be read.
const ID_CAP = 200;
// The four keys `shape()` writes itself. Listed once so the derived loop cannot emit a second copy of a
// value the spine already carries under a different name.
const SPINE_KEYS = new Set(['vendor_id', 'company', 'domain']);
/**
 * The fields NOT offered to the model: the spine it already carries, and bookkeeping the model has no use
 * for. A NEW SCHEMA FIELD IS INCLUDED BY DEFAULT: it has to be named here to be kept out, so the failure mode
 * is "too much" rather than the silent "too little".
 *
 * EVERY DOMAIN IS TREATED EQUALLY (owner rule, 2026-09-24: "all domains are treated equally - there is no such
 * thing as 'space treats them differently' - EQUAL! same capability and functionality"). This list also kept
 * out `geo`, `contacts` and the two `jco_*` detail blocks, and `readField` returned nothing for any structured
 * value, so Space sent the model none of its identifiers, ownership, export control, sites or contacts while
 * a domain record sent every one of its equivalents. Only the same bookkeeping is held back on both.
 */
const SHAPE_SKIP = new Set([
  'vendor_id', 'company', 'lifecycle_status', 'review_state', 'scan_archetype', 'verified_by',
  // VH-401 (owner, 2026-10-06): Hugo neither reads nor says the JCO/NATO readiness grade, typed or spoken. The
  // grade and the four `jco_*` blocks behind it (one of which holds a grade per line of effort) stay stored.
  'grade', 'jco_match_pct', 'jco_requirement_matches', 'jco_assessed_at', 'jco_pws_ref', 'jco_loe_scores',
  // VH-801: a vendor's missions are Mission Alignment's, handed over as `nato_jco_missions`; the stored list is not read.
  'missions',
]);
const SHAPE_FIELDS = Object.freeze([...RECORD_FIELDS].filter((k) => !SHAPE_SKIP.has(k)));

const str = (v, cap) => (typeof v === 'string' ? sanitiseUntrustedText(v).replaceAll(/\s+/g, ' ').trim().slice(0, cap) : '');
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
// The code-unit comparator this repository uses wherever order must be stable and locale-free (S2871
// also refuses a bare sort, and the mirrored rule is what the App Store's SonarQube gate reads).
const byText = (a, b) => (a > b) - (a < b);
// A hyphenated id folds to the registered underscore form (VH-171): the tool text once taught the model
// `natural-resources` and `national-security`, and an unrecognised id falls back to the default domain, so a
// question about either was answered from another catalogue without a word said.
const domainOf = (v, fallback) => {
  const id = typeof v === 'string' ? v.trim().toLowerCase().replaceAll('-', '_') : v;
  return domainIds().includes(id) ? id : fallback;
};

// The first non-empty string among the candidates, bounded.
const pick = (cap, ...values) => {
  for (const v of values) {
    const s = str(v, cap);
    if (s) return s;
  }
  return '';
};
// A stored row arrives as `{ rev, record }` from the Space store and as a flat provider row from a domain
// store; either way the record object is what the fields are read from.
function recordOf(row) {
  if (isObj(row?.record)) return row.record;
  return isObj(row) ? row : {};
}
const fail = (error) => ({ ok: false, error: String(error).slice(0, 300) });

// WHICH STORE HOLDS WHICH CAPABILITY FACET, written from the descriptors (VH-624) rather than by hand, so a facet a
// descriptor gains is named to the model with no edit here. Keys the same stores hold are named together.
const andList = (xs) => (xs.length > 1 ? xs.slice(0, -1).join(', ') + ' and ' + xs.at(-1) : xs.join(''));
function facetKeysText() {
  const storesOf = new Map();
  for (const id of domainIds()) {
    for (const f of getDescriptor(id)?.capabilityFacets || []) {
      if (!storesOf.has(f.key)) storesOf.set(f.key, []);
      storesOf.get(f.key).push(getDescriptor(id).label);
    }
  }
  const keysOn = new Map();
  for (const [key, stores] of storesOf) {
    const on = andList(stores);
    if (!keysOn.has(on)) keysOn.set(on, []);
    keysOn.get(on).push(key);
  }
  return [...keysOn].map(([on, keys]) => andList(keys) + ' on ' + on).join('; ');
}

// The families in force by name, so a model can map "electronic warfare" to its key (VH-775). EACH DOMAIN HOLDS ITS OWN
// (owner, 2026-10-20, by popup: "Families per domain") and these definitions serve every domain and every caller, the
// realtime relay outside any request among them, so each domain is read by name: one list while every domain holds the
// same families, as before the split, and once they differ one list for each set of domains holding the same.
function familyNamesText() {
  const byText = new Map();
  for (const id of domainIds()) {
    const text = Object.values(familiesIn(id)).map((f) => f.key + ' is ' + f.name).join(', ');
    byText.set(text, [...(byText.get(text) || []), getDescriptor(id)?.label || id]);
  }
  const lists = [...byText];
  return lists.length === 1 ? lists[0][0] : lists.map(([text, labels]) => 'on ' + andList(labels) + ', ' + text).join('; ');
}

/**
 * The tool definitions in the OpenAI chat-completions shape (`{ type: 'function', function: {...} }`); the
 * realtime relay flattens them with `realtimeToolDefs`. `mode` is this layer's own annotation. BUILT, not held: the
 * family keys and names in the query filter are the ones in force (VH-775), so `hugoToolDefs` rebuilds them when an
 * admin changes a family.
 */
function buildToolDefs() {
  return Object.freeze([
  tool('query_records', 'read', 'Query the vendor dataset in one domain with structured filters and return up to 50 matching records, each with a stable reference and every field the record actually carries - capability, data types, missions, verification date and the rest. Use for "which", "list", "show me" questions. If you only need HOW MANY, call count_records instead: it is cheaper and it does not truncate. If a query would exceed 50, narrow the filter or count it rather than reasoning from a partial list, and tell the operator you did.', {
    domain: { type: 'string', description: 'A domain id: ' + domainIds().join(', ') + '.' },
    filter: { type: 'object', description: 'Filters: each domain\'s own capability facets by their keys (' + facetKeysText() + '), search (a company name or any text the operator typed, matched over the whole record as the board search box matches it), countries (array of country names), gdm (array of GDM states), sections, missions, productTypes (arrays of controlled values), families (capability family keys: ' + hugoFamilyKeys('all').join(', ') + '), stages, blockerKinds, priorities, owners (pipeline), due (overdue|today|week|month|none), blocked (boolean), ageing (whole days in the current stage). Every domain runs every one of these. The families by name: ' + familyNamesText() + '.' },
    limit: { type: 'integer', description: 'Records to return, at most 50.' },
  }),
  tool('count_records', 'read', 'Count the records matching structured filters in one domain, without returning them.', {
    domain: { type: 'string' }, filter: { type: 'object' },
  }),
  tool('get_record', 'read', 'Fetch one record by id (for example VH-0001) with its provenance summary.', {
    domain: { type: 'string' }, id: { type: 'string' },
  }),
  tool('find_similar', 'read', 'Find records likely to be the same organisation as the given record, each with the match model\'s explanation.', {
    domain: { type: 'string' }, id: { type: 'string' },
  }),
  tool('record_provenance', 'read', 'The provenance held for one record: which fields are sourced, from where, and the evidence band.', {
    domain: { type: 'string' }, id: { type: 'string' },
  }),
  tool('pipeline_summary', 'read', 'The GDM onboarding pipeline summary for a domain or all domains: totals by stage and band, blocked, overdue, needing triage.', {
    domain: { type: 'string', description: 'A pipeline domain id, or "all".' },
  }),
  tool('propose_scan', 'confirm', 'Turn a plain-English hunt request into a structured scan design for the operator to confirm. Never starts a run.', {
    text: { type: 'string' }, domain: { type: 'string' }, crossDomain: { type: 'boolean' },
  }),
  tool('propose_update', 'confirm', 'Preview a field-level change to one record with a citable source, for the operator to confirm. Never writes.', {
    domain: { type: 'string' }, id: { type: 'string' }, patch: { type: 'object' }, source: { type: 'string', description: 'The https source the change rests on.' },
  }),
  tool('explain_match', 'read', 'Explain, feature by feature, how the match model compares two records by id.', {
    domain: { type: 'string' }, idA: { type: 'string' }, idB: { type: 'string' },
  }),
  // THE WEB (owner decision, V1.79): "internet interaction allowed for deeper context such as followon
  // questions about vendors etc". READ-only and sourced: it returns text with the URLs it came from, and a
  // record change still goes through propose_update and the operator's confirmation.
  tool('web_lookup', 'read', 'Look something up on the public web. Pass a question to search, or a url to read one page; returns text WITH its source urls. Reach for it whenever the dataset cannot answer - what a company actually sells, who owns it, a recent announcement, a registry page, whether a supplier is still trading - and follow a thread across several lookups where the question needs it. Cross-check what you read against the dataset rather than reporting it raw. ALWAYS name the source url in your answer, and never state a web claim as the dataset\'s own figure.', {
    question: { type: 'string', description: 'What to search the web for.' },
    url: { type: 'string', description: 'A single http(s) page to read instead of searching.' },
  }),
  // THE VIEW OFFER (owner decision, V1.79): "if a specific question is answerable by Hugo driving the app to
  // display analytics or an answer - then a popup simply says - allow Hugo to show you". Before this, driving
  // the app was a separate non-conversational route with its own button, and the persona's instruction was to
  // tell the operator to press it. Now Hugo offers, in the conversation, and one tap applies it.
  // WHAT HUGO KNOWS ABOUT THE APP ITSELF (VH-777 Lane T, `knowledge.js`): read-only, each result naming its source.
  tool('search_help', 'read', 'Search the app\'s own help and user guide for how to do something, what a screen or term means, or why something looks the way it does. Returns the passages that answer, each with its source. Reach for it for any question about using the app, and say which help entry or guide section the answer came from.', {
    question: { type: 'string', description: 'The question, in the operator\'s words.' },
  }),
  tool('describe_app', 'read', 'Describe the app itself: its name, its domains and each domain\'s capability facets, and its views with what each is for.', {}),
  tool('app_state', 'read', 'The app as it is running now: its version and how many records each domain holds.', {}),
  tool('recent_history', 'read', 'The latest changes to the dataset: when, by whom, which action, on which store and record. The changed values are not included; the record\'s own history in the app holds them.', {
    domain: { type: 'string', description: 'A product-line domain id to read only its changes, or omit for every change.' },
    limit: { type: 'integer', description: 'Changes to return, at most 25.' },
  }),
  tool('propose_view', 'confirm', 'Offer to SHOW the answer in the app rather than describe it: the board, the map, the analytics panel or the onboarding pipeline, filtered to the question. Returns a proposal the operator confirms with one tap; it never changes what is on screen by itself. Reach for it whenever the answer is better seen than read, and answer in prose as well so the reply stands on its own.', {
    view: { type: 'string', description: 'board, map, analytics or pipeline.' },
    domain: { type: 'string', description: 'A domain id, or omit for the one the operator is looking at.' },
    filter: { type: 'object', description: 'The same filters query_records takes.' },
    crossDomain: { type: 'boolean', description: 'True to span every domain rather than one.' },
    reason: { type: 'string', description: 'One short line for the operator: what they would be looking at.' },
  }),
  ]);
}

/** The definitions as the server started with them: the tool names and modes, which no family change alters. */
export const HUGO_TOOL_DEFS = buildToolDefs();

let builtFor = familyNamesText();
let liveDefs = HUGO_TOOL_DEFS;
/** The definitions with the families in force now, rebuilt only when a family changed. */
export function hugoToolDefs() {
  const now = familyNamesText();
  if (now !== builtFor) { liveDefs = buildToolDefs(); builtFor = now; }
  return liveDefs;
}

function tool(name, mode, description, properties) {
  return { type: 'function', mode, function: { name, description, parameters: { type: 'object', properties, additionalProperties: false } } };
}

/** The same definitions in the realtime session shape (flat, no wrapper). */
export function realtimeToolDefs() {
  return hugoToolDefs().map((t) => ({ type: 'function', name: t.function.name, description: t.function.description, parameters: t.function.parameters }));
}

/** The chat-completions shape without this layer's `mode` annotation. */
export function chatToolDefs() {
  return hugoToolDefs().map(({ type, function: fn }) => ({ type, function: fn }));
}

export const TOOL_NAMES = Object.freeze(HUGO_TOOL_DEFS.map((t) => t.function.name));

// ---- The ledger ------------------------------------------------------------------------------------------

const NUMBER_RE = /-?\d+(?:\.\d+)?/g;
// The urls inside any tool result, for the ledger's link set. THE SAME PATTERN AND THE SAME TRIM as
// `urlsInText` in agent.js, because the verifier compares what it finds in the answer against what this
// finds in the result, and two patterns that differ by one character are a false violation waiting to
// happen. Case-INSENSITIVE: a security gate got `HTTPS://evil.example/x` past the answer-side check with a
// case-sensitive pattern, and a harvester that could not see the same form would reopen it from this side.
const TOOL_URL_RE = /https?:\/\/[^\s<>"')\]]+/gi;
function urlsIn(value) {
  const text = JSON.stringify(value ?? null);
  return [...text.matchAll(TOOL_URL_RE)].map((m) => m[0].replace(/[.,;:!?\\"]{1,8}$/, ''));
}
const normName = (s) => String(s || '').toLowerCase().replaceAll(/[^a-z0-9]+/g, ' ').trim();

/**
 * The session ledger of what the tools returned: row ids, names (normalised), numbers, and the reference
 * table the answer may cite. Pure bookkeeping; the agent verifies against it.
 */
export function createLedger() {
  const ids = new Set();
  const names = new Set();
  const numbers = new Set();
  const sources = new Set();
  const links = new Set();
  const refs = [];
  const seenRef = new Map();
  return {
    addRow({ id, name, domain }) {
      const key = `${domain}|${id}`;
      if (id) ids.add(String(id));
      if (name) names.add(normName(name));
      if (seenRef.has(key)) return seenRef.get(key);
      const ref = refs.length + 1;
      refs.push({ ref, id: String(id || ''), name: String(name || ''), domain });
      seenRef.set(key, ref);
      return ref;
    },
    addNumbers(value) {
      for (const m of JSON.stringify(value ?? null).matchAll(NUMBER_RE)) numbers.add(Number(m[0]));
    },
    // WEB SOURCES (V1.79). A web answer has to be attributable, so the ledger holds the URLs a lookup
    // actually returned and the verifier refuses any other link in the answer. Compared on the exact
    // string the tool returned: normalising a URL to compare it is a rabbit hole (case, trailing slash,
    // tracking parameters), and the model is asked to quote the source it was given, not to rewrite it.
    addSource(url) {
      const u = String(url || '').trim();
      if (u) { sources.add(u); links.add(u); }
    },
    hasSource: (url) => sources.has(String(url || '').trim()),
    get sourceList() { return [...sources]; },
    // EVERY URL ANY TOOL SHOWED THE MODEL, which is a different question from "which hosts did this turn
    // reach" and needs its own set. An engineering gate found the two conflated: `sources` was fed only by
    // `web_lookup` while the verifier refused any link not in it, so an answer quoting a record's own
    // `evidence` URL - free text a scan writes, which does carry urls - failed verification, retried, and
    // then failed closed on the operator. Numbers were already harvested from every tool result for exactly
    // this reason; links now are too.
    //
    // KEPT SEPARATE FROM `sources` deliberately. The audit row records the hosts Hugo REACHED, and it reads
    // `sourceList`; folding dataset urls into that set would put a host nobody visited on the audit trail,
    // which is the defect the same gate raised one finding earlier.
    addLinks(value) {
      for (const u of urlsIn(value)) links.add(u);
    },
    hasLink: (url) => links.has(String(url || '').trim()),
    hasId: (id) => ids.has(String(id)),
    hasName: (name) => names.has(normName(name)),
    hasNumber: (n) => numbers.has(Number(n)),
    hasRef: (ref) => Number.isInteger(ref) && ref >= 1 && ref <= refs.length,
    get refs() { return refs.map((r) => ({ ...r })); },
    get size() { return ids.size; },
  };
}

// ---- The runner -------------------------------------------------------------------------------------------

/**
 * Bind the tools to one caller's context. `runQuery(intent, page)` is the route's own query runner (the
 * same one the confirm-first Apply uses, so a tool can never see a row the operator could not); the repos
 * are optional, and a tool whose repository is absent answers `{ ok: false }` rather than pretending.
 * Returns `{ run(name, args), ledger, defs }`.
 */
// THE PREVIEW FOR WHICHEVER STORE OWNS THIS RECORD (V1.81). `unavailable` names the reason in the
// operator's terms when a store is not wired, rather than reporting the record as missing: "this domain is
// not connected" and "no such record" are different answers and only one of them is the operator's problem.
// Module scope, so it is a plain function of its inputs rather than a closure inside the tool table.
async function previewForStore({ domain, id, patch, vendorRepo, domainRepoFor }) {
  if (domain === 'space') {
    if (typeof vendorRepo?.previewUpdate !== 'function') return { unavailable: 'the Space store is not available' };
    return { out: await vendorRepo.previewUpdate(id, patch) };
  }
  const repo = typeof domainRepoFor === 'function' ? domainRepoFor(domain) : null;
  if (typeof repo?.previewProviderUpdate !== 'function') return { unavailable: `the ${domain} store is not connected on this deployment` };
  return { out: await repo.previewProviderUpdate(id, patch) };
}

// A domain record's own fields as [key, text] pairs, from its descriptor and the one-record read's shape
// (VH-199): the capability facets and scalars, the shared identity, the GDM overlay, VH-192's details and
// every product line with every facet. Text only, bounded by the caller's budget; nothing here is written.
const kv = (blob) => (blob && typeof blob === 'object' && !Array.isArray(blob)
  ? Object.entries(blob).filter(([, v]) => v !== null && v !== undefined && v !== '').map(([k, v]) => k + ': ' + (typeof v === 'object' ? JSON.stringify(v) : String(v))).join('; ')
  : '');
const listText = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string' || typeof x === 'number').join(', ') : v);
const LINE_TEXT_KEYS = Object.freeze(['product_type', 'object_domain', 'data_nature', 'collection_vantage', 'data_delivery', 'data_owned',
  'data_sensitivity', 'source_status', 'evidence_tier', 'collection_point', 'derivation_source', 'line_eligibility']);
function lineText(l) {
  return LINE_TEXT_KEYS.map((k) => [k, listText(l?.[k])]).filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => k + '=' + v).join(', ');
}
function domainPairs(rec, domain) {
  let descriptor = null;
  try { descriptor = getDescriptor(domain); } catch { descriptor = null; }
  const facets = (descriptor?.capabilityFacets || []).map((f) => [f.key, listText(rec[f.key])]);
  const id = rec.identity && typeof rec.identity === 'object' ? rec.identity : {};
  const d = rec.details && typeof rec.details === 'object' ? rec.details : {};
  const ids = kv(Object.fromEntries(Object.entries(id.identifiers || {}).map(([k, v]) => [k, v && typeof v === 'object' ? v.value : v])));
  const lines = Array.isArray(rec.lines) ? rec.lines : [];
  return [
    ['hq_country', rec.hq_country], ['section', listText(rec.section)], ['chain', listText(rec.chain)],
    ...facets,
    ['evidence_confidence', rec.evidence_confidence], ['coverage', rec.coverage],
    ['focus_coverage', kv(rec.focus_coverage)], ['extra_facets', kv(rec.extra_facets)], ['zone', rec.computed_zone],
    ['aka', listText(id.aka)], ['hq_city', id.hq_city], ['source_operator', id.source_operator], ['ultimate_owner', id.ultimate_owner],
    ['ownership_country', id.ownership_country], ['ownership_effective_from', id.ownership_effective_from], ['identifiers', ids], ['identity_record', kv(id.data)],
    ['gdm_stage', rec.gdm?.gdm_stage], ['gdm_priority', rec.gdm?.priority], ['gdm_record', kv(rec.gdm?.data)],
    // The people with their titles, numbers and profiles, and the company's own lines (VH-756), as the exports write them.
    ['contacts', contactsCell(d.contacts)], ['company_emails', reachCell(d.company_emails, 'email')],
    ['company_phones', reachCell(d.company_phones, 'phone')], ['linkedin', d.linkedin],
    ['sites', (d.sites || []).map((x) => [x?.country, x?.latitude, x?.longitude].filter((y) => y !== undefined && y !== null && y !== '').join(' ')).join('; ')],
    ['offerings', listText(d.offerings)], ['founded', d.founded],
    ['product_lines', lines.map(lineText).join(' | ')],
    ['product_lines_withheld', rec.lines_withheld ? String(rec.lines_withheld) : ''],
  ];
}

/**
 * One field's value for a record, as text, tolerant of the two row shapes.
 *
 * THE DOMAIN ROWS ARE NOT SPACE RECORDS. The Space master carries `{ record }` with `company` and
 * `country`; a domain provider row is flat and carries `legal_name` and `hq_country`. A reader that
 * assumed one shape would work on the master and return nothing for every other domain - the same "works
 * on one surface only" failure the alliance filter's `rowRecord` exists to stop.
 *
 * A LIST BECOMES A SENTENCE, not JSON: `['SAR', 'Radar']` reads as "SAR, Radar", which is what a model
 * handles well and what an operator would have written. A STRUCTURED VALUE READS AS ITS PAIRS, the way the
 * domain read renders its own (`kv`): an object as "key: value; key: value", a list of objects as those
 * pairs per item, " | " between items. It is text, sanitised and capped by `shape` like every other field.
 */
function readField(key, rec, row) {
  const value = rec?.[key] ?? row?.[key];
  if (value === undefined || value === null) return '';
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (Array.isArray(value)) {
    if (value.some(isObj)) return value.map((v) => (isObj(v) ? kv(v) : readScalar(v))).filter(Boolean).join(' | ');
    return value.filter((v) => typeof v === 'string' || typeof v === 'number').join(', ');
  }
  return isObj(value) ? kv(value) : '';
}
const readScalar = (v) => (typeof v === 'string' || typeof v === 'number' ? String(v) : '');

// EACH RECORD'S OWN NAME AND COUNTRY (VH-278, F3; the set-aside VH-232). The comparator reads `company` and
// `country`, which is how Space's store names them; the other stores name them `name` (or `legal_name`) and
// `hq_country`, so for a record in Land, Natural Resources, Air, Maritime, Cyber or National Security both scored
// as missing. Each record is read through its own names first.
const comparable = (r) => ({ ...r, company: r?.company ?? r?.name ?? r?.legal_name, country: r?.country ?? r?.hq_country });

// THE STORED MATCHES AS THE PANEL READS THEM (VH-278, F2): the OTHER record (the row's own member is the record
// asked about, so reporting it said nothing), and a person's verdict over the model's, the model's own verdict
// beside it, best first.
const storedMatch = (m) => {
  const other = m?.explanation?.other;
  const model = typeof m?.explanation?.decision === 'string' ? m.explanation.decision : null;
  return {
    other: other && typeof other === 'object' ? { domain: str(other.domain, 40), id: str(other.id, ID_CAP), company: str(other.company, TEXT_CAP) } : null,
    decision: m?.decision && m.decision !== 'auto' ? m.decision : model,
    modelDecision: model,
    score: m?.score ?? null,
  };
};

export function createToolRunner({ runQuery, vendorRepo, domainRepoFor, provenanceRepo, pipelineRepo, erRepo, compileScan, webLookup, defaultDomain, alignment } = {}) {
  const ledger = createLedger();
  // THE DOMAIN THE CONVERSATION IS IN, NAMED BY THE CALLER (VH-280). It used to default to Space, so a runner
  // built without one answered every tool call the model made without a domain from Space's store, and the
  // answer read as the operator's own domain. Refused at construction, because no tool can be right without it.
  if (!domainIds().includes(defaultDomain)) throw new TypeError('createToolRunner needs the domain the conversation is in');
  const fallbackDomain = defaultDomain;

  // `ok()` NO LONGER HARVESTS LINKS FROM THE WHOLE RESULT, and this is a security fix rather than a tidy.
  //
  // It used to run `ledger.addLinks(result)` over the entire result blob. Two tool results ECHO THE MODEL'S
  // OWN ARGUMENTS back - `propose_view` returns the `reason` it was given, `propose_update` returns its
  // `source` and `changes` - so the model could write a url into an argument, have `ok()` enter it in the
  // link set, quote it in the next turn's answer, and pass `verifyAnswer`. A round-2 security gate did
  // exactly that with no attacker page and no injection: `hasLink(FAKE)` true, `verifyAnswer ok:true`, and
  // the client then rendered "Verified against the dataset" while the audit row showed no host at all. The
  // same blanket harvest also swept urls out of `pageText`, a stranger's prose, so a planted url on a host
  // nobody fetched could be presented as a source.
  //
  // The whole point of requiring a source url is defeated if the thing being verified can supply it. So
  // links are now entered ONLY from server-derived values, at the two places that produce them: `shape()`
  // for a record's own stored urls, and `web_lookup` for the urls the fetcher actually returned. Numbers are
  // still harvested from the result, because a number is not a claim of provenance.
  const ok = (result) => { ledger.addNumbers(result); return { ok: true, result }; };

  /**
   * One record, bounded for the model, and entered in the ledger with its reference.
   *
   * SCHEMA-DERIVED, NOT A HAND-PICKED LIST (owner, 2026-09-19: "Hugo should interact with every element of
   * every schema across all domains"). This function used to return NINE keys - ref, id, name, domain,
   * country, grade, gdm, section, website - and `capability`, `product_types`, `missions` and
   * `last_verified` were not among them. The consequence was not that Hugo answered capability questions
   * badly; it is that "who does synthetic aperture radar in Europe" was UNANSWERABLE from `query_records`
   * by construction, because the field holding the answer was never handed over. Adding those four would
   * have bought one release before the fifth was asked for, so the list comes from `TRACKER_COLUMNS` - the
   * same catalogue the exports and the field picker read - and a field added to the schema reaches Hugo
   * with no change here.
   *
   * TWO BOUNDS, because "everything" cannot mean "unbounded".
   *  ● EMPTY FIELDS ARE OMITTED, so the payload is proportional to what a record actually carries rather
   *    than to the width of the schema. A sparse record stays as small as it was before this change.
   *  ● A per-record byte ceiling stops one pathological row consuming the turn, and the fields are emitted
   *    in catalogue order, so what survives the ceiling is the identity and the headline facts rather than
   *    whatever happened to be last.
   */
  // A ROW'S NATO/JCO MISSIONS (VH-801), read from the domain's Mission Alignment for the data types the row supplies: a
  // Space record's `product_types`, a domain provider's lines.
  async function missionsIn(domain) {
    const read = await missionReader(alignment, domain);
    return (row) => {
      const rec = recordOf(row);
      if (domain === 'space') return read(rec.product_types);
      return read(lineTypesOf(rec.lines ? rec : row));
    };
  }

  function shape(row, domain, { budget: cap = RECORD_CHARS, missions = [] } = {}) {
    const rec = recordOf(row);
    const id = pick(ID_CAP, rec.vendor_id, rec.id, row?.vendor_id, row?.provider_key, row?.id);
    const name = pick(TEXT_CAP, rec.company, rec.legal_name, row?.legal_name, row?.name);
    const ref = ledger.addRow({ id, name, domain });
    // The spine is fixed: the model needs a stable reference and an identity on every row, whatever the
    // schema says. Everything after it is derived.
    const out = { ref, id, name, domain };
    let budget = cap;
    // A DOMAIN RECORD IS SHAPED FROM ITS OWN SCHEMA TOO (VH-199, owner instruction 2026-09-23). The loop
    // below was the Space tracker's field names alone, so a domain provider reached the model with 36 of its
    // 222 fields (measured): no capability facet, no product line, no identity, no GDM state. The Claude deep
    // search reads a record through this same tool. Space pairs come first, the domain's own after them.
    const pairs = [...SHAPE_FIELDS.map((key) => [key, readField(key, rec, row)]), ['nato_jco_missions', missions.join(', ')],
      ...(domain === 'space' ? [] : domainPairs(rec, domain))];
    for (const [key, value] of pairs) {
      if (!value || Object.hasOwn(out, key)) continue;
      // A product-line list is one field carrying many lines, so it may use the whole budget.
      const limit = key === 'product_lines' ? cap : FIELD_CAP;
      const isLink = key === 'website' || key === 'linkedin';
      const text = str(value, isLink ? TEXT_CAP : limit);
      if (!text) continue;
      budget -= text.length + key.length;
      if (budget < 0) break;
      out[key] = text;
      // A record's own stored url, entered in the LINK set once it is shown to the model, never before: the website, the
      // LinkedIn page and a person's profile (VH-756) are urls a tool genuinely showed it, so it may quote them without
      // tripping the verifier. They come from the DATABASE, not from an argument the model wrote or a fetched page's prose.
      if (isLink || key === 'contacts') ledger.addLinks(text);
    }
    return out;
  }


  function intentFor(args) {
    const domain = domainOf(str(args?.domain, 40), fallbackDomain);
    const descriptor = getDescriptor(domain) || SPACE_DESCRIPTOR;
    const raw = { domain, filterSpec: isObj(args?.filter) ? args.filter : {}, question: '' };
    return normaliseViewIntent(raw, descriptor, { domainIds: domainIds(), crossDomain: false }).intent;
  }

  // THE ELIGIBILITY BACKSTOP (H-4) ON A READ BY ID, on both sides (V2.3 re-cut, security gate MAJOR). The set
  // reads have always held an excluded or quarantined row or line; this read did not, and once VH-199 gave
  // `get_record` the product lines, excluded and quarantined lines reached Hugo and the Claude deep search,
  // a quarantined one reading as admitted. A held Space record is refused as not found, as the set reads
  // leave it out; a domain record keeps its released lines only and says how many it held back.
  async function readRecord(domain, id) {
    if (!id) return null;
    if (domain === 'space') {
      const held = await vendorRepo?.getVendor?.(id);
      if (!held || spaceRecordIsHeld(held.record)) return null;
      return { ...held.record, vendor_id: id };
    }
    const repo = typeof domainRepoFor === 'function' ? domainRepoFor(domain) : null;
    const row = await repo?.get?.(id);
    if (!row) return null;
    const lines = Array.isArray(row.lines) ? row.lines : [];
    const released = lines.filter((l) => !lineIsHeld(l));
    return { ...row, lines: released, lines_withheld: lines.length - released.length, provider_key: id };
  }

  async function similarTo(domain, base) {
    const stored = await erRepo?.matchesFor?.({ domain, memberId: str(base.vendor_id || base.provider_key, ID_CAP), limit: SIMILAR_TOP }).catch(() => []);
    const live = await runQuery(intentFor({ domain, filter: { countries: [base.country || base.hq_country].filter(Boolean) } }), { limit: SIMILAR_CANDIDATES, offset: 0 });
    const scored = [];
    for (const row of live.rows || []) {
      const rec = isObj(row.record) ? row.record : row;
      const id = rec.vendor_id || row.provider_key || row.vendor_id;
      if (!id || id === (base.vendor_id || base.provider_key)) continue;
      const vector = compareRecords(comparable(base), comparable(rec));
      const s = scorePair(vector, { weights: LABELLED_WEIGHTS, prior: LABELLED_PRIOR });
      scored.push({ ...shape(row, domain), probability: Math.round(s.probability * 1000) / 1000, decision: decidePair(s, vector).decision, agreements: Object.entries(vector).filter(([, v]) => v === 'exact' || v === 'close').map(([k]) => k) });
    }
    scored.sort((a, b) => b.probability - a.probability);
    return { stored: (Array.isArray(stored) ? stored : []).map(storedMatch), candidates: scored.slice(0, SIMILAR_TOP) };
  }

  // One domain's record count for `app_state`, through the same query `count_records` runs.
  const countDomain = async (domain) => (await runQuery(intentFor({ domain }), { limit: 1, offset: 0 })).total ?? null;

  const handlers = {
    async query_records(args) {
      const intent = intentFor(args);
      const limit = Math.max(1, Math.min(TOOL_MAX_ROWS, Math.round(Number(args?.limit)) || TOOL_MAX_ROWS));
      const r = await runQuery(intent, { limit, offset: 0 });
      const missionsOf = await missionsIn(intent.domain);
      const records = (r.rows || []).slice(0, limit).map((row) => shape(row, intent.domain, { missions: missionsOf(row) }));
      return ok({ domain: intent.domain, total: r.total || 0, shown: records.length, applied: r.applied || [], notApplied: r.notApplied || [], records });
    },
    async count_records(args) {
      const intent = intentFor(args);
      const r = await runQuery(intent, { limit: 1, offset: 0 });
      return ok({ domain: intent.domain, total: r.total || 0, applied: r.applied || [], notApplied: r.notApplied || [] });
    },
    async get_record(args) {
      const domain = domainOf(str(args?.domain, 40), fallbackDomain);
      const id = str(args?.id, ID_CAP);
      const rec = await readRecord(domain, id);
      if (!rec) return fail(`no record ${id || '(none)'} in ${domain}`);
      // Same absent method as `record_provenance` had, but reached through optional chaining, so this one
      // short-circuited to undefined instead of throwing and reported `provenance: null` for every record
      // on every deployment: a silent always-null rather than a visible failure, which is the worse of the
      // two. `current` returns claim rows; the count of distinct fields is what this summary wants.
      const claims = provenanceRepo
        ? await provenanceRepo.current(domain, id).catch(() => null)
        : null;
      // `evidence` IS THE DATASET'S OWN SOURCE FIELD, so the urls in it are entered in the link set here.
      // This is the case the link set was widened for: a scan writes a source url into `evidence`, the model
      // quotes it, and the verifier must not refuse it and fail closed on the operator. It is a text field
      // rather than a url field, so the urls are extracted from it - the difference from the blanket harvest
      // this replaces is WHERE the text came from. `evidence` is a database column; `propose_view.reason` was
      // the model's own argument and a fetched page's `pageText` was a stranger's prose, and neither is
      // evidence of anything.
      const evidence = str(rec.evidence, TEXT_CAP);
      ledger.addLinks(evidence);
      const provenance = Array.isArray(claims) && claims.length
        ? { claims: claims.length, fields: new Set(claims.map((c) => c?.field).filter(Boolean)).size }
        : null;
      return ok({ ...shape(rec, domain, { budget: DETAIL_CHARS, missions: (await missionsIn(domain))(rec) }), hq: str(rec.hq, TEXT_CAP), capability: str(rec.capability, TEXT_CAP), evidence, provenance });
    },
    async find_similar(args) {
      const domain = domainOf(str(args?.domain, 40), fallbackDomain);
      const rec = await readRecord(domain, str(args?.id, ID_CAP));
      if (!rec) return fail('no such record');
      return ok({ domain, base: shape(rec, domain, { missions: (await missionsIn(domain))(rec) }), ...(await similarTo(domain, rec)) });
    },
    async record_provenance(args) {
      if (!provenanceRepo) return fail('provenance is not available on this deployment');
      const domain = domainOf(str(args?.domain, 40), fallbackDomain);
      const id = str(args?.id, ID_CAP);
      // `current(domain, memberId)` IS THE METHOD, and there has never been a `read`. This line called
      // `provenanceRepo.read(...)` from the day the tool shipped, so on every deployment that wires a
      // provenance repository the tool threw a TypeError, `run`'s catch swallowed it, and the model was
      // told "provenanceRepo.read is not a function" as the answer to a question about a named vendor.
      // It also expected a shape nothing returns (`p.band`, `p.fields[field].sources`); what `current`
      // returns is the claim ROWS, so they are folded by field here.
      const rows = await provenanceRepo.current(domain, id);
      if (!Array.isArray(rows) || rows.length === 0) return fail(`no provenance for ${id}`);
      const byField = new Map();
      for (const row of rows) {
        const key = str(row?.field, 120);
        if (!key) continue;
        const seen = byField.get(key) || { field: key, sources: 0, verdicts: new Set() };
        // A person's uncited edit (VH-605) is a claim with no source behind it, so it counts as none.
        if (row?.source_key !== null) seen.sources += 1;
        if (row?.verdict) seen.verdicts.add(str(row.verdict, 40));
        byField.set(key, seen);
      }
      const fields = [...byField.values()].slice(0, 30)
        .map((f) => ({ field: f.field, sources: f.sources, state: [...f.verdicts].sort(byText).join('/') }));
      // No band: nothing computes one. Reporting a null is honest; inventing a letter would not be.
      return ok({ domain, id, claims: rows.length, fields });
    },
    async pipeline_summary(args) {
      if (!pipelineRepo) return fail('the pipeline is not available on this deployment');
      const domain = str(args?.domain, 40) || 'all';
      return ok({ domain, ...(await pipelineRepo.summary({ domain: domain === 'all' ? 'all' : domainOf(domain, fallbackDomain) })) });
    },
    async propose_scan(args) {
      if (typeof compileScan !== 'function') return fail('the scan compiler is not available');
      const text = str(args?.text, 2000);
      if (!text) return fail('a request in plain English is required');
      const r = await compileScan({ text, domain: domainOf(str(args?.domain, 40), fallbackDomain), crossDomain: args?.crossDomain === true });
      return ok({ requiresConfirmation: true, compiled: r.ok, design: r.design, unmapped: (r.unmapped || []).slice(0, 20) });
    },
    /**
     * PREVIEW A SOURCED CHANGE TO ONE RECORD, on Space or on any wired domain (V1.81, parity gap
     * `hugo.tool.propose_update.space.only`).
     *
     * This refused every non-Space domain outright, and the refusal was a WIRING gap rather than a missing
     * capability: `previewProviderUpdate` has been on the domain repository for a release, the HTTP route
     * behind the drawer's own composer has served every wired domain since it shipped, and the client
     * composer already binds to the open domain provider. Only Hugo's own tool said no, so an operator
     * working in Air could be told to go and do by hand what the app could already show them.
     *
     * A DOMAIN PATCH IS `{ fields, lines, gdm }`, NOT A FLAT RECORD, and the answer says which shape it
     * previewed. The two stores diff differently - Space returns the moved fields, a domain returns before
     * and after plus its product-line movement - and flattening one into the other would be inventing a
     * diff neither store produced.
     */
    async propose_update(args) {
      const domain = domainOf(str(args?.domain, 40), fallbackDomain);
      const id = str(args?.id, ID_CAP);
      const source = str(args?.source, 500);
      if (!/^https?:\/\//i.test(source)) return fail('a change needs an http(s) source');
      if (!isObj(args?.patch)) return fail('a patch object is required');
      const preview = await previewForStore({ domain, id, patch: args.patch, vendorRepo, domainRepoFor });
      if (preview.unavailable) return fail(preview.unavailable);
      if (!preview.out || preview.out.notFound) return fail(`no record ${id}`);
      if (preview.out.invalid) return fail('the patch is not valid: ' + (preview.out.errors || []).slice(0, 5).join('; '));
      const base = { requiresConfirmation: true, domain, id, source, changes: preview.out.changes || {}, hasChanges: preview.out.hasChanges === true };
      if (domain === 'space') return ok(base);
      // The line movement is carried only when it MOVED. Reporting "0 lines changed" on every field edit
      // would put a number in front of the operator that answers a question they did not ask.
      const moved = preview.out.linesAfter !== preview.out.linesBefore;
      return ok({ ...base, shape: 'domain', ...(moved ? { linesBefore: preview.out.linesBefore, linesAfter: preview.out.linesAfter } : {}) });
    },
    async web_lookup(args) {
      if (!webLookup || typeof webLookup.lookup !== 'function') return fail('web lookup is not available on this deployment');
      const out = await webLookup.lookup({ url: str(args?.url, 500), question: str(args?.question, 400) });
      if (!out.ok) return fail(out.error);
      // The SOURCES go in the ledger, so the verifier can refuse a link the lookup never returned, and the
      // figures and names go in as any tool result's do - the ledger is a fabrication check ("a tool showed
      // you this"), not a truth check, and the answer is required to attribute a web claim to its url.
      // `addSource` already enters these in the WEB set, which the audit row reads. They go in the LINK set
      // too, explicitly, because `ok()` no longer harvests urls from the result: these are the urls the
      // fetcher actually returned, so they are exactly what the verifier should accept, and they are the
      // only urls on this path that a server reached rather than a model or a page wrote.
      for (const c of out.result.sources || []) { ledger.addSource(c.url); ledger.addLinks(c.url); }
      if (out.result.source) { ledger.addSource(out.result.source); ledger.addLinks(out.result.source); }
      return ok(out.result);
    },
    async propose_view(args) {
      const view = str(args?.view, 40).toLowerCase();
      // FAIL CLOSED on the view name rather than defaulting to the board: an offer to show the operator
      // something other than what the model meant is worse than no offer, because they will accept it.
      if (!VIEWS.includes(view)) return fail(`view must be one of ${VIEWS.join(', ')}`);
      const domain = domainOf(str(args?.domain, 40), fallbackDomain);
      const crossDomain = args?.crossDomain === true;
      // A view across every domain reads every domain's vocabulary and facets (VH-263).
      const descriptor = intentDescriptor(domain, crossDomain);
      // The SAME validator the Apply path uses, so a proposal can only ever name descriptor-valid values and
      // an unmappable phrase comes back as `unmapped` instead of a filter nobody asked for.
      const { intent, unmapped } = normaliseViewIntent(
        { domain, filterSpec: isObj(args?.filter) ? args.filter : {}, view, question: str(args?.reason, TEXT_CAP) },
        descriptor,
        { domainIds: domainIds(), crossDomain },
      );
      // COUNT BEFORE OFFERING. An empty board reads as a bug, so the operator is told the figure before they
      // consent rather than discovering it after the view has moved under them. One count query, no rows.
      const counted = await runQuery(intent, { limit: 1, offset: 0 }).catch(() => null);
      return ok({
        requiresConfirmation: true,
        view: intent.view,
        domain: intent.domain,
        crossDomain,
        intent,
        hasFilter: intentHasFilter(intent),
        total: counted ? counted.total || 0 : null,
        applied: counted?.applied || [],
        unmapped: unmapped.slice(0, 20),
        reason: str(args?.reason, TEXT_CAP),
      });
    },
    async search_help(args) {
      return ok(await searchHelp(str(args?.question, TEXT_CAP)));
    },
    async describe_app() {
      return ok(describeApp());
    },
    async app_state() {
      return ok(await appState({ countDomain }));
    },
    async recent_history(args) {
      return ok(await recentHistory(vendorRepo, { domain: str(args?.domain, 40), limit: args?.limit }));
    },
    async explain_match(args) {
      const domain = domainOf(str(args?.domain, 40), fallbackDomain);
      const [a, b] = await Promise.all([readRecord(domain, str(args?.idA, ID_CAP)), readRecord(domain, str(args?.idB, ID_CAP))]);
      if (!a || !b) return fail('both records are needed');
      const [ca, cb] = [comparable(a), comparable(b)];
      const vector = compareRecords(ca, cb);
      const s = scorePair(vector, { weights: LABELLED_WEIGHTS, prior: LABELLED_PRIOR });
      // `noneShared` on the same three comparisons the match panel words, through the helper `matchPair` uses.
      return ok({ domain, a: shape(a, domain), b: shape(b, domain), probability: Math.round(s.probability * 1000) / 1000, decision: decidePair(s, vector), features: vector, contributions: markNoneShared(s.contributions, ca, cb) });
    },
  };

  async function run(name, args) {
    const handler = Object.hasOwn(handlers, name) ? handlers[name] : null;
    if (!handler) return { name, ...fail(`unknown tool ${str(name, 40) || '(none)'}`) };
    const input = isObj(args) ? args : {};
    try {
      // Each call reads the families of the domain it names, the conversation's own when it names none (VH-785): no
      // Hugo route carries its domain in the path, so the request's scope never covers a tool call.
      return { name, ...(await withFamilyScope(domainOf(str(input.domain, 40), fallbackDomain), () => handler(input))) };
    } catch (err) {
      return { name, ...fail(err?.message || err) };
    }
  }

  return { run, ledger, defs: chatToolDefs(), modeOf: (name) => HUGO_TOOL_DEFS.find((t) => t.function.name === name)?.mode || null };
}
