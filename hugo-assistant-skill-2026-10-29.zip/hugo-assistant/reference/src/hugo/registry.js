// HUGO'S ONE TOOL REGISTRY (VH-777 Lane T). Every channel that talks to Hugo takes its tools from here: the typed agent
// loop, the same-origin spoken relay and the GPT-Live sideband (Development 4, `src/hugo/live-*.js`). One set of
// definitions in each wire shape, and one session runner per conversation, bound to the operator's own principal
// through the tool layer (`tools.js`), with the ledger every answer is checked against (`voice-runner.js`).
//
// RUN ONCE PER CALL. A transport may deliver the same function call twice (a reconnect, a replayed event), and a
// confirm-first tool or a web look-up must not run twice for it. `runCall` keys each call by its call id and hands a
// repeat the first call's result, so the sideband can run every call it sees without tracking which it has run.

import { chatToolDefs, realtimeToolDefs } from './tools.js';
import { createVoiceRunner } from './voice-runner.js';

export const TOOL_SHAPES = Object.freeze(['chat', 'realtime', 'responses']);
// The calls a session remembers by id, far past any real conversation; the oldest is forgotten first.
const CALLS_KEPT = 512;
const CALL_ID = /^[A-Za-z0-9_.:-]{1,128}$/;

/**
 * The tool definitions in a wire shape: `chat` for chat completions (`{ type, function }`), `realtime` and `responses`
 * flat (`{ type, name, description, parameters }`), the shape both the Realtime session and the Responses API take.
 */
export function hugoToolDefinitions(shape = 'chat') {
  if (!TOOL_SHAPES.includes(shape)) throw new TypeError('hugoToolDefinitions: unknown shape ' + String(shape).slice(0, 20));
  return shape === 'chat' ? chatToolDefs() : realtimeToolDefs();
}

/**
 * One conversation's tools, bound to the caller's repositories and the domain the conversation is in (`defaultDomain`,
 * required). Returns the voice runner's `run`, `ledger`, `newTurn` and `check`, plus `runCall({ callId, name, args })`,
 * which runs each call id once, and `definitions(shape)`.
 */
export function createHugoSession(deps = {}) {
  const runner = createVoiceRunner(deps);
  const calls = new Map();
  function runCall({ callId, name, args } = {}) {
    if (typeof callId !== 'string' || !CALL_ID.test(callId)) return Promise.resolve({ name, ok: false, error: 'a call needs its id' });
    if (calls.has(callId)) return calls.get(callId);
    const result = runner.run(name, args);
    calls.set(callId, result);
    if (calls.size > CALLS_KEPT) calls.delete(calls.keys().next().value);
    return result;
  }
  return { ...runner, runCall, definitions: hugoToolDefinitions };
}
