// RANKING A CROSS-DOMAIN ANSWER, AND SAYING WHAT IT LEFT OUT (V1.83, AR-S6 and AR-S7).
//
// TWO FINDINGS, ONE PLACE, because they are the same question asked twice: what is actually in front of the
// operator, and is it the best of what matched?
//
// AR-S7, ORDERING. A cross-domain answer was ordered by STORE: Space first, then the registry order of the
// domains. So a provider in the sixth store that matched every clause of the question sat below every weak
// Space row that matched one. The operator reads the first screen; a ranking that ignores relevance means
// the best answer can be on the third.
//
// AR-S6, TRUNCATION. Each store was read at `limit 500` and the union was paged in memory, while `total`
// summed the true per-store counts. A domain with more than 500 matches therefore lost the remainder in
// SILENCE, and the total said otherwise - the worst combination, because the number on screen proves the
// rows are there and they are not.
//
// THE SCORE IS DELIBERATELY CRUDE AND EXPLAINABLE: how many of the clause GROUPS the operator asked for
// this row actually satisfies. Not a learned relevance, not a similarity: a count an operator can verify by
// looking at the row. A row matching three of the four things you asked for outranks one matching two,
// whichever store it came from, and store order survives only as the tie-break, so nothing moves without a
// reason. Inventing a weighted or embedding-based score here would be exactly the unverifiable precision
// this project refuses elsewhere; the IDEA row for semantic ranking stays open on purpose.

import { familyKey } from '../../public/views/fingerprint-glyph.js';

const lc = (v) => String(v ?? '').trim().toLowerCase();
const listOf = (v) => (Array.isArray(v) ? v : []).map(lc).filter(Boolean);

/**
 * The values a row carries for one clause, whichever store shape it arrived in.
 *
 * Space rows are `{ record }` with the tracker's field names; a domain row is a provider with `hq_country`,
 * `legal_name` and its facet columns. One reader rather than two, because a clause that reads only one
 * shape would score every row of the other store as zero and rank a whole store to the bottom - which is
 * the defect this file exists to fix, reintroduced by the fix.
 */
const READERS = Object.freeze({
  countries: (r) => [lc(r.country || r.hq_country)],
  sections: (r) => [lc(r.section), ...listOf(r.section)],
  // VH-801: Mission Alignment's missions, which the caller reads for the row's data types (`jco_missions`).
  missions: (r) => listOf(r.jco_missions),
  gdm: (r) => [lc(typeof r.gdm === 'string' ? r.gdm : (r.gdm?.gdm_stage || r.gdm_stage))],
  productTypes: (r) => [...listOf(r.product_types), ...listOf((r.lines || []).map((l) => l?.product_type)), ...listOf(r.chain)], // VH-706
  // THE FAMILIES A ROW'S DATA TYPES ARE FILED UNDER, IN THE ROW'S OWN DOMAIN (VH-785, families per domain). Each store
  // expands a family clause to its own types as a clause of its own, and a store that holds none of them runs without
  // it, so its rows came back unfiltered by the family. Scored here, those rows rank below the rows that are in it.
  families: (r, domain) => typesOf(r).map((type) => lc(familyKey(type, domain))),
});

// A row's data types as it holds them, unfolded, for the registry to file.
function typesOf(r) {
  const lines = Array.isArray(r.lines) ? r.lines.map((l) => l?.product_type) : [];
  return [...(Array.isArray(r.product_types) ? r.product_types : []), ...lines].filter((t) => typeof t === 'string' && t.trim());
}

function valuesFor(row, clause) {
  const read = READERS[clause];
  if (!read) return [];
  // A Space row arrives untagged; every other store's row carries the `_domain` the union gave it.
  return read(row?.record || row || {}, row?._domain || 'space').filter(Boolean);
}

// The clause groups a row can be scored against, families among them (VH-785). Until families were held per domain
// this left families out on the reading that the clause was expanded into product types; it never was: it is its own
// clause in every store, so scoring it counts nothing twice.
const SCORED_CLAUSES = Object.freeze(Object.keys(READERS));

/** How many of the asked-for clause groups this row satisfies. */
export function relevanceScore(row, filterSpec) {
  let score = 0;
  for (const clause of SCORED_CLAUSES) {
    const asked = listOf(filterSpec?.[clause]);
    if (asked.length === 0) continue;
    const held = valuesFor(row, clause);
    if (held.some((v) => asked.includes(v))) score += 1;
  }
  return score;
}

/**
 * Rank a cross-domain union: most clauses satisfied first, then the order the stores were read in, then the
 * name, so the result is deterministic and a re-run of the same question returns the same page.
 *
 * `parts` are the per-store results in read order; each row keeps the `_domain` tag the caller applied.
 */
export function rankCrossDomain(rows, filterSpec) {
  return rows
    .map((row, index) => ({ row, index, score: relevanceScore(row, filterSpec) }))
    .sort((a, b) => (b.score - a.score)
      || (a.index - b.index)
      || lc(a.row?.record?.company || a.row?.legal_name).localeCompare(lc(b.row?.record?.company || b.row?.legal_name)))
    .map((entry) => entry.row);
}

/**
 * Which stores had more matches than the read window carried back.
 *
 * Reported per store rather than as one number, because "900 Air matches, 500 read" is actionable (narrow
 * the question, or ask that domain on its own) and "some rows are missing" is not.
 */
export function truncatedStores(parts) {
  return parts
    .filter((p) => (p.total || 0) > (p.rows || []).length)
    .map((p) => ({ domain: p.domain, shown: (p.rows || []).length, total: p.total || 0 }));
}
