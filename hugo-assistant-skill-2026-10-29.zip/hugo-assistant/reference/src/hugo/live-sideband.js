// THE SERVER'S SIDEBAND TO A LIVE SESSION (VH-777 Lane V). Once `live-session.js` has created a session from the
// browser's offer, this server dials OUT to the same session over a WebSocket of its own and holds it for the life of
// the conversation. Nothing dials in, so no inbound WebSocket has to cross the App Store ingress (the transport the
// relay depends on, and which has never been measured live).
//
// WHAT THE SIDEBAND DOES, each read from OpenAI's published specification and SDK (Phase 0, docs/VH-777-LIVE-FACTS.md):
//  ● It attaches at `wss://api.openai.com/v1/live/sessions/{session_id}/attach` with the key as a bearer header
//    (`openai` 7.43.0, resources/live/sideband/internal-base.ts and ws-base.ts).
//  ● The brain's work arrives as `response.event`, "A streaming Responses API event from a backend delegated to by the
//    Live session", carrying the nested event and its `delegation_id` (LiveResponseEvent). A function call is the
//    Responses stream's `response.output_item.done` with an item of type `function_call`.
//  ● A tool's answer goes back as `response.item.create` with "a function tool result", and `response.create` then
//    continues "a delegated response waiting for tool results" (LiveResponseItemCreateParam, LiveResponseCreateParam).
//  ● Spend: `session.usage.updated` carries the CUMULATIVE audio seconds ("Do not sum this value across usage events"),
//    and "Delegated Responses token usage is reported separately in response.event events" (LiveSessionUsageUpdated).
//  ● `session.close` asks the session to end, and `session.closed` "contains the close reason and final usage"
//    (LiveSessionCloseParam, LiveSessionClosed).
//
// GOVERNANCE, the same rails the relay holds: every tool runs here, exactly once per call id, with the caller's own
// principal (the runner is built per session); the daily cap is asked before each tool runs and as audio usage
// accrues, and a spent day ends the session; the session has a length bound; one audit row per delegated turn, never
// the words. `wsFactory`, the timers and the clock are injected so all of it is unit-tested against a fake socket.

export const LIVE_SIDEBAND_BASE = 'wss://api.openai.com/v1';
export const SIDEBAND_OPEN_TIMEOUT_MS = 10_000;
export const SIDEBAND_CLOSE_GRACE_MS = 5_000;
export const SIDEBAND_FRAME_MAX = 2_000_000;
const TOOL_OUTPUT_MAX = 12_000; // a tool result handed back to the brain is bounded, as the relay's is (V1.77 D6)
const ARGS_MAX = 20_000;
const DIAG = /^[\w.:-]{1,80}$/;
const diag = (v) => (typeof v === 'string' && DIAG.test(v) ? v : undefined);
// THE CONNECTION CHECK'S DELEGATED TURN (owner, 26 October 2026: the check must test what Hugo uses). The sideband asks
// the brain one question that needs one tool, so a green result means the brain answered AND a tool ran on this server.
export const PROBE_TEXT = 'Connection check. Call count_records for the space domain with no filters, then say the count in one short sentence.';
export const PROBE_TIMEOUT_MS = 25_000;

/** The sideband URL for a session id (already checked path-safe by the caller, and encoded here regardless). */
export const sidebandUrl = (sessionId, base = LIVE_SIDEBAND_BASE) => base + '/live/sessions/' + encodeURIComponent(sessionId) + '/attach';

// A call's arguments as an object: bounded, and `{}` for anything that is not a JSON object.
function argsOf(raw) {
  let args = {};
  try { args = raw.length <= ARGS_MAX ? JSON.parse(raw || '{}') : {}; } catch { args = {}; }
  return args && typeof args === 'object' && !Array.isArray(args) ? args : {};
}

/** A function call in a nested Responses event, or null. */
export function functionCallOf(nested) {
  const item = nested?.type === 'response.output_item.done' ? nested.item : null;
  if (item?.type !== 'function_call' || typeof item.call_id !== 'string' || typeof item.name !== 'string') return null;
  return { callId: item.call_id, name: item.name, args: String(item.arguments ?? '') };
}

/** Token usage on a finished nested response, in the ledger's shape, or null. */
export function brainUsageOf(nested) {
  if (!['response.completed', 'response.incomplete', 'response.failed'].includes(nested?.type)) return null;
  const u = nested.response?.usage;
  const input = Number(u?.input_tokens);
  const output = Number(u?.output_tokens);
  if (!Number.isFinite(input) && !Number.isFinite(output)) return null;
  return { input_tokens: Math.max(0, input || 0), output_tokens: Math.max(0, output || 0) };
}

/**
 * Attach a sideband to one Live session. Resolves `ready` once the socket opens (or rejects on refusal or timeout).
 * @returns {{ ready: Promise<void>, close: (reason?: string) => void, probeTurn: (ms?: number) => Promise<object>, state: () => object }}
 */
export function attachSideband({
  apiKey, sessionId, wsFactory, base = LIVE_SIDEBAND_BASE,
  liveModel, brainModel,
  runTool, onUsage = () => {}, turnAllowed = async () => true, onTurn = () => {}, onClose = () => {},
  maxSessionMs = 0, openTimeoutMs = SIDEBAND_OPEN_TIMEOUT_MS,
  setTimer = setTimeout, clearTimer = clearTimeout, now = Date.now,
}) {
  const startedAt = now();
  const evidence = { turns: 0, tools: 0, errors: 0 };
  const answered = new Set(); // call ids already run: each tool runs exactly once
  const responses = new Map(); // per delegation: the current response's tool bookkeeping
  let seconds = 0; // cumulative audio seconds already booked
  let opened = false;
  let ended = false;
  let closeReason = '';
  let graceTimer = null;
  let lengthTimer = null;
  let probeWaiter = null;
  let closer = null; // the second link that ends a session whose first link dropped

  const ws = wsFactory(sidebandUrl(sessionId, base), { headers: { authorization: 'Bearer ' + apiKey }, maxPayload: SIDEBAND_FRAME_MAX });
  const send = (event) => { if (opened && !ended) { try { ws.send(JSON.stringify(event)); } catch { /* the close handler reports it */ } } };

  let resolveReady;
  let rejectReady;
  const ready = new Promise((resolve, reject) => { resolveReady = resolve; rejectReady = reject; });
  ready.catch(() => {}); // a caller that never awaits it must not leave an unhandled rejection
  const openTimer = setTimer(() => {
    if (opened) return;
    finish('open_timeout');
    rejectReady(Object.assign(new Error('hugo live sideband timed out'), { timedOut: true }));
  }, openTimeoutMs);

  function finish(reason, detail = {}) {
    if (ended) return;
    ended = true;
    closeReason = closeReason || reason;
    probeWaiter?.done({ ok: false, kind: 'closed' });
    clearTimer(openTimer);
    clearTimer(graceTimer);
    clearTimer(lengthTimer);
    try { ws.close(1000); } catch { /* already gone */ }
    try { closer?.close(1000); } catch { /* already gone */ }
    try { onClose(closeReason, { ...evidence, seconds, ms: now() - startedAt, ...detail }); } catch { /* reporting must never throw */ }
  }

  /** Ask the session to end; the socket is dropped after a grace period if `session.closed` never comes. */
  function close(reason = 'operator_left') {
    if (ended) return;
    closeReason = closeReason || reason;
    if (!opened) { finish(reason); return; }
    // A second link already dialling to close it keeps its own, longer grace (2.20.0 round two, security MINOR 5): this
    // socket is gone, and replacing that grace with 5 seconds could end the session before the second link opened.
    if (closer) return;
    send({ type: 'session.close' });
    clearTimer(graceTimer);
    graceTimer = setTimer(() => finish(reason), SIDEBAND_CLOSE_GRACE_MS);
    graceTimer?.unref?.();
  }

  function book(usage, model) {
    try { onUsage(usage, model); } catch { /* metering must never break the session */ }
  }

  // Cumulative seconds, booked as the increase since the last report so nothing is counted twice.
  function bookSeconds(total) {
    const t = Number(total);
    if (!Number.isFinite(t) || t <= seconds) return;
    book({ input_tokens: 0, output_tokens: 0, audio_seconds: t - seconds }, liveModel);
    seconds = t;
  }

  const entryFor = (key) => {
    if (!responses.has(key)) responses.set(key, { called: false, pending: 0, completed: false, continued: false });
    return responses.get(key);
  };
  function maybeContinue(entry) {
    if (!entry.called || !entry.completed || entry.pending > 0 || entry.continued) return;
    entry.continued = true;
    send({ type: 'response.create' });
  }

  async function runCall(key, call) {
    if (answered.has(call.callId)) return;
    answered.add(call.callId);
    const entry = entryFor(key);
    entry.called = true;
    entry.pending += 1;
    evidence.tools += 1;
    let out = { error: 'daily_cap_reached' };
    try {
      if (await turnAllowed()) out = await runTool(call.name, argsOf(call.args), call.callId);
    } catch {
      out = { error: 'tool_failed' };
    }
    let text = '';
    try { text = JSON.stringify(out ?? null); } catch { text = '{"error":"unserialisable"}'; }
    send({ type: 'response.item.create', item: { type: 'function_call_output', call_id: call.callId, output: text.slice(0, TOOL_OUTPUT_MAX) } });
    entry.pending -= 1;
    if (probeWaiter && !probeWaiter.tool) probeWaiter.tool = call.name;
    if (out?.error === 'daily_cap_reached') { close('daily_cap_reached'); return; }
    maybeContinue(entry);
  }

  function onResponseEvent(msg) {
    const nested = msg.event;
    const key = typeof msg.delegation_id === 'string' ? msg.delegation_id : '';
    if (nested?.type === 'response.created') {
      const prev = responses.get(key);
      if (prev?.continued !== false || prev.completed) responses.set(key, { called: false, pending: 0, completed: false, continued: false });
      return;
    }
    const call = functionCallOf(nested);
    if (call) { runCall(key, call); return; }
    const usage = brainUsageOf(nested);
    if (usage) book(usage, brainModel);
    if (usage || nested?.type === 'response.completed') {
      const entry = entryFor(key);
      entry.completed = true;
      maybeContinue(entry);
      settleProbe(nested, entry);
    }
  }

  // The probe passes when a response that FOLLOWED a tool's answer completes: the brain called a tool, this server ran
  // it, and the brain answered from it. A failed or incomplete response, or a session error, fails it by name.
  function settleProbe(nested, entry) {
    if (!probeWaiter) return;
    if (nested.type !== 'response.completed') { probeWaiter.done({ ok: false, kind: 'failed', code: diag(nested.response?.status) }); return; }
    if (probeWaiter.tool && !entry.called) probeWaiter.done({ ok: true, tool: probeWaiter.tool });
  }

  /** One delegated turn that must call a tool: `{ ok, tool?, kind?, code?, latencyMs }`. Never rejects. */
  function probeTurn(timeoutMs = PROBE_TIMEOUT_MS) {
    const t0 = now();
    return new Promise((resolve) => {
      if (!opened || ended) { resolve({ ok: false, kind: 'not_attached', latencyMs: 0 }); return; }
      const timer = setTimer(() => { if (probeWaiter === waiter) waiter.done({ ok: false, kind: 'timeout' }); }, timeoutMs);
      const waiter = {
        tool: '',
        done(out) {
          clearTimer(timer);
          if (probeWaiter === waiter) probeWaiter = null;
          resolve({ ...out, latencyMs: now() - t0 });
        },
      };
      probeWaiter = waiter;
      send({ type: 'response.item.create', item: { type: 'message', role: 'user', content: [{ type: 'input_text', text: PROBE_TEXT }] } });
      send({ type: 'response.create' });
    });
  }

  async function onUsageUpdated(msg) {
    bookSeconds(msg.usage?.seconds);
    let allowed = false;
    try { allowed = (await turnAllowed()) === true; } catch { allowed = false; }
    if (!allowed) close('daily_cap_reached');
  }

  ws.on('open', () => {
    opened = true;
    clearTimer(openTimer);
    if (maxSessionMs > 0) lengthTimer = setTimer(() => close('session_length'), maxSessionMs);
    resolveReady();
  });
  ws.on('message', (data, isBinary) => {
    if (isBinary || ended) return;
    let msg = null;
    try { msg = JSON.parse(String(data)); } catch { return; }
    switch (msg?.type) {
      case 'response.event': onResponseEvent(msg); break;
      case 'session.delegation.created':
        evidence.turns += 1;
        try { onTurn(); } catch { /* the audit must never break the session */ }
        break;
      case 'session.usage.updated': onUsageUpdated(msg); break;
      case 'session.closed':
        bookSeconds(msg.usage?.seconds);
        finish(closeReason || diag(msg.reason) || 'closed');
        break;
      case 'error':
        evidence.errors += 1;
        evidence.lastError = diag(msg.error?.code) || diag(msg.error?.type);
        probeWaiter?.done({ ok: false, kind: 'refused', code: evidence.lastError });
        break;
      default: break;
    }
  });
  ws.on('error', () => { evidence.socketError = true; });
  ws.on('close', (code) => {
    if (!opened) rejectReady(Object.assign(new Error('hugo live sideband refused'), { refused: true, code }));
    // ANY drop after open, while `session.closed` is unseen and no second link exists, is redialled to close the session
    // (2.20.0 round two, security MINOR 5 and engineering MINOR 8): a drop after the server had already asked to close
    // (the session length, the daily cap, a replacing open) used to end it here, with the close never confirmed.
    if (opened && !ended && !closer) { endFromNewLink(Number(code) || 0); return; }
    finish(closeReason || 'upstream_closed', { code: Number(code) || 0 });
  });

  // A DROPPED LINK STILL ENDS ITS SESSION (2.20.0 security gate, MAJOR). This socket is what meters the session and holds its
  // length; when it drops after the session opened (a network blip, an upstream close), the browser's audio can run on with
  // nothing booking it against the day, and whether OpenAI ends a session whose sideband went is not known (TBC, re-verify).
  // So one new link is opened to send `session.close`, and the session counts as open, for End and for shutdown, until that
  // link reports `session.closed`, closes, or the grace period ends.
  function endFromNewLink(code) {
    closeReason = closeReason || 'upstream_closed';
    const detail = { code, reclosed: false };
    try {
      closer = wsFactory(sidebandUrl(sessionId, base), { headers: { authorization: 'Bearer ' + apiKey }, maxPayload: SIDEBAND_FRAME_MAX });
    } catch {
      finish(closeReason, detail);
      return;
    }
    clearTimer(graceTimer);
    graceTimer = setTimer(() => finish(closeReason, detail), openTimeoutMs + SIDEBAND_CLOSE_GRACE_MS);
    graceTimer?.unref?.();
    closer.on('open', () => {
      try { closer.send(JSON.stringify({ type: 'session.close' })); detail.reclosed = true; } catch { /* its close handler ends it */ }
    });
    closer.on('message', (data, isBinary) => {
      if (isBinary) return;
      let msg = null;
      try { msg = JSON.parse(String(data)); } catch { return; }
      if (msg?.type === 'session.closed') { bookSeconds(msg.usage?.seconds); finish(closeReason, detail); }
    });
    closer.on('error', () => { evidence.socketError = true; });
    closer.on('close', () => finish(closeReason, detail));
  }

  return { ready, close, probeTurn, state: () => ({ opened, ended, reason: closeReason, ...evidence, seconds }) };
}
