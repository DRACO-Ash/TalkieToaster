// HUGO'S VOICE ON GPT-LIVE (VH-777 Lane V, owner 2026-10-26: "Use GPT-Live with Astra"). The browser's WebRTC offer
// comes to THIS server, which creates the Live session with the key and hands back OpenAI's answer. Audio then flows
// between the browser and OpenAI directly; the key never reaches the browser and `connect-src 'self'` holds, because
// the browser's only HTTP call is to this origin. The server then attaches its own OUTBOUND sideband socket to the same
// session (`live-sideband.js`), which runs every tool, meters spend and closes the session.
//
// EVERY OPENAI FACT HERE WAS READ, NOT REMEMBERED (Phase 0, 26 October 2026, docs/VH-777-LIVE-FACTS.md). OpenAI's own
// hosts are refused by this build's egress proxy, so the sources are OpenAI's published OpenAPI description
// (github.com/openai/openai-openapi, `openapi.yaml`) and the `openai` npm package 7.43.0, both OpenAI's own:
//  ● `POST /v1/live/sessions` with `{ session, transport: { type: 'webrtc', sdp } }` answers 201 with
//    `{ session: { id }, transport: { type: 'webrtc', sdp } }`; "do not send session.start again" (LiveSessionCreateRequest).
//  ● `session.model` is required; `gpt-live-1` is the named Live model (ModelIdsLive). Frontend instructions are
//    "Limited to 16,384 client-supplied tokens" and are "Immutable after startup" (LiveSessionCreateParams).
//  ● `delegation: { type: 'responses', responses: { model, instructions, tools, ... } }` hands reasoning and tools to a
//    Responses model (LiveResponsesDelegationParam); function tools take `{ type, name, description, parameters }`.
//  ● `client.data_channel` sets which events "an untrusted WebRTC frontend can send and receive over its data channel.
//    These restrictions do not apply to trusted sideband connections" (LiveDataChannelConfigParam). That is the lock:
//    the browser may only mute and unmute, and may read captions, so it can neither re-instruct Hugo nor call a tool.
//  ● Voices: `marin` is the default, and every voice the picker offers is in the Live list (LiveInitialSessionAudioOutputParam).
// What the deployed service does with these shapes is verified at deploy with the key, by the connection check.

import { providerError } from './openai-chat.js';
import { REALTIME_INSTRUCTIONS, PLAIN_ENGLISH, hugoInstructions } from './persona.js';
import { REALTIME_VOICES, DEFAULT_REALTIME_VOICE } from './openai-realtime.js';

export const LIVE_BASE = 'https://api.openai.com/v1';
export const DEFAULT_LIVE_MODEL = 'gpt-live-1';
export const DEFAULT_LIVE_BRAIN = 'gpt-6-astra';
// The fallback voice model on the same WebRTC pattern (the plan's first fallback). Named so the check can report
// whether the key reaches it; the relay (`openai-realtime.js`) is what dials it today.
export const FALLBACK_REALTIME_MODEL = 'gpt-realtime-2.1';
// The models the check asks the key about, names only.
export const HUGO_MODEL_IDS = Object.freeze([DEFAULT_LIVE_MODEL, DEFAULT_LIVE_BRAIN, FALLBACK_REALTIME_MODEL]);

/** The Live model and the brain behind it, from the environment (OPENAI_LIVE_MODEL, OPENAI_LIVE_BRAIN_MODEL). */
const pickModel = (raw, fallback) => (typeof raw === 'string' && /^[\w.:-]{1,80}$/.test(raw.trim()) ? raw.trim() : fallback);
export function liveModels(env = process.env) {
  return { model: pickModel(env.OPENAI_LIVE_MODEL, DEFAULT_LIVE_MODEL), brain: pickModel(env.OPENAI_LIVE_BRAIN_MODEL, DEFAULT_LIVE_BRAIN) };
}

// THE OFFER IS VALIDATED BEFORE IT IS SENT ANYWHERE. A browser offer for one audio track and one data channel is a few
// kilobytes; 64 KB is room for any real one and a hard bound on what a caller can make this server post. Every line of
// an SDP is `<letter>=<printable ASCII>` (RFC 8866 section 5), so anything else is refused rather than forwarded.
export const SDP_OFFER_MAX_BYTES = 64 * 1024;
const SDP_LINE = /^[a-z]=[\x20-\x7e]*$/;
/** The offer as CRLF lines, or '' when it is not one: oversized, not SDP, or missing the audio or data section. */
export function validSdpOffer(sdp) {
  if (typeof sdp !== 'string' || sdp.length === 0 || Buffer.byteLength(sdp, 'utf8') > SDP_OFFER_MAX_BYTES) return '';
  const lines = sdp.split(/\r?\n/);
  if (lines.at(-1) === '') lines.pop();
  if (lines[0] !== 'v=0' || !lines.every((l) => SDP_LINE.test(l))) return '';
  if (!lines.some((l) => l.startsWith('m=audio ')) || !lines.some((l) => l.startsWith('m=application '))) return '';
  return lines.join('\r\n') + '\r\n';
}

/** A voice from the picker's list, or the default; anything else is never forwarded. */
export function liveVoice(asked) {
  const v = typeof asked === 'string' ? asked.trim().toLowerCase() : '';
  return REALTIME_VOICES.includes(v) ? v : DEFAULT_REALTIME_VOICE;
}

// THE TWO BRIEFS, FROM THE ONE PERSONA (VH-777 Lane T, `persona.js`). GPT-Live speaks and listens; the brain behind it
// (Astra, through Responses delegation) looks things up and reasons. The Live guide asks for "frontend conversation
// instructions and a separate backend prompt" (`/live/sessions/{id}/accept` in the specification). The voice is Hugo's
// spoken persona with when to hand a question back; the brain is Hugo's spoken brief for the scope on screen.
export const LIVE_DELEGATION_GUIDE = [
  'Talk freely about yourself and greet the operator naturally. For anything about the records, the app, its screens, its help or its history, hand the question to your backend and speak its answer; never state a figure, a vendor or a setting from memory.',
  'If the operator interrupts you, stop and listen.',
  PLAIN_ENGLISH,
].join(' ');
export const LIVE_FRONTEND_INSTRUCTIONS = REALTIME_INSTRUCTIONS + ' ' + LIVE_DELEGATION_GUIDE;
/** The brain's brief for a scope: a domain id or 'all'. */
export const liveBackendInstructions = (scope) => hugoInstructions({ channel: 'spoken', scope });

// WHAT THE BROWSER MAY DO ON ITS DATA CHANNEL. Mute and unmute its own microphone, and nothing else: no
// `session.update`, no `response.create`, no `response.item.create`, so it can neither re-instruct Hugo nor run, fake or
// answer a tool. It hears the session start and end, the two captions, errors and notices. The sideband, which is this
// server, is not restricted (the specification says so), and it is the only party that answers a tool.
export const FRONTEND_CLIENT_EVENTS = Object.freeze(['session.input_audio.mute', 'session.input_audio.unmute']);
export const FRONTEND_SERVER_EVENTS = Object.freeze(['session.started', 'session.input_transcript.delta', 'session.output_transcript.delta', 'session.delegation.created', 'session.closed', 'error', 'info']);

/** The body POSTed to `/v1/live/sessions`. Pure, so the shape is unit-tested against the specification's. */
export function buildLiveSessionRequest({ sdp, voice, tools = [], scope = '', model = DEFAULT_LIVE_MODEL, brain = DEFAULT_LIVE_BRAIN, instructions = LIVE_FRONTEND_INSTRUCTIONS, backendInstructions = liveBackendInstructions(scope) } = {}) {
  return {
    session: {
      model,
      instructions,
      audio: { output: { voice: liveVoice(voice) } },
      delegation: {
        type: 'responses',
        responses: {
          model: brain,
          instructions: backendInstructions,
          tools: tools.map(({ name, description, parameters }) => ({ type: 'function', name, description, parameters })),
          parallel_tool_calls: true,
        },
      },
      client: {
        data_channel: {
          allowed_client_events: [...FRONTEND_CLIENT_EVENTS],
          allowed_server_events: FRONTEND_SERVER_EVENTS.map((type) => ({ type })),
        },
      },
    },
    transport: { type: 'webrtc', sdp },
  };
}

// An opaque Live session id is kept as given (the specification: "Preserve the returned value unchanged, including its
// prefix"), and checked to be a path-safe token before it is ever put in a URL.
const SESSION_ID = /^[\w-]{1,200}$/;
export const LIVE_CREATE_TIMEOUT_MS = 15_000;

const timeoutError = (what) => Object.assign(new Error('hugo live ' + what + ' timed out'), { statusCode: 504, timedOut: true });

/**
 * The Live client: create a session from an offer, and list which of Hugo's models the key reaches.
 * `fetchImpl` is injected so the whole exchange is unit-tested with no network.
 */
export function createLiveClient({ apiKey, fetchImpl, base = LIVE_BASE, env = process.env, timeoutMs = LIVE_CREATE_TIMEOUT_MS } = {}) {
  const doFetch = fetchImpl || (typeof fetch === 'function' ? fetch : null);
  const configured = Boolean(apiKey) && typeof doFetch === 'function';
  const { model, brain } = liveModels(env);

  async function call(path, init, what) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), timeoutMs);
    try {
      return await doFetch(base + path, { ...init, headers: { authorization: 'Bearer ' + apiKey, ...init.headers }, signal: ctl.signal });
    } catch (err) {
      if (ctl.signal.aborted) throw timeoutError(what);
      throw Object.assign(new Error('hugo live ' + what + ' unreachable'), { statusCode: 502, egress: true, cause: err });
    } finally { clearTimeout(timer); }
  }

  /** `{ sessionId, sdp }` for a validated offer, or a thrown provider error carrying status and code only. */
  async function create({ sdp, voice, tools = [], scope = '' } = {}) {
    if (!configured) throw Object.assign(new Error('hugo live not configured'), { statusCode: 503 });
    const offer = validSdpOffer(sdp);
    if (!offer) throw Object.assign(new Error('invalid sdp offer'), { statusCode: 400 });
    const body = buildLiveSessionRequest({ sdp: offer, voice, tools, scope, model, brain });
    const res = await call('/live/sessions', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }, 'session');
    if (!res.ok) throw await providerError(res, 'hugo live session error');
    let out = null;
    try { out = JSON.parse((await res.text()).slice(0, 200_000)); } catch { out = null; }
    const sessionId = out?.session?.id;
    const answer = out?.transport?.sdp;
    if (typeof sessionId !== 'string' || !SESSION_ID.test(sessionId) || typeof answer !== 'string' || !answer.startsWith('v=0')) {
      throw Object.assign(new Error('hugo live session answer malformed'), { statusCode: 502, providerStatus: res.status, providerCode: 'malformed' });
    }
    return { sessionId, sdp: answer, model, brain };
  }

  /** Which of Hugo's models the key reaches, NAMES ONLY: `{ reached: string[], missing: string[] }`. */
  async function reachableModels(ids = HUGO_MODEL_IDS) {
    if (!configured) throw Object.assign(new Error('hugo live not configured'), { statusCode: 503 });
    const res = await call('/models', { method: 'GET', headers: {} }, 'models');
    if (!res.ok) throw await providerError(res, 'hugo model list error');
    let listed = [];
    try { listed = JSON.parse((await res.text()).slice(0, 2_000_000))?.data ?? []; } catch { listed = []; }
    const names = new Set(Array.isArray(listed) ? listed.map((m) => String(m?.id ?? '')) : []);
    const wanted = [...new Set([model, brain, ...ids])];
    return { reached: wanted.filter((id) => names.has(id)), missing: wanted.filter((id) => !names.has(id)) };
  }

  return { configured, model, brain, create, reachableModels };
}

export const liveSessionIdValid = (id) => typeof id === 'string' && SESSION_ID.test(id);
