// Hugo's reasoning brain (owner-ruled: HUGO IS OPENAI). A thin, server-side proxy to OpenAI's chat
// completions API, isolated here so the network boundary is one testable place and the provider is
// swappable. The API key is read on the server only (never sent to the browser); when absent, `configured`
// is false and the routes answer 503 rather than calling out. `fetchImpl` is INJECTED so every test
// exercises the request shaping and the SSE parsing without a network call.
//
// Two callables, one endpoint:
//  ● streamOnce({ system, messages }) -> { content: [{type:'text', text}], usage } - collapsed to the final
//    text, so it satisfies the same contract the Anthropic caller gave Hugo's compiler (extractText reads a
//    text-block array), which is what lets the ViewIntent compiler run unchanged on OpenAI.
//  ● streamChat({ system, messages, onDelta }) -> { text, usage } - a real-time stream: each token delta is
//    handed to onDelta as it arrives, for the conversational rail.
//
// USAGE is mapped from OpenAI's { prompt_tokens, completion_tokens } to the { input_tokens, output_tokens }
// shape the spend ledger already accumulates (src/scan/cost.js), so the daily cost cap governs OpenAI spend
// exactly as it governed the model spend before, with no change to the ledger.

/*
 * THE MODEL IS THE MOST ADVANCED ONE OPENAI OFFERS FOR THIS USE, which is the owner's standing instruction
 * and not a per-release choice: `gpt-6-astra`.
 *
 * LOOKED UP, NOT REMEMBERED, and the distinction is the whole point of this comment. An engineering gate
 * raised the first version of it as a BLOCKER, correctly: it asserted flatly that this id was the flagship
 * and was supported on Chat Completions, and nothing in the session had produced either fact. The id was
 * then verified against published sources on 2026-09-17, and what they say is:
 *   - `gpt-6-astra` is the real API id of GPT-6 Astra, OpenAI's frontier flagship, released 2026-09-03,
 *     succeeding GPT-5.6 Sol. $10 per million input tokens, $50 per million output.
 *   - It is supported on Responses (`/v1/responses`), Chat Completions (`/v1/chat/completions`) and Batch.
 *   - TOOL CALLING REQUIRES THE RESPONSES API, on Chat Completions it is not available.
 * That last line is the one that matters here, because it is exactly the split `chatOnce` implements: a
 * tool-free turn stays on `/chat/completions`, a tool-carrying turn goes to `/v1/responses`. The endpoint
 * design is therefore confirmed by a source rather than inferred, which it was not when it was written.
 * Sources: openai.com/index/gpt-6-astra/, developers.openai.com/api/docs/models/gpt-6-astra (the developer
 * docs host is blocked by this environment's egress proxy, so that one is cited from search results and not
 * from a fetch), docs.aws.amazon.com/bedrock/latest/userguide/model-card-openai-gpt-6-astra.html.
 *
 * WHAT IS STILL NOT MEASURED, stated rather than glossed: that this id RESOLVES ON THIS ACCOUNT. That needs
 * a live key this project does not hold, and no amount of reading the documentation substitutes for it. If
 * the account has no GPT-6 Astra entitlement, every Hugo turn will 400 and `OPENAI_HUGO_MODEL` is the
 * one-variable way out, with no code change and no redeploy.
 *
 * A CORRECTION IS RECORDED HERE BECAUSE AN EARLIER COMMENT WAS FALSE. It claimed the previous default,
 * `gpt-5.6-sol`, was an invented id. That was wrong: GPT-5.6 Sol is a real OpenAI model and a real id. The
 * claim was made from memory rather than from a source, which is the exact failure the never-invent-a-fact
 * rule exists to prevent, committed while accusing this line of committing it. Changing the id was never
 * the fix for the owner's `400 invalid_request_error`; the ENDPOINT was.
 */
const DEFAULT_MODEL = 'gpt-6-astra';

function mapUsage(u) {
  return {
    input_tokens: Number(u?.prompt_tokens) || 0,
    output_tokens: Number(u?.completion_tokens) || 0,
  };
}

// The messages array OpenAI wants: the system prompt(s) first, then the caller's turns (each
// {role, content}). `system` may be an ARRAY, which becomes one system message per entry: B9's grounding
// pack is a SECOND system message rather than a paragraph appended to the persona, so the persona stays a
// fixed server-side string and the pack is visibly a separate, per-turn data block.
function withSystem(system, messages) {
  const prompts = (Array.isArray(system) ? system : [system])
    .filter((s) => s !== null && s !== undefined && String(s) !== '')
    .map((s) => ({ role: 'system', content: String(s) }));
  return [...prompts, ...(Array.isArray(messages) ? messages : [])];
}

/**
 * The error for a provider response that is not ok, WITH THE STATUS AND THE PROVIDER'S OWN CODE IN THE
 * MESSAGE.
 *
 * THE MESSAGE IS THE ONLY THING THAT SURVIVES. `src/faults.js` records `err.message` and nothing else, and
 * the agent route records exactly that (`ctx.faults?.record('hugo-agent', err?.message)`), so while this
 * threw a fixed string every provider failure was indistinguishable in the one diagnostic an operator can
 * reach without shell access: a rejected key (401), a model id this account cannot reach (404), a spent
 * quota or rate limit (429) and a provider outage (5xx) all read as "hugo model provider error". On
 * 2026-09-11 Hugo fell back to the dataset resolver in the live deployment and that string was the whole of
 * the evidence, which is four candidate causes and no way to choose between them. `providerStatus` was
 * already on the error object and is still set, but nothing recorded it.
 *
 * The body is read for the provider's `error.code` (`model_not_found`, `invalid_api_key`,
 * `insufficient_quota`), which names the cause outright. It is bounded, it is never the operator's prompt,
 * and an unreadable or non-JSON body simply leaves the status to speak for itself.
 */
/**
 * Strip anything credential-shaped out of a provider's own sentence.
 *
 * TWO BINDING GATES DISAGREED ABOUT THIS LINE AND BOTH WERE RIGHT ABOUT THEIR HALF, so the fix takes both.
 * The engineering gate found that removing the provider's prose from `err.message` left the diagnostic
 * recorded NOWHERE - the fault ring stores `err.message` and nothing reads `providerDetail` - so an operator
 * was back to `400 invalid_request_error` with four indistinguishable causes, which is the owner's original
 * symptom. Its fix was to record the prose to the ring, "safe because the ring is admin-only". The security
 * gate had already MEASURED that the ring was carrying `sk-proj-...` before the change, so restoring the raw
 * prose there would put the key fragment straight back into a reader. Its fix was to keep it out and correct
 * the comments.
 *
 * Neither half is satisfactory alone: one loses a diagnostic the owner needs, the other keeps a leak. So the
 * prose comes back, REDACTED, and only to the admin ring. What survives redaction is the part that names the
 * cause ("The model `x` does not exist", "Unsupported parameter: ..."); what does not is anything that looks
 * like a credential.
 *
 * DENY BY SHAPE, NOT BY VENDOR PREFIX. Matching only `sk-` would pass an Azure key, a bearer token or the
 * next provider's format. This masks any long unbroken run of credential alphabet, which is what a key looks
 * like whoever issued it, and accepts that it will sometimes mask a long model id - a redacted model id still
 * leaves the status and the code, and the alternative failure is a key in a log.
 */
export function redactSecrets(text) {
  return String(text == null ? '' : text)
    // A URL's user and password (a database connection string a store error quotes back), however short the password:
    // the run rule below misses one under 16 characters (2.21.0 round one, security MINOR 4).
    .replaceAll(/\b([a-z][a-z0-9+.-]*:\/\/)[^\s/@]+@/gi, '$1[REDACTED:credential]@')
    // Bearer/Basic/Token headers quoted back at us, value and all.
    .replaceAll(/\b(bearer|basic|token)\s+\S+/gi, '$1 [REDACTED:credential]')
    // Any run of 16 or more characters from the alphabet keys are minted from. Hyphen and underscore are in
    // the class because every common key format uses them as separators inside the secret itself.
    .replaceAll(/[A-Za-z0-9_-]{16,}/g, (m) => (/\d/.test(m) && /[A-Za-z]/.test(m) ? '[REDACTED:credential]' : m));
}

export async function providerError(res, label) {
  let code = '';
  let detail = '';
  try {
    const parsed = JSON.parse((await res.text()).slice(0, 4000));
    code = String(parsed?.error?.code || parsed?.error?.type || '').slice(0, 60);
    // AND THE PROVIDER'S OWN SENTENCE (owner defect 9, V1.90). The status and the code were already here
    // and they were still not enough: the owner's fault line read `400 invalid_request_error`, which is the
    // TYPE with no code, and four different malformed-request causes produce exactly that. The provider's
    // message names which - "The model `x` does not exist", "Unsupported parameter: ...". It describes the
    // REQUEST WE BUILT, never the operator's prompt, which is in `messages` and not echoed in an OpenAI
    // error; it is bounded hard all the same, and this string reaches only the admin fault ring - which is
    // true of `providerDetail` below and was NOT true of `message` when this comment was first written. See
    // the note on the return.
    detail = String(parsed?.error?.message || '').replaceAll(/\s+/g, ' ').trim().slice(0, 200);
  } catch { /* a non-JSON, empty or already-consumed body: the status still names the class */ }
  // THE SENTENCE STAYS OFF `err.message`, AND A SECURITY GATE MEASURED WHY (V1.90, found the same release
  // that added it). `src/app.js` returns `{ error: err.message }` for ANY error carrying a `statusCode`, and
  // `providerError` sets one, so anything on `message` is one uncaught throw away from the wire on every
  // model-backed route. Measured end to end on `POST /api/v3/hugo/agent`, HTTP 200:
  //   "providerReason":"hugo model provider error 401 invalid_api_key: Incorrect API key provided:
  //    sk-proj-Ab3xQ********************************"
  // OpenAI masks the middle, so that is not full key recovery; it is still the key's identifying prefix, the
  // account's model id and the provider's description of the request we built, reaching a caller who on the
  // open-writable posture is anonymous. The reasoning that put it here was that the message "describes the
  // REQUEST WE BUILT, never the operator's prompt" - true, and beside the point, because the provider is
  // free to quote the credential back and does.
  // So: `message` carries our label, the status and the closed-vocabulary code, all three of which are ours.
  // Fixed at the SOURCE rather than at the one route the gate could drive, because the class is the generic
  // handler and not the finding.
  //
  // AN EARLIER VERSION OF THIS COMMENT SAID `providerDetail` "carries the provider's prose to the admin fault
  // ring, which is the reader it was actually for". THAT WAS FALSE and both gates said so independently:
  // nothing in `src/` read `providerDetail`, every `faults.record` call passed `err.message`, so the
  // diagnostic was not moved to a safer reader, it was deleted. `ringDetail` below is the actual fix.
  const message = label + ' ' + res.status + (code ? ' ' + code : '');
  // `ringDetail` IS THE ADMIN-ONLY STRING, and it exists because `providerDetail` was reaching no reader at
  // all. A call site that records a fault reads `err.ringDetail || err.message` and needs no import and no
  // knowledge of redaction; anything that puts `err.message` on the wire is unchanged and still carries only
  // our label, the status and the closed-vocabulary code. Two properties rather than one because the two
  // readers have different rights: the ring may see a redacted sentence, an HTTP response may not see one at
  // all.
  const safeDetail = redactSecrets(detail);
  return Object.assign(new Error(message), {
    statusCode: 502,
    providerStatus: res.status,
    providerCode: code,
    providerDetail: detail,
    ringDetail: safeDetail ? message + ': ' + safeDetail : message,
  });
}

/**
 * THE CHAT-SHAPED TOOL CONTRACT, TRANSLATED FOR THE RESPONSES API (owner defect 9, V1.90).
 *
 * The agent loop in `src/hugo/agent.js` speaks Chat Completions: it appends the assistant message verbatim,
 * then one `{role:'tool', tool_call_id, content}` turn per result. OpenAI's current reasoning models take
 * FUNCTION CALLING on the Responses endpoint only, so the loop's shape has to be preserved while the wire
 * format changes underneath it. These four pure functions are that seam, and they are pure precisely so the
 * translation is unit-testable without a network.
 *
 * Labelled honestly: the owner's fault line is `hugo-agent hugo model provider error 400
 * invalid_request_error`, a type with no code, which is what an unsupported parameter returns, and `tools`
 * on `/chat/completions` is the unsupported parameter on this model tier. That chain is INFERRED from the
 * provider's documentation and from the fault carrying the agent's label rather than the chat rail's; it is
 * not measured, because measuring it needs a live key this project does not hold. What IS certain is that
 * the Responses endpoint is the documented home of function calling, so this is the correct call either way.
 */

/** Chat-shaped tools -> Responses-shaped tools: the function fields are flat rather than nested. */
function toResponsesTools(tools) {
  return (Array.isArray(tools) ? tools : []).map((t) => {
    const fn = t?.function && typeof t.function === 'object' ? t.function : t;
    return {
      type: 'function',
      name: String(fn?.name || ''),
      description: String(fn?.description || ''),
      parameters: fn?.parameters && typeof fn.parameters === 'object' ? fn.parameters : { type: 'object', properties: {} },
    };
  }).filter((t) => t.name);
}

/**
 * Chat-shaped turns -> Responses `input` items.
 *
 * An assistant turn carrying tool calls becomes one `function_call` item PER CALL, keyed by `call_id`, and a
 * `tool` turn becomes the matching `function_call_output`. The pairing is what makes the next turn well
 * formed, so the id is carried through unchanged rather than regenerated.
 */
function toolCallItems(m) {
  const items = [];
  if (typeof m.content === 'string' && m.content) items.push({ role: 'assistant', content: m.content });
  for (const c of m.tool_calls) {
    items.push({
      type: 'function_call',
      call_id: String(c?.id || ''),
      name: String(c?.function?.name || ''),
      arguments: String(c?.function?.arguments ?? ''),
    });
  }
  return items;
}

function toResponsesInput(messages) {
  const input = [];
  for (const m of Array.isArray(messages) ? messages : []) {
    if (m?.role === 'tool') {
      input.push({ type: 'function_call_output', call_id: String(m.tool_call_id || ''), output: String(m.content ?? '') });
    } else if (m?.role === 'assistant' && Array.isArray(m.tool_calls) && m.tool_calls.length > 0) {
      input.push(...toolCallItems(m));
    } else {
      input.push({ role: m?.role === 'assistant' ? 'assistant' : 'user', content: String(m?.content ?? '') });
    }
  }
  return input;
}

/** The system prompt(s) as the Responses API's single `instructions` string. */
function toInstructions(system) {
  return (Array.isArray(system) ? system : [system])
    .filter((x) => x !== null && x !== undefined && String(x) !== '')
    .map(String)
    .join('\n\n');
}

/**
 * A Responses reply -> the chat-shaped assistant message the agent loop appends.
 *
 * `finishReason` is DERIVED rather than read: the Responses API has no `finish_reason`, and the loop only
 * asks one question of it, which is whether this turn wants tools run. Deriving it from the presence of a
 * function call answers exactly that question and cannot disagree with the `tool_calls` beside it.
 */
function fromResponsesMessage(out) {
  const items = Array.isArray(out?.output) ? out.output : [];
  const toolCalls = items
    .filter((i) => i?.type === 'function_call')
    .map((i) => ({
      id: String(i.call_id || i.id || ''),
      type: 'function',
      function: { name: String(i.name || ''), arguments: String(i.arguments ?? '') },
    }));
  return {
    message: { role: 'assistant', content: responseText(out), tool_calls: toolCalls },
    finishReason: toolCalls.length > 0 ? 'tool_calls' : 'stop',
  };
}

/**
 * How long one model request may take before it is abandoned (VH-777 Lane T). Not inside the turn's 75-second wall, which
 * only stops new tool calls (`src/hugo/agent.js`): a turn past the wall still makes its answering and closing requests,
 * each bounded by this (2.20.0 round one, engineering MINOR 4, correcting this comment).
 */
export const MODEL_REQUEST_MS = 45_000;

export function createOpenAiChat({
  apiKey,
  fetchImpl,
  model = process.env.OPENAI_HUGO_MODEL || DEFAULT_MODEL,
  base = 'https://api.openai.com/v1',
  maxTokens = 2000,
  onUsage = () => {},
  // THE EVAL RECORDER (V1.74 D1): optional `{ record({ provider, model, request, providerRequest, response }) }`
  // handed every pair for free replay under `npm run eval`. `request` is the caller-level argument object (the
  // replay key), `providerRequest` the posted body. eval/lib/recordings.js supplies one only under
  // EVAL_RECORD=1; absent, the request body is byte-identical (test/eval-recorder.test.js). Never throws.
  recorder = null,
  // EVERY MODEL CALL HAS A DEADLINE (VH-777 Lane T). A request that never answered held the turn open until the
  // browser gave up, with nothing said; past this it is abandoned, which the route answers as a model failure.
  requestMs = MODEL_REQUEST_MS,
} = {}) {
  const doFetch = fetchImpl || (typeof fetch === 'function' ? fetch : null);
  const configured = Boolean(apiKey) && typeof doFetch === 'function';
  const record = (pair) => {
    if (typeof recorder?.record !== 'function') return;
    try { recorder.record({ provider: 'openai', model, ...pair }); } catch { /* recording must never fail the request */ }
  };

  async function post(body) {
    return doFetch(base + '/chat/completions', {
      method: 'POST',
      signal: AbortSignal.timeout(requestMs),
      headers: { authorization: 'Bearer ' + apiKey, 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
  }

  // The streaming reply (`streamChat`) and the one-shot completion the intent compiler read (`streamOnce`) are
  // retired with the routes that called them (VH-318-F): Hugo's turns go through the Realtime session.

  // TOOL CALLING (V1.77 D6): one non-streaming turn that may answer with tool calls instead of text. Returns
  // the assistant MESSAGE as OpenAI shaped it (`content`, `tool_calls`), because the agent loop has to append
  // that exact message before the tool results for the next turn to be well formed, plus the mapped usage
  // and the finish reason. `messages` may carry `tool` role turns (the results of earlier calls); `system`
  // is prepended as before, so a client can no more inject a system message here than on the chat route.
  async function chatOnce({ system, messages, tools = [], toolChoice = 'auto', maxTokens: cap } = {}) {
    if (!configured) throw new Error('hugo model not configured');
    const wantsTools = Array.isArray(tools) && tools.length > 0;
    // THE ENDPOINT IS CHOSEN BY WHETHER THE TURN CARRIES TOOLS (owner defect 9, V1.90). Function calling
    // lives on the Responses API on OpenAI's current reasoning models, and attaching `tools` to
    // `/chat/completions` is an unsupported parameter, which answers 400 `invalid_request_error` with no
    // code - the owner's exact fault string, under the agent's own label. A tool-free turn stays on
    // `/chat/completions`, where it has always worked, so this changes the agent's path and nothing else.
    if (wantsTools) return responsesOnce({ system, messages, tools, toolChoice, cap });
    const body = { model, messages: withSystem(system, messages), max_completion_tokens: cap || maxTokens, stream: false };
    const res = await post(body);
    if (!res.ok) throw await providerError(res, 'hugo model provider error');
    const out = await res.json();
    const choice = out?.choices?.[0] || {};
    const message = choice.message && typeof choice.message === 'object' ? choice.message : { role: 'assistant', content: '' };
    const usage = mapUsage(out?.usage);
    try { onUsage(usage, model); } catch { /* usage accounting must never fail the request */ }
    const result = { message: { role: 'assistant', content: typeof message.content === 'string' ? message.content : '', tool_calls: Array.isArray(message.tool_calls) ? message.tool_calls : [] }, usage, finishReason: String(choice.finish_reason || '') };
    record({ request: { system, messages, tools, toolChoice, maxTokens: cap || maxTokens, stream: false }, providerRequest: body, response: result });
    return result;
  }

  // The tool-calling turn on the Responses endpoint. Same arguments in, same shape out, so `src/hugo/agent.js`
  // is untouched: the four pure translators above are the whole of the difference.
  async function responsesOnce({ system, messages, tools, toolChoice, cap }) {
    const body = {
      model,
      instructions: toInstructions(system),
      input: toResponsesInput(messages),
      tools: toResponsesTools(tools),
      tool_choice: toolChoice || 'auto',
      max_output_tokens: cap || maxTokens,
    };
    const res = await doFetch(base + '/responses', {
      method: 'POST',
      signal: AbortSignal.timeout(requestMs),
      headers: { authorization: 'Bearer ' + apiKey, 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) throw await providerError(res, 'hugo model provider error');
    const out = await res.json();
    // The Responses API reports usage as input/output tokens directly, which is already the ledger's shape,
    // so this does NOT go through `mapUsage` (that maps the Chat Completions prompt/completion names).
    const usage = { input_tokens: Number(out?.usage?.input_tokens) || 0, output_tokens: Number(out?.usage?.output_tokens) || 0 };
    try { onUsage(usage, model); } catch { /* usage accounting must never fail the request */ }
    const { message, finishReason } = fromResponsesMessage(out);
    const result = { message, usage, finishReason };
    record({ request: { system, messages, tools, toolChoice, maxTokens: cap || maxTokens, stream: false }, providerRequest: body, response: result });
    return result;
  }

  // THE PROVIDER'S HOSTED WEB SEARCH (owner decision, V1.79: OpenAI's hosted search). Posted to the
  // Responses API, which is where the hosted tools live; chat/completions has no equivalent. The search runs
  // AT THE PROVIDER, so this adds no outbound path from the container and no second model vendor, which is
  // exactly why it was chosen over a sub-call to the hunt's Anthropic web_search.
  //
  // Returns `{ text, citations: [{url, title}], usage }`. The citations come from the response's url
  // annotations rather than from the prose, so a link the model wrote into a sentence but that the search
  // never returned is not a source: the caller refuses a result with no citation, and the agent's ledger
  // holds the answer to the URLs that actually came back.
  async function searchWeb({ query, maxTokens: cap } = {}) {
    if (!configured) throw new Error('hugo model not configured');
    const body = {
      model,
      input: String(query || '').slice(0, 400),
      instructions: 'Answer the question from current web sources. Be brief and factual, name the '
        + 'organisations and figures you found, and do not speculate beyond what the sources say.',
      tools: [{ type: 'web_search' }],
      tool_choice: 'auto',
      max_output_tokens: cap || maxTokens,
    };
    const res = await doFetch(base + '/responses', {
      method: 'POST',
      signal: AbortSignal.timeout(requestMs),
      headers: { authorization: 'Bearer ' + apiKey, 'content-type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!res.ok) throw await providerError(res, 'hugo search provider error');
    const out = await res.json();
    const usage = { input_tokens: Number(out?.usage?.input_tokens) || 0, output_tokens: Number(out?.usage?.output_tokens) || 0 };
    try { onUsage(usage, model); } catch { /* usage accounting must never fail the request */ }
    const result = { text: responseText(out), citations: responseCitations(out), usage };
    record({ request: { search: body.input }, providerRequest: body, response: result });
    return result;
  }

  return { configured, model, chatOnce, searchWeb };
}

// The assistant text of a Responses API reply. `output_text` is the convenience field; the walk over
// `output` is the contract, and is what a response carrying tool calls before the message actually has.
function responseText(out) {
  if (typeof out?.output_text === 'string' && out.output_text) return out.output_text;
  return responseParts(out).filter((c) => typeof c?.text === 'string').map((c) => c.text).join('\n').trim();
}

// Every content part of a Responses API reply, flattened. Both readers below walk the same shape, and one
// tolerant flattener is easier to keep right than two nested triple loops.
function responseParts(out) {
  return (Array.isArray(out?.output) ? out.output : [])
    .flatMap((item) => (Array.isArray(item?.content) ? item.content : []));
}

// The url citations of a Responses API reply, from the annotations rather than the prose: a link the model
// wrote into a sentence that the search never returned is not a source.
function responseCitations(out) {
  const seen = new Set();
  const cites = [];
  for (const a of responseParts(out).flatMap((c) => (Array.isArray(c?.annotations) ? c.annotations : []))) {
    const url = typeof a?.url === 'string' ? a.url : '';
    if (!url || seen.has(url)) continue;
    seen.add(url);
    cites.push({ url, title: typeof a?.title === 'string' ? a.title : '' });
  }
  return cites;
}
