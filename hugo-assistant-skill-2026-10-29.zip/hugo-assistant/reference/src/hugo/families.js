// The capability-family keys and a query-term resolver for Hugo. The canonical taxonomy (the icons, hues and
// the product_type -> family rules) lives in public/views/fingerprint-glyph.js, which the server imports. Since VH-775
// the families are DATA an admin shapes, so the keys are read live from that registry, in its order, rather than held
// here as a parallel copy: a family an admin adds is a family Hugo, the search boxes and the board filter all read.
//
// The resolver here answers a different question from the glyph's familyKey(): the glyph maps a provider's
// product_type LABEL to a family; this maps an operator's QUERY TERM ("EO", "electro-optical", "radar") to a
// family KEY, so "show me the SAR vendors" resolves deterministically with no model call.

import { familiesIn, familyKey } from '../../public/views/fingerprint-glyph.js';
import { domainIds } from '../domain/descriptor.js';

// THE DOMAIN EACH READ HERE IS FOR (owner, 2026-10-20, by popup: "Families per domain"): every domain holds its own
// families, so each reader takes one. A domain id reads that domain; none reads the request's own (the scope
// src/domain/family-scope.js sets); any other word, a question asked across domains ('all', or the ticked domains' ''),
// reads every domain. A word that is not a domain is never passed on to the registry, which would make it a domain of
// its own holding the shipped nine.
const own = (domain) => (domainIds().includes(domain) ? domain : undefined);
const domainsOf = (domain) => (domain === undefined || own(domain) ? [own(domain)] : domainIds());

/**
 * The family keys in force, in the registry's order, Other last: read live (VH-775), on `domain` as above. Across
 * domains, each domain's in turn, first seen first, so a key one domain added is a key the question may name.
 */
export function hugoFamilyKeys(domain) {
  const keys = new Set();
  for (const id of domainsOf(domain)) for (const k of Object.keys(familiesIn(id))) if (k !== 'OTHER') keys.add(k);
  return [...keys, 'OTHER'];
}

// THE SHIPPED FAMILIES' OWN WORDS, by key. Ordered longest/most-specific first so "synthetic aperture radar" is not
// shadowed by a bare "radar" rule, and so a specific phrase wins over a two-letter acronym. Grounded in the glyph's
// own FAMILY names and FAMILY_RULES vocabulary, not invented. Keyed by the family's KEY, which never changes, so a
// family an admin renames still answers to these words; a family an admin removed answers to none of them.
const SHIPPED_TERMS = Object.freeze([
  [/hyperspectral|(^|\W)hsi(\W|$)/i, 'HSI'],
  [/synthetic aperture radar|synthetic aperture|(^|\W)sar(\W|$)|passive radar|(^|\W)radar/i, 'SAR'],
  [/infrared|thermal|(^|\W)ir(\W|$)/i, 'IR'],
  [/weather|(^|\W)wx(\W|$)|meteorolog/i, 'WX'],
  [/electro[- ]?optical|(^|\W)eo(\W|$)|optical imagery/i, 'EO'],
  [/radio frequency|\brf\b|signals intelligence|\bsigint\b|\belint\b|geo-?location|gnss|tdoa|fdoa/i, 'RF'],
  // "space situational awareness" and SSA, the older name for the same work (VH-499, the VH-372 deep dive's O10).
  [/space domain awareness|space situational awareness|(^|\W)sda(\W|$)|(^|\W)ssa(\W|$)|orbital|conjunction|manoeuvre|maneuver|space object/i, 'SDA'],
  [/analytics|analytic|fusion|data fusion/i, 'AN'],
]);

const escapeRe = (text) => text.replaceAll(/[.*+?^${}()|[\]\\]/g, String.raw`\$&`);
const SHIPPED_NAMES = Object.freeze({ EO: 'Electro-optical', SAR: 'SAR / radar', RF: 'RF / signals', IR: 'Infrared / thermal',
  HSI: 'Hyperspectral', SDA: 'Orbital / SDA', WX: 'Weather', AN: 'Analytics / fusion' });

// THE WORDS IN FORCE ON ONE DOMAIN, rebuilt when that domain's registry changes. A family's own NAME answers to it, whole
// and case-blind, for a family an admin added or renamed; an ADDED family's LABEL answers to it as a whole word. The
// registry's own words lead, longest first, so a name that holds a shipped word ("Passive radar networks") is not taken by
// that word's rule. `text` is the scan over free text, where a label must be written in capitals: a two- or three-letter
// label read case-blind would take ordinary words ("an", "it") out of a sentence. `terms` is for a whole term or query,
// where it may be written in any case. Each answers only a family in force. Held by the domain's own registry object,
// which the glyph module keeps for the life of the process, so 7 domains are 7 entries, each kept in its 3 parts so a
// question across domains can put every domain's own words first, as one domain's are.
const RULES = new WeakMap();
function wordsOf(domain) {
  const fam = familiesIn(domain);
  const sig = Object.values(fam).map((f) => f.key + '\u0001' + f.name + '\u0001' + f.label).join('\u0002');
  const held = RULES.get(fam);
  if (held?.sig === sig) return held.words;
  const named = [];
  const labels = { terms: [], text: [] };
  for (const key of Object.keys(fam)) {
    if (key === 'OTHER') continue;
    const f = fam[key];
    if (!f.shipped || SHIPPED_NAMES[key] !== f.name) named.push([new RegExp(String.raw`(^|\W)` + escapeRe(f.name) + String.raw`(\W|$)`, 'i'), key, f.name.length]);
    if (!f.shipped) {
      const word = '(^|[^A-Za-z0-9])' + escapeRe(f.label) + '([^A-Za-z0-9]|$)';
      labels.terms.push([new RegExp(word, 'i'), key]);
      labels.text.push([new RegExp(word), key]);
    }
  }
  const words = { named, labels, shipped: SHIPPED_TERMS.filter(([, key]) => fam[key]) };
  RULES.set(fam, { sig, words });
  return words;
}

// The rules of every domain a read is for (`kind` 'terms' or 'text'): the names first, longest first across them all,
// then the added labels, then the shipped words, so across domains no domain's own name is taken by another's shipped word.
function inForce(domain, kind) {
  const all = domainsOf(domain).map((id) => wordsOf(id));
  const named = all.flatMap((w) => w.named).toSorted((a, b) => b[2] - a[2]).map(([re, key]) => [re, key]);
  return [...named, ...all.flatMap((w) => w.labels[kind]), ...all.flatMap((w) => w.shipped)];
}

/**
 * Resolve a single query term to a family key, or null when it names no family, on `domain` as above. Whole-string
 * match against the ordered rules; the caller scans an operator's phrase for these terms (see deterministic.js).
 */
export function familyKeyFromTerm(term, domain) {
  const s = typeof term === 'string' ? term : '';
  if (!s) return null;
  for (const [re, key] of inForce(domain, 'terms')) {
    if (re.test(s)) return key;
  }
  return null;
}

// The words a person puts around a capability without changing it: "SAR imagery", "hyperspectral data".
const CAPABILITY_FILLER = new Set(['imagery', 'image', 'images', 'data', 'product', 'products', 'sensing', 'sensor', 'sensors',
  'capability', 'capabilities', 'vendor', 'vendors', 'provider', 'providers', 'companies', 'supplier', 'suppliers', 'service', 'services']);

/**
 * THE FAMILY A WHOLE SEARCH QUERY NAMES, for the search boxes (VH-499). Hugo has read "SAR" and "hyperspectral" as
 * capability families since V1.45 and the boxes never did: the VH-372 deep dive measured capability queries at R@5
 * 0.52 on the board against 0.73 through Hugo, and "SAR imagery" and "space situational awareness" returning nothing.
 * Only a query that IS a capability, once filler words are set aside, answers a family: "Bravo Radar" is a company
 * name with a capability word in it and answers none, so a name search is never widened. Returns [] or one key, read
 * on `domain` as above: a store's search box asks with its own domain.
 */
export function capabilityQueryFamilies(query, domain) {
  const q = (typeof query === 'string' ? query : '').toLowerCase().split(/\s+/).filter((w) => w && !CAPABILITY_FILLER.has(w)).join(' ');
  if (q === '' || q.split(' ').length > 4) return [];
  const rule = inForce(domain, 'terms').find(([re]) => re.test(q));
  if (!rule) return [];
  return q.replace(rule[0], ' ').replaceAll(/[\W_]+/g, '') === '' ? [rule[1]] : [];
}

/**
 * Scan a free-text phrase for every family term it names, returning the matched keys in canonical order with
 * no duplicates, on `domain` as above. Used by the deterministic resolver so "EO and SAR vendors" resolves to
 * ['EO','SAR'] with no model call. A phrase naming no family returns [].
 */
export function familiesInText(text, domain) {
  const s = typeof text === 'string' ? text : '';
  const found = new Set();
  for (const [re, key] of inForce(domain, 'text')) {
    if (re.test(s)) found.add(key);
  }
  return hugoFamilyKeys(domain).filter((k) => found.has(k));
}

// THE PRODUCT_TYPE -> FAMILY MAPPING IS THE CARDS' OWN (VH-623). Until V2.8 this file held a parallel copy of the
// glyph's FAMILY_RULES with a Space-only parity test, and the copy lacked the glyph's exact-name table: measured, it
// filed 97 of the 247 product types on the other 6 domains under a different family from the cards, so Hugo, search
// and Explore disagreed with what the board drew. Hugo's `families` clause EXPANDS a family to product types at plan
// time, so the expansion must badge exactly the rows the cards badge; calling the cards' function is the only way
// that cannot drift, and it files a value added at runtime the same way on every surface. The glyph module is pure
// (it imports only the escaper), and the server already reads other `public/views` modules the same way.
/** A vocabulary as an array, whether it arrives as the live Set or the schema's array; anything else is empty. */
export function listOf(vocab) {
  if (vocab instanceof Set) return [...vocab];
  return Array.isArray(vocab) ? vocab : [];
}

/**
 * The family a product-type LABEL belongs to on one domain, `OTHER` when none: the cards' own answer. A label belongs
 * to one domain's vocabulary, so a word that is not a domain reads the request's own rather than every domain.
 */
export function familyKeyOfProductType(type, domain) {
  return familyKey(type, own(domain));
}

/**
 * The product types a set of family keys covers, from one domain's vocabulary, in vocabulary order, de-duplicated,
 * each placed as that domain places it. Case-insensitive on the keys, because the deterministic layer emits keys and
 * a model may not honour case.
 */
export function productTypesForFamilies(keys, vocab, domain) {
  const want = new Set((Array.isArray(keys) ? keys : []).map((k) => String(k || '').trim().toUpperCase()).filter(Boolean));
  if (want.size === 0) return [];
  return listOf(vocab).filter((t) => want.has(familyKeyOfProductType(t, domain)));
}
