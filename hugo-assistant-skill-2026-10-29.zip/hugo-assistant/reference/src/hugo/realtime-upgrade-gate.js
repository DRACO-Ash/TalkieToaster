// THE GATE ON A REALTIME VOICE UPGRADE (VH-523), lifted out of `src/index.js` so it can be tested. The VH-372 deep
// dive counted it among the 4 of 20 security controls no test held: it ran inline in the upgrade listener, which
// is wired only when an OpenAI key and a store are both present, so nothing a test boots ever reached it.
//
// The order is the order the listener always used, and it is deliberate: the cheap refusals first, then the
// caller's credential, then the daily spend cap, all BEFORE any socket to OpenAI is dialled.
//   1. another path: not ours, closed with no status line (`stray`);
//   2. a cross-site page: 403, judged as the mutating request a paid session is (src/csrf.js);
//   3. no valid domain named on the URL: 400 (VH-280);
//   4. the paid always-on listener while its price is unread: 503, fail closed (VH-318-F);
//   5. no principal (no bearer and no platform identity on the upgrade), or one without the agent role: 403;
//   6. the daily spend cap reached: 429.
// A credential check that throws is the caller's 500, as it was inline.

import { crossSiteRefusal } from '../csrf.js';
import { realtimeUpgradeToken, realtimeDomainFromUrl, realtimeModeFromUrl, realtimeVoiceFromUrl } from './openai-realtime.js';

export const REALTIME_PATH = '/api/v3/hugo/realtime';

/**
 * @returns {Promise<{ stray: true } | { refuse: string } | { principal: object, domain: string, listen: boolean }>}
 */
export async function realtimeUpgradeGate(req, { allowedOrigin, verify, paidCallAllowed, listeningPriced }) {
  let reqPath = '';
  try { reqPath = new URL(req.url, 'http://localhost').pathname; } catch { reqPath = ''; }
  if (reqPath !== REALTIME_PATH) return { stray: true };
  if (crossSiteRefusal(req, 'POST', allowedOrigin)) return { refuse: '403 Forbidden' };
  const domain = realtimeDomainFromUrl(req.url);
  if (!domain) return { refuse: '400 Bad Request' };
  const mode = realtimeModeFromUrl(req.url);
  const listen = mode === 'listen';
  if (listen && !listeningPriced()) return { refuse: '503 Service Unavailable' };
  // The browser carries its bearer in the subprotocol (a WebSocket has no Authorization header), so a shimmed
  // request is verified, exactly as an HTTP call's would be. The upgrade request itself rides along (VH-707): the
  // platform identity is read from ITS headers. Where those name no one and the sign-in is Entra, the person is the
  // verified token's own (VH-779), which here is the token the subprotocol carried, signature checked as any other.
  // NO BEARER IS NOT NO ONE (VH-873): an operator signed in through the platform's own identity holds no app token, so
  // the upgrade request's own headers decide, through the same verifier an HTTP call meets. A static-token deployment
  // still answers null for no bearer, and is refused below as before.
  const token = realtimeUpgradeToken(req);
  const principal = await verify({ headers: token ? { authorization: 'Bearer ' + token } : {} }, req);
  if (!principal?.roles?.includes('agent')) return { refuse: '403 Forbidden' };
  if (!(await paidCallAllowed())) return { refuse: '429 Too Many Requests' };
  return { principal, domain, listen, check: mode === 'check' };
}

// THE UPGRADE LISTENER ITSELF (VH-665), lifted out of `src/index.js` for the reason the gate was: the entrypoint is
// the process, no test imports it, and the listener is wired only when an OpenAI key and a store are both present,
// so none of its lines ran under test. Moved as it stood: the gate above, a stray path closed with no status line,
// a refusal answered with its status line and closed, and a 500 for anything that throws. An accepted socket goes
// to the relay as a transcription session (`listen`) or a Talk session holding the tool layer for the domain on
// screen; each is audited, and each logs one line when it ends. `src/index.js` builds `deps` once and registers this
// as the server's sole `upgrade` listener.
export async function handleRealtimeUpgrade(req, socket, head, { gateDeps, wss, bridge, spendGuards, vendorRepo, runnerFor, toolDefs, turnAllowed }) {
  const reject = (code) => { try { socket.write('HTTP/1.1 ' + code + '\r\n\r\n'); } catch { /* gone */ } socket.destroy(); };
  try {
    // THE GATE (VH-523, above, where each refusal and its order is explained): path, cross-site origin, domain,
    // the unpriced listener, the agent role, then the daily spend cap, all before any socket is dialled. This is
    // the sole upgrade listener, so a stray path is closed here.
    const gate = await realtimeUpgradeGate(req, gateDeps);
    if (gate.stray) { socket.destroy(); return; }
    if (gate.refuse) { reject(gate.refuse); return; }
    const { principal, domain, listen } = gate;
    // THE CONNECTION CHECK'S SOCKET (VH-777): through every refusal above, then one frame and closed, with no upstream
    // dialled, no session and nothing spent. It answers what no server-side check can: whether the route between the
    // browser and this server lets a WebSocket upgrade through.
    if (gate.check) {
      wss.handleUpgrade(req, socket, head, (clientWs) => {
        try { clientWs.send(JSON.stringify({ type: 'vh.check', ok: true })); } finally { clientWs.close(1000); }
      });
      return;
    }
    wss.handleUpgrade(req, socket, head, (clientWs) => {
      const onClose = (reason, detail) => {
        console.log(JSON.stringify({ event: 'realtime-closed', reason, ...(listen ? { mode: 'listen' } : {}), ...detail }));
        spendGuards.flushSpendToLedger().catch(() => {});
      };
      if (listen) {
        // A transcription session: the microphone in, transcripts out, nothing else (no tools, no replies).
        bridge.connect(clientWs, { mode: 'listen', onClose, turnAllowed });
        vendorRepo.auditHugoChat(principal.subject, { domain: 'voice', turns: 0, via: 'listen' }).catch(() => { /* audit must never break the session */ });
        return;
      }
      const runner = runnerFor(domain);
      bridge.connect(clientWs, {
        tools: toolDefs(),
        onToolCall: (name, args) => runner.run(name, args),
        onUserTurn: () => runner.newTurn(),
        turnAllowed,
        // Every finished answer is checked against the session's tool results (VH-318-E).
        checkAnswer: (text) => runner.check(text),
        // The operator's voice pick, validated against the Realtime voices (VH-318-C); marin otherwise.
        voice: realtimeVoiceFromUrl(req.url),
        // One line per ended session, with the bridge's codes-only evidence (VH-318-B), so a Talk that fails
        // or drops out on the deployed app says why in the log rather than leaving it to be guessed.
        onClose,
      });
      vendorRepo.auditHugoChat(principal.subject, { domain: 'voice', turns: 0 })
        .catch(() => { /* audit must never break the session */ });
    });
  } catch { reject('500 Internal Server Error'); }
}
