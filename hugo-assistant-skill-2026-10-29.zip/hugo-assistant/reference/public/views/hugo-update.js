// Hugo permissioned single-record update (WS2), the client half. Hugo is the dataset expert: when a
// conversation or a search turns up something that verifiably updates a record, the operator logs the
// change here with its SOURCE, sees the exact field diff the server computes against the live record,
// and only then grants permission to apply it. This module is pure and unit-tested: it builds the
// preview request, renders the diff-confirm card, and derives the patch the ordinary audited update
// endpoint then writes. Nothing here writes; nothing here fabricates. Every reflected value is escaped.

import { esc } from '../lib-v3.js';

// Build the /hugo/suggest-update request body from the composer fields. Space carries a flat patch
// ({ field: value }); a product-line domain carries its facets under { fields }. A multi-value field
// (comma-separated) becomes an array so an array facet (missions, sections) is set, not a string.
// Returns null when the field, value or source is missing, so the caller can refuse before any call.
export function suggestBody({ domain = '', id = '', field = '', value = '', source = '' } = {}) {
  const f = String(field || '').trim();
  const v = String(value || '').trim();
  const src = String(source || '').trim();
  const rec = String(id || '').trim();
  // NO DOMAIN IS NOT SPACE (VH-280): a suggestion that names no store is refused, never sent to Space.
  if (!f || !v || !src || !rec || !domain) return null;
  const parsed = v.includes(',') ? v.split(',').map((s) => s.trim()).filter(Boolean) : v;
  const isSpace = domain === 'space';
  const patch = isSpace ? { [f]: parsed } : { fields: { [f]: parsed } };
  return { domain: isSpace ? 'space' : domain, id: rec, patch, source: src };
}

// The patch the APPLY sends to the ordinary update endpoint, taken from the preview the server
// returned, so the write is exactly what the operator confirmed. Space applies the changed scalars/
// arrays flat; a domain applies them under { fields }. Returns null when there is nothing to apply.
export function patchFromPreview(preview) {
  const after = preview?.changes?.after ?? null;
  if (!after || Object.keys(after).length === 0) return null;
  const isSpace = preview.domain === 'space';
  return isSpace ? { ...after } : { fields: { ...after } };
}

// A single before -> after line for the diff card. Arrays read as a comma list; an absent side reads
// as an em-free "(empty)" so a fill is legible. Escaped.
export function changeLine(name, before, after) {
  const show = (val) => {
    if (Array.isArray(val)) return val.length ? esc(val.join(', ')) : '(empty)';
    const s = String(val ?? '').trim();
    return s ? esc(s) : '(empty)';
  };
  return '<li class="hugo-update-change"><span class="hu-field">' + esc(name.replaceAll('_', ' ')) + '</span>'
    + '<span class="hu-from"><span class="sr-only">from </span>' + show(before) + '</span>'
    + '<span class="hu-arrow" aria-hidden="true">&#8594;</span>'
    + '<span class="hu-to"><span class="sr-only">to </span>' + show(after) + '</span></li>';
}

// Render the diff-confirm card from a preview payload. When the patch would change nothing, it says so
// (so the operator is never asked to confirm a no-op); otherwise it lists each moved field, cites the
// source, and offers Apply / Cancel. The apply is a permissioned write, so the button says as much.
export function previewCardHtml(preview) {
  if (!preview || preview.hasChanges === false) {
    return '<div class="hugo-update-card"><p class="dim">That would not change anything on this record.</p>'
      + '<div class="hugo-update-actions"><button type="button" class="btn" data-act="hugo-update-cancel">Close</button></div></div>';
  }
  const before = preview.changes?.before ?? {};
  const after = preview.changes?.after ?? {};
  const names = Object.keys(after);
  const rows = names.map((n) => changeLine(n, before[n], after[n])).join('');
  return '<div class="hugo-update-card">'
    + '<p class="hugo-update-lede">With your permission I would update this record:</p>'
    + '<ul class="hugo-update-changes">' + rows + '</ul>'
    + '<p class="hugo-update-source">Source: <span>' + esc(String(preview.source || '')) + '</span></p>'
    + '<div class="hugo-update-actions">'
    + '<button type="button" class="btn btn-accent" data-act="hugo-update-apply">Apply the update</button>'
    + '<button type="button" class="btn" data-act="hugo-update-cancel">Cancel</button>'
    + '</div></div>';
}

// The composer that opens in the drawer: one field name, its new value, and a required source. Kept
// deliberately small; the field name is free text validated server-side against the record's schema,
// so an unknown field is refused rather than silently stored.
export function composerHtml() {
  return '<div class="hugo-update-composer">'
    + '<p class="hugo-update-lede">Log a sourced update. I will show you exactly what would change before anything is written.</p>'
    + '<label class="hu-row"><span>Field</span><input type="text" id="hugo-update-field" autocomplete="off" placeholder="e.g. coverage, missions"></label>'
    + '<label class="hu-row"><span>New value</span><input type="text" id="hugo-update-value" autocomplete="off" placeholder="the value, or a comma-separated list"></label>'
    + '<label class="hu-row"><span>Source</span><input type="text" id="hugo-update-source" autocomplete="off" placeholder="where this came from (a link or citation)"></label>'
    + '<div class="hugo-update-actions">'
    + '<button type="button" class="btn btn-accent" data-act="hugo-update-preview">Preview the change</button>'
    + '<button type="button" class="btn" data-act="hugo-update-cancel">Cancel</button>'
    + '</div><div id="hugo-update-result"></div></div>';
}
