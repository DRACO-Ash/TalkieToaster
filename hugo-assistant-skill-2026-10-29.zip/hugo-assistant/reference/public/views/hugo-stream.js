// TYPED HUGO OVER THE REALTIME SESSION (VH-318-C). Pure helpers, no DOM, so the client's half of the stream is
// unit-tested in node (the monolith that calls them cannot be).
//
// A typed turn is one user text item on the same Realtime session Talk uses, sent over the same-origin relay
// (owner decision 2026-10-06: keep the relay). The server rebuilds the item and asks for a TEXT response, so the
// rail streams `response.output_text.delta` as it is produced instead of waiting up to 75 seconds for the
// request-and-response agent loop. A turn may take several responses (a tool call, then the answer), so it ends
// on the first `response.done` that carries no function call.
//
// LOADED ON FIRST USE, not with the board: `public/app-v3.js` imports this module when Hugo first takes a typed
// turn or opens Talk, so none of it is in the first-load payload (`test/source-guards.test.js`, the eager budget).

import { esc, motion } from '../lib-v3.js';

/**
 * The voices Talk may use, marin first as the default: the server's `REALTIME_VOICES`
 * (`src/hugo/openai-realtime.js`), mirrored here and held equal to it, and to the picker, by
 * `test/hugo-stream.test.js`. The server validates the pick again; this list only builds the URL.
 */
export const REALTIME_VOICES_CLIENT = Object.freeze(['marin', 'cedar', 'alloy', 'ash', 'ballad', 'coral', 'echo', 'sage', 'shimmer', 'verse']);

/** The longest typed turn the relay takes; the server bounds it again (`TEXT_TURN_MAX_CHARS`). */
export const TEXT_TURN_MAX = 4000;
/** How long a typed turn may wait for its answer before it is given up, the agent loop's own wall clock. */
export const TEXT_TURN_WAIT_MS = 75_000;

/** The client event for one typed turn. */
export function textTurnEvent(text) {
  const said = typeof text === 'string' ? text : '';
  return {
    type: 'conversation.item.create',
    item: { type: 'message', role: 'user', content: [{ type: 'input_text', text: said.slice(0, TEXT_TURN_MAX) }] },
  };
}

/**
 * What the typed-turn stream does with one relayed server event, or null to ignore it.
 *  ● `{ delta, responseId }` a piece of the answer to append, as produced.
 *  ● `{ done: { responseId, toolCall, status } }` a response finished; the turn ends when `toolCall` is false.
 *  ● `{ error: code }` the provider refused the turn.
 */
export function textStreamAction(event) {
  const type = event?.type;
  if (type === 'response.output_text.delta') {
    return typeof event.delta === 'string' && event.delta ? { delta: event.delta, responseId: String(event.response_id || '') } : null;
  }
  if (type === 'response.done') return doneOf(event);
  if (type === 'error') return { error: String(event.error?.code || event.error?.type || 'provider-error') };
  // The relay replaced an upstream that ended mid-reply (V2.8 W40): the answer will never come, so the turn ends now
  // rather than waiting out TEXT_TURN_WAIT_MS. Its words are its own (VH-650): the session is still open for the retry.
  if (type === TALK_RESUMED) return { error: 'cut' };
  if (type === 'vh.grounding' && event.modality === 'text') return { check: checkOf(event) };
  return null;
}
function doneOf(event) {
  const output = Array.isArray(event.response?.output) ? event.response.output : [];
  return { done: { responseId: String(event.response?.id || ''), toolCall: output.some((o) => o?.type === 'function_call'), status: String(event.response?.status || '') } };
}

// GROUNDING UNDER STREAMING (VH-318-E). The relay checks each finished answer against what the session's tools
// returned and sends a `vh.grounding` frame: `verified`, or `withdrawn` (a typed answer that failed) or `flagged`
// (a spoken one: it was heard, so it stays, marked, and Hugo corrects it aloud). The marks themselves are the one
// rail's (`views/hugo-rail.js` turnMarkHtml, VH-318-D): this module only sets a turn's state, `checking` while it
// streams and the verdict after, the rail's `withdrawn` on a spoken turn reading as flagged.
const CHECK_STATES = new Set(['verified', 'withdrawn', 'flagged']);
function checkOf(frame) {
  const state = CHECK_STATES.has(frame?.state) ? frame.state : 'withdrawn'; // an unreadable verdict is not a pass
  const violations = Array.isArray(frame?.violations) ? frame.violations.filter((v) => typeof v === 'string').slice(0, 5) : [];
  return { state, violations };
}

/** Why a check failed, escaped, under the rail's own mark. Never empty, so a withdrawn body is never blank. */
export function reasonsHtml(violations) {
  const list = Array.isArray(violations) ? violations : [];
  if (list.length === 0) return '<span class="hugo-verify-list">The check gave no reason.</span>';
  return '<ul class="hugo-verify-list">' + list.map((v) => '<li>' + esc(String(v)) + '</li>').join('') + '</ul>';
}

/**
 * What a finished typed turn hands the rail. A WITHDRAWN answer carries NO TEXT, only the reasons, so nothing
 * the check refused can be painted, kept in the conversation or read back. A verified one carries its text.
 */
export function answerOutcome(text, check) {
  const verdict = checkOf(check);
  if (verdict.state !== 'verified') return { withdrawn: true, state: 'withdrawn', reasonsHtml: reasonsHtml(verdict.violations) };
  return { text: String(text || ''), state: 'verified' };
}

/**
 * A verdict on Hugo's latest SPOKEN reply, set on that turn in the history: `verified`, or the rail's
 * `withdrawn`, which on a spoken turn reads as flagged and keeps the words. Returns true when a turn changed.
 */
export function applySpokenCheck(history, frame) {
  if (frame?.type !== 'vh.grounding' || frame.modality !== 'audio' || !Array.isArray(history)) return false;
  const turn = history.findLast((t) => t?.role === 'assistant' && t.channel === 'spoken');
  if (!turn) return false;
  const verdict = checkOf(frame);
  turn.state = verdict.state === 'verified' ? 'verified' : 'withdrawn';
  if (turn.state === 'withdrawn') turn.reasonsHtml = reasonsHtml(verdict.violations);
  return true;
}

/**
 * The spoken verdict on the rail: set by `applySpokenCheck`, then `repaint()`, after the strike has drawn through
 * the words when the check flagged them (VH-712). Returns whether the frame was a spoken verdict, at once.
 */
export function spokenCheck(history, frame, review, repaint) {
  if (!applySpokenCheck(history, frame)) return false;
  const flagged = history.findLast((t) => t?.role === 'assistant' && t.channel === 'spoken').state === 'withdrawn';
  (flagged ? strikeLive(review, '.hugo-turn-hugo[data-channel="spoken"] .hugo-turn-text') : Promise.resolve()).then(repaint);
  return true;
}

/** The upgrade URL for the realtime session, naming the domain on screen and the voice picked. */
export function realtimeUrl(origin, domain, voice) {
  const pick = REALTIME_VOICES_CLIENT.includes(voice) ? voice : REALTIME_VOICES_CLIENT[0];
  return String(origin).replace(/^http/, 'ws') + '/api/v3/hugo/realtime?domain=' + encodeURIComponent(domain || '') + '&voice=' + encodeURIComponent(pick);
}

/**
 * The reason a typed turn over the live session got no answer, in words the operator can act on. The session
 * is refused at the upgrade for the same reasons the typed route answered 403 and 429 (the agent role, the
 * daily cap), and a WebSocket cannot read the refusal's status, so a failed open names those causes rather
 * than guessing between them. `insufficient_quota` and `rate_limit_exceeded` are the provider's own codes.
 */
export function textTurnErrorText(code) {
  const said = {
    connect: 'Hugo could not be reached. Your sign-in may not have the agent role, or today\'s spending limit may be reached.',
    closed: 'Hugo\'s connection ended before the answer arrived. Send the message again.',
    cut: 'Hugo\'s answer was cut off by the connection. Send the message again to hear the rest.',
    timeout: 'Hugo did not answer in time. Try again.',
    superseded: 'Hugo stopped that answer to take your new message.',
    'no-answer': 'Hugo finished without an answer. Try rephrasing the question.',
    insufficient_quota: 'Hugo has run out of credit with his AI service. An admin can top it up.',
    rate_limit_exceeded: 'Hugo\'s AI service is busy just now. Try again shortly.',
  };
  return Object.hasOwn(said, String(code)) ? said[String(code)] : 'Hugo could not answer that just now. Try again.';
}

const WS_OPEN = 1;
// One relayed frame as an object, or null when it is not JSON.
function parsed(raw) {
  if (typeof raw !== 'string') return raw && typeof raw === 'object' ? raw : null;
  try { return JSON.parse(raw); } catch { return null; }
}

/**
 * The typed-turn session: which socket a turn goes on, the turn in flight, and how it ends. Everything it touches
 * is injected, so every path (a refused open, a provider error, a closed session, a timeout, a superseded turn)
 * is driven in node with a fake socket.
 *  ● `makeSocket(url)` opens a session socket (the browser passes `new WebSocket(url, [subprotocol, token])`).
 *  ● `talkSocket()` is Talk's socket while Talk is on, so a typed turn then shares Talk's session.
 *  ● `domain()` and `voice()` are read at open: a session speaks for the domain it was opened in, so a domain
 *    change reopens it rather than answering from the last one.
 * `ask(text, onText)` resolves `{ text, markHtml }`, `{ withdrawn, markHtml }` or `{ error, said }`, never rejects; `onText(soFar)` streams the answer.
 * `onEvent(raw)` takes every relayed event, from either socket; `onFrame(event)` sees every event on the session's
 * own socket (Talk's socket already has its own handler).
 */
export function createTextSession({ makeSocket, talkSocket = () => null, domain = () => '', voice = () => '', origin = '', waitMs = TEXT_TURN_WAIT_MS, setTimer = setTimeout, clearTimer = clearTimeout, onFrame = () => {} } = {}) {
  let own = null;
  let turn = null;

  function end(outcome) {
    const t = turn;
    if (!t) return;
    turn = null;
    clearTimer(t.timer);
    t.resolve(outcome);
  }

  function close() {
    const ws = own;
    own = null;
    // A socket a newer turn replaces supersedes its own turn rather than failing it (2.15.0 engineering round one).
    if (ws) ws.vhSuperseded = true;
    try { if (ws?.readyState <= WS_OPEN) ws.close(); } catch { /* already gone */ }
  }

  function socket() {
    const talk = talkSocket();
    if (talk?.readyState === WS_OPEN) return Promise.resolve(talk);
    if (own?.readyState === WS_OPEN && own.vhDomain === domain()) return Promise.resolve(own);
    close();
    return new Promise((resolve, reject) => {
      const ws = makeSocket(realtimeUrl(origin, domain(), voice()));
      ws.vhDomain = domain();
      own = ws;
      ws.onopen = () => resolve(ws);
      // Every event on this session also goes to `onFrame`, so the relay's `hugo.proposal` frame (VH-318-H)
      // reaches the rail for a typed turn as it does on Talk's session.
      ws.onmessage = (ev) => {
        const event = parsed(ev.data);
        if (!event) return;
        onEvent(event);
        try { onFrame(event); } catch { /* the rail must never end the session */ }
      };
      const failed = () => new Error(ws.vhSuperseded ? 'superseded' : 'connect');
      ws.onerror = () => reject(failed());
      ws.onclose = () => {
        if (own === ws) own = null;
        // Closed before it opened, with or without an error first: a failed connect, never a turn left waiting (VH-777).
        reject(failed());
        end({ error: 'closed' });
      };
    });
  }

  function onEvent(raw) {
    const t = turn;
    if (!t) return;
    let event = raw;
    if (typeof raw === 'string') {
      try { event = JSON.parse(raw); } catch { return; }
    }
    const action = textStreamAction(event);
    if (!action) return;
    if (action.delta) {
      t.text += action.delta;
      try { t.onText(t.text); } catch { /* the rail repainting must never end the turn */ }
    } else if (action.error) {
      end({ error: action.error });
    } else if (action.check) {
      // The relay's verdict on the answer that just finished: the turn ends on it, not on response.done.
      end({ text: t.text, check: action.check });
    } else if (action.done && !action.done.toolCall && !t.text) {
      end({ error: 'no-answer' });
    }
  }

  // One turn, resolving `{ text, markHtml }`, `{ withdrawn, markHtml }` or `{ error, said }`, `said` being the
  // operator's words for the cause.
  async function ask(text, onText = () => {}) {
    const out = await turnOf(text, onText);
    return out.error ? { ...out, said: textTurnErrorText(out.error) } : answerOutcome(out.text, out.check);
  }

  async function turnOf(text, onText) {
    // A new message while an answer is still streaming ends that turn where it stands, so none waits for ever.
    end({ error: 'superseded' });
    let ws;
    try { ws = await socket(); } catch (err) { return { error: err?.message === 'superseded' ? 'superseded' : 'connect' }; }
    return new Promise((resolve) => {
      turn = { text: '', onText, resolve, timer: setTimer(() => end({ error: 'timeout' }), waitMs) };
      try { ws.send(JSON.stringify(textTurnEvent(text))); } catch { end({ error: 'closed' }); }
    });
  }

  return { ask, onEvent, close, end };
}

/**
 * One typed turn on the one rail (VH-318-C, VH-318-E). Hugo's answer joins `history` straight after the question,
 * `checking` from its first word as it streams, then verified or withdrawn; `repaint(history)` redraws the rail
 * and the streamed text is written in place into the checking turn under `review`. On a failure the question and
 * its answer leave the history by identity (a newer message may have arrived meanwhile) and the operator's words
 * for the cause are returned; '' means the turn stands. A socket that will not open is not the end of the turn
 * (VH-777): with `onNoSocket`, the question stays and that answers it instead, on the typed route's model.
 */
export async function typedTurn(session, history, { repaint, review, onNoSocket }) {
  const asked = history.at(-1);
  const answer = { role: 'assistant', content: '', state: 'checking' };
  history.splice(history.indexOf(asked) + 1, 0, answer);
  motion(); // loaded while the answer streams, so a withdrawal can strike
  repaint(history);
  const out = await session.ask(String(asked?.content || ''), (t) => {
    answer.content = t;
    const live = [...review.querySelectorAll('.hugo-turn.is-checking .hugo-turn-text')].at(-1);
    if (live) live.textContent = t;
    review.scrollTop = review.scrollHeight;
  });
  // Only the newest question is handed over: an older one whose socket failed after a newer message is a failed turn.
  const newest = history.findLast((t) => t.role === 'user') === asked;
  if (out.error === 'connect' && newest && typeof onNoSocket === 'function') {
    const i = history.indexOf(answer);
    if (i >= 0) history.splice(i, 1);
    repaint(history);
    return onNoSocket();
  }
  if (out.said) {
    for (const t of [asked, answer]) { const i = history.indexOf(t); if (i >= 0) history.splice(i, 1); }
    repaint(history);
    return out.said;
  }
  if (out.state === 'withdrawn') await strikeLive(review, '.hugo-turn.is-checking .hugo-turn-text');
  Object.assign(answer, { content: out.text || '', state: out.state, reasonsHtml: out.reasonsHtml });
  repaint(history);
  return '';
}

/**
 * THE TRUST MOMENT (VH-712): the last turn under `review` matching `selector` has its words struck through, left to
 * right, where they stand, and resolves when the line is drawn. The words are wrapped as text, never as markup. Under
 * reduced motion, or before the motion helper has loaded, the strike lands at once and nothing waits. The caller then
 * repaints the verdict: a typed answer loses its words for its reasons, a spoken one keeps them, struck.
 */
export async function strikeLive(review, selector) {
  const text = [...(review?.querySelectorAll(selector) || [])].at(-1);
  if (!text) return;
  const line = text.ownerDocument.createElement('span');
  line.className = 'hugo-strike';
  line.textContent = text.textContent;
  text.replaceChildren(line);
  const drawn = motion().play(line, [{ backgroundSize: '0% 2px' }, { backgroundSize: '100% 2px' }], { easing: '--ease-out' });
  if (drawn) await drawn.finished.catch(() => {});
}

// TALK'S CONTINUATION (owner ruling, 2026-10-07).
// "default to 2hrs with a popup that allows a continuation of 2hrs at a time, with no upper limit to extensions".
// Before Talk's session ends the relay sends `vh.session.expiring` (`src/hugo/openai-realtime.js`); the dialog
// `public/index.html` ships (`#hugo-talk-dialog`) offers one more session length, and Continue sends the relay's own
// `vh.session.extend`, which the relay keeps and never forwards. ESCAPE DISMISSES, the same as not answering: the
// session then ends at the time the dialog named and never sooner, so a stray key can neither cut a conversation
// short nor spend more. FOCUS LANDS ON THE TITLE, not Continue (VH-651, the owner's option A), so a stray Space or
// Enter extends nothing; Tab then reaches End now, then Continue. End now is a separate, deliberate press. Only
// Talk's socket is watched: a typed session opened on its own reopens with the next message, so it is left to end
// on time unasked.

export const TALK_EXPIRING = 'vh.session.expiring';
export const TALK_EXTENDED = 'vh.session.extended';
export const TALK_EXTEND = 'vh.session.extend';
export const TALK_RESUMED = 'vh.session.resumed';

/** A session length in the operator's words: "2 hours", "1 hour", "90 minutes", "1 minute". */
export function sessionLengthWords(minutes) {
  const m = Math.max(1, Math.round(Number(minutes) || 0));
  if (m % 60 === 0) return m === 60 ? '1 hour' : m / 60 + ' hours';
  return m === 1 ? '1 minute' : m + ' minutes';
}

/** A moment as the 24-hour clock reads it here, "15:55", or '' when it is not a moment. */
export function clockTime(ms) {
  return Number.isFinite(ms) ? new Date(ms).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '';
}

/** What the dialog says for one offer, from the relay's frame: `{ title, lede }`. */
export function talkOfferCopy(frame) {
  const minutes = Number(frame?.extend_minutes) || 0;
  const length = sessionLengthWords(minutes);
  const endsAt = Date.parse(String(frame?.ends_at || ''));
  const title = 'Continue Talk for another ' + length + '?';
  if (!Number.isFinite(endsAt)) {
    return { title, lede: 'Talk is about to end. Continue keeps it going for another ' + length + '. Today\'s usage cap still applies.' };
  }
  const end = clockTime(endsAt);
  return {
    title,
    lede: 'Talk ends at ' + end + '. Continue keeps it going until ' + clockTime(endsAt + Math.max(1, Math.round(minutes)) * 60_000)
      + '. If you do not answer, Talk ends at ' + end + '. Today\'s usage cap still applies.',
  };
}

/**
 * Watch Talk's socket for the relay's offer and answer it through the dialog. `openPanel` and `closePanel` are the
 * shell's own, so the dialog takes the shared scrim, focus trap, Escape and focus return like every other panel;
 * `end` ends Talk as its Stop button does. Returns `{ stop }`, which unhooks everything; a closed socket stops it too.
 */
export function watchTalkSession(ws, { openPanel, closePanel, end, doc = globalThis.document } = {}) {
  const part = (id) => doc?.getElementById(id) || null;
  const dialog = part('hugo-talk-dialog');
  let open = false;
  const hide = () => {
    const was = open;
    open = false;
    if (was && dialog && !dialog.hidden) closePanel(dialog);
  };
  const say = (text) => {
    const live = part('sr-status');
    if (!live) return;
    live.textContent = '';
    globalThis.requestAnimationFrame?.(() => { live.textContent = text; });
  };
  const onFrame = (ev) => {
    const frame = parsed(ev?.data);
    if (frame?.type === TALK_EXPIRING && dialog) {
      const copy = talkOfferCopy(frame);
      part('hugo-talk-title').textContent = copy.title;
      part('hugo-talk-lede').textContent = copy.lede;
      open = true;
      openPanel(dialog, '#hugo-talk-title');
    } else if (frame?.type === TALK_EXTENDED) {
      const until = clockTime(Date.parse(String(frame.ends_at || '')));
      const text = until ? 'Talk continues until ' + until + '.' : 'Talk continues.';
      say(text);
      // Seen as well as heard (VH-652, the owner's option B): the line under Hugo's name, the one the shell's
      // setHugoStatus writes while Talk runs, says it too, until Stop puts Hugo's role back.
      const sub = doc?.querySelector?.('#hugo-rail .hugo-rail-sub');
      if (sub) sub.textContent = 'Listening. ' + text;
    }
  };
  // Continue answers the one offer once, however often it is pressed; the relay holds the same rule.
  const onContinue = () => {
    if (!open) return;
    hide();
    try { ws.send(JSON.stringify({ type: TALK_EXTEND })); } catch { /* a closed socket ends Talk on its own */ }
  };
  const onEnd = () => {
    hide();
    end();
  };
  const stop = () => {
    hide();
    ws.removeEventListener?.('message', onFrame);
    ws.removeEventListener?.('close', stop);
    part('hugo-talk-continue')?.removeEventListener('click', onContinue);
    part('hugo-talk-end')?.removeEventListener('click', onEnd);
  };
  ws.addEventListener('message', onFrame);
  ws.addEventListener('close', stop);
  part('hugo-talk-continue')?.addEventListener('click', onContinue);
  part('hugo-talk-end')?.addEventListener('click', onEnd);
  return { stop };
}

// ---- THE PAID ALWAYS-ON LISTENER (VH-318-F) ------------------------------------------------------------------
// In a browser with no speech API of its own, "Hey Hugo" listens through a Realtime TRANSCRIPTION session over the
// same relay (`mode=listen`): the microphone streams as 24kHz PCM16, the server's voice detection sends only the
// speech it hears to gpt-live-transcribe, and each finished transcript goes through the same `wakeUtterance`
// parser the free engine uses. It is PAID, so the server refuses it until its price per hour is read (owner,
// 2026-10-06), and the rail says so beside the tickbox. Everything is injected, so it is driven in node.

/** The upgrade URL for the listener: the session URL with `mode=listen`. */
export function listenUrl(origin, domain) {
  return realtimeUrl(origin, domain, '') + '&mode=listen';
}

/** The finished transcript a listener event carries, or ''. */
export function heardText(raw) {
  let event = raw;
  if (typeof raw === 'string') {
    try { event = JSON.parse(raw); } catch { return ''; }
  }
  const said = event?.type === 'conversation.item.input_audio_transcription.completed' ? event.transcript : '';
  return typeof said === 'string' ? said.trim() : '';
}

/**
 * Open the microphone and the listening session. Resolves `{ stop, live: true }`; rejects only when the
 * microphone cannot be opened. `onHeard(text)` receives each finished transcript; `onEnd()` is called once if the
 * session ends by itself (refused, capped, dropped), never after `stop()`. `stop()` releases the microphone
 * tracks, the socket and the audio context, and is idempotent.
 */
export async function startLiveListener({ makeSocket, url, getUserMedia, AudioContext: Ctx, codec, onHeard, onEnd = () => {} }) {
  const media = await getUserMedia({ audio: true });
  let stopped = false;
  let proc = null;
  let ctx = null;
  let ws = null;
  const stop = () => {
    if (stopped) return;
    stopped = true;
    try { proc?.disconnect(); } catch { /* already gone */ }
    for (const t of media.getTracks()) { try { t.stop(); } catch { /* already ended */ } }
    try { ws?.close(); } catch { /* already gone */ }
    try { ctx?.close(); } catch { /* already gone */ }
  };
  try {
    ctx = new Ctx(); // at the device's rate, resampled to 24 kHz below (VH-764)
    ctx.resume?.()?.catch(() => {});
    ws = makeSocket(url);
  } catch (err) {
    stop(); // the microphone must not stay open behind a session that never started
    throw err;
  }
  ws.onopen = () => {
    ctx.resume?.()?.catch(() => {});
    const source = ctx.createMediaStreamSource(media);
    proc = ctx.createScriptProcessor(4096, 1, 1);
    const to24k = codec.createResampler(ctx.sampleRate);
    proc.onaudioprocess = (e) => {
      if (stopped || ws.readyState !== WS_OPEN) return;
      ws.send(JSON.stringify({ type: 'input_audio_buffer.append', audio: codec.bytesToBase64(codec.floatToPcm16(to24k(e.inputBuffer.getChannelData(0)))) }));
    };
    source.connect(proc);
    proc.connect(ctx.destination);
  };
  ws.onmessage = (ev) => {
    const said = heardText(ev.data);
    if (said) onHeard(said);
  };
  ws.onerror = () => { /* onclose decides */ };
  ws.onclose = () => {
    const byItself = !stopped;
    stop();
    if (byItself) onEnd();
  };
  return { stop, live: true };
}
