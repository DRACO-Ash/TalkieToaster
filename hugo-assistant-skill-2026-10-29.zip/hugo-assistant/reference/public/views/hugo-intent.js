// The Hugo confirm-first surface (docs/PLAN-hugo-query-drive.md item C, text-first cut). Pure builders that
// turn a compiled ViewIntent (from POST /api/v3/hugo/compile) and an executed result (from
// POST /api/v3/hugo/query) into the escaped blocks the Hugo panel shows. The owner's decision is CONFIRM
// FIRST: nothing applies to the live data until the operator presses Apply, so this surface is the mandatory
// review step where a mis-read query is caught.
//
// Everything here is pure and DOM-free so it is unit-tested without a browser, and every reflected value is
// model- or data-derived and therefore untrusted: it all goes through the one shared escaper. The mascot and
// the non-intrusive dock (Hugo backlog #52) are a later, owner-directed presentation over these same builders.

import { esc } from '../lib-v3.js';
import { TYPE_CHAIN_LABEL } from '../type-chain.js';

const asArray = (v) => (Array.isArray(v) ? v : []);
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

// A friendly label for each filterSpec clause, so the review reads in words, not field keys.
const CLAUSE_LABEL = Object.freeze({
  // The typed name (VH-181) and, below, each domain's own facets (VH-263).
  search: 'Name or text',
  countries: 'Countries', gdm: 'GDM', sections: 'Sections', missions: 'NATO/JCO Missions',
  families: 'Capability families',
  productTypes: TYPE_CHAIN_LABEL, // VH-706: Hugo filters by either value
  regime_capabilities: 'Orbital regime', capability_class: 'Capability class', target_stratum: 'Target stratum',
  observation_mode: 'Observation mode', resource_class: 'Resource class',
});
// ONE TABLE FOR "WHICH VIEW": the review PROMISES a destination and the apply path CHOOSES one, and they were
// two objects that disagreed both ways. Onboarding is absent deliberately - it is not in `HUGO_VIEWS`, so it
// honours no filter, and a view that cannot be reached is never named. test/hugo-intent-view.test.js.
const VIEW_TARGET = Object.freeze({
  board: 'master', master: 'master', map: 'map', analytics: 'analytics', dashboard: 'dashboard',
});
const VIEW_LABEL = Object.freeze({
  board: 'the Master board', master: 'the Master board', map: 'the Map',
  analytics: 'Custom analytics', dashboard: 'the Domain Dashboard',
});

// A LABEL FOR A CLAUSE KEY, through `Object.hasOwn` rather than a bare index (V1.81 security sweep).
// The keys below arrive from the SERVER's `applied` / `notApplied` / `coverage` payloads, and a bare
// lookup reads the PROTOTYPE CHAIN: `constructor` would render "function Object() { [native code] }" as
// a filter's name. It escapes, so the worst case was cosmetic, but it is the same class as the domain
// sort's prototype hole and is fixed with it rather than left as the one that got away.
const clauseLabel = (key) => (Object.hasOwn(CLAUSE_LABEL, String(key)) ? CLAUSE_LABEL[String(key)] : String(key));
// The same guard for the view label. `view` is a server-supplied string too, so `view: 'constructor'`
// would have read as a truthy label and printed "On function Object() { [native code] }".
const viewLabel = (key) => (Object.hasOwn(VIEW_LABEL, String(key)) ? VIEW_LABEL[String(key)] : '');

// Named and reachable are the same question, off the same table. `Object.hasOwn` rather than a bare index:
// `view` is model-derived, and a bare lookup answers `constructor` with a truthy function.
export const isKnownView = (key) => Object.hasOwn(VIEW_TARGET, String(key));
export const viewTarget = (key) => (isKnownView(key) ? VIEW_TARGET[String(key)] : 'master');
/** The table's keys, so a test can assert the two sets have not drifted apart again. */
export const VIEW_KEYS = Object.freeze(Object.keys(VIEW_TARGET));

// Every clause is a list except the typed name (VH-181).
const clauseList = (values) => (typeof values === 'string' ? [values] : asArray(values));

// One escaped chip row: a label and its values as chips, nothing when the list is empty.
function chipRow(label, values) {
  const list = clauseList(values).filter((v) => typeof v === 'string' && v);
  if (list.length === 0) return '';
  const chips = list.map((v) => '<span class="intent-chip">' + esc(v) + '</span>').join('');
  return '<div class="intent-row"><span class="intent-row-label">' + esc(label) + '</span>'
    + '<span class="intent-row-chips">' + chips + '</span></div>';
}

/**
 * The escaped "Hugo understood" review block for a compiled ViewIntent. Shows each populated filter clause and
 * the chosen view. Returns '' for an intent with no filter and no view, so the caller can show an
 * "I could not read that" state instead. `intent` is the validated ViewIntent from the compile route.
 */
export function hugoUnderstoodHtml(intent, heading) {
  const i = isObj(intent) ? intent : null;
  if (!i) return '';
  const f = isObj(i.filterSpec) ? i.filterSpec : {};
  const rows = Object.keys(CLAUSE_LABEL).map((key) => chipRow(CLAUSE_LABEL[key], f[key])).filter(Boolean);
  const view = typeof i.view === 'string' ? viewLabel(i.view) : '';
  if (rows.length === 0 && !view) return '';
  const viewLine = view
    ? '<p class="intent-view">On <b>' + esc(view) + '</b>.</p>' : '';
  const conf = typeof i.confidence === 'string' && i.confidence
    ? '<p class="intent-confidence">Confidence: <b>' + esc(i.confidence) + '</b>. Check it, then Apply.</p>'
    : '<p class="intent-confidence">Check it, then Apply.</p>';
  // OVERRIDABLE, because two surfaces show this block and only one is Hugo. Default unchanged, so the
  // approved consent popup reads exactly as it did.
  const head = typeof heading === 'string' && heading ? heading : 'Hugo understood';
  return '<div class="intent-understood"><h4>' + esc(head) + '</h4>' + rows.join('') + viewLine + conf + '</div>';
}

/**
 * A short PLAIN-TEXT sentence for Hugo to SPEAK (H-5 voice), summarising the understood intent. Not HTML and
 * never rendered, so it carries no markup and needs no escaper; it is the string POSTed to the text-to-speech
 * route. Returns a rephrase prompt when nothing mapped, so Hugo never speaks a misleadingly empty confirmation.
 */
export function hugoSpokenSummary(intent) {
  const i = isObj(intent) ? intent : null;
  const f = i && isObj(i.filterSpec) ? i.filterSpec : {};
  const parts = [];
  for (const key of Object.keys(CLAUSE_LABEL)) {
    const list = clauseList(f[key]).filter((v) => typeof v === 'string' && v);
    if (list.length) parts.push(CLAUSE_LABEL[key] + ' ' + list.join(', '));
  }
  if (parts.length === 0) return 'Hugo could not map that to a filter. Try rephrasing.';
  const viewName = i && typeof i.view === 'string' ? viewLabel(i.view) : '';
  const view = viewName ? ' on ' + viewName : '';
  return 'Hugo understood: ' + parts.join('; ') + view + '. Check it, then apply.';
}

/**
 * The escaped notice for phrases Hugo could not map to a controlled value (the compile route's `unmapped`).
 * Returns '' when nothing was dropped.
 */
export function hugoUnmappedHtml(unmapped) {
  const list = asArray(unmapped).filter((u) => isObj(u) && typeof u.value === 'string' && u.value);
  if (list.length === 0) return '';
  const items = list.map((u) => {
    const field = typeof u.field === 'string' && u.field ? u.field : 'field';
    return '<li>' + esc(u.value) + ' <span class="dim">(' + esc(field) + ')</span></li>';
  }).join('');
  return '<div class="intent-unmapped"><b>Not mapped to a known value</b>'
    + '<p class="dim">These parts of your request did not match a value Hugo can filter on, and were left out. '
    + 'Rephrase and ask again to include them.</p><ul>' + items + '</ul></div>';
}

/**
 * The escaped notice for clauses the database cannot yet filter on (the query route's `notApplied`). Honest
 * about the H0-3 first cut: these clauses were understood but not applied to the result. Returns '' when empty.
 */
export function hugoNotAppliedHtml(notApplied, coverage) {
  const all = asArray(notApplied).filter((k) => typeof k === 'string' && k);
  // Across domains (`coverage` set), a family no domain fills emptied the result (VH-785).
  const noFamily = isObj(coverage) && all.includes('families');
  const list = noFamily ? all.filter((k) => k !== 'families') : all;
  const family = noFamily ? '<div class="intent-notapplied"><b>No domain holds such a family</b>'
    + '<p class="dim">No domain files any of its data under the family you asked for, so none answers.</p></div>' : '';
  if (list.length === 0) return family;
  const items = list.map((k) => '<span class="intent-chip">' + esc(clauseLabel(k)) + '</span>').join('');
  return '<div class="intent-notapplied"><b>Not yet filterable</b>'
    + '<p class="dim">Hugo understood these, but the app cannot filter on them yet, so they are not '
    + 'applied to this result:</p><div class="intent-row-chips">' + items + '</div></div>' + family;
}

/**
 * THE CLAUSES THAT RAN IN SOME STORES AND NOT OTHERS (V1.81, parity gap `hugo.crossdomain.applied.space`).
 *
 * A cross-domain query runs against seven stores that do not honour the same clause set, and `applied` is the
 * union of what they ran. That union is the honest headline (a clause that ran in Space DID narrow the
 * result), but it leaves a gap the two lists cannot express: a clause that ran in four stores appears in
 * `applied` and not in `notApplied`, so the operator sees no warning at all for the three that ignored it.
 * This is that warning, and it NAMES THE STORES rather than saying "partly", because "which of my seven"
 * is the question an operator with a mixed result is actually asking.
 *
 * `labelOf` maps a domain id to its display label; the id is used unchanged when no labeller is given, which
 * is honest (it is the real id) rather than a reconstructed name.
 */
export function hugoPartialHtml(coverage, labelOf) {
  if (!isObj(coverage)) return '';
  const name = typeof labelOf === 'function' ? labelOf : (id) => id;
  const rowOf = (clause) => {
    const ran = asArray(coverage[clause]?.ran);
    const missed = asArray(coverage[clause]?.missed);
    // Only the MIXED clauses. A clause every store ran needs no notice, and one no store ran is already
    // reported by `hugoNotAppliedHtml`; repeating it here would be two notices for one fact.
    if (ran.length === 0 || missed.length === 0) return '';
    const chips = missed.map((id) => '<span class="intent-chip">' + esc(String(name(id) || id)) + '</span>').join('');
    return '<div class="intent-row"><span class="intent-row-label">'
      + esc(clauseLabel(clause)) + '</span><span class="intent-row-chips">' + chips + '</span></div>';
  };
  const rows = Object.keys(coverage).filter((clause) => clause !== 'families').map(rowOf).filter(Boolean);
  // A domain holding no such family answers none (VH-785), so it is not in the unfiltered line.
  const family = Object.hasOwn(coverage, 'families') ? rowOf('families') : '';
  if (rows.length === 0 && !family) return '';
  return '<div class="intent-partial"><b>Applied to some domains only</b>'
    // "in most stores" was a figure nobody measured: the row prints whenever ONE store ran the clause, so
    // one of seven read as "most". This says what the code actually guarantees.
    + (rows.length ? '<p class="dim">These parts narrowed the result in some domains, but the domains listed beside each '
    + 'one do not hold that field, so their rows are not filtered by it:</p>' + rows.join('') : '')
    + (family ? '<p class="dim">These domains hold no such family, so they answer none for it:</p>' + family : '') + '</div>';
}

/**
 * THE CONSENT BODY (owner decision, V1.79): "a popup simply says - allow Hugo to show you".
 *
 * `proposal` is the agent route's `proposal` for a `propose_view` call: the validated intent, the view, and
 * the row count the server took BEFORE offering. Returns the escaped body of the modal, or '' when the
 * proposal is not one this popup can honestly offer, which the caller reads as "do not raise it".
 *
 * Three things are stated rather than implied, because the operator is consenting to the app moving:
 * where they will land, what the filter is, and how many records are behind it. A count of zero is shown as
 * a warning and not hidden: an empty board reads as a bug, and finding that out after consenting is worse
 * than being told first.
 */
// The count line for a view offer: the figure when the server took one, the empty-view warning at zero, and
// nothing at all when the count could not be taken (a failed count must not read as "no records").
function countLine(total) {
  if (!Number.isFinite(total)) return '';
  if (total === 0) return '<p class="intent-confidence"><b>No records match this.</b> Hugo can still show you, but the view will be empty.</p>';
  // PLURALISED FROM THE COUNT, as `hugoResultSummary` twenty lines below and `triage.js` both do. This is
  // the most-read new string in the app - it is in the consent popup - and "1 record(s)" in it is the
  // first thing an operator sees Hugo say.
  const noun = total === 1 ? 'record' : 'records';
  return '<p class="intent-confidence"><b>' + esc(String(total)) + '</b> ' + noun + ' behind it.</p>';
}

export function hugoShowProposalHtml(proposal) {
  const p = isObj(proposal) ? proposal : null;
  // An optional chain rather than a `!p ||` guard: `p?.tool` is `undefined` when `p` is null, which is
  // never `'propose_view'`, so the refusal is identical and the following clause is still unreachable with
  // a null `p`. The App Store's Code Quality gate flags the longhand.
  if (p?.tool !== 'propose_view' || !isObj(p.intent)) return '';
  const view = typeof p.view === 'string' ? viewLabel(p.view) : '';
  if (!view) return '';
  const f = isObj(p.intent.filterSpec) ? p.intent.filterSpec : {};
  const rows = Object.keys(CLAUSE_LABEL).map((key) => chipRow(CLAUSE_LABEL[key], f[key])).filter(Boolean);
  const reason = typeof p.reason === 'string' && p.reason ? '<p class="intent-view">' + esc(p.reason) + '</p>' : '';
  const scope = p.crossDomain === true ? ' across every domain' : '';
  const count = countLine(p.total);
  const whole = rows.length === 0 && p.hasFilter !== true
    ? '<p class="intent-confidence">No filter: this shows the whole set.</p>' : '';
  return '<p class="intent-view">Hugo would take you to <b>' + esc(view) + '</b>' + esc(scope) + '.</p>'
    + reason + rows.join('') + whole + count;
}

/**
 * The escaped one-line result summary for an executed query: how many matched, on which domain(s), and the
 * cross-domain coverage note. `result` is the /hugo/query response. Never fabricates: an empty result says so.
 */
export function hugoResultSummary(result) {
  const r = isObj(result) ? result : {};
  const total = Number.isFinite(r.total) ? r.total : 0;
  const noun = total === 1 ? 'company' : 'companies';
  const unseeded = asArray(r.domainsUnseeded).filter((d) => typeof d === 'string' && d);
  const unseededNoun = unseeded.length === 1 ? 'domain is' : 'domains are';
  const coverage = r.crossDomain && unseeded.length > 0
    ? ' <span class="dim">(' + esc(String(unseeded.length)) + ' other ' + unseededNoun + ' not seeded yet)</span>'
    : '';
  const head = total === 0
    ? '<b>No ' + noun + ' match.</b> Loosen a filter and ask again.'
    : '<b>' + esc(String(total)) + '</b> ' + noun + ' match.' + coverage;
  return '<p class="intent-result">' + head + '</p>';
}

/**
 * VH-149: the app sends no email, so this opens the operator's own mail app with this app's address and no
 * recipient. A bare http(s) origin only; anything else gives ''.
 * @param {unknown} origin the page's origin
 * @returns {string} a `mailto:` address, or ''
 */
export function phoneLinkMailto(origin) {
  if (typeof origin !== 'string' || origin === '') return '';
  let url = null;
  try { url = new URL(origin); } catch { return ''; }
  const web = url.protocol === 'http:' || url.protocol === 'https:';
  if (!web || url.origin !== origin) return '';
  const body = 'Open this link on your phone, sign in and tap Ask Hugo:\n' + url.origin + '/';
  return 'mailto:?subject=' + encodeURIComponent('Ask Hugo on your phone') + '&body=' + encodeURIComponent(body);
}

// --- The wake phrase (owner decision, V1.79) --------------------------------------------------------------

// "Hey Hugo", tolerant of the punctuation a speech recogniser inserts and of the openers people actually use.
// Not anchored to the start: a recogniser hands over a rolling transcript, so the phrase can arrive mid-string.
const WAKE_RE = /\b(?:hey|hi|hello|ok|okay)[\s,.]+hugo\b[\s,.:;!?-]*/i;

/**
 * Read one recogniser transcript as a wake event and the question that followed it.
 *
 * WHY THE QUESTION MATTERS. The old handler only opened the panel, so "Hey Hugo, which UK vendors are not in
 * the GDM" opened a blank box and threw the question away - the operator said it once and then had to type it.
 * The remainder of the utterance IS the question, in its original casing, so it can be sent as typed.
 *
 * `send` is true only when the utterance CLEARLY continues past the phrase (three words or more). A false wake
 * ("hey Hugo's the one who...") or a one-word fragment fills the box and waits, because acting on a
 * misheard fragment is worse than asking.
 * @param {string} transcript one recogniser result
 * @returns {{woke: boolean, question: string, send: boolean}}
 */
export function wakeUtterance(transcript) {
  const said = typeof transcript === 'string' ? transcript : '';
  const m = WAKE_RE.exec(said);
  if (!m) return { woke: false, question: '', send: false };
  const question = said.slice(m.index + m[0].length).trim().replace(/^[\s,.:;!?-]+/, '');
  const words = question.split(/\s+/).filter(Boolean);
  return { woke: true, question, send: words.length >= 3 };
}

/**
 * WHAT THE SPACE DASHBOARD DRAWS UNDER HUGO'S FILTER (VH-324). The matches are held, still being read, or REFUSED, and
 * the three are different sentences: a refused read is an unreadable dataset and never an empty one, so it must not say
 * "No vendors yet" and send the operator to pay for a search. The refusal counts only for the filter generation it was
 * made under, so a cleared, replaced or switched filter and a write each leave an old refusal stale without a reset.
 * @param {{filtered: boolean, rows: unknown, refusal: ({gen: number}|null), gen: number}} o
 * @returns {'whole'|'matches'|'loading'|'refused'}
 */
export function hugoDashboardPhase({ filtered, rows, refusal, gen }) {
  if (!filtered) return 'whole';
  if (Array.isArray(rows)) return 'matches';
  return refusal?.gen === gen ? 'refused' : 'loading';
}
