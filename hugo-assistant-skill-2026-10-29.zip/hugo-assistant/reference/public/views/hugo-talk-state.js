// WHETHER TALK CAN RUN HERE, AND IF NOT, WHY IN WORDS (VH-865, owner: "where is my feature to use hugo voice - failed - fix
// it"). Talk was hidden whenever any one of six conditions failed, and one of them was a bearer token in the browser: an
// operator signed in through the platform's own identity holds none, so the voice probe never ran and Talk never showed,
// though Hugo's live voice (WebRTC) worked end to end on the same deployment. So on a browser that can capture sound a
// signed-in operator always sees Talk: enabled when either path is known good, the live voice first, else disabled with
// the reason and the one step that fixes it. Pure, so every state is tested.

/** The environment variable an administrator sets for Hugo's voice; a name only, never a value. */
export const VOICE_KEY_VAR = 'OPENAI_API_KEY';

const ASK_ADMIN = ' Ask your administrator.';
const off = (reason) => ({ show: true, enabled: false, path: '', reason });

/**
 * @param {object} s
 * @param {boolean} s.capture the browser can capture sound (`getUserMedia`)
 * @param {boolean} s.signedIn
 * @param {'pending'|'done'} s.probe whether the voice probe has answered
 * @param {{ configured?: boolean, live?: boolean, realtime?: boolean, fault?: string, canFix?: boolean }} s.voice its answer
 * @param {boolean} s.webrtc the browser has `RTCPeerConnection`, which the live voice needs
 * @param {boolean} s.relay the browser has WebSocket and AudioContext, which the app's own link needs
 * @returns {{ show: boolean, enabled: boolean, path: 'live'|'relay'|'', reason: string }}
 */
export function talkState({ capture, signedIn, probe, voice = {}, webrtc, relay }) {
  if (!capture || !signedIn) return { show: false, enabled: false, path: '', reason: '' };
  if (probe !== 'done') return off('Checking whether Hugo can talk here.');
  if (voice.fault === 'unreachable') return off('Could not check whether Hugo can talk. Reload the page to try again.');
  if (voice.live === true && webrtc) return { show: true, enabled: true, path: 'live', reason: '' };
  // The app's own link needs no app token since VH-873: the upgrade's own identity is read where it carries none.
  if (voice.realtime === true && relay) return { show: true, enabled: true, path: 'relay', reason: '' };
  const fix = (step) => (voice.canFix === true ? ' ' + step : ASK_ADMIN);
  if (voice.fault === 'key-rejected') return off('Hugo\'s voice key was refused.' + fix('Replace ' + VOICE_KEY_VAR + ' in the App Store environment, then apply it.'));
  if (voice.configured !== true) return off('Hugo\'s voice is not set up on this app.' + fix('Set ' + VOICE_KEY_VAR + ' in the App Store environment, then apply it.'));
  if (voice.live === true) return off('This browser cannot open Hugo\'s live voice: it needs WebRTC. Use a current Chrome, Edge, Firefox or Safari.');
  return off('Hugo\'s live voice is off on this app.' + fix('Run Check Hugo\'s connection, under Settings, Hugo\'s voice, to see why.'));
}
