// Hugo voice PCM/base64 codec helpers, extracted verbatim from app-v3.js so they are unit-testable in node
// (the client monolith is a top-level DOM script the coverage lcov cannot attribute; these are pure data
// transforms with no DOM). They bridge the browser microphone and the server realtime bridge: 32-bit float
// audio frames to little-endian PCM16 and back, and PCM16 bytes to/from base64 for the JSON WebSocket frames.
// Behaviour is identical to the inline versions; only the location moved.

// Float32 samples in [-1, 1] -> little-endian signed PCM16 bytes.
export function floatToPcm16(floats) {
  const out = new Uint8Array(floats.length * 2);
  const view = new DataView(out.buffer);
  // eslint-disable-next-line unicorn/no-for-loop -- paired index into a DataView for little-endian PCM16; for-of cannot express it
  for (let i = 0; i < floats.length; i += 1) {
    const s = Math.max(-1, Math.min(1, floats[i]));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return out;
}

// Little-endian signed PCM16 bytes -> Float32 samples in [-1, 1).
export function pcm16ToFloat(bytes) {
  const n = Math.floor(bytes.length / 2);
  const view = new DataView(bytes.buffer, bytes.byteOffset, n * 2);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i += 1) out[i] = view.getInt16(i * 2, true) / 0x8000;
  return out;
}

// Raw bytes -> base64 (one code unit per byte, then btoa).
export function bytesToBase64(bytes) {
  let bin = '';
  for (const b of bytes) bin += String.fromCodePoint(b);
  return btoa(bin);
}

// base64 -> raw bytes.
export function base64ToBytes(b64) {
  return Uint8Array.from(atob(b64), (ch) => ch.codePointAt(0));
}

// The microphone at the device's own rate -> the 24 kHz the Realtime session takes (VH-764). The audio engine runs at
// the device's rate because Firefox refuses to connect a microphone to an engine at any other (TBC, re-verify: only
// Chromium runs here). Linear interpolation, carried across frames so no sample is lost or doubled at a frame edge.
export function createResampler(fromRate, toRate = 24000) {
  const step = fromRate / toRate;
  if (!Number.isFinite(step) || step <= 0) throw new RangeError('a sample rate must be a positive number');
  let prev = 0; // the previous frame's last sample, read as index -1
  let at = 0; // the next output sample's place, in this frame's samples
  return (input) => {
    const out = [];
    const n = input.length;
    while (at <= n - 1) {
      const i = Math.floor(at);
      const a = i < 0 ? prev : input[i];
      const b = i + 1 < n ? input[i + 1] : a;
      out.push(a + (b - a) * (at - i));
      at += step;
    }
    if (n) { at -= n; prev = input[n - 1]; }
    return Float32Array.from(out);
  };
}

// What the Talk client does with one relayed server event (VH-318-B): `{ audio }` to play, `{ heard }` for what the
// operator said, `{ transcript }` for a piece of what Hugo says, `{ done: true }` when Hugo's spoken turn is
// complete, or null to ignore. The event names are the generally available interface's (openai 7.23.0
// `resources/realtime/realtime.d.ts`); the beta names `response.audio.delta` and
// `response.audio_transcript.delta` are gone, so a client listening for them played and showed nothing. The
// operator's words and Hugo's are told apart (VH-318-D) so each lands as its own turn on the one rail; they used
// to be run together into a single bubble.
// A REPLY CUT OFF BY THE UPSTREAM ENDS THE TURN TOO (V2.8 W40): the relay's `vh.session.resumed` (`SESSION_RESUMED_TYPE`,
// src/hugo/openai-realtime.js) says it will never finish, so the turn is settled as it stands, unmarked, as Stop settles
// it, and the next reply opens a turn of its own instead of being appended to this one and taking its verdict. `cut`
// is the line the shell writes after it (VH-653, the owner's option B): the session is still open, and the next step,
// in the words the typed turn uses for the same cut (VH-650).
const SPOKEN_CUT = 'Hugo\'s reply was cut off by the connection. Ask again to hear the rest.';
export function realtimeVoiceAction(event) {
  const type = event?.type;
  if (type === 'response.output_audio.delta') return typeof event.delta === 'string' ? { audio: event.delta } : null;
  if (type === 'vh.session.resumed') return { done: true, cut: SPOKEN_CUT };
  if (type === 'response.output_audio_transcript.done') return { done: true };
  const heard = type === 'conversation.item.input_audio_transcription.completed';
  let text = '';
  if (type === 'response.output_audio_transcript.delta') text = event.delta;
  else if (heard) text = event.transcript;
  if (typeof text !== 'string' || !text) return null;
  return heard ? { heard: text } : { transcript: text };
}
