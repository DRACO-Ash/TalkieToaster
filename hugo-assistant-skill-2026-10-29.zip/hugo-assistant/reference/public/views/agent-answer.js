// HUGO'S VERIFIED ANSWER (V1.77 E8, from D6). Pure builders, no DOM.
//
// The agent route returns an answer the SERVER has already verified against what the tools returned, with
// the citations it validated, the verification verdict and the tool trail. This module renders those and
// nothing else. The one rule that matters: a citation chip can only come from the server's list. An `[Rn]`
// in the answer text becomes a chip when `n` is in `citations`, and is DROPPED when it is not, so a
// reference the verifier did not admit has nowhere to render as provenance. Names in the prose are never
// parsed into chips.
//
// No reserved colour. Whether an answer was verified is carried by the words and a neutral banner class.

import { esc } from '../lib-v3.js';

const REF_RE = /\[R(\d{1,3})\]/g;

/** The answer text with admitted references rendered as chips and the rest dropped. Escaped throughout. */
export function answerTextHtml(answer, citations) {
  const byRef = new Map((Array.isArray(citations) ? citations : []).map((c) => [Number(c.ref), c]));
  const text = String(answer || '');
  let out = '';
  let last = 0;
  for (const m of text.matchAll(REF_RE)) {
    out += esc(text.slice(last, m.index));
    const c = byRef.get(Number(m[1]));
    if (c) out += '<span class="hugo-cite" title="' + esc(c.id || '') + '">' + esc('[R' + c.ref + '] ' + (c.name || c.id || '')) + '</span>';
    last = m.index + m[0].length;
  }
  out += esc(text.slice(last));
  return out;
}

/** The verification banner: verified, verified after a correction, or withheld. */
export function verificationHtml(verification) {
  const v = verification && typeof verification === 'object' ? verification : {};
  if (v.ok === true && !v.retried) return '<span class="hugo-verify hugo-verify-ok">Verified against the dataset</span>';
  if (v.ok === true) return '<span class="hugo-verify hugo-verify-ok">Verified after one correction</span>';
  const items = Array.isArray(v.violations) ? v.violations.slice(0, 5) : [];
  return '<span class="hugo-verify hugo-verify-held">Part of the answer was withheld: it could not be verified</span>'
    + (items.length ? '<ul class="hugo-verify-list">' + items.map((x) => '<li>' + esc(String(x)) + '</li>').join('') + '</ul>' : '');
}

/** The tool trail: what Hugo looked up, in order, with a failed step said so. */
export function stepsHtml(steps) {
  const list = Array.isArray(steps) ? steps : [];
  if (list.length === 0) return '<span class="hugo-steps dim">No lookups</span>';
  return '<ol class="hugo-steps">' + list.map((s) => '<li class="' + (s.ok ? 'ok' : 'failed') + '">' + esc(String(s.tool || '')) + (s.ok ? '' : ' (failed)') + '</li>').join('') + '</ol>';
}

/**
 * WHAT THE ANSWER COST, AND HOW MANY OF HUGO'S DATASET LOOKUPS IT USED (VH-116, the owner's approved picture
 * `docs/mockups/v23-vh116-hugo-cost-and-listening.png`). The server prices the turn from the model's own token
 * counts (`src/api-v3.js` hugoTurnMeasures). Two honesty rules:
 *  ● NO COST, NO LINE. An older reply carries no `cost`, and the deterministic path costs nothing and says
 *    `usd: 0`; a "$0.00" under either would read as a measured figure, so both render nothing.
 *  ● A TURN THAT REACHED THE WEB IS NOT PRICED WHOLE. Web lookups are not in the token counts, so the figure
 *    says it excludes them rather than reading as the whole cost.
 */
export function costLineHtml(out) {
  const cost = out?.cost && typeof out.cost === 'object' ? out.cost : null;
  const usd = Number(cost?.usd);
  if (!cost || !Number.isFinite(usd) || usd <= 0) return '';
  let text = 'This answer cost ' + (usd < 0.01 ? 'less than $0.01' : 'about $' + usd.toFixed(2))
    + (cost.excludesWeb === true ? ', excluding web lookups' : '');
  const used = Number(out.lookups?.used);
  const cap = Number(out.lookups?.cap);
  if (Number.isInteger(used) && Number.isInteger(cap) && used >= 0 && cap > 0) text += ' · ' + used + ' of ' + cap + ' dataset lookups used';
  return '<span class="hugo-cost">' + esc(text) + '</span>';
}

/**
 * One agent turn: the mode line (model or deterministic fallback), the answer with its chips, the
 * verification banner, the trail, and what it cost.
 */
// The mode line: nothing for a model answer, the honest reason for a fallback one.
function modeLine(o) {
  if (!o.fallback) return '';
  // THE REASON, WHERE THERE IS ONE. "The model call failed" told an operator nothing they could act on, and
  // on 2026-09-11 that was the whole of the evidence for a Hugo that had stopped conversing. The server now
  // sends the provider's status and error code (`openai-chat.js` builds it; no prompt, no key, no provider
  // prose), so the line names the cause and an admin can go and fix it.
  if (o.providerFailed) {
    const reason = typeof o.providerReason === 'string' ? o.providerReason.trim() : '';
    return 'Hugo\'s AI service did not answer, so this was answered from the dataset alone.'
      + (reason ? ' Reason: ' + reason + '.' : '');
  }
  return 'Answered from the dataset alone; Hugo\'s AI service is not available.';
}

export function agentAnswerHtml(out) {
  const o = out && typeof out === 'object' ? out : {};
  const mode = modeLine(o);
  return '<div class="hugo-agent">'
    + (mode ? '<span class="hugo-ground dim">' + esc(mode) + '</span>' : '')
    + '<span class="hugo-turn-text">' + answerTextHtml(o.answer, o.citations) + '</span>'
    + verificationHtml(o.verification)
    + stepsHtml(o.steps)
    + costLineHtml(o)
    + '</div>';
}
