// THE ONE RAIL (VH-318-D). Typed and spoken turns land in ONE conversation, and the panel is designed for a
// stream: a turn can be streaming (text arriving), checking (shown, while the check against the tool results
// runs beside it), verified, or withdrawn (the check failed after the text was shown). The Hugo panel tidy
// (VH-015) is folded in here, so the conversation is the body of the rail and the composer sits under it.
//
// Pure builders, no DOM, so they are unit-tested in node. Every reflected value goes through the app's one
// escaper. No reserved status colour: a turn's state is carried by its words and a neutral class.

import { esc } from '../lib-v3.js';
import { changeLine } from './hugo-update.js';

/** The states a Hugo turn can be in. Anything else renders as a settled turn with no mark. */
export const TURN_STATES = Object.freeze(['streaming', 'checking', 'verified', 'withdrawn']);

/** How a turn arrived. Only `spoken` is marked, because typing is the default and a tag on every turn is noise. */
export function channelOf(turn) {
  return turn?.channel === 'spoken' ? 'spoken' : 'typed';
}

/**
 * The mark under a Hugo turn for its state. `streaming` has none (the caret says it), `checking` says the
 * check is running, and `withdrawn` says why the text no longer stands. Audio already played cannot be
 * unsaid, so a spoken turn is FLAGGED rather than withdrawn: the words stay, struck, with the reason.
 */
export function turnMarkHtml(state, channel) {
  if (state === 'checking') return '<span class="hugo-mark hugo-mark-checking">Checking against the dataset</span>';
  if (state === 'verified') return '<span class="hugo-verify hugo-verify-ok">Verified against the dataset</span>';
  if (state !== 'withdrawn') return '';
  const text = channel === 'spoken'
    ? 'Flagged: Hugo said this aloud, but it could not be checked against the dataset'
    : 'Withdrawn: it could not be checked against the dataset';
  return '<span class="hugo-verify hugo-verify-held">' + text + '</span>';
}

/**
 * One turn of the conversation. `turn` is `{ role, content, channel?, state? }`; `bodyHtml`, when given, is
 * an already-escaped body (the verified agent answer) that replaces the plain text. The who line always names
 * the speaker, so a verified answer no longer loses its "Hugo" label when its body is rebuilt. `afterHtml`
 * (already escaped) follows the body: the grounding slots and the cost line. `pending` marks the in-flight turn.
 */
export function turnHtml(turn, { bodyHtml = '', afterHtml = '', pending = false } = {}) {
  const you = turn?.role === 'user';
  const channel = channelOf(turn);
  const state = TURN_STATES.includes(turn?.state) ? turn.state : '';
  const classes = ['hugo-turn', you ? 'hugo-turn-you' : 'hugo-turn-hugo'];
  if (state) classes.push('is-' + state);
  // `hugo-turn-pending` is how the grounding filler finds the in-flight turn without a re-render.
  if (pending) classes.push('hugo-turn-pending');
  const via = channel === 'spoken' ? '<span class="hugo-turn-via">spoken</span>' : '';
  const live = state === 'streaming' ? ' hugo-turn-live' : '';
  const body = bodyHtml || '<span class="hugo-turn-text' + live + '">' + esc(String(turn?.content ?? '')) + '</span>';
  return '<div class="' + classes.join(' ') + '" data-channel="' + channel + '">'
    + '<span class="hugo-turn-who">' + (you ? 'You' : 'Hugo') + via + '</span>'
    + body + afterHtml + (you ? '' : turnMarkHtml(state, channel)) + '</div>';
}

// WHAT HUGO IS DOING WHILE A TYPED TURN RUNS (VH-777 Lane T): each tool the streamed turn reports, in words, once each,
// in the order they ran. A tool this list does not know is left out rather than shown by its code name.
const STEP_WORDS = Object.freeze({
  query_records: 'searching the records', count_records: 'counting the records', get_record: 'reading a record',
  find_similar: 'finding similar companies', record_provenance: 'checking where a fact came from',
  pipeline_summary: 'reading the onboarding pipeline', propose_scan: 'drafting a search', propose_update: 'drafting an update',
  explain_match: 'explaining a match', web_lookup: 'looking on the web', search_help: 'reading the help',
  describe_app: 'reading how the app works', app_state: 'reading the app\'s figures', recent_history: 'reading recent changes',
  propose_view: 'drafting a view',
});

/** The steps so far as one line, "Searching the records, reading a record…", or '' before the first. */
// Own entries only (2.20.0 round one, security MINOR 2): a tool named `constructor` or `__proto__` would read an Object
// member off the table and show it in the line.
const stepWordOf = (tool) => (typeof tool === 'string' && Object.hasOwn(STEP_WORDS, tool) ? STEP_WORDS[tool] : '');

export function stepsText(steps) {
  const words = [...new Set((Array.isArray(steps) ? steps : []).map((s) => stepWordOf(s?.tool)).filter(Boolean))];
  if (words.length === 0) return '';
  const line = words.join(', ');
  return line.charAt(0).toUpperCase() + line.slice(1) + '\u2026';
}

// --- THE SPOKEN HALF (VH-318-D) ---------------------------------------------------------------------------
// What the operator says and what Hugo says back land in the same history as typed turns, tagged spoken. Each
// function mutates the history it is given and returns a boolean, so the caller knows whether to repaint.

/** Whether a turn is Hugo's spoken reply still arriving. */
export function isLiveSpoken(turn) {
  return turn?.role === 'assistant' && turn.channel === 'spoken' && turn.state === 'streaming';
}

/**
 * Place what the operator said. It is transcribed a moment after it is spoken, so when Hugo's reply is already
 * under way it goes BEFORE that reply, in the order things were said. Returns false for empty text.
 */
export function placeHeard(history, text) {
  if (!Array.isArray(history) || typeof text !== 'string' || !text) return false;
  const turn = { role: 'user', content: text, channel: 'spoken' };
  if (isLiveSpoken(history.at(-1))) history.splice(-1, 0, turn);
  else history.push(turn);
  return true;
}

/**
 * Add a piece of Hugo's spoken reply. Returns true when it OPENED a new turn (the caller repaints) and false
 * when it grew the live one (the caller writes the text in place) or there was nothing to add.
 */
export function appendSaid(history, piece) {
  if (!Array.isArray(history) || typeof piece !== 'string' || !piece) return false;
  const last = history.at(-1);
  if (isLiveSpoken(last)) { last.content += piece; return false; }
  history.push({ role: 'assistant', content: piece, channel: 'spoken', state: 'streaming' });
  return true;
}

/** Settle Hugo's live spoken turn as it stands. Returns true when there was one to settle. */
export function settleSpoken(history) {
  const last = Array.isArray(history) ? history.at(-1) : null;
  if (!isLiveSpoken(last)) return false;
  delete last.state;
  return true;
}

// --- PROPOSALS ON THE RAIL (VH-318-H) ----------------------------------------------------------------------

const PROPOSAL_TOOLS = Object.freeze({ propose_view: 'view', propose_scan: 'scan', propose_update: 'update' });
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const isText = (v, max) => typeof v === 'string' && v.length > 0 && v.length <= max;

/**
 * The kind of a confirm-first proposal, or '' when it is not one this rail can honestly offer. Validated at
 * the boundary, because a spoken proposal arrives on the voice socket: the tool must be one of the three,
 * `requiresConfirmation` must be true (a failed or foreign result raises nothing), and the fields the card
 * and its action read must be present and of the right type.
 */
export function proposalKind(proposal) {
  if (!isObj(proposal) || proposal.requiresConfirmation !== true) return '';
  const kind = PROPOSAL_TOOLS[proposal.tool] || '';
  if (kind === 'view') return isObj(proposal.intent) && isText(proposal.view, 40) ? kind : '';
  if (kind === 'scan') return isObj(proposal.design) ? kind : '';
  if (kind === 'update') {
    const ok = isText(proposal.domain, 40) && isText(proposal.id, 200) && isObj(proposal.changes) && /^https?:\/\//i.test(String(proposal.source || ''));
    return ok ? kind : '';
  }
  return '';
}

/**
 * Read one relayed voice frame as a proposal, or null. The relay sends `{ type: 'hugo.proposal', proposal }`
 * built from the SERVER's tool result (src/hugo/openai-realtime.js), never the model's arguments; this is the
 * client half of the same boundary, so a malformed or foreign frame is dropped rather than rendered.
 */
export function proposalFromFrame(event) {
  if (!isObj(event) || event.type !== 'hugo.proposal') return null;
  return proposalKind(event.proposal) ? event.proposal : null;
}

/**
 * Why an update proposal cannot be opened from here, or '' when it can. The record's drawer opens on the domain
 * on screen, so a change to a record in another catalogue says which one to switch to rather than opening a
 * record of the same id in the wrong store. `labelOf` names a domain id.
 */
export function proposalRefusal(proposal, domain, labelOf) {
  if (proposalKind(proposal) !== 'update' || proposal.domain === domain) return '';
  const label = typeof labelOf === 'function' ? String(labelOf(proposal.domain) || proposal.domain) : proposal.domain;
  return 'This change is to a company in the ' + label + ' domain. Switch to ' + label + ' to review it.';
}

// The body of an update card: what would change on which record, and the source it rests on.
function updateBodyHtml(p) {
  const before = isObj(p.changes.before) ? p.changes.before : {};
  const after = isObj(p.changes.after) ? p.changes.after : {};
  const names = Object.keys(after);
  const rows = names.map((n) => changeLine(n, before[n], after[n])).join('');
  const what = names.length ? '<ul class="hugo-update-changes">' + rows + '</ul>' : '<p class="dim">That would not change anything for this company.</p>';
  return '<p class="hugo-update-lede">A change to company <b>' + esc(p.id) + '</b>:</p>' + what
    + '<p class="hugo-update-source">Source: <span>' + esc(p.source) + '</span></p>';
}

const PROPOSAL_COPY = Object.freeze({
  view: { head: 'Hugo offers to show you', act: 'Show me' },
  scan: { head: 'Hugo proposes a scan', act: 'Set up this scan' },
  update: { head: 'Hugo proposes a change', act: 'Open the company to apply' },
});

/**
 * The proposal card in the conversation. Nothing runs from the card itself: its one action opens the
 * existing confirmation surface for that kind (the consent popup, the scan dialog, the record's sourced
 * update card), where the operator confirms. `bodyHtml` is the caller's already-escaped body for a view or a
 * scan (the consent body and the understood block need the app's labels); an update builds its own.
 * Returns '' for anything `proposalKind` refuses.
 */
export function proposalCardHtml(proposal, { bodyHtml = '', index = 0 } = {}) {
  const kind = proposalKind(proposal);
  if (!kind) return '';
  const copy = PROPOSAL_COPY[kind];
  const body = kind === 'update' ? updateBodyHtml(proposal) : bodyHtml;
  const via = proposal.channel === 'spoken' ? '<span class="hugo-turn-via">spoken</span>' : '';
  const n = Number.isInteger(index) && index >= 0 ? index : 0;
  return '<div class="hugo-proposal" data-kind="' + kind + '">'
    + '<span class="hugo-proposal-head">' + copy.head + via + '</span>'
    + body
    + '<div class="hugo-proposal-actions"><button type="button" class="btn btn-sm btn-accent" data-hugo-proposal="' + n + '">'
    + copy.act + '</button></div></div>';
}
