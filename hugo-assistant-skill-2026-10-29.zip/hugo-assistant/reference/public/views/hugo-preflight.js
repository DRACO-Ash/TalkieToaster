// HUGO'S PREFLIGHT, IN WORDS (owner, 2026-09-17: "hugo still sucks ass - it doesnt work", with both
// provider keys already set).
//
// Hugo answers plausibly whether or not he has a brain, because the deterministic tool layer answers
// anyway. So a missing key, a refused key, an unknown model id, a spent quota and a blocked egress all
// reach the operator as the same shrug, and "it does not work" is the only sentence available to them.
// Each of those has a different fix and a different person who can apply it.
//
// A PURE MODULE, because `app-v3.js` touches `document` at load and cannot be imported by a test, and
// these sentences are the whole feature: one that names the wrong variable sends an admin somewhere there
// is nothing to find.

import { startLive, LIVE_CHECK_ROUTE } from './hugo-live.js';

/**
 * The preflight's finding as one sentence. Pure and exported, so the wording is unit-tested:
 * these sentences are the entire value of the feature, and a wrong one sends an admin to the wrong place.
 */
export function hugoPreflightLine(res, live = null, voice = undefined) {
  // `reached` is "the check ran"; `ok` is "Hugo is connected". They are different questions and they used
  // to share a name, which made a successful check that found a real fault report itself as a broken check.
  if (res?.reached !== true) return { text: 'The check could not run. That is a problem with this app, not with Hugo.', good: false };
  if (res.configured === false) {
    return { text: 'Hugo has no AI service key. This app cannot see OPENAI_API_KEY, so he is answering from the dataset alone. Set it in the App Store environment and restart.', good: false };
  }
  const model = res.model ? ' (' + res.model + ')' : '';
  if (res.ok && res.kind === '') {
    const more = linksLine(res.links, live, model, voice?.ok === true);
    const gpt = gptLiveLine(res.links, voice);
    // NEVER GREEN UNLESS HUGO CAN CONVERSE (owner, 26 October 2026): any link that failed holds the line off green.
    let good = more.good;
    if (more.good === false || gpt.good === false) good = false;
    else if (gpt.good === true) good = true;
    return { text: 'Hugo is connected' + model + ' and answered in ' + (Number(res.latencyMs) || 0) + 'ms.' + more.text + gpt.text, good };
  }
  // THE PROSE NAMES "THE AI SERVICE", THE LITERALS STAY LITERAL, and that split is not a branding
  // preference. An operator reading this is trying to fix something, and the two things they may have to
  // type - the environment variable and the hostname to allow-list - are useless to them in any form but
  // the exact one. Everything around those is a description of what went wrong, and there the vendor's
  // name tells the reader nothing they can act on.
  //
  // THIS FILE WAS THE ONLY OUTLIER, which is why the fix is one file and not a sweep. The scan diagnostics
  // in `app-v3.js` already read "The model API rejected the key (401). Check ANTHROPIC_API_KEY is a valid,
  // active key" and name `api.anthropic.com` only in the allow-list sentence. Measured before changing
  // anything: this was the one place a vendor name sat in the description rather than in the value.
  return { text: wallText(res.kind, model, 'OPENAI_HUGO_MODEL', res.error), good: false };
}

function wallText(kind, model, variable, error) {
  const WALLS = {
    auth: 'The AI service refused the key. Check the value, and that it has not been replaced or withdrawn.',
    permission: 'The key works but is not allowed to use this model' + model + '. Check the account.',
    model: 'The AI service does not know this model' + model + '. Set ' + variable + ' to one the account can use.',
    rate_limit: 'The AI service asked Hugo to slow down, or the credit is spent. Check the billing account.',
    provider: 'The AI service had a fault of its own. Nothing to fix here; try again shortly.',
    egress: 'This app could not reach the AI service at all. Check the network policy allows api.openai.com.',
  };
  return WALLS[kind] || ('The call to the AI service failed' + (error ? ': ' + error + '.' : '.'));
}

// EVERY LINK A TURN USES (VH-777): the tool turn a typed answer takes, the speech service Talk takes, and the live link
// from this browser to the app, each named when it fails, so a green first call no longer hides a Hugo that cannot talk.
// A later link's refusal is said in its own words: the first call has just shown the key works and the host is reached,
// so "refused the key" or "could not reach the AI service at all" would send the admin to the wrong place.
const AFTER_FIRST = {
  tools: {
    auth: 'The AI service refused the key for a tool turn, though it took it for the first call. Check the account.',
    egress: 'The first call reached the AI service but the tool turn did not. Try again; if it persists, check the network policy allows api.openai.com.',
  },
  speech: {
    auth: 'The AI service refused the key for its speech service, though it took it for the first call. Check the account may use it.',
    egress: 'This app reached the AI service but could not open its speech socket. Check the network policy lets WebSocket (wss) connections through to api.openai.com.',
  },
};
// The wait the probe measured, in whole seconds, so the sentence never states a figure the code did not produce.
function speechTimeout(ms) {
  const secs = Math.round((Number(ms) || 0) / 1000);
  return 'The speech service did not open a session' + (secs >= 1 ? ' within ' + secs + ' seconds' : ' in time')
    + '. Try again; if it persists, check the network policy lets WebSocket (wss) connections through to api.openai.com.';
}
// Off by this deployment's own settings is neither a pass nor a fault, so it takes neither reserved colour (good: null).
const OFF = {
  no_store: ' Talk and voice are off: this app has no database to hold their spend to the daily cap.',
  unpriced: ' Talk and voice are off: a daily spend cap is set and the speech model has no price, so a session could not be held to it. Set OPENAI_REALTIME_MODEL to a priced model, or remove the cap.',
};
// Why the app's own link did not open, in words.
const SOCKET_HOW = Object.freeze({
  timeout: 'it did not answer within 8 seconds',
  refused: 'it was refused',
});
function linksLine(links, live, model, liveVoiceOk = false) {
  if (!links || typeof links !== 'object') return { text: '', good: true };
  const tools = links.tools || {};
  if (tools.ok === false && tools.kind !== 'not_run') {
    const why = AFTER_FIRST.tools[tools.kind] || wallText(tools.kind, model, 'OPENAI_HUGO_MODEL', tools.error);
    return { text: ' But his tools did not answer, so he cannot look anything up. ' + why, good: false };
  }
  const toolsMs = tools.ok ? ' His tools answered in ' + (Number(tools.latencyMs) || 0) + 'ms.' : '';
  const speech = speechLine(links.realtime || {}, live, liveVoiceOk);
  return { text: toolsMs + speech.text, good: speech.good };
}

// The speech service: off by this deployment's settings, refused, or answered, and then the browser's live link. Where his
// live voice (WebRTC) works, Talk runs over it (VH-865), so a refused socket is a note for the platform team, not a fault.
function speechLine(speech, live, liveVoiceOk = false) {
  if (speech.off) return { text: OFF[speech.reason] || '', good: OFF[speech.reason] ? null : true };
  const voiceModel = speech.model ? ' (' + speech.model + ')' : '';
  if (speech.ok !== true) {
    const refused = 'The AI service refused the session' + (speech.code ? ' (' + speech.code + ')' : '') + '.';
    let why = AFTER_FIRST.speech[speech.kind] || wallText(speech.kind, voiceModel, 'OPENAI_REALTIME_MODEL', '');
    if (speech.kind === 'refused') why = refused;
    if (speech.kind === 'timeout') why = speechTimeout(speech.latencyMs);
    return { text: ' His speech service' + voiceModel + ' did not answer, so Talk and voice will not work. ' + why, good: false };
  }
  const heard = ' His speech service' + voiceModel + ' answered in ' + (Number(speech.latencyMs) || 0) + 'ms';
  if (live?.ok === true) return { text: heard + ', and this browser reached his live link.', good: true };
  if (live?.ok !== false) return { text: heard + '.', good: true };
  const how = SOCKET_HOW[live.why] || SOCKET_HOW.refused;
  if (liveVoiceOk) {
    return { text: heard + '. Talk runs over his live voice here. The app\'s own link, which Talk falls back to, could not open from this browser (' + how + '): a note for the platform team, whose route must let WebSocket upgrades through to /api/v3/hugo/realtime.', good: true };
  }
  return { text: heard + ', but this browser could not open his live link (' + how + '), so Talk and voice will not work here. The App Store route must let WebSocket upgrades through to /api/v3/hugo/realtime.', good: false };
}

/**
 * THE LIVE LINK FROM THIS BROWSER (VH-777). The check socket (`mode=check`) passes the same gate as Talk's, is sent one
 * `vh.check` frame and closed, with nothing dialled upstream: it answers whether the route to this app lets a WebSocket
 * upgrade through, which no server-side check can. Resolves `{ ok: true }` or `{ ok: false, why: 'refused' | 'timeout' }`.
 */
export function checkLiveSocket({ makeSocket, url, waitMs = 8000, setTimer = setTimeout, clearTimer = clearTimeout }) {
  return new Promise((resolve) => {
    let ws = null;
    let done = false;
    let timer = null;
    const finish = (out) => {
      if (done) return;
      done = true;
      clearTimer(timer);
      try { ws?.close(); } catch { /* already gone */ }
      resolve(out);
    };
    timer = setTimer(() => finish({ ok: false, why: 'timeout' }), waitMs);
    try { ws = makeSocket(url); } catch { finish({ ok: false, why: 'refused' }); return; }
    ws.addEventListener('message', (e) => {
      let frame = null;
      try { frame = JSON.parse(String(e.data)); } catch { frame = null; }
      if (frame?.type === 'vh.check') finish({ ok: frame.ok === true, ...(frame.ok === true ? {} : { why: 'refused' }) });
    });
    ws.addEventListener('error', () => finish({ ok: false, why: 'refused' }));
    ws.addEventListener('close', () => finish({ ok: false, why: 'refused' }));
  });
}

// ---- GPT-LIVE, LINK BY LINK (VH-777 Lane V) ------------------------------------------------------------------------
// The owner's ask: the check tests what Hugo uses, each link by name, and is never green unless he can converse. The
// server half names the key's reach over Hugo's models and whether Live is on (`links.models`, `links.live`); the
// browser half (`checkLiveVoice`, below) makes a real WebRTC connect through every link Talk takes.

const LIVE_OFF = {
  no_store: ' His live voice is off: this app has no database to hold its spend to the daily cap.',
  unpriced: ' His live voice is off: a daily spend cap is set and the live models have no price, so a session could not be held to it.',
};
const HANDSHAKE = {
  auth: 'the AI service refused the key for a live session. Check the account may use GPT-Live.',
  permission: 'the key is not allowed to use the live model. Check the account.',
  model: 'the AI service does not offer the live model to this key. Set OPENAI_LIVE_MODEL to one the account can use.',
  rate_limit: 'the AI service asked Hugo to slow down, or the credit is spent. Check the billing account.',
  timeout: 'the AI service did not answer in time. Try again shortly.',
  egress: 'this app could not reach the AI service. Check the network policy allows api.openai.com.',
  provider: 'the AI service had a fault of its own. Try again shortly.',
};
const tag = (kind, code) => (kind || code ? ' (' + [kind, code].filter(Boolean).join(', ') + ')' : '');

function liveLinkFailed(voice) {
  const why = tag(voice.kind, voice.code);
  switch (voice.failed) {
    case 'config': return LIVE_OFF[voice.reason] || ' His live voice is not set up on this app.';
    case 'sideband': return ' His live voice started, but this app could not attach its control link to it' + why + ', so it could not run his tools. Check the network policy lets WebSocket (wss) connections out to api.openai.com.';
    case 'webrtc': return ' His live voice started, but this browser\'s audio link did not connect (ICE ' + (voice.ice || 'unknown') + ', ' + (voice.state || 'unknown') + (voice.timedOut ? ', timed out' : '') + '). This network may block the audio route to OpenAI; Talk will use the app\'s own link instead.';
    case 'delegation': return ' His live voice connected, but the brain behind it did not complete a turn with a tool' + why + ', so he cannot look anything up by voice.';
    default: return ' His live voice did not start: ' + (HANDSHAKE[voice.kind] || 'the AI service refused the session' + why + '.');
  }
}

function gptLiveLine(links, voice) {
  const on = links?.live;
  if (!on) return { text: '', good: null };
  const reach = links.models;
  const missing = Array.isArray(reach?.missing) ? reach.missing.filter((m) => m === on.model || m === on.brain) : [];
  const unreached = missing.length ? ' The key cannot reach ' + missing.join(' or ') + '.' : '';
  if (on.off) return { text: LIVE_OFF[on.reason] || '', good: null };
  if (voice === undefined) return { text: unreached, good: missing.length ? false : null };
  if (voice === null) return { text: unreached + ' His live voice could not be tried from this browser: it needs WebRTC.', good: false };
  if (voice.ok !== true) return { text: unreached + liveLinkFailed(voice), good: false };
  const said = ' His live voice (' + on.model + ' with ' + on.brain + ') connected in ' + (Number(voice.connectMs) || 0) + 'ms, ICE ' + voice.ice
    + ', and a spoken turn ran ' + voice.tool + ' in ' + (Number(voice.delegationMs) || 0) + 'ms.';
  return { text: unreached + said, good: missing.length === 0 };
}

// A session that did not start, named by the link that broke; anything else is the handshake's.
const NAMED_LINKS = new Set(['config', 'sideband', 'webrtc']);
function startFailure(err) {
  const { link, kind = '', code = '', reason = '', ice = '', state = '', timedOut = false } = err ?? {};
  const failed = NAMED_LINKS.has(link) ? link : 'handshake';
  return { ok: false, failed, kind, code, reason, ice, state, timedOut: Boolean(timedOut) };
}

/**
 * THE BROWSER HALF OF THE CHECK (VH-777): a real Live session through every link Talk takes, the handshake, the
 * server's sideband, this browser's WebRTC link and one delegated turn that must call a tool, then closed. It needs no
 * microphone. Resolves `{ ok: true, ... }` or `{ ok: false, failed: <link>, ... }`, never rejects.
 */
export async function checkLiveVoice({ post, RTCPeerConnection, domain, now = () => Date.now(), timeoutMs }) {
  const t0 = now();
  let live = null;
  try {
    live = await startLive({ post, RTCPeerConnection, getUserMedia: null, audio: null, domain, voice: '', check: true, ...(timeoutMs ? { timeoutMs } : {}) });
  } catch (err) {
    return startFailure(err);
  }
  const connectMs = now() - t0;
  const { ice, state } = live.states();
  let delegation = null;
  try {
    const r = await post(LIVE_CHECK_ROUTE, { sessionId: live.sessionId });
    delegation = r?.status === 200 ? r.body?.delegation : null;
  } catch { delegation = null; }
  await live.end();
  if (delegation?.ok !== true) return { ok: false, failed: 'delegation', kind: delegation?.kind ?? 'not_run', code: delegation?.code ?? '', ice, state };
  return { ok: true, ice, state, connectMs, tool: String(delegation.tool || ''), delegationMs: Number(delegation.latencyMs) || 0 };
}
