// HUGO'S VOICE ON GPT-LIVE, THE BROWSER HALF (VH-777 Lane V). The browser makes a WebRTC offer, posts it to THIS app
// (`/api/v3/hugo/live`), and sets the answer the app hands back. Audio then flows between the browser and OpenAI over
// WebRTC; the browser holds no key and makes no HTTP call to any other origin, so `connect-src 'self'` stands. Its data
// channel may only mute and unmute (the server locks it when it creates the session), and carries the two captions.
//
// What OpenAI's SDK does, and so what this does (`openai` 7.43.0, src/lib/webrtc/connection.ts, read 26 October 2026):
// the data channel is named `oai-events` and made before the offer; the offer is sent as soon as the local description
// is set; the link is ready when the peer connection is `connected` AND the channel is `open`.
//
// A PURE MODULE: every browser object is injected, so the whole path, its timeout and its failures are unit-tested.

export const LIVE_ROUTE = '/api/v3/hugo/live';
export const LIVE_END_ROUTE = '/api/v3/hugo/live/end';
export const LIVE_CHECK_ROUTE = '/api/v3/hugo/live/check';
export const LIVE_CONNECT_MS = 15_000;
export const LIVE_QUIET_MS = 1_200; // Live sends no end-of-reply event, so a reply is settled after this much quiet

/** An error naming the link that broke, for the notice and for the check. */
export function liveError(link, extra = {}) {
  return Object.assign(new Error('live ' + link + ' failed'), { link, ...extra });
}

// Resolve when the peer is connected and the channel open; reject, naming the ICE and connection states, on a failed
// or closed peer or when the wait runs out. Cleans up its own listeners and timer either way.
export function waitConnected(pc, dc, { timeoutMs = LIVE_CONNECT_MS, setTimer = setTimeout, clearTimer = clearTimeout } = {}) {
  return new Promise((resolve, reject) => {
    const states = () => ({ ice: String(pc.iceConnectionState || ''), state: String(pc.connectionState || '') });
    let timer = null;
    const done = (fn, arg) => {
      clearTimer(timer);
      pc.removeEventListener?.('connectionstatechange', check);
      dc.removeEventListener?.('open', check);
      fn(arg);
    };
    function check() {
      if (pc.connectionState === 'connected' && dc.readyState === 'open') done(resolve, states());
      else if (pc.connectionState === 'failed' || pc.connectionState === 'closed') done(reject, liveError('webrtc', states()));
    }
    timer = setTimer(() => done(reject, liveError('webrtc', { ...states(), timedOut: true })), timeoutMs);
    pc.addEventListener('connectionstatechange', check);
    dc.addEventListener('open', check);
    check();
  });
}

const statesOf = (pc) => ({ ice: String(pc.iceConnectionState || ''), state: String(pc.connectionState || '') });

// The microphone, or none for the connection check, which offers to send and receive audio with no track: that needs
// no permission prompt and still tests every link but the operator's own microphone.
async function microphone(getUserMedia) {
  if (!getUserMedia) return null;
  try { return await getUserMedia({ audio: true }); } catch (err) { throw liveError('microphone', { name: String(err?.name || '') }); }
}

// The peer: Hugo's audio into the <audio> element, the microphone (or an empty audio offer) out, and the data channel.
function openPeer(PC, stream, audio, onEvent) {
  const pc = new PC();
  pc.addEventListener('track', (e) => { if (audio) audio.srcObject = e.streams?.[0] || null; });
  if (stream) for (const track of stream.getTracks()) pc.addTrack(track, stream);
  else pc.addTransceiver('audio', { direction: 'sendrecv' });
  const dc = pc.createDataChannel('oai-events');
  dc.addEventListener('message', (e) => {
    let event = null;
    try { event = JSON.parse(String(e.data)); } catch { return; }
    if (event && typeof event.type === 'string') onEvent(event);
  });
  return { pc, dc };
}

// This tab's id, so the server keeps one Live session per operator AND tab: on the shared team token every operator is
// the same sign-in, and keyed by that alone one operator's Talk closed another's (2.20.0 round one, security MINOR 4).
// Held for the tab's life, so a reload replaces the session it left behind rather than opening a second.
let tabId = '';
export function liveTabId(store = globalThis.sessionStorage, make = () => globalThis.crypto.randomUUID()) {
  if (tabId) return tabId;
  try { tabId = store?.getItem('vh_live_tab') || ''; } catch { tabId = ''; }
  if (!/^[\w-]{8,64}$/.test(tabId)) {
    tabId = make();
    try { store?.setItem('vh_live_tab', tabId); } catch { /* private mode: the id lives for this page */ }
  }
  return tabId;
}

// The offer to this app, and its answer; a refusal is thrown naming the link the server named.
async function exchange(post, pc, fields) {
  await pc.setLocalDescription(await pc.createOffer());
  const res = await post(LIVE_ROUTE, { sdp: pc.localDescription?.sdp || '', tab: liveTabId(), ...fields });
  const body = res?.body || {};
  if (res?.status !== 201 || typeof body.sdp !== 'string') {
    throw liveError(body.link || 'handshake', { status: Number(res?.status) || 0, kind: body.kind || '', code: body.code || '', reason: body.reason || '', error: typeof body.error === 'string' ? body.error : '' });
  }
  return body;
}

/**
 * Start a Live session. `post(path, body)` is the app's authenticated JSON POST and resolves `{ status, body }`.
 * Resolves the session handle; rejects with `liveError(link)` naming what failed: 'microphone', 'handshake' (or the
 * link the server named), or 'webrtc'. Everything opened before the failure is released. `getUserMedia: null` is the
 * connection check's: no microphone.
 */
export async function startLive({ post, RTCPeerConnection: PC, getUserMedia, audio, domain, voice, check = false, onEvent = () => {}, onDrop = () => {}, timeoutMs = LIVE_CONNECT_MS, setTimer = setTimeout, clearTimer = clearTimeout }) {
  const stream = await microphone(getUserMedia);
  let peer = null;
  let sessionId = '';
  let ended = false;
  let lengthTimer = null;
  const release = () => {
    try { peer?.pc.close(); } catch { /* already closed */ }
    try { stream?.getTracks().forEach((t) => t.stop()); } catch { /* already stopped */ }
  };
  const end = async () => {
    if (ended) return;
    ended = true;
    // The length timer goes with the session (2.20.0 round two, engineering MINOR 10): it could not act once ended, but it
    // kept the finished session's peer and stream referenced until the limit.
    clearTimer(lengthTimer);
    release();
    if (sessionId) await post(LIVE_END_ROUTE, { sessionId }).catch(() => {});
  };
  try {
    peer = openPeer(PC, stream, audio, onEvent);
    const { pc, dc } = peer;
    const body = await exchange(post, pc, { domain, voice, check });
    sessionId = String(body.sessionId || '');
    await pc.setRemoteDescription({ type: 'answer', sdp: body.sdp });
    const connected = await waitConnected(pc, dc, { timeoutMs, setTimer, clearTimer });
    // A link that drops after it connected (the network, or the server ending the session) is said once, by the caller.
    pc.addEventListener('connectionstatechange', () => {
      if (!ended && (pc.connectionState === 'failed' || pc.connectionState === 'closed')) onDrop(statesOf(pc));
    });
    // THE BROWSER HOLDS THE SESSION'S LENGTH TOO (2.20.0 security gate): it ends its own audio link at the limit the server
    // sent, so a session whose server link dropped cannot run on past it.
    const limit = Number(body.maxSessionMs);
    if (Number.isFinite(limit) && limit > 0) {
      lengthTimer = setTimer(() => { if (!ended) { const at = statesOf(pc); end(); onDrop({ ...at, reason: 'session_length' }); } }, limit);
      lengthTimer?.unref?.();
    }
    return {
      sessionId, pc, dc, stream, connected, model: body.model, brain: body.brain, end,
      states: () => statesOf(pc),
      mute(on) { try { dc.send(JSON.stringify({ type: on ? 'session.input_audio.mute' : 'session.input_audio.unmute' })); } catch { /* channel gone */ } },
    };
  } catch (err) {
    end();
    throw err?.link ? Object.assign(err, { sessionId }) : liveError('webrtc', { detail: String(err?.name || '') });
  }
}

/**
 * Live's captions turned into the rail's own actions, the ones the relay's events already map to: `{ heard }` once the
 * operator's words are complete, `{ transcript }` for each piece of Hugo's reply, `{ done }` when a reply has settled.
 * Live marks no turn ends ("these events do not define complete turns", LiveInputTranscriptDelta), so the operator's
 * words are complete when Hugo starts to answer, and a reply has settled after a quiet spell, or when the operator
 * starts speaking over it (barge-in: GPT-Live stops itself; the rail stops the caret with it).
 */
export function createLiveCaptions({ emit, quietMs = LIVE_QUIET_MS, setTimer = setTimeout, clearTimer = clearTimeout }) {
  let heard = '';
  let speaking = false;
  let quiet = null;
  const settle = () => {
    clearTimer(quiet);
    quiet = null;
    if (speaking) { speaking = false; emit({ done: true }); }
  };
  return {
    feed(event) {
      const delta = typeof event?.delta === 'string' ? event.delta : '';
      if (event?.type === 'session.input_transcript.delta' && delta) {
        if (speaking) settle();
        heard += delta;
      } else if (event?.type === 'session.output_transcript.delta' && delta) {
        if (heard.trim()) emit({ heard: heard.trim() });
        heard = '';
        speaking = true;
        emit({ transcript: delta });
        clearTimer(quiet);
        quiet = setTimer(settle, quietMs);
      } else if (event?.type === 'session.closed') {
        settle();
      }
    },
    settle,
  };
}

// WHY THE MICROPHONE WAS REFUSED (VH-906, owner, 2026-10-28, an iPhone: "says it's disabled but browser settings say it is
// enabled"). `name` is the browser's error, `permission` what the Permissions API says of the microphone ('denied',
// 'granted', 'prompt', or nothing where it cannot say), `framed` whether the app runs inside another page. Only a real
// 'denied' is told to allow it; a refusal while the site is allowed is the app open inside another app.
const OPEN_IT_ITSELF = 'Open the app in Safari or Chrome itself, not inside another app, and try Talk again.';
function micRefusalText({ name = '', permission = '', framed = false } = {}) {
  if (name === 'NotFoundError' || name === 'OverconstrainedError') return 'Hugo could not find a working microphone. Check one is connected, then try Talk again.';
  if (name === 'NotReadableError' || name === 'AbortError') return 'Hugo could not use the microphone: it may be in use by another app. Close that app and try Talk again.';
  if (framed || name === 'SecurityError') return 'The microphone is blocked because the app is open inside another app or a frame. ' + OPEN_IT_ITSELF;
  if (permission === 'denied') return 'Hugo could not use the microphone. Allow the microphone for this site in the browser\'s settings and try Talk again.';
  if (permission === 'granted' || permission === 'prompt') return 'Hugo could not use the microphone, although this site is allowed to. ' + OPEN_IT_ITSELF;
  return 'Hugo could not use the microphone. Allow the microphone for this site; if it is already allowed, open the app in Safari or Chrome itself, not inside another app.';
}

/**
 * The operator's notice for a Live failure, by the link that broke. Pure, so the wording is tested. `fallback` says
 * whether the relay will be tried next, so the notice never promises a path that is not there.
 */
export function liveFailureText(err, { fallback = true } = {}) {
  const link = err?.link || '';
  if (link === 'microphone') return micRefusalText(err);
  // Which limit a 429 met is in the server's body (VH-902): only the spent day is until tomorrow.
  if (err?.status === 429 && err.error === 'daily_cap_reached') return 'Hugo has reached today\'s spending limit for the AI service, so Talk is off until tomorrow.';
  if (err?.status === 429) return 'That is more Talk starts than Hugo takes in a minute. Wait a moment and press Talk again.';
  if (link === 'config' && fallback) return '';
  const then = fallback ? ', so Talk is using the app\'s own link instead.' : '. Try again, or run "Check Hugo\'s connection" in Settings.';
  if (link === 'webrtc') return 'Hugo\'s live voice could not connect from this network' + then;
  return 'Hugo\'s live voice did not start (' + link + (err?.kind ? ', ' + err.kind : '') + ')' + then;
}
