// HUGO'S STARTER CHIPS (PLAN-9.5 I8): three tappable openings derived from data ALREADY IN STATE, so the
// idle rail offers a place to begin rather than a blank box. Pure and DOM-free: given the cached whole set
// (or nothing) and the analytics report (or nothing), it returns three { label, sentence } pairs; the label
// is what the chip shows, the sentence is what tapping it puts in Hugo's box for the operator to send or
// edit. Nothing runs on a tap: confirm-first is unchanged.
//
// HONEST BY CONSTRUCTION. A figure appears in a label only when the rows it is counted from are held; with
// nothing loaded each chip falls back to the same opening with no number in it, never an invented one.
//   1. Onboarding headroom: the capability family with the most vendors not yet in the GDM.
//   2. Freshness: how many records are past the 18-month verification window (the cockpit's own fold).
//   3. Coverage: the widest coverage gap the analytics named, on the map; else the In-GDM set on the map.

import { deriveCockpit } from '../lib-v3.js';
import { FAMILY, familiesOf } from './fingerprint-glyph.js';

// The family with the most vendors NOT in the GDM, from board rows ({ record }) or bare records; ties break on
// the key so the answer is deterministic. Null when no row carries a family.
export function familyHeadroom(rows) {
  const counts = new Map();
  for (const row of Array.isArray(rows) ? rows : []) {
    const r = row?.record || row || {};
    if (r.gdm === 'In GDM') continue;
    for (const key of familiesOf(r.product_types, r._domain)) counts.set(key, (counts.get(key) || 0) + 1);
  }
  let best = null;
  for (const [key, count] of counts) {
    if (!best || count > best.count || (count === best.count && key < best.key)) best = { key, count };
  }
  return best ? { key: best.key, name: FAMILY[best.key]?.name || best.key, count: best.count } : null;
}

// "No records", "1 record", "N records": a genuine zero is stated in words rather than as a bare "0".
function recordCount(n) {
  if (n === 0) return 'No records';
  if (n === 1) return '1 record';
  return n + ' records';
}

export function starterChips({ rows, analytics } = {}) {
  const held = Array.isArray(rows) ? rows : null;
  const chips = [];
  const headroom = held ? familyHeadroom(held) : null;
  chips.push(headroom
    ? { label: headroom.name + ' scoped vendors not in the GDM (' + headroom.count + ')', sentence: 'the ' + headroom.name + ' scoped vendors that are not in the GDM' }
    : { label: 'Scoped vendors not in the GDM', sentence: 'the scoped vendors that are not in the GDM' });
  const staleCount = held ? recordCount(deriveCockpit(held).stale) : 'Records';
  chips.push({ label: staleCount + ' past 18 months since verification', sentence: 'the companies not verified in the last 18 months' });
  const gap = analytics?.answers?.gap?.region;
  chips.push(gap
    ? { label: 'The coverage gap in ' + gap + ', on the map', sentence: 'the companies covering ' + gap + ', on a map' }
    : { label: 'In GDM vendors, on the map', sentence: 'the vendors in the GDM, on a map' });
  return chips;
}
