// VH-765: THE PHONE'S HUGO, the owner's approved "Orb" (docs/mockups/2026-10-19-dev3-vh765/round3-blue/, "Approved, Orb",
// 2026-10-19). On a screen 640 pixels wide or narrower the app opens straight into Hugo, asked across all domains (the
// owner's rule: "a HUGO interface that allows questions to be asked across all domains"), with every control in the lower
// half under the thumb, Bluestaq blues only, and answers in short plain sentences, one glass card per domain.
//
// Loaded on first use by `public/app-v3.js` (`maybeEnterPhoneHugo`), never on the desktop's first paint. It moves the
// rail's own parts into the phone screen rather than drawing copies (the review, the starters and the composer), and
// puts every one back when the screen is taken down. A PHONE SHOWS HUGO ONLY (VH-811): the rail's Minimise is hidden
// there rather than turned into a way out, and only the desktop's Orb keeps it, in the dock's right-hand slot.

import { esc } from '../lib-v3.js';

// How long a press is held before it is a "hold to talk" rather than a tap.
const HOLD_MS = 450;

const MIN_SVG = '<svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 6l6 6-6 6"/></svg>';
const TICK_SVG = '<svg class="orb-tick" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

// Two openings in short words that read the same in every domain. A tap asks at once.
const STARTERS = Object.freeze([
  { label: 'Not in the GDM yet', ask: 'the scoped vendors that are not in the GDM' },
  { label: 'Not checked in 18 months', ask: 'the companies not verified in the last 18 months' },
]);

const domainList = (domains) => (Array.isArray(domains) ? domains : []).filter((d) => d && typeof d.id === 'string' && d.id);
// A domain's colour class: the ids carry underscores (`natural_resources`), the tokens hyphens.
const hueClass = (id) => 'h-' + String(id).replaceAll('_', '-');
const labelIn = (domains, id) => domainList(domains).find((d) => d.id === id)?.label || id;

/** What the scope button and the answers say: "All 7 domains", or the one domain chosen. */
export function scopeText(scope, domains) {
  return scope === 'all' ? 'All ' + domainList(domains).length + ' domains' : labelIn(domains, scope);
}

/** The phone screen: the greeting (reading only, top half) and the dock (domains, the orb, and the desktop's Minimise). */
/** What the orb says about the microphone (VH-905), by phase. */
export const MIC_WORDS = Object.freeze({ off: '', open: 'Microphone on. Hugo is listening.', hearing: 'Hugo hears you.' });

/**
 * The orb's microphone as the operator sees and hears it (VH-905): green only once the browser says the microphone is
 * open, brighter while it hears sound, off on end or error. `phase` is 'off', 'open' or 'hearing'; anything else is off.
 */
export function setOrbMic(orb, say, phase) {
  const p = Object.hasOwn(MIC_WORDS, phase) ? phase : 'off';
  const open = p !== 'off';
  const hearing = p === 'hearing';
  orb.classList.toggle('is-mic-open', open);
  orb.classList.toggle('is-hearing', hearing);
  if (say?.textContent !== undefined && say.textContent !== MIC_WORDS[p]) say.textContent = MIC_WORDS[p];
}

export function phoneScreenHtml({ domains, scope = 'all', canTalk = false, desktop = false } = {}) {
  // A mouse clicks (2.20.0 round one, design MINOR 11): the desktop's Orb said "Tap" to a mouse user.
  const press = desktop ? 'Click' : 'Tap';
  const n = domainList(domains).length;
  const one = scope !== 'all';
  return '<div class="orb-read">'
    + '<section class="orb-hero"><p class="orb-eyebrow">Hugo, your data co-pilot</p>'
    + '<h2 class="orb-title">Ask me about<br><em>any company.</em></h2>'
    + '<p class="orb-sub" data-phone-sub>' + esc(one ? 'I search ' + labelIn(domains, scope) + '.' : 'I search all ' + n + ' domains at once.') + '</p></section>'
    + '</div>'
    + '<div class="orb-reach"><div class="orb-starters">'
    + STARTERS.map((c) => '<button type="button" class="orb-starter" data-phone-ask="' + esc(c.ask) + '">' + esc(c.label) + '</button>').join('')
    + '</div><div class="orb-dock">'
    + '<button type="button" class="orb-side" data-phone-act="scope" aria-haspopup="dialog" aria-label="' + esc('Asking ' + scopeText(scope, domains) + '. Choose') + '">'
    + '<span class="orb-face"><span class="orb-ring7" aria-hidden="true"></span><b aria-hidden="true" data-phone-mark>' + esc(one ? labelIn(domains, scope).slice(0, 1) : String(n)) + '</b></span>'
    + '<span class="orb-cap" aria-hidden="true" data-phone-cap>' + esc(one ? labelIn(domains, scope) : 'All domains') + '</span></button>'
    + '<div class="orb-core"><button type="button" class="orb-btn" data-phone-act="orb" aria-label="' + esc(canTalk ? 'Ask Hugo. ' + press + ' to type, hold to talk' : 'Ask Hugo. ' + press + ' to type') + '">'
    + '<img src="/hugo.png" alt=""></button>'
    + '<span class="orb-hint" aria-hidden="true">' + (canTalk ? press + ' to ask · hold to talk' : press + ' to ask') + '</span>'
    + '<span class="sr-only" data-phone-mic role="status" aria-live="polite"></span></div>'
    + '<span class="orb-full-slot"></span>'
    + '</div></div>';
}

/** Choose a domain: a sheet from the bottom, every choice under the thumb. */
export function domainSheetHtml({ domains, scope = 'all' } = {}) {
  const pick = (id, label, extra) => '<button type="button" class="orb-pick' + extra + '" data-phone-scope="' + esc(id) + '" aria-pressed="'
    + (scope === id ? 'true' : 'false') + '">' + esc(label) + (scope === id ? TICK_SVG : '') + '</button>';
  return '<div class="orb-scrim" data-phone-act="close"></div>'
    + '<div class="orb-sheet" role="dialog" aria-modal="true" aria-labelledby="orb-sheet-t"><span class="orb-grab" aria-hidden="true"></span>'
    + '<h2 id="orb-sheet-t">Ask about</h2><div class="orb-grid">'
    + pick('all', scopeText('all', domains), ' is-all')
    + domainList(domains).map((d) => pick(d.id, d.label || d.id, ' ' + esc(hueClass(d.id)))).join('')
    + '</div><button type="button" class="orb-close" data-phone-act="close">Close</button></div>';
}

/** Hugo's answer on the phone, head part: the scope, the sentence without its reference marks, and the check. */
export function phoneAnswerHeadHtml(out, scopeLabel) {
  const o = out && typeof out === 'object' ? out : {};
  const text = String(o.answer || '').replaceAll(/\[R\d{1,3}\]/g, '').replaceAll(/ {2,}/g, ' ').replaceAll(' .', '.').replaceAll(' ,', ',').trim();
  const checked = o.verification?.ok === true ? '<span class="hugo-verify hugo-verify-ok">Checked against the dataset</span>' : '';
  return '<span class="orb-scope-tag">' + esc(scopeLabel || '') + '</span>'
    + '<div class="hugo-agent"><span class="hugo-turn-text">' + esc(text) + '</span>' + checked + '</div>';
}

/** The vendors an answer names, one glass card per domain, in the order the answer gave them. */
export function phoneAnswerCardsHtml(out, labelOf = (id) => id) {
  const refs = Array.isArray(out?.citations) ? out.citations : [];
  const byDomain = new Map();
  for (const c of refs) {
    const domain = typeof c?.domain === 'string' && c.domain ? c.domain : '';
    if (!domain || !c.id) continue;
    if (!byDomain.has(domain)) byDomain.set(domain, []);
    byDomain.get(domain).push(c);
  }
  return [...byDomain].map(([domain, list]) => '<section class="orb-card ' + esc(hueClass(domain)) + '" aria-label="' + esc(labelOf(domain)) + '">'
    + '<h3 class="orb-card-head">' + esc(labelOf(domain)) + '<span class="orb-count">' + list.length + (list.length === 1 ? ' company' : ' companies') + '</span></h3>'
    + '<div class="orb-refs">' + list.map((c) => '<button type="button" class="orb-ref" data-phone-record="' + esc(c.id) + '" data-phone-domain="' + esc(domain) + '">'
      + esc(c.name || c.id) + '</button>').join('') + '</div></section>').join('');
}

/**
 * Builds the phone screen into the rail and wires it. The app's own parts move in and are put back by `unmount`.
 * @returns {{ setScope: (scope: string) => void, unmount: () => void }}
 */
export function mountPhoneHugo({ doc, rail, domains, scope = 'all', speech = null, talk = null, desktop = false, onAsk, onScope, onOpenRecord }) {
  const panel = doc.getElementById('hugo-rail-panel');
  let current = scope;
  const screen = doc.createElement('div');
  screen.className = 'orb-screen';
  const live = typeof talk?.start === 'function' && typeof talk?.stop === 'function';
  screen.innerHTML = phoneScreenHtml({ domains, scope, canTalk: live || typeof speech === 'function', desktop });
  panel.append(screen);
  rail.classList.add('orb-ui');

  // The app's own parts, moved in; where each came from is kept so leaving puts it back.
  const moved = [];
  const move = (node, into, before = null) => {
    if (!node) return;
    moved.push({ node, parent: node.parentNode, next: node.nextSibling });
    if (before) before.before(node);
    else into.append(node);
  };
  const reach = screen.querySelector('.orb-reach');
  const dock = screen.querySelector('.orb-dock');
  move(doc.getElementById('hugo-review'), screen.querySelector('.orb-read'));
  move(rail.querySelector('.hugo-composer'), reach, dock);
  const full = doc.getElementById('hugo-collapse');
  const fullWas = full ? { cls: full.className, html: full.innerHTML, label: full.getAttribute('aria-label'), hidden: full.hidden } : null;
  if (full && desktop) {
    move(full, dock, screen.querySelector('.orb-full-slot'));
    full.className = 'orb-side';
    // ON THE DESKTOP (owner, 26 October 2026: desktop Hugo looks like the phone's, approved from a rendered mockup with
    // Minimise in this slot) the full app is already behind it, so the control stays Minimise and does its own job.
    full.setAttribute('aria-label', 'Minimise Hugo');
    full.innerHTML = '<span class="orb-face">' + MIN_SVG + '</span><span class="orb-cap" aria-hidden="true">Minimise</span>';
  } else if (full) {
    // On a phone there is no way out of Hugo (VH-811), so the rail's Minimise is hidden while the phone screen stands.
    full.hidden = true;
  }

  const input = doc.getElementById('hugo-input');
  const typing = () => { screen.classList.add('is-typing'); input?.focus(); };
  const fold = () => { screen.classList.remove('is-typing'); input?.blur(); };
  // The sheet is modal, so what lies behind it is inert while it is open: Tab stays in the sheet (2.12.0 design round three).
  const behind = (on) => { for (const el of screen.querySelectorAll('.orb-read, .orb-reach')) el.inert = on; };
  const closeSheet = () => { behind(false); screen.querySelector('.orb-sheet-host')?.remove(); screen.querySelector('[data-phone-act="scope"]')?.focus(); };
  const openSheet = () => {
    const host = doc.createElement('div');
    host.className = 'orb-sheet-host';
    host.innerHTML = domainSheetHtml({ domains, scope: current });
    screen.append(host);
    behind(true);
    host.querySelector('[aria-pressed="true"]')?.focus();
  };

  // TAP TO TYPE, HOLD TO TALK. A hold longer than HOLD_MS listens through the browser's own speech service (whether
  // that stays on the device is `TBC, re-verify` per browser) and sends what it heard; a shorter press opens the box. Without a speech service the orb is tap only.
  const orb = screen.querySelector('[data-phone-act="orb"]');
  let holdTimer = 0;
  // A hold ends in a click too: the press that listened must not also open the box.
  let held = false;
  let listening = null;
  const mic = (phase) => setOrbMic(orb, screen.querySelector('[data-phone-mic]'), phase);
  const stopListening = () => { try { listening?.stop(); } catch { /* already stopped */ } };
  // HUGO SPEAKS ON THE PHONE (VH-777 Lane V). Where GPT-Live is on, a hold starts a spoken conversation with Hugo, who
  // answers aloud, and it carries on hands-free until a tap ends it; the browser's speech service is the fallback.
  let talking = false;
  orb.addEventListener('pointerdown', () => {
    // Every press starts unheld: a hold slid off the orb ends with no click on it to clear the flag (2.13.0 round one).
    held = false;
    if (live) {
      // The microphone is asked for in the press itself (VH-906): asked from the timer, iOS refuses it whatever the site's
      // setting. The hold's Talk takes what the press got; a short tap gives it back (`release`).
      if (!talking) { talk.prime?.(); holdTimer = setTimeout(() => { holdTimer = 0; held = true; talk.start(); }, HOLD_MS); }
      return;
    }
    if (typeof speech !== 'function') return;
    holdTimer = setTimeout(() => {
      holdTimer = 0;
      held = true;
      try {
        const rec = new speech();
        rec.lang = 'en-GB';
        rec.interimResults = false;
        rec.onresult = (e) => { const said = String(e.results?.[0]?.[0]?.transcript || '').trim(); if (said) onAsk(said); };
        // Green on the browser's own word that the microphone is open, not on the press (VH-905).
        rec.onaudiostart = () => mic('open');
        rec.onsoundstart = rec.onspeechstart = () => mic('hearing');
        rec.onsoundend = rec.onspeechend = () => { if (listening === rec) mic('open'); };
        rec.onerror = () => mic('off');
        rec.onend = () => { listening = null; orb.classList.remove('is-listening'); mic('off'); };
        listening = rec;
        orb.classList.add('is-listening');
        rec.start();
      } catch { listening = null; orb.classList.remove('is-listening'); mic('off'); }
    }, HOLD_MS);
  });
  const release = () => { if (holdTimer) { clearTimeout(holdTimer); holdTimer = 0; talk?.release?.(); } stopListening(); };
  orb.addEventListener('pointerup', release);
  orb.addEventListener('pointercancel', release);
  orb.addEventListener('pointerleave', release);
  orb.addEventListener('contextmenu', (e) => e.preventDefault());

  const api = {
    /** Open the box for typing (the board's Edit hands a sentence back to Hugo, VH-777's desktop Orb). */
    openTyping: typing,
    /** Live Talk started or ended (the app calls this as it goes): the orb shows it and a tap now ends it. */
    setTalking(on) {
      talking = Boolean(on);
      orb.classList.toggle('is-listening', talking);
      if (!talking) mic('off');
      orb.setAttribute('aria-label', talking ? 'Hugo is listening. Tap to stop' : 'Ask Hugo. Tap to type, hold to talk');
    },
    /** The microphone's phase on Live Talk (VH-905): 'open' once the session answers, 'hearing' while it hears. */
    setMic(phase) { mic(talking ? phase : 'off'); },
    setScope(next) {
      current = next === 'all' || domainList(domains).some((d) => d.id === next) ? next : 'all';
      const one = current !== 'all';
      const mark = screen.querySelector('[data-phone-mark]');
      if (mark) mark.textContent = one ? labelIn(domains, current).slice(0, 1) : String(domainList(domains).length);
      const cap = screen.querySelector('[data-phone-cap]');
      if (cap) cap.textContent = one ? labelIn(domains, current) : 'All domains';
      const sub = screen.querySelector('[data-phone-sub]');
      if (sub) sub.textContent = one ? 'I search ' + labelIn(domains, current) + '.' : 'I search all ' + domainList(domains).length + ' domains at once.';
      screen.querySelector('[data-phone-act="scope"]')?.setAttribute('aria-label', 'Asking ' + scopeText(current, domains) + '. Choose');
    },
    unmount() {
      release();
      screen.removeEventListener('click', onClick);
      doc.removeEventListener('keydown', onKey, true);
      if (full && fullWas) { full.className = fullWas.cls; full.innerHTML = fullWas.html; full.hidden = fullWas.hidden; if (fullWas.label) full.setAttribute('aria-label', fullWas.label); }
      for (const m of moved.toReversed()) m.parent?.insertBefore(m.node, m.next?.parentNode === m.parent ? m.next : null);
      screen.remove();
      rail.classList.remove('orb-ui');
    },
  };

  const onClick = (e) => {
    const act = e.target.closest('[data-phone-act]')?.dataset.phoneAct;
    if (act === 'orb') {
      if (held) { held = false; return; }
      if (talking) { talk.stop(); return; }
      if (!listening && !orb.classList.contains('is-listening')) typing();
      return;
    }
    if (act === 'scope') { openSheet(); return; }
    if (act === 'close') { closeSheet(); return; }
    const pick = e.target.closest('[data-phone-scope]');
    if (pick) { api.setScope(pick.dataset.phoneScope); onScope?.(current); closeSheet(); return; }
    const record = e.target.closest('[data-phone-record]');
    if (record) { onOpenRecord?.(record.dataset.phoneRecord, record.dataset.phoneDomain); return; }
    const ask = e.target.closest('[data-phone-ask]');
    if (ask) { onAsk(ask.dataset.phoneAsk); return; }
    if (e.target.closest('#hugo-send')) fold();
  };
  screen.addEventListener('click', onClick);
  const onKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.target === input) { setTimeout(fold, 0); return; }
    if (e.key !== 'Escape') return;
    // ONLY THE ORB'S OWN ESCAPE (VH-777): on the desktop a dialog can sit over the Orb (Talk's continuation, a record), and
    // Escape is that dialog's. So the Orb takes it only with focus inside it, its sheet open or its box being typed in.
    if (!screen.contains(doc.activeElement)) return;
    // On the desktop Escape closes Hugo, as it always has there (the rail's own handler); only the sheet is the Orb's.
    if (desktop && !screen.querySelector('.orb-sheet-host')) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (screen.querySelector('.orb-sheet-host')) closeSheet();
    else if (screen.classList.contains('is-typing')) { fold(); orb.focus(); }
  };
  doc.addEventListener('keydown', onKey, true);

  return api;
}
