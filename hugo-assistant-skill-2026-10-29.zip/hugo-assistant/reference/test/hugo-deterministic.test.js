// The deterministic-first resolver: the common phrasings resolve offline, with no model and no egress. It is
// deliberately liberal (confirm-first reviews every result), but it never invents a value and everything it
// emits is re-checked by the validator.

import test from 'node:test';
import assert from 'node:assert/strict';

import { resolveDeterministic } from '../src/hugo/deterministic.js';
import { normaliseViewIntent } from '../src/hugo/view-intent.js';
import { getDescriptor, domainIds } from '../src/domain/descriptor.js';
import { canonicalCountry, isIsoFillName, cityCountry } from '../src/domain/country-canon.js';
import { SUBDIVISIONS, SUBDIVISIONS_CURATED } from '../public/geo-subdivision-table.js';

const SPACE = getDescriptor('space');
const IDS = domainIds();

// Resolve then normalise, the real pipeline order, so the tests prove the two halves agree.
function run(text) {
  const { raw, resolved } = resolveDeterministic(text, SPACE);
  const { intent, unmapped } = normaliseViewIntent(raw, SPACE, { domainIds: IDS });
  return { raw, resolved, intent, unmapped };
}

test("the owner's worked example resolves offline", () => {
  // "the C-UAS vendors in the UK that are not in the GDM, on a map": C-UAS is a mission not in the Space
  // vocab, so it is not matched here (it maps once the domains carry it); the country, gdm and view do.
  const { intent, resolved } = run('show me all the vendors in the UK that are not in the GDM, on a map');
  assert.equal(resolved, true);
  assert.deepEqual(intent.filterSpec.countries, ['United Kingdom']);
  assert.deepEqual(intent.filterSpec.gdm, ['Not in GDM']);
  assert.equal(intent.view, 'map');
});

test('family terms resolve to keys', () => {
  const { intent } = run('the SAR and electro-optical providers');
  assert.deepEqual(intent.filterSpec.families, ['EO', 'SAR']);
});

test('gdm negation beats the affirmative and onboarding is distinct', () => {
  assert.deepEqual(run('vendors not in the gdm').intent.filterSpec.gdm, ['Not in GDM']);
  assert.deepEqual(run('vendors in the gdm').intent.filterSpec.gdm, ['In GDM']);
  assert.deepEqual(run('who is onboarding').intent.filterSpec.gdm, ['Onboarding']);
  assert.deepEqual(run('vendors outside the GDM').intent.filterSpec.gdm, ['Not in GDM']);
});

test('a controlled section value in the text is matched', () => {
  const { intent } = run('the Spaceflight Safety vendors');
  assert.deepEqual(intent.filterSpec.sections, ['Spaceflight Safety']);
});

test('country codes match only when uppercase, so "us" the pronoun does not fire', () => {
  assert.deepEqual(run('show us the vendors').intent.filterSpec.countries, []);
  assert.deepEqual(run('vendors in the USA').intent.filterSpec.countries, ['United States']);
  assert.deepEqual(run('vendors in Germany').intent.filterSpec.countries, ['Germany']);
});

test('view cues resolve; the geographic cue wins', () => {
  assert.equal(run('vendors on a map').intent.view, 'map');
  assert.equal(run('where are the coverage gaps').intent.view, 'map'); // "where are" is a map cue
  assert.equal(run('the coverage breakdown').intent.view, 'analytics');
  assert.equal(run('list the vendors').intent.view, 'board');
  assert.equal(run('the vendors').intent.view, '');
});

test('a phrase that maps to nothing resolves to false and an empty intent', () => {
  const { resolved, intent, unmapped } = run('hello there');
  assert.equal(resolved, false);
  assert.equal(intent.filterSpec.countries.length, 0);
  assert.equal(intent.view, '');
  assert.deepEqual(unmapped, []);
});

test('bad input never throws', () => {
  for (const bad of [null, undefined, 42, {}]) {
    const { raw, resolved } = resolveDeterministic(bad, SPACE);
    assert.equal(resolved, false);
    assert.equal(raw.question, '');
  }
});

test('"PAIR" the section does not fire on "repair" (whole-token match)', () => {
  assert.deepEqual(run('vendors that repair satellites').intent.filterSpec.sections, []);
});

test('a descriptor whose vocab is an array (not a Set) is handled by both halves', () => {
  // Production descriptors carry Set vocabularies; the Set/Array dual support mirrors scan-design.js and is
  // the defensive path for a differently-shaped descriptor. One run exercises it end to end: the resolver
  // reads the array vocab (vocabValues) and the validator admits from it (vocabHas).
  const arrayDescriptor = { id: 'space', hasGdm: true, hasReadiness: true, vocab: { section: ['TacSRT'] } };
  const { raw } = resolveDeterministic('the TacSRT vendors', arrayDescriptor);
  assert.deepEqual(raw.filterSpec.sections, ['TacSRT']);
  // A mission is checked against the domain's Mission Alignment list (VH-801), never the descriptor's vocabulary: EMSO is
  // one of Space's missions and is kept, a name that is not is unmapped. control_status, until VH-824 retired it, proves
  // a retired clause is no clause at all.
  const { intent, unmapped } = normaliseViewIntent(
    { ...raw, filterSpec: { ...raw.filterSpec, missions: ['EMSO', 'Missile warning'], controlStatus: ['ITAR'] } }, arrayDescriptor, { domainIds: IDS },
  );
  assert.deepEqual(intent.filterSpec.sections, ['TacSRT']);
  assert.deepEqual(intent.filterSpec.missions, ['EMSO']);
  assert.ok(unmapped.some((u) => u.field === 'missions' && u.value === 'Missile warning'), 'an old label is no mission');
  assert.equal(Object.hasOwn(intent.filterSpec, 'controlStatus'), false, 'a retired clause is no clause of the intent');
});

test('the resolver output survives the validator unchanged (paths agree)', () => {
  const { raw } = resolveDeterministic('SAR vendors in France in the gdm', SPACE);
  const { intent, unmapped } = normaliseViewIntent(raw, SPACE, { domainIds: IDS });
  assert.deepEqual(intent.filterSpec.families, ['SAR']);
  assert.deepEqual(intent.filterSpec.countries, ['France']);
  assert.deepEqual(intent.filterSpec.gdm, ['In GDM']);
  assert.deepEqual(unmapped, []);
});

// --- THE PIPELINE PHRASES (V1.77 W1-3) --------------------------------------------------------------------
//
// Every ask below was run through the resolver and its answer read before the assertion was written, which is
// how two of them came to be corrected rather than accepted: see the two tests at the end of this block.
//
// The whole point is the round trip: the resolver's raw output goes through the SAME validator the model's
// does, so a phrase that resolves to a value the schema does not carry is dropped there rather than honoured.
// Each case therefore asserts the VALIDATED intent, not the raw one.

const pipelineIntent = (text) => {
  const { raw, resolved } = resolveDeterministic(text, SPACE);
  const { intent, unmapped } = normaliseViewIntent(raw, SPACE, { domainIds: IDS });
  return { spec: intent.filterSpec, view: intent.view, resolved, unmapped };
};

test('a stage is matched by the words people use, never by the schema identifier', () => {
  // Nobody types "technical_evaluation", and the phrase resolves to the value the column accepts.
  assert.deepEqual(pipelineIntent('who is in technical evaluation').spec.stages, ['technical_evaluation']);
  assert.deepEqual(pipelineIntent('anything stuck in contracting').spec.stages, ['contracting']);
  assert.deepEqual(pipelineIntent('who has signed an NDA').spec.stages, ['nda']);
  // Two stages in one question is one question with two stages in it, not a first-match.
  assert.deepEqual(pipelineIntent('paused or declined vendors').spec.stages, ['paused', 'declined']);
});

test('the owner token, the blocked tristate and a relative due window all resolve from free text', () => {
  assert.deepEqual(pipelineIntent('show me my pipeline').spec.owners, ['me']);
  assert.deepEqual(pipelineIntent('what is on my plate').spec.owners, ['me']);
  assert.equal(pipelineIntent('what is blocked').spec.blocked, true);
  assert.equal(pipelineIntent('what is held up').spec.blocked, true);
  assert.equal(pipelineIntent('overdue vendors').spec.due, 'overdue');
  // "nobody has scheduled it" is a different question from "not overdue" and is asked as often.
  assert.equal(pipelineIntent('anything unscheduled').spec.due, 'none');
});

test('"not blocked" is tested BEFORE "blocked", because they share the word', () => {
  // The negative first, or the positive pattern matches inside the negative phrase and returns the OPPOSITE
  // filter, which is the worst available failure for a filter: a confident, plausible, inverted answer.
  assert.equal(pipelineIntent('which vendors are not blocked').spec.blocked, false);
  assert.equal(pipelineIntent('unblocked vendors').spec.blocked, false);
  assert.equal(pipelineIntent('anything with no blockers').spec.blocked, false);
  // And the positive still reads positive, so this is not passing by never matching at all.
  assert.equal(pipelineIntent('anything with blockers').spec.blocked, true);
});

test('an ageing phrase converts its unit to days, which is what the query binds', () => {
  assert.equal(pipelineIntent('stuck for more than 3 weeks').spec.ageingDays, 21);
  assert.equal(pipelineIntent('in the same stage over 60 days').spec.ageingDays, 60);
  assert.equal(pipelineIntent('longer than 2 months').spec.ageingDays, 60);
  // No number, no clause: "stuck for ages" is not a duration and is not guessed at.
  assert.equal(pipelineIntent('stuck for ages').spec.ageingDays, undefined);
});

test('a pipeline question drives the pipeline view, and does not steal a map or an analytics question', () => {
  assert.equal(pipelineIntent('show me my pipeline').view, 'pipeline');
  assert.equal(pipelineIntent('what is stuck in contracting').view, 'pipeline');
  // "how many are stuck" is a DISTRIBUTION question, so Analytics keeps it: the pipeline cue sits behind
  // analytics and ahead of board on purpose.
  assert.equal(pipelineIntent('how many are stuck').view, 'analytics');
  assert.equal(pipelineIntent('the SAR vendors in the UK, on a map').view, 'map');
  assert.equal(pipelineIntent('list the UK vendors').view, 'board');
});

test('CORRECTED BY MEASUREMENT: "technical evaluation" is a stage, not a technical blocker', () => {
  // The first version of the blocker table matched a bare "technical", so this ask returned BOTH the stage
  // and `blockerKinds: ['technical']`, narrowing the question to blocked-on-technical vendors. Printed, seen,
  // and fixed with a negative lookahead rather than accepted as an acceptable greedy match.
  const { spec } = pipelineIntent('who has been in technical evaluation over 60 days');
  assert.deepEqual(spec.stages, ['technical_evaluation']);
  assert.deepEqual(spec.blockerKinds, [], 'the stage must not also read as a blocker kind');
  assert.equal(spec.ageingDays, 60);
  // A real technical blocker still resolves, so the lookahead did not disable the kind.
  assert.deepEqual(pipelineIntent('blocked on a technical problem').spec.blockerKinds, ['technical']);
});

test('a pipeline-only question counts as RESOLVED, including one whose only clause is a scalar', () => {
  // The resolver's own `anyFilter` check read `.length > 0` over every clause, which is undefined for a
  // boolean and a number: "show me what is not blocked" resolved to nothing and would have gone to the model
  // for a question this pass answers exactly. The same defect `intentHasFilter` carried one module upstream.
  // THE PHRASES ARE CHOSEN TO ISOLATE IT, and the first version of this test did not: "which vendors are
  // not blocked" also carries a pipeline VIEW cue, and `resolved` is `anyFilter || view !== ''`, so it
  // passed on the view even with the clause check reverted. Measured, then replaced with three phrases that
  // resolve NO array clause and NO view cue, so the scalar is the only thing that can make them resolved.
  for (const ask of ['longer than 2 months', 'with no blockers', 'anything unscheduled']) {
    const { spec, view, resolved } = pipelineIntent(ask);
    assert.equal(view, '', ask + ' must carry no view cue, or this test measures the cue');
    const arrays = Object.values(spec).filter((v) => Array.isArray(v) && v.length > 0);
    assert.deepEqual(arrays, [], ask + ' must populate no array clause, for the same reason');
    assert.equal(resolved, true, ask);
  }
  // A sentence with no filter and no view cue is still honestly unresolved.
  assert.equal(pipelineIntent('hello there').resolved, false);
});

// VH-005 PART 2, OWNER DECISION 2026-09-23 (option A): the ISO subdivision rows are trusted in a place field and
// never read out of a question. Measured before the gate: "a Falcon 9" read as Venezuela, "delta" as Nigeria,
// "meta data pool" as Colombia and Congo, and the Hugo evaluation's refusal score fell from 1.00 to 0.50.
test('a name only the ISO fill holds is a place in a field, never in a question; the curated regions still read in both', () => {
  const countriesOf = (q) => resolveDeterministic(q, getDescriptor('space'))?.raw?.filterSpec?.countries;
  // "Falcon" is a Venezuelan state in the ISO fill. This line asked it as a price question until VH-608 made a
  // price question stop before any place is read, so it is asked here in a form the place reader still sees.
  assert.deepEqual(countriesOf('who launches a Falcon 9'), []);
  assert.deepEqual(countriesOf('vendors in delta'), []);
  assert.deepEqual(countriesOf('who sells meta data pool services'), []);
  assert.deepEqual(countriesOf('vendors in Bavaria'), ['Germany'], 'a curated region still reads in a question');
  assert.deepEqual(countriesOf('vendors in Venezuela'), ['Venezuela'], 'and a country always does');
  assert.equal(canonicalCountry('Delta'), 'Nigeria', 'the same word in a country field still files');
  assert.equal(isIsoFillName('Delta'), true);
  assert.equal(isIsoFillName('bavaria'), false);
  assert.equal(isIsoFillName(''), false);
  // THE GATE TAKES NOTHING THAT RESOLVED BEFORE: no fill name is one the city layer, which answers first,
  // already knows. 56 curated countries and 3,063 fill names, measured.
  const fill = Object.entries(SUBDIVISIONS).filter(([k]) => !SUBDIVISIONS_CURATED[k]).flatMap(([, names]) => names);
  assert.equal(Object.keys(SUBDIVISIONS_CURATED).length, 56);
  assert.equal(fill.length, 3063);
  assert.deepEqual(fill.filter((n) => cityCountry(n)), []);
});

test('VH-608: a price or cost question naming a capability is refused as out-of-data, never read as a filter', () => {
  // MEASURED before the guard: the first two resolved to Radar and GNSS filters, the third to Radar plus a
  // commercial BLOCKER, because "cost" is also a blocker word. The dataset holds no price, so each one is a
  // question the dataset cannot answer, and a filtered list in reply would read as an answer to it.
  for (const q of [
    'what is the radar price of a satellite',
    'how much does a GNSS receiver cost',
    'what does a radar satellite cost',
    'the cost of SAR imagery from UK vendors',
    'How much is a LEO launch?',
  ]) {
    const r = resolveDeterministic(q, SPACE);
    assert.equal(r.resolved, false, q);
    assert.equal(r.outOfData, 'price', q);
  }
  // A cost BLOCKER is a pipeline question the dataset does hold, and keeps resolving.
  for (const q of ['which vendors are blocked on pricing', 'vendors with a commercial cost blocker']) {
    const r = resolveDeterministic(q, SPACE);
    assert.equal(r.resolved, true, q);
    assert.equal(r.outOfData, undefined, q);
    assert.deepEqual(r.raw.filterSpec.blockerKinds, ['commercial'], q);
  }
  assert.equal(resolveDeterministic('radar vendors in the UK', SPACE).resolved, true);
});
