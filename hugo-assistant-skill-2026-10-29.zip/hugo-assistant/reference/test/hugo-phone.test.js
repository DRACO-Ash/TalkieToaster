// VH-765: THE PHONE'S HUGO, the owner's approved "Orb" (docs/mockups/2026-10-19-dev3-vh765/round3-blue/). Pins what the
// owner asked for in words that can fail: no "Design a search", short answers with the domain named, one card per domain,
// Bluestaq blues only, every control 44 pixels or more, and the shell sending "all" and never the Realtime session for it.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { scopeText, phoneScreenHtml, domainSheetHtml, phoneAnswerHeadHtml, phoneAnswerCardsHtml, setOrbMic, MIC_WORDS } from '../public/views/hugo-phone.js';

const DOMAINS = [{ id: 'space', label: 'Space' }, { id: 'air', label: 'Air' }, { id: 'maritime', label: 'Maritime' }];
const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');

test('each answer keeps the scope it was asked under; the sheet is modal and escapes its classes (2.12.0 round three)', () => {
  const shell = read('public/app-v3.js');
  assert.match(shell, /history\.splice\(at >= 0 \? at \+ 1 : history\.length, 0, \{ role: 'assistant', content: result\.answer, agent: result, scope \}\);/);
  assert.match(shell, /const i = history\.indexOf\(asked\);\n\s+if \(i >= 0\) history\.splice\(i, 1\);/, 'a failed turn removes its own question, not the newest (2.15.0)');
  assert.match(shell, /m\.scopeText\(turn\.scope \?\? phoneHugo\.scope, phoneHugo\.domains\)/, 'drawn from the turn, not the scope chosen since');
  const mod = read('public/views/hugo-phone.js');
  assert.match(mod, /screen\.append\(host\);\n\s+behind\(true\);/, 'what lies behind the sheet is inert while it is open');
  assert.match(mod, /const closeSheet = \(\) => \{ behind\(false\);/, 'and comes back when it closes');
  assert.doesNotMatch(domainSheetHtml({ domains: [{ id: 'x"><img src=x onerror=alert(1)>', label: 'X' }] }), /<img/);
});

test('the answer reads as short plain sentences: references come out of the text and go to the cards', () => {
  const out = { answer: '3 vendors match. Space: 2 [R1] [R2]. Maritime: 1 [R3]. The other 1 domain has none.', verification: { ok: true } };
  const head = phoneAnswerHeadHtml(out, 'All 3 domains');
  assert.match(head, /<span class="hugo-turn-text">3 vendors match\. Space: 2\. Maritime: 1\. The other 1 domain has none\.<\/span>/);
  assert.match(head, /<span class="orb-scope-tag">All 3 domains<\/span>/);
  assert.match(head, /Checked against the dataset/);
  assert.doesNotMatch(phoneAnswerHeadHtml({ answer: 'x', verification: { ok: false } }, ''), /Checked/);
  assert.match(phoneAnswerHeadHtml({ answer: '<img src=x onerror=1>' }, '<b>'), /&lt;img src=x onerror=1&gt;.*|&lt;b&gt;/);
  assert.doesNotMatch(phoneAnswerHeadHtml({ answer: '<img src=x onerror=1>' }, '<b>'), /<img|<b>/);
});

test('one card per domain, in the order the answer named them, each vendor a 48-pixel button that opens it', () => {
  const html = phoneAnswerCardsHtml({ citations: [
    { ref: 1, id: 'VH-0001', name: 'Example vendor A', domain: 'space' },
    { ref: 2, id: 'MAR-0001', name: 'Example <vendor> C', domain: 'maritime' },
    { ref: 3, id: 'VH-0002', name: 'Example vendor B', domain: 'space' },
    { ref: 4, id: '', name: 'no id', domain: 'air' },
    { ref: 5, id: 'X', name: 'no domain' },
  ] }, (id) => scopeText(id, DOMAINS));
  const cards = [...html.matchAll(/<section class="orb-card h-([a-z-]+)"/g)].map((m) => m[1]);
  assert.deepEqual(cards, ['space', 'maritime'], 'a citation with no id or no domain makes no card');
  assert.match(html, /Space<span class="orb-count">2 companies<\/span>/);
  assert.match(html, /Maritime<span class="orb-count">1 company<\/span>/);
  assert.match(html, /data-phone-record="VH-0002" data-phone-domain="space">Example vendor B</);
  assert.match(html, /Example &lt;vendor&gt; C/);
  assert.equal(phoneAnswerCardsHtml({}), '');
});

test('the screen: no "Design a search", the domain named, and "hold to talk" only where the device can listen', async () => {
  const all = phoneScreenHtml({ domains: DOMAINS, scope: 'all', canTalk: true });
  assert.doesNotMatch(all, /Design a search/i, 'the owner: "No need for design a search on mobile view"');
  assert.match(all, /I search all 3 domains at once\./);
  assert.match(all, /aria-label="Asking All 3 domains\. Choose"/);
  assert.match(all, /Tap to ask · hold to talk/);
  // Two openings in short words that hold in every domain, and none that needs the map a phone does not show.
  assert.deepEqual([...all.matchAll(/class="orb-starter" data-phone-ask="([^"]+)">([^<]+)</g)].map((m) => m[2] + ' = ' + m[1]),
    ['Not in the GDM yet = the scoped vendors that are not in the GDM', 'Not checked in 18 months = the companies not verified in the last 18 months']);
  const tapOnly = phoneScreenHtml({ domains: DOMAINS, scope: 'air', canTalk: false });
  assert.match(tapOnly, />Tap to ask</);
  // The desktop's Orb says Click to a mouse user, in the hint and the button's name (2.20.0 round one, design MINOR 11).
  const desk = phoneScreenHtml({ domains: DOMAINS, scope: 'all', canTalk: true, desktop: true });
  assert.match(desk, />Click to ask · hold to talk</);
  assert.match(desk, /aria-label="Ask Hugo\. Click to type, hold to talk"/);
  assert.doesNotMatch(desk, /Tap to/);
  const { readFileSync } = await import('node:fs');
  assert.match(readFileSync(new URL('../public/views/hugo-phone.js', import.meta.url), 'utf8'), /phoneScreenHtml\(\{ domains, scope, canTalk: [^}]*, desktop \}\)/, 'the mount hands its desktop flag to the screen');
  assert.doesNotMatch(tapOnly, /hold to talk/);
  assert.match(tapOnly, /I search Air\./);
  assert.equal(scopeText('all', DOMAINS), 'All 3 domains');
  assert.equal(scopeText('maritime', DOMAINS), 'Maritime');
});

test('choosing a domain: All first, every domain after it, the chosen one pressed and ticked', () => {
  const html = domainSheetHtml({ domains: DOMAINS, scope: 'air' });
  const picks = [...html.matchAll(/data-phone-scope="([a-z-]+)" aria-pressed="(true|false)"/g)].map((m) => m[1] + ':' + m[2]);
  assert.deepEqual(picks, ['all:false', 'space:false', 'air:true', 'maritime:false']);
  assert.match(html, /role="dialog" aria-modal="true" aria-labelledby="orb-sheet-t"/);
  assert.equal((html.match(/class="orb-tick"/g) || []).length, 1);
  // The ids carry underscores and the colour tokens hyphens, so each domain's dot finds its own colour.
  const two = [{ id: 'natural_resources', label: 'Natural Resources' }, { id: 'national_security', label: 'National Security' }];
  assert.match(domainSheetHtml({ domains: two }), /class="orb-pick h-natural-resources"[^]*class="orb-pick h-national-security"/);
  assert.match(phoneAnswerCardsHtml({ citations: [{ id: 'N1', name: 'n', domain: 'natural_resources' }] }), /class="orb-card h-natural-resources"/);
});

test('the shell enters it at 640 pixels and narrower, asks "all" without the Realtime session, and offers no view on a phone (wired)', () => {
  const app = read('public/app-v3.js');
  assert.match(app, /readAdminLock\(\);\n {2}maybeEnterPhoneHugo\(\);\n\}/, 'entered once signed in');
  assert.match(app, /function phoneHugoWanted\(\) \{\n {2}return PHONE_QUERY\?\.matches === true;\n\}/);
  assert.match(app, /if \(phoneHugo \|\| signedOutUi\(\) \|\| !phoneHugoWanted\(\)\) return;/);
  assert.match(app, /const HUGO_SHEET_QUERY = globalThis\.matchMedia\?\.\('\(max-width: 640px\)'\) \?\? null;/);
  assert.match(app, /importFresh\('\.\/views\/hugo-phone\.js'\)/);
  assert.match(app, /const scope = phoneHugo \? phoneHugo\.scope : state\.domain;\n {2}if \(scope !== 'all' && hugoRealtimeReady\(\)\)/);
  assert.match(app, /api\.hugoAgent\(state\.token, \{ messages, domain: scope, onStep \}\)/);
  // The phone offers no view; the desktop's Orb does (VH-777), and it needs no domain on screen to open.
  assert.match(app, /if \(phoneHugo\?\.desk !== false\) showHugoProposal\(result\.proposal\);/);
  assert.match(app, /if \(!phoneHugo && !deskOrb && needDomain\('Hugo'\)\) return;/);
  assert.match(app, /if \(hugoVoiceUnavailable && VOICE_FAULT_NOTE\[hugoVoiceFault\] && !phoneHugoWanted\(\)\) \{/, 'no voice-key notice over the thumb dock');
  assert.match(app, /function signOut\(\) \{\n {2}leavePhoneHugo\(\);/);
});

// VH-811: A PHONE SHOWS HUGO ONLY, with no way into the full app. These pin the wiring; e2e/phone-hugo-pass.mjs drives it.
test('a phone is a narrow screen with a touch pointer, so a magnified or narrow desktop keeps the full app (VH-811, WCAG 1.4.10)', () => {
  const app = read('public/app-v3.js');
  assert.match(app, /const PHONE_QUERY = globalThis\.matchMedia\?\.\('\(max-width: 640px\) and \(pointer: coarse\)'\) \?\? null;/);
});

test('the phone screen mounts before the board loads and on a turn of the screen, and comes down when it widens (VH-811)', () => {
  const app = read('public/app-v3.js');
  assert.match(app, /state\.pendingUrlOffset = 0;\n[^\n]*\n {2}maybeEnterPhoneHugo\(\);\n {2}const ok = await loadBoardPage\(0\);/, 'before the first board read');
  // Mounted that early, it waits for the voice probe alone, so the orb knows whether Hugo can talk (VH-777).
  assert.match(app, /await probeHugoVoice\(\)\.catch\(\(\) => \{\}\);\n {2}if \(!phoneHugoWanted\(\)\) return;\n {2}await mountOrbHugo\(false\);/);
  assert.match(app, /if \(!hugoVoiceProbed\) \{ hugoVoiceProbed = true; hugoVoiceProbing = readHugoVoice\(\); showHugoTalkIfSupported\(\); \}\n {2}return hugoVoiceProbing \?\? Promise\.resolve\(\);/);
  assert.match(app, /PHONE_QUERY\?\.addEventListener\?\.\('change', \(\) => \{\n {2}if \(PHONE_QUERY\.matches\) maybeEnterPhoneHugo\(\);\n {2}else if \(phoneHugo && !phoneHugo\.desk\) leavePhoneHugo\(\);\n\}\);/);
});

test('nothing leaves the phone screen: no Full app control, no remembered way out, Hugo stays open (VH-811)', () => {
  const app = read('public/app-v3.js');
  const mod = read('public/views/hugo-phone.js');
  for (const [name, src] of [['the shell', app], ['the Orb', mod]]) {
    assert.doesNotMatch(src, /vh_phone_full|onFullApp|Open the full app|'Full app'/, name + ' keeps no way into the full app');
  }
  assert.match(mod, /\} else if \(full\) \{\n[^\n]*\n {4}full\.hidden = true;\n {2}\}/, 'the rail\'s Minimise is hidden on a phone');
  assert.match(mod, /full\.hidden = fullWas\.hidden;/, 'and given back when the phone screen comes down');
  assert.match(app, /function closeHugoPanel\(\) \{\n[^\n]*\n {2}if \(phoneHugo && !phoneHugo\.desk\) return;/, 'Escape and every other close leave the phone screen standing');
  assert.match(app, /if \(!desk\) byId\('app'\)\?\.classList\.add\('phone-only'\);/);
  assert.match(read('public/styles.css'), /#app\.phone-only > :not\(#hugo-rail\) \{ display: none; \}/, 'nothing of the full app is drawn under it');
});

test('a record opens over the phone screen, which stays; the desktop opens it beside the board (VH-811)', () => {
  const app = read('public/app-v3.js');
  assert.match(app, /const open = \(\) => \(store === 'space' \? openDrawer\(id\) : openDomainDrawer\(id\)\);\n {6}if \(desk\) goToView\('master'\)\.then\(open\);\n {6}else open\(\);/);
  assert.doesNotMatch(app, /if \(!desk\) leavePhoneHugo\(\);/);
});

test('Bluestaq blues only, and every control in the phone screen 44 pixels or more', () => {
  const css = read('public/styles.css');
  const start = css.indexOf('/* VH-765: THE PHONE\'S HUGO');
  assert.ok(start > 0, 'the section is present');
  const section = css.slice(start);
  // The owner: no rainbow. Gradients draw only in the blues; a domain hue appears only as its own dot or edge.
  for (const g of section.matchAll(/(?:conic|linear|radial)-gradient\(([^;]*)/g)) assert.doesNotMatch(g[1], /--dom-|--d-/, 'a domain hue in a gradient: ' + g[0].slice(0, 80));
  assert.match(section, /--orb-blues: var\(--brand-strong\), var\(--accent\), var\(--brand\), var\(--accent\), var\(--brand-strong\);/);
  // The measures are named once (the spacing ladder holds none of them) and every control reads its own.
  assert.match(section, /\.orb-screen \{ --orb-hit: 48px; [^}]*--orb-pick-h: 56px; --orb-close-h: 52px;/);
  assert.match(section, /\.orb-dock \{ --orb-size: 104px; [^}]*--orb-side: 76px;/);
  for (const [sel, size] of [['.orb-btn', /width: var\(--orb-size\); height: var\(--orb-size\);/],
    ['.orb-side', /min-width: var\(--orb-side\); min-height: var\(--orb-side\);/], ['.orb-ref', /min-height: var\(--orb-hit\);/],
    ['.orb-pick', /min-height: var\(--orb-pick-h\);/], ['.orb-close', /min-height: var\(--orb-close-h\);/],
    ['.orb-starter', /min-height: var\(--orb-hit\);/], ['#hugo-rail.orb-ui .orb-reach #hugo-send', /min-height: var\(--orb-hit\);/]]) {
    const rule = section.slice(section.indexOf(sel + ' {'), section.indexOf('}', section.indexOf(sel + ' {')));
    assert.match(rule, size, sel);
  }
});

// TALK BY KEYBOARD ON THE DESKTOP (2.20.0 design critic, WCAG 2.1.1): a hold on the orb was the only way to Talk there, so the
// desktop's Orb is marked and its typing box (Enter on the orb opens it) shows Talk wherever voice is set up. Seen in the
// running app: Talk hidden at rest, shown after Enter, reached by Tab.
test('the Orb offers Talk to the keyboard at rest, on the desktop and the phone (VH-903)', async () => {
  const { readFileSync } = await import('node:fs');
  const view = readFileSync(new URL('../public/views/hugo-phone.js', import.meta.url), 'utf8');
  assert.doesNotMatch(view, /is-desk/, 'Talk shows at rest everywhere (VH-903), so the desktop needs no mark of its own');
  const css = readFileSync(new URL('../public/styles.css', import.meta.url), 'utf8');
  // VH-903 (owner, 2026-10-28): the box, Send and Talk show at rest, desktop and phone alike, not only once the orb is pressed.
  assert.match(css, /#hugo-rail\.orb-ui \.orb-reach \.hugo-composer \{ display: block; padding: 0; border: 0; background: none; \}/);
  assert.match(css, /#hugo-rail\.orb-ui \.orb-reach \.hugo-talk:not\(\[hidden\]\) \{ display: inline-flex; \}/);
  assert.doesNotMatch(css, /\.orb-reach \.hugo-composer \{ display: none; \}|is-desk\.is-typing \.orb-reach \.hugo-talk/, 'nothing hides them until a press');
  // The starters stay at rest, beside the box; pressing the orb still focuses the box.
  assert.match(view, /const typing = \(\) => \{ screen\.classList\.add\('is-typing'\); input\?\.focus\(\); \};/);
});

// THE ORB IS GREEN ONLY WHILE THE MICROPHONE IS OPEN (VH-905, owner, 2026-10-28): the glow came on at the press, before the
// browser had the microphone, so it said "listening" when nothing was. Green on the browser's own audiostart, brighter while
// it hears, off on end or error; the words go to a live region; reduced motion keeps the brighter ring steady.
test('the orb\'s microphone state: green only once open, brighter while hearing, off on end, and said in words', () => {
  const cls = new Set();
  const orb = { classList: { toggle: (c, on) => (on ? cls.add(c) : cls.delete(c)), contains: (c) => cls.has(c) } };
  const say = { textContent: '' };
  setOrbMic(orb, say, 'open');
  assert.deepEqual([...cls].sort(), ['is-mic-open']);
  assert.equal(say.textContent, MIC_WORDS.open);
  setOrbMic(orb, say, 'hearing');
  assert.deepEqual([...cls].sort(), ['is-hearing', 'is-mic-open']);
  assert.equal(say.textContent, MIC_WORDS.hearing);
  setOrbMic(orb, say, 'nonsense');
  assert.deepEqual([...cls], [], 'anything but open or hearing is off');
  assert.equal(say.textContent, '');
  assert.match(phoneScreenHtml({ domains: DOMAINS, canTalk: true }), /<span class="sr-only" data-phone-mic role="status" aria-live="polite"><\/span>/);
  // Wired to the browser's own events, not the press.
  const mod = read('public/views/hugo-phone.js');
  assert.match(mod, /rec\.onaudiostart = \(\) => mic\('open'\);/);
  assert.match(mod, /rec\.onsoundstart = rec\.onspeechstart = \(\) => mic\('hearing'\);/);
  assert.match(mod, /rec\.onerror = \(\) => mic\('off'\);/);
  assert.match(mod, /rec\.onend = \(\) => \{ listening = null; orb\.classList\.remove\('is-listening'\); mic\('off'\); \};/);
  // The press lights nothing: the glow is the open microphone's, green, and only hearing moves.
  const css = read('public/styles.css');
  assert.doesNotMatch(css, /\.orb-btn\.is-listening \{[^}]*box-shadow/);
  assert.match(css, /\.orb-btn\.is-mic-open::before \{ opacity: 0; \}/, 'the blue ring steps back');
  assert.match(css, /--orb-glow-mic: 0 0 0 3px var\(--ok\),/, 'and the button\'s own edge rings green');
  assert.match(css, /@media \(prefers-reduced-motion: no-preference\) \{ \.orb-btn\.is-hearing::after \{ animation: orb-breathe/);
  // Live Talk marks the microphone open once its session answers, and the relay once it holds the stream.
  const shell = read('public/app-v3.js');
  assert.match(shell, /setHugoStatus\('Listening\. Speak when ready\.'\);\n\s+markHugoMicOpen\(\);/);
  assert.match(shell, /function markHugoMicOpen\(\) \{ phoneHugo\?\.ctl\?\.setMic\?\.\('open'\); \}/);
});

// THE MICROPHONE IS ASKED FOR IN THE PRESS (VH-906): a hold began Talk from a timer, outside the press, and iOS (every browser
// there is WebKit) refuses a microphone asked for outside a press, whatever the site's setting. The press asks now, the
// hold uses what it got, and a short tap gives it back; notices sit at the top while the Orb is open, never over the orb.
test('the press asks for the microphone, the hold uses it, a tap gives it back, and no notice covers the orb', () => {
  const mod = read('public/views/hugo-phone.js');
  assert.match(mod, /if \(!talking\) \{ talk\.prime\?\.\(\); holdTimer = setTimeout\(\(\) => \{ holdTimer = 0; held = true; talk\.start\(\); \}, HOLD_MS\); \}/,
    'asked for in the press itself, before the timer');
  assert.match(mod, /const release = \(\) => \{ if \(holdTimer\) \{ clearTimeout\(holdTimer\); holdTimer = 0; talk\?\.release\?\.\(\); \} stopListening\(\); \};/);
  const shell = read('public/app-v3.js');
  assert.match(shell, /\{ start: \(\) => toggleHugoTalk\(\), stop: \(\) => stopHugoTalk\(\), prime: primeHugoMic, release: releaseHugoMic \}/);
  const prime = /function primeHugoMic\(\) \{[\s\S]*?\n\}/.exec(shell)?.[0] || '';
  assert.match(prime, /new Ctx\(\)/, 'the sound engine is made in the press');
  assert.match(prime, /getUserMedia\(\{ audio: true \}\)/, 'and the microphone asked for in it');
  assert.match(shell, /const mic = takeHugoMic\(\);/, 'Talk takes what the press got');
  const css = read('public/styles.css');
  // Below the protective marking bar, never over it (the 2.23.0 design critic, round one).
  assert.match(css, /body:has\(#hugo-rail\.orb-ui\.is-expanded\) \.toast \{ top: calc\(var\(--marking-h\) \+ var\(--space-2\)\); bottom: auto; \}/);
  // A Talk that does not start gives the press's microphone back (the 2.23.0 engineering gate, round one); the behaviour is
  // proved in the browser by `e2e/mic-release-pass.mjs`, and these hold its four doors in place.
  assert.match(shell, /if \(hugoVoice\) \{ releaseHugoMic\(\); stopHugoTalk\(\); return; \}/);
  assert.match(shell, /if \(hugoTalkWhy\) \{ releaseHugoMic\(\); toast\(hugoTalkWhy, 'warn'\); return; \}/);
  assert.match(shell, /\} finally \{\n {4}getMic\.free\(\);/);
  assert.match(shell, /function clearRunIndicators\(\) \{\n {2}releaseHugoMic\(\);/);
  assert.match(shell, /function leavePhoneHugo\(\) \{\n {2}releaseHugoMic\(\);/);
});
