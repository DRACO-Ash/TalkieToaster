// The Hugo query plan builder: a validated filterSpec -> a parameterised WHERE. Pure, so it is tested without
// a database; the repo test proves it runs over real Postgres.

import test from 'node:test';
import assert from 'node:assert/strict';

import { buildIntentWhere } from '../src/hugo/query-plan.js';
import { DISPOSITIONS, isExcluded } from '../src/domain/eligibility.js';

// The eligibility backstop (H-4) binds the excluded dispositions as the FIRST param on every build, so the
// supported clauses that follow start at $2. Derived from the one gate rather than re-listed, so this test
// tracks a policy change instead of masking it.
const EXCLUDED = DISPOSITIONS.filter(isExcluded);

test('an empty filterSpec filters to live rows and applies the eligibility backstop', () => {
  const { sql, params, applied, notApplied } = buildIntentWhere({});
  assert.match(sql, /coalesce\(lifecycle_status/);
  // The backstop is always present: the excluded dispositions bound at $1, plus the quarantined stop.
  assert.match(sql, /line_eligibility[^$]*= ANY\(\$1::text\[\]\)/);
  assert.match(sql, /quarantined/);
  assert.deepEqual(params, [EXCLUDED]);
  assert.deepEqual(applied, []);
  assert.deepEqual(notApplied, []);
});

test('supported clauses become bound ANY predicates in order after the backstop param', () => {
  // `grades` was the fourth clause here and gave the test its $5. It went with the readiness axis in
  // V1.80, and `missions` takes the slot - measured against SUPPORTED, which now holds exactly four
  // clauses, rather than picked. `sizeBands` was the wrong substitute and running it said so: it is a
  // DEFERRED clause, so it lands in `notApplied` and binds no parameter at all.
  const { sql, params, applied } = buildIntentWhere({
    countries: ['United Kingdom', 'France'], gdm: ['Not in GDM'], sections: ['TacSRT'], missions: ['EMSO'],
  });
  assert.deepEqual(applied, ['countries', 'gdm', 'sections', 'missions']);
  // $1 is the eligibility backstop; the supported clauses follow at $2..$5.
  // The GDM value is folded, because the clause reads the band the row SHOWS, folded, as the board's control does.
  assert.deepEqual(params, [EXCLUDED, ['United Kingdom', 'France'], ['not in gdm'], ['TacSRT'], ['emso']]);
  assert.match(sql, /data->>'country' = ANY\(\$2::text\[\]\)/);
  assert.match(sql, /lower\(btrim\(\(case when lower\(btrim\(coalesce\(gdm, ''\)\)\) = 'in gdm' then 'In GDM'[\s\S]* end\)\)\) = ANY\(\$3::text\[\]\)/);
  assert.match(sql, /section = ANY\(\$4::text\[\]\)/);
  assert.match(sql, /lower\(btrim\(ml\.name\)\) = any\(\$5::text\[\]\)/, 'the fourth clause takes $5, so the numbering advances');
  // AND A GRADE CLAUSE NOW BUILDS NOTHING, whatever a caller sends: no predicate, no bound parameter.
  const gone = buildIntentWhere({ grades: ['In JCO'] });
  assert.deepEqual(gone.applied, [], 'a grade clause is not applied');
  assert.ok(!/grade = ANY/.test(gone.sql), 'and no grade predicate is built');
});

test('a mission is Mission Alignment\'s: a data type the record supplies carries it, one folded param after the backstop', () => {
  // VH-801: until then a mission matched the record's section OR its stored list. Now it is the board's own rule.
  const { sql, params, applied } = buildIntentWhere({ missions: ['EMSO', 'PAIR'] });
  assert.deepEqual(applied, ['missions']);
  assert.deepEqual(params, [EXCLUDED, ['emso', 'pair']]);
  assert.match(sql, /join data_type_mission dtm on dtm\.domain = 'space' and dtm\.state = 'confirmed'/);
  assert.match(sql, /lower\(btrim\(ml\.name\)\) = any\(\$2::text\[\]\)/);
  assert.doesNotMatch(sql, /data->'missions'/, 'the stored list is not read');
});

test('the capability clauses become SQL (V1.82, RT-Q4): nothing Hugo resolves is left as a dead end', () => {
  // These five were resolved by the deterministic layer, listed as DEFERRED, and never turned into a WHERE
  // clause, so "show me the SAR vendors" and "the ITAR-controlled vendors" filtered nothing while the confirm
  // surface said what had been understood. Each now binds a text[] and reads the record where the value
  // actually lives. VH-824 retired size band, control status and releasability: sent, they bind nothing.
  const { sql, params, applied, notApplied } = buildIntentWhere({
    families: ['SAR'], sizeBands: ['11-50'], controlStatus: ['Controlled'], releasability: ['NATO'],
    productTypes: ['Electro-Optical'], countries: ['France'],
  });
  assert.deepEqual(applied, ['countries', 'productTypes', 'families']);
  assert.deepEqual(notApplied, []);
  assert.doesNotMatch(sql, /size_band|export_control/, 'the retired clauses reach no WHERE');
  assert.match(sql, /data->'product_types' \?\| \$\d+/);
  // A FAMILY IS EXPANDED TO THE PRODUCT TYPES IT COVERS, at plan time, from the Space vocabulary, so the SQL
  // carries plain values and no regex; the bound list is real product-type labels, and every one is SAR.
  const familyParam = params.find((p) => Array.isArray(p) && p.some((v) => /radar|synthetic aperture/i.test(v)));
  assert.ok(familyParam && familyParam.length > 0, 'the families clause binds the SAR product types');
  assert.ok(!familyParam.includes('Electro-Optical'), 'and not an EO type');
});

test('a family that expands to no product type is reported as not applied, never bound empty', () => {
  const { applied, notApplied, sql } = buildIntentWhere({ families: ['NOT-A-FAMILY'] });
  assert.deepEqual(applied, []);
  assert.deepEqual(notApplied, ['families']);
  assert.doesNotMatch(sql, /product_types/);
});

test('includeMerged drops the live-only clause', () => {
  const { sql } = buildIntentWhere({ countries: ['France'] }, { includeMerged: true });
  assert.doesNotMatch(sql, /lifecycle_status/);
  assert.match(sql, /data->>'country'/);
});

test('non-array and empty clauses are ignored; malformed input is safe', () => {
  const { params, applied } = buildIntentWhere({ countries: 'France', gdm: [], sections: [null, 3, ''] });
  assert.deepEqual(applied, []);
  // No supported clause applied, so only the always-on eligibility backstop param remains.
  assert.deepEqual(params, [EXCLUDED]);
  assert.deepEqual(buildIntentWhere(null).applied, []);
});
