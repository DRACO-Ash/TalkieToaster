// WHAT HUGO'S PREFLIGHT SAYS (owner, 2026-09-17: "hugo still sucks ass - it doesnt work", with both keys
// already set).
//
// THE SENTENCES ARE THE FEATURE. "It does not work" was never actionable and the interface could not do
// better, because Hugo answers plausibly from the deterministic tool layer whether or not he has a brain:
// a missing key, a refused key, an unknown model id, a spent quota and a blocked egress all read the same.
// Each has a different fix and a different person who can apply it, so each gets its own sentence naming
// the next action. A wrong sentence here sends an admin to the wrong place, which is worse than silence.
import test from 'node:test';
import assert from 'node:assert/strict';

import { hugoPreflightLine, checkLiveSocket } from '../public/views/hugo-preflight.js';

test('THE TRANSPORT AND THE DIAGNOSIS ARE DIFFERENT FACTS, and they used to share a name', () => {
  // The defect this pins, measured in a browser: the route answered HTTP 200 with a correct
  // `{ok:false, kind:'not_configured'}` and the screen read "The check could not run". The client spread
  // the payload over its own `{ok:true}`, so the diagnosis's `ok` overwrote the transport's, and a
  // SUCCESSFUL check that found a REAL fault reported itself as a broken check - the one answer that tells
  // an operator nothing at all.
  const found = hugoPreflightLine({ reached: true, ok: false, configured: false, kind: 'not_configured' });
  assert.match(found.text, /Hugo has no AI service key/, 'a successful check that finds a fault REPORTS the fault');
  assert.equal(found.good, false);
  // And a check that genuinely could not run still says so.
  assert.match(hugoPreflightLine({ reached: false, status: 500 }).text, /check could not run/);
  assert.match(hugoPreflightLine(null).text, /check could not run/);
});

test('no key names the variable and the place to set it', () => {
  const out = hugoPreflightLine({ reached: true, ok: false, configured: false, kind: 'not_configured' });
  assert.match(out.text, /OPENAI_API_KEY/, 'the exact variable, because "a key" is not actionable');
  assert.match(out.text, /App Store environment/);
  assert.match(out.text, /restart/, 'and that it is read at boot, which is why setting it is not enough on its own');
  assert.equal(out.good, false);
});

test('a working Hugo says so, with the model and the latency', () => {
  const out = hugoPreflightLine({ reached: true, ok: true, configured: true, kind: '', model: 'gpt-6-astra', latencyMs: 412 });
  assert.equal(out.good, true);
  assert.match(out.text, /Hugo is connected \(gpt-6-astra\) and answered in 412ms\./);
});

test('EVERY WALL NAMES ITS OWN FIX', () => {
  const line = (kind, extra = {}) => hugoPreflightLine({ reached: true, ok: false, configured: true, kind, model: 'gpt-6-astra', ...extra }).text;
  assert.match(line('auth'), /refused the key/);
  assert.match(line('permission'), /not allowed to use this model/);
  assert.match(line('model'), /OPENAI_HUGO_MODEL/, 'names the variable that changes the model id');
  assert.match(line('rate_limit'), /billing account/);
  assert.match(line('provider'), /Nothing to fix here/);
  assert.match(line('egress'), /api\.openai\.com/, 'names the host the network policy has to allow');
  // AN UNKNOWN KIND FALLS BACK RATHER THAN PRINTING "undefined", and carries whatever the server did say.
  assert.match(line('something_new', { error: 'hugo model provider error 418' }), /hugo model provider error 418/);
  // Every wall is a bad verdict: none of them may read as success.
  for (const k of ['auth', 'permission', 'model', 'rate_limit', 'provider', 'egress', 'something_new']) {
    assert.equal(hugoPreflightLine({ reached: true, ok: false, configured: true, kind: k }).good, false, k);
  }
});

test('PROVIDER-NAMING: the walls describe the AI service and keep the literals literal', () => {
  const KINDS = ['auth', 'permission', 'model', 'rate_limit', 'provider', 'egress'];
  const lines = KINDS.map((kind) => hugoPreflightLine({ reached: true, configured: true, ok: false, kind, model: 'gpt-x' }).text);

  // NO VENDOR NAME IN THE DESCRIPTION. An operator reading a wall is trying to fix something, and the
  // vendor's name in the prose tells them nothing they can act on.
  for (const line of lines) {
    assert.doesNotMatch(line, /\bOpenAI\b/, 'a wall names the vendor in prose: ' + line);
    assert.doesNotMatch(line, /\bAnthropic\b/, 'a wall names the vendor in prose: ' + line);
  }

  // AND THE LITERALS SURVIVE, which is the other half and the reason this is not a blanket ban. The two
  // things an operator may have to TYPE are useless in any form but the exact one, so the assertion has
  // to be able to fail in both directions: strip the hostname or the variable and this goes red too.
  const egress = lines[KINDS.indexOf('egress')];
  assert.match(egress, /api\.openai\.com/, 'the allow-list hostname is what the admin has to enter');
  const modelWall = lines[KINDS.indexOf('model')];
  assert.match(modelWall, /OPENAI_HUGO_MODEL/, 'the environment variable is what the admin has to set');

  // The unconfigured line names its variable too.
  const unset = hugoPreflightLine({ reached: true, configured: false }).text;
  assert.match(unset, /OPENAI_API_KEY/);
  assert.doesNotMatch(unset, /\bOpenAI\b/);
});

// VH-777: "connected (gpt-6-astra), 2728ms" while Hugo would not converse. Each link is named, and a good one says so.
test('every link a turn uses is named: tools, the speech service and this browser\'s live link', () => {
  const base = { reached: true, ok: true, configured: true, kind: '', model: 'gpt-6-astra', latencyMs: 2728 };
  const rt = { ok: true, model: 'gpt-realtime-2', latencyMs: 412 };
  const tools = { ok: true, latencyMs: 900 };
  const line = (links, live = null) => hugoPreflightLine({ ...base, links }, live);
  assert.deepEqual(line({ tools, realtime: rt }, { ok: true }), { good: true,
    text: 'Hugo is connected (gpt-6-astra) and answered in 2728ms. His tools answered in 900ms. His speech service (gpt-realtime-2) answered in 412ms, and this browser reached his live link.' });
  const toolsDown = line({ tools: { ok: false, kind: 'model' }, realtime: rt });
  assert.equal(toolsDown.good, false);
  assert.match(toolsDown.text, /But his tools did not answer, so he cannot look anything up\. The AI service does not know this model \(gpt-6-astra\)\. Set OPENAI_HUGO_MODEL/);
  // A later link's refusal in its own words: the first call has just shown the key works and the host is reached
  // (2.15.0 design critic round one).
  assert.match(line({ tools: { ok: false, kind: 'auth' }, realtime: rt }).text, /refused the key for a tool turn, though it took it for the first call/);
  const speechDown = line({ tools, realtime: { ok: false, kind: 'model', model: 'gpt-realtime-2' } });
  assert.equal(speechDown.good, false);
  assert.match(speechDown.text, /His speech service \(gpt-realtime-2\) did not answer, so Talk and voice will not work\. .*Set OPENAI_REALTIME_MODEL/);
  assert.match(line({ tools, realtime: { ok: false, kind: 'egress' } }).text, /reached the AI service but could not open its speech socket\. Check the network policy lets WebSocket \(wss\) connections through/);
  assert.doesNotMatch(line({ tools, realtime: { ok: false, kind: 'egress' } }).text, /could not reach the AI service at all/);
  assert.match(line({ tools, realtime: { ok: false, kind: 'refused', code: 'session_expired' } }).text, /refused the session \(session_expired\)\./);
  // The wait the probe measured, never a figure the code did not produce (2.15.0 design critic round one).
  assert.match(line({ tools, realtime: { ok: false, kind: 'timeout', latencyMs: 15_004 } }).text, /did not open a session within 15 seconds/);
  assert.match(line({ tools, realtime: { ok: false, kind: 'timeout', latencyMs: 0 } }).text, /did not open a session in time/);
  const off = line({ tools, realtime: { ok: false, off: true, reason: 'unpriced' } });
  assert.equal(off.good, null, 'off by this deployment\'s own settings is neither a pass nor a fault, so neither reserved colour');
  assert.match(off.text, /Talk and voice are off: a daily spend cap is set/);
  const blocked = line({ tools, realtime: rt }, { ok: false, why: 'timeout' });
  assert.equal(blocked.good, false);
  assert.match(blocked.text, /could not open his live link \(it did not answer within 8 seconds\).*WebSocket upgrades through to \/api\/v3\/hugo\/realtime/);
  assert.match(line({ tools, realtime: rt }, { ok: false, why: 'refused' }).text, /\(it was refused\)/);
  assert.equal(line({ tools, realtime: rt }).text.endsWith('answered in 412ms.'), true, 'no live check run, nothing claimed about it');
});

test('the live-link check: one vh.check frame is a pass; a refusal, a close or silence is named', async () => {
  const sock = () => {
    const on = {};
    return { on, closed: 0, addEventListener(ev, cb) { on[ev] = cb; }, close() { this.closed += 1; } };
  };
  let s = null;
  const timers = [];
  const run = () => checkLiveSocket({ makeSocket: (url) => { s = sock(); s.url = url; return s; }, url: 'wss://x/api/v3/hugo/realtime?domain=space&mode=check',
    setTimer: (fn) => { timers.push(fn); return 1; }, clearTimer: () => {} });
  const good = run();
  s.on.message({ data: JSON.stringify({ type: 'other' }) });
  s.on.message({ data: JSON.stringify({ type: 'vh.check', ok: true }) });
  assert.deepEqual(await good, { ok: true });
  assert.equal(s.closed, 1);
  const refused = run();
  s.on.error({});
  assert.deepEqual(await refused, { ok: false, why: 'refused' });
  const closed = run();
  s.on.close({});
  assert.deepEqual(await closed, { ok: false, why: 'refused' });
  const silent = run();
  timers.at(-1)();
  assert.deepEqual(await silent, { ok: false, why: 'timeout' });
  assert.deepEqual(await checkLiveSocket({ makeSocket: () => { throw new Error('blocked'); }, url: 'x', setTimer: () => 1, clearTimer: () => {} }), { ok: false, why: 'refused' });
});
