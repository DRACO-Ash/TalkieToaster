// Route tests for POST /api/v3/hugo/agent. In-process via createApp with a stub model and a stub store, so no
// network. VH-318-F answered this route from the dataset tools alone; VH-777 puts the verified agent loop back, because
// every typed turn the Realtime socket does not carry (all domains, the phone, a socket not ready) lost the model with
// the key set. Covers the agent role, the message validation, the model's answer with its spend rails, the tools-alone
// floor without a model and after a provider failure, and the audit shape.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';
import { TYPED_INSTRUCTIONS } from '../src/hugo/persona.js';
import { FINAL_ANSWER_RULES } from '../src/hugo/agent.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';

function listen(handler) {
  return new Promise((resolve) => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => resolve(s)); });
}
function request(server, path, { method = 'GET', headers = {}, body } = {}) {
  const { port } = server.address();
  const payload = body === undefined ? null : JSON.stringify(body);
  const allHeaders = payload ? { 'content-type': 'application/json', ...headers } : headers;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method, headers: allHeaders }, (res) => {
      let text = '';
      res.on('data', (c) => { text += c; });
      res.on('end', () => { let parsed = null; try { parsed = JSON.parse(text); } catch { parsed = null; } resolve({ status: res.statusCode, payload: parsed }); });
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

const verify = createStaticVerifier({ 'agent-tok': { subject: 'ada', roles: ['agent'] }, 'lead-tok': { subject: 'lena', roles: ['gdm_lead'] } });
const agent = { authorization: 'Bearer agent-tok' };
const lead = { authorization: 'Bearer lead-tok' };
const AGENT = '/api/v3/hugo/agent';

const ROWS = [
  { rev: 1, record: { vendor_id: 'VH-0001', company: 'Orbital Signals Ltd', country: 'United Kingdom', grade: 'Unknown', gdm: 'Not in GDM', section: 'TacSRT' } },
  { rev: 1, record: { vendor_id: 'VH-0002', company: 'Nordic Radar AB', country: 'Sweden', grade: 'In JCO', gdm: 'In GDM', section: 'EMSO' } },
];

function stubs({ replies = [], configured = true, throwModel = false, paidAllowed = true } = {}) {
  const seen = { modelCalls: 0, audit: null, flushed: 0, queries: [] };
  const hugoChat = {
    configured,
    model: 'gpt-6-astra',
    chatOnce: async ({ system, messages, tools }) => {
      seen.modelCalls += 1;
      seen.system = system;
      if (throwModel) throw Object.assign(new Error('hugo model provider error 404 model_not_found'), { statusCode: 502, providerStatus: 404, providerCode: 'model_not_found' });
      const next = replies.shift() || { text: '{"answer":"(exhausted)","cited":[],"entities":[],"numbers":[]}' };
      if (next.tools && tools.length > 0) return { message: { role: 'assistant', content: '', tool_calls: next.tools.map((t, i) => ({ id: 'c' + seen.modelCalls + i, type: 'function', function: { name: t.name, arguments: JSON.stringify(t.args) } })) }, usage: { input_tokens: 5, output_tokens: 5 } };
      seen.lastMessages = messages;
      return { message: { role: 'assistant', content: next.text, tool_calls: [] }, usage: { input_tokens: 5, output_tokens: 5 } };
    },
  };
  const vendorRepo = {
    queryByIntent: async (filterSpec, opts) => {
      seen.queries.push(filterSpec);
      const countries = filterSpec.countries || [];
      const rows = countries.length ? ROWS.filter((r) => countries.includes(r.record.country)) : ROWS;
      return { rows: rows.slice(0, opts.limit), total: rows.length, applied: countries.length ? ['countries'] : [], notApplied: [] };
    },
    getVendor: async (id) => { const r = ROWS.find((x) => x.record.vendor_id === id); return r ? { rev: 1, record: r.record } : null; },
    auditHugoChat: async (actor, detail) => { seen.audit = { actor, detail }; },
    auditHugoQuery: async () => {},
  };
  const app = createApp({ env: {}, vendorRepo, hugoChat, verify, allowedOrigin: ORIGIN, paidCallAllowed: async () => paidAllowed, flushSpend: async () => { seen.flushed += 1; } });
  return { app, seen };
}

const ask = (text) => ({ messages: [{ role: 'user', content: text }], domain: 'space' });

test('a non-agent is refused and a malformed conversation is a 400', async () => {
  const { app } = stubs();
  const server = await listen(app);
  try {
    assert.equal((await request(server, AGENT, { method: 'POST', headers: lead, body: ask('x') })).status, 403);
    assert.equal((await request(server, AGENT, { method: 'POST', headers: agent, body: { messages: [] } })).status, 400);
    assert.equal((await request(server, AGENT, { method: 'POST', headers: agent, body: { messages: [{ role: 'assistant', content: 'hi' }] } })).status, 400);
  } finally { server.close(); }
});

test('a typed turn is answered by the verified agent loop where a model is configured, inside the spend rails (VH-777)', async () => {
  const replies = [
    { tools: [{ name: 'query_records', args: { domain: 'space', filter: { countries: ['Sweden'] } } }] },
    { text: '{"answer":"Nordic Radar AB is the one vendor in Sweden [R1].","cited":["VH-0002"],"entities":["Nordic Radar AB"],"numbers":[]}' },
  ];
  const { app, seen } = stubs({ replies });
  const server = await listen(app);
  try {
    const res = await request(server, AGENT, { method: 'POST', headers: agent, body: ask('show me vendors in Sweden') });
    assert.equal(res.status, 200);
    assert.equal(res.payload.model, true);
    assert.equal(res.payload.fallback, false);
    assert.equal(res.payload.answer, 'Nordic Radar AB is the one vendor in Sweden [R1].');
    assert.equal(res.payload.verification.ok, true);
    assert.deepEqual(res.payload.cost, { usd: 0.0006, pricing: 'listed', excludesWeb: false }, 'priced from the configured model id, 10 in and 10 out');
    assert.equal(seen.modelCalls, 2, 'a tool turn, then the answer');
    assert.deepEqual(seen.queries[0].countries, ['Sweden'], 'the model\'s query reached the store');
    assert.equal(seen.flushed, 1, 'the spend is flushed once');
    assert.ok(seen.system[0].startsWith('You are Hugo, the data co-pilot'), 'the typed brief, not the spoken one');
    assert.deepEqual(seen.system, [TYPED_INSTRUCTIONS, FINAL_ANSWER_RULES], 'and the answer rules beside it');
    assert.ok(!seen.system[0].includes('across all'), 'one domain asks no all-domains brief');
    assert.deepEqual(seen.audit, { actor: 'ada', detail: { domain: 'space', turns: 1, via: 'agent', steps: 1 } });
  } finally { server.close(); }
});

test('all domains brief the model to pass a domain to every tool; a spent cap is a 429 before any model call', async () => {
  const { app, seen } = stubs({ replies: [{ text: '{"answer":"Hello, I am Hugo.","cited":[],"entities":[],"numbers":[]}' }] });
  const server = await listen(app);
  try {
    const res = await request(server, AGENT, { method: 'POST', headers: agent, body: { messages: [{ role: 'user', content: 'hey hugo' }], domain: 'all' } });
    assert.equal(res.status, 200);
    assert.equal(res.payload.answer, 'Hello, I am Hugo.');
    assert.match(seen.system[0], /across all 7 domains \(space, .*\): pass the domain to every tool/);
  } finally { server.close(); }
  const capped = stubs({ paidAllowed: false });
  const s2 = await listen(capped.app);
  try {
    const res = await request(s2, AGENT, { method: 'POST', headers: agent, body: ask('vendors in Sweden') });
    assert.equal(res.status, 429);
    assert.equal(res.payload.error, 'daily_cap_reached');
    assert.equal(capped.seen.modelCalls, 0);
    assert.equal(capped.seen.flushed, 0);
  } finally { s2.close(); }
});

test('without a model, or when the model call throws, the dataset tools answer and say why (VH-777)', async () => {
  const none = stubs({ configured: false });
  const s1 = await listen(none.app);
  try {
    const res = await request(s1, AGENT, { method: 'POST', headers: agent, body: ask('show me vendors in Sweden') });
    assert.equal(res.status, 200);
    assert.equal(res.payload.fallback, true);
    assert.equal(res.payload.model, false);
    assert.equal(res.payload.answer, '1 record matches (countries): Nordic Radar AB (Sweden) [R1].');
    assert.equal(res.payload.providerFailed, undefined);
    assert.equal(none.seen.modelCalls, 0);
    assert.equal(none.seen.flushed, 0, 'nothing paid, nothing flushed');
  } finally { s1.close(); }
  const broken = stubs({ throwModel: true });
  const s2 = await listen(broken.app);
  try {
    const res = await request(s2, AGENT, { method: 'POST', headers: agent, body: ask('show me vendors in Sweden') });
    assert.equal(res.status, 200);
    assert.equal(res.payload.fallback, true);
    assert.equal(res.payload.answer, '1 record matches (countries): Nordic Radar AB (Sweden) [R1].');
    assert.equal(res.payload.providerFailed, true);
    assert.equal(res.payload.providerReason, 'hugo model provider error 404 model_not_found');
    assert.equal(broken.seen.flushed, 1, 'a call that was attempted is still flushed');
  } finally { s2.close(); }
});

// VH-116: WHAT A TURN COST AND HOW MANY LOOKUPS IT USED. The owner ruled that cost is SHOWN per question, so
// the figure the client draws must come from the rate table, from the model's own token counts, and must say
// when it is incomplete because the turn reached the web (whose look-ups are not in those counts).
test('hugoTurnMeasures prices the turn from its tokens, caps the lookups, and flags a web turn', async () => {
  const { hugoTurnMeasures } = await import('../src/api-v3.js');
  const turn = { usage: { input_tokens: 6000, output_tokens: 400 }, steps: [{}, {}] };
  assert.deepEqual(hugoTurnMeasures(turn, 'gpt-6-astra'),
    { cost: { usd: 0.08, pricing: 'listed', excludesWeb: false }, lookups: { used: 2, cap: 24 } });
  const web = { ...turn, steps: new Array(30).fill({}), sources: ['https://example.org/a'] };
  assert.deepEqual(hugoTurnMeasures(web, 'gpt-6-astra').lookups, { used: 24, cap: 24 }, 'never more than the cap');
  assert.equal(hugoTurnMeasures(web, 'gpt-6-astra').cost.excludesWeb, true);
  // Malformed input prices to zero rather than NaN, and an unknown model takes the CEILING rates.
  assert.deepEqual(hugoTurnMeasures({ usage: { input_tokens: 'x' }, steps: 'no' }, 'unknown-model'),
    { cost: { usd: 0, pricing: 'fallback-max', excludesWeb: false }, lookups: { used: 0, cap: 24 } });
  assert.equal(hugoTurnMeasures(null, 'gpt-6-astra').cost.usd, 0);
});

test('the tools-alone floor carries no cost (it spent nothing) and its lookups beside the answer', async () => {
  const { app } = stubs({ configured: false });
  const server = await listen(app);
  try {
    const r = await request(server, AGENT, { method: 'POST', headers: agent, body: ask('vendors in Sweden') });
    assert.equal(r.status, 200);
    assert.equal(r.payload.cost.usd, 0, 'no model, no spend, so the client draws no cost line');
    assert.deepEqual(r.payload.lookups, { used: r.payload.steps.length, cap: 24 });
  } finally { server.close(); }
});

// A TYPED TURN, STREAMED (VH-777 Lane T): asked for `application/x-ndjson`, the route sends a line as each tool finishes
// and the checked answer as the last line, the same answer the JSON reply carries. Never a result, never a claim before
// the check: a step line names the tool and whether it answered, nothing else.
test('a typed turn asked for a stream sends each finished tool, then the checked answer as its last line', async () => {
  const replies = [
    { tools: [{ name: 'query_records', args: { domain: 'space', filter: { countries: ['Sweden'] } } }, { name: 'describe_app', args: {} }] },
    { text: '{"answer":"Nordic Radar AB is the one vendor in Sweden [R1].","cited":["VH-0002"],"entities":["Nordic Radar AB"],"numbers":[]}' },
  ];
  const { app } = stubs({ replies });
  const server = await listen(app);
  try {
    const raw = await new Promise((resolve, reject) => {
      const body = JSON.stringify(ask('show me vendors in Sweden'));
      const req = http.request({ host: '127.0.0.1', port: server.address().port, path: AGENT, method: 'POST',
        headers: { ...agent, 'content-type': 'application/json', accept: 'application/x-ndjson' } }, (res) => {
        let text = '';
        res.on('data', (c) => { text += c; });
        res.on('end', () => resolve({ status: res.statusCode, type: res.headers['content-type'], text }));
      });
      req.on('error', reject);
      req.end(body);
    });
    assert.equal(raw.status, 200);
    assert.match(raw.type, /^application\/x-ndjson/);
    const lines = raw.text.trim().split('\n').map((l) => JSON.parse(l));
    assert.deepEqual(lines.slice(0, -1), [{ type: 'step', tool: 'query_records', ok: true }, { type: 'step', tool: 'describe_app', ok: true }], 'each tool, in the model\'s order');
    const last = lines.at(-1);
    assert.equal(last.type, 'answer');
    assert.deepEqual([last.answer, last.verification.ok], ['Nordic Radar AB is the one vendor in Sweden [R1].', true]);
    assert.doesNotMatch(lines.slice(0, -1).map((l) => JSON.stringify(l)).join(''), /Nordic|Sweden|VH-0002/, 'no result travels before the answer');
  } finally { server.close(); }
});
