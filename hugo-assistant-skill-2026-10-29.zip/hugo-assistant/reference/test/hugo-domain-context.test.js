// VH-233: HUGO ON A DOMAIN HAS THAT DOMAIN'S CONTEXT, in three places the VH-220 audit (A9) found it missing.
// 1. The chat grounding pack dropped a domain record's GDM stage and capability facets. Retired with the
//    streaming chat route in VH-318-F, so its two tests went with it.
// 2. A Hugo web find on a domain provider was audited as a Space `vendor` event, so the provider's own
//    history, which reads rows keyed on its domain, never showed it.
// 3. Voice lookups defaulted to Space whatever domain was on screen: the browser never said which.
import test from 'node:test';
import assert from 'node:assert/strict';

import { realtimeDomainFromUrl } from '../src/hugo/openai-realtime.js';
import { createVendorRepo } from '../src/db/vendor-repo.js';
import { createDomainRepo } from '../src/db/domain-repo.js';
import { AIR_DESCRIPTOR } from '../src/domain/descriptor.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';

test('a Hugo web find on a domain provider shows in that provider\'s own history', async () => {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  try {
    const vendors = createVendorRepo(executor);
    const air = createDomainRepo(executor, AIR_DESCRIPTOR);
    await vendors.auditHugoFind('lead', { vendorId: 'host:aero.example', cohortSize: 1, domain: 'air' });
    const history = await air.listHistory('host:aero.example');
    const rows = Array.isArray(history) ? history : history.rows || history.entries || [];
    assert.ok(rows.some((r) => r.action === 'hugo-find'), 'the find is in the Air provider\'s history: ' + JSON.stringify(history).slice(0, 300));
  } finally {
    await executor.close();
  }
});

for (const [url, expected] of [['/api/v3/hugo/realtime?domain=air', 'air'], ['/api/v3/hugo/realtime?domain=natural-resources', 'natural_resources'],
  ['/api/v3/hugo/realtime?domain=space', 'space'],
  // VH-280: no domain, or one not registered, is '' rather than Space, and the upgrade is refused on it.
  ['/api/v3/hugo/realtime', ''], ['/api/v3/hugo/realtime?domain=%3Cscript%3E', ''], ['', '']]) {
  test('a voice session opened at ' + (url || '(no url)') + ' looks up ' + (expected || 'nothing'), () => {
    assert.equal(realtimeDomainFromUrl(url), expected);
  });
}

test('the browser opens a voice session naming the domain on screen', async () => {
  const { readFileSync } = await import('node:fs');
  // The URL is built in one place since VH-318-C (`realtimeUrl`, which typed turns and Talk share), and every
  // socket the app opens to the bridge passes it the domain on screen.
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const view = readFileSync(new URL('../public/views/hugo-stream.js', import.meta.url), 'utf8');
  const opens = view.match(/\/api\/v3\/hugo\/realtime[^;\n]*/g) || [];
  assert.equal(opens.length, 1, 'the one URL builder was found');
  assert.match(opens[0], /\?domain=' \+ encodeURIComponent\(domain /, opens[0]);
  assert.match(src, /realtimeUrl\(location\.origin, state\.domain, /, 'Talk passes the domain on screen');
  assert.match(src, /domain: \(\) => state\.domain,/, 'typed turns pass the domain on screen');
  assert.doesNotMatch(src, /\/api\/v3\/hugo\/realtime/, 'no second URL builder in the shell');
});
