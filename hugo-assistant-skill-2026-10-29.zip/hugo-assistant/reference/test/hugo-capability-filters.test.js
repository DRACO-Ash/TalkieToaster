// HUGO'S CAPABILITY FILTERS REACH THE DATABASE (V1.82, RT-Q4), over real Postgres (pglite). The plan test
// proves the SQL shape; this proves the rows, because a clause can be well-formed and still read the wrong key.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createVendorRepo } from '../src/db/vendor-repo.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';
import { SPACE_DESCRIPTOR } from '../src/domain/descriptor.js';
import { familyKeyOfProductType } from '../src/hugo/families.js';

const types = () => [...SPACE_DESCRIPTOR.vocab.product_types];

test('families and product types each narrow to the right rows, and the clauses VH-824 retired narrow nothing', async () => {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  const sarType = types().find((t) => familyKeyOfProductType(t) === 'SAR');
  const eoType = types().find((t) => familyKeyOfProductType(t) === 'EO');
  assert.ok(sarType && eoType, 'the vocabulary carries a SAR and an EO type');
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Radar Co', country: 'France', grade: 'Unknown', gdm: 'Not in GDM',
    product_types: [sarType], size_band: '11-50', export_control: { itar: 'Controlled', releasability: ['NATO'] } }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'Optics Co', country: 'France', grade: 'Unknown', gdm: 'Not in GDM',
    product_types: [eoType], size_band: '5000+', export_control: { itar: 'Not controlled', releasability: ['Five Eyes'] } }, 'seed');
  const ids = async (spec) => (await repo.queryByIntent(spec, { limit: 50, offset: 0 })).rows.map((r) => r.record.vendor_id).sort();
  assert.deepEqual(await ids({ families: ['SAR'] }), ['VH-0001'], 'show me the SAR vendors');
  assert.deepEqual(await ids({ families: ['EO'] }), ['VH-0002']);
  assert.deepEqual(await ids({ productTypes: [eoType] }), ['VH-0002']);
  // Size band, control status and releasability are still stored but no longer filter (VH-824): neither row is lost.
  for (const spec of [{ sizeBands: ['11-50'] }, { controlStatus: ['Controlled'] }, { releasability: ['NATO'] }]) {
    const res = await repo.queryByIntent(spec, { limit: 50, offset: 0 });
    assert.deepEqual([res.total, res.applied], [2, []], JSON.stringify(spec) + ' applies nothing');
  }
  // Two clauses compose with AND, as every other clause does.
  assert.deepEqual(await ids({ families: ['SAR'], productTypes: [eoType] }), []);
});
