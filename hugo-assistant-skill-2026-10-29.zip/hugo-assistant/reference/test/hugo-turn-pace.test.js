// A TYPED TURN'S PACE (VH-777 Lane T): one turn's tool calls run together, the ones that number records still in the
// model's order so a citation means the same thing each time; and every model request has a deadline, so a provider
// that never answers is abandoned rather than holding the turn open.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runHugoAgent } from '../src/hugo/agent.js';
import { createLedger } from '../src/hugo/tools.js';
import { createOpenAiChat, MODEL_REQUEST_MS } from '../src/hugo/openai-chat.js';

const wait = (ms) => new Promise((resolve) => { setTimeout(resolve, ms); });

test('one turn\'s calls run together, the record tools one after another in order, past the budget refused', async () => {
  const log = [];
  const runner = {
    ledger: createLedger(), defs: [{}], modeOf: () => 'read',
    async run(name) {
      log.push('start ' + name);
      await wait({ web_lookup: 40, describe_app: 40, query_records: 30, get_record: 5 }[name] ?? 1);
      log.push('end ' + name);
      return { ok: true, result: { tool: name } };
    },
  };
  const calls = ['web_lookup', 'query_records', 'describe_app', 'get_record', 'app_state'];
  const toolCalls = calls.map((name, i) => ({ id: 'c' + i, type: 'function', function: { name, arguments: '{}' } }));
  let turn = 0;
  const chat = {
    async chatOnce() {
      turn += 1;
      if (turn === 1) return { message: { role: 'assistant', content: null, tool_calls: toolCalls }, usage: {} };
      return { message: { role: 'assistant', content: '{"answer":"Done."}' }, usage: {} };
    },
  };
  const caps = { maxSteps: 4, maxToolCalls: 4, wallMs: 60_000, answerMaxChars: 4000 };
  const out = await runHugoAgent({ chat, runner, system: ['s'], messages: [{ role: 'user', content: 'q' }], caps });
  const at = (entry) => log.indexOf(entry);
  assert.ok(at('start describe_app') < at('end web_lookup'), 'the help and the web run together: ' + log.join(', '));
  assert.ok(at('end query_records') < at('start get_record'), 'the record tools one after another: ' + log.join(', '));
  assert.ok(at('start get_record') > at('start query_records'), 'and in the model\'s order');
  assert.equal(at('start app_state'), -1, 'the 5th call is past the budget of 4 and never runs');
  assert.deepEqual(out.steps.map((s) => [s.tool, s.ok]), [['web_lookup', true], ['query_records', true], ['describe_app', true], ['get_record', true], ['app_state', false]], 'recorded in the model\'s order');
});

test('every model request has a deadline, on each of the 3 endpoints', async () => {
  assert.equal(MODEL_REQUEST_MS, 45_000);
  const signals = [];
  const never = (url, opts) => new Promise((resolve, reject) => {
    signals.push(opts.signal);
    opts.signal.addEventListener('abort', () => reject(opts.signal.reason));
  });
  const chat = createOpenAiChat({ apiKey: 'k', fetchImpl: never, requestMs: 30 });
  const started = Date.now();
  // A deadline's timer does not hold the process open (a live request does, in the server), so this test holds it.
  const hold = setInterval(() => {}, 1000);
  try {
    await assert.rejects(chat.chatOnce({ system: ['s'], messages: [{ role: 'user', content: 'q' }] }));
    await assert.rejects(chat.chatOnce({ system: ['s'], messages: [{ role: 'user', content: 'q' }], tools: [{ type: 'function', function: { name: 't', parameters: { type: 'object', properties: {} } } }] }));
    await assert.rejects(chat.searchWeb({ query: 'q' }));
  } finally { clearInterval(hold); }
  assert.equal(signals.length, 3);
  assert.ok(signals.every((s) => s instanceof AbortSignal && s.aborted), 'each request was abandoned at its deadline');
  assert.ok(Date.now() - started < 5_000, 'and promptly');
});
