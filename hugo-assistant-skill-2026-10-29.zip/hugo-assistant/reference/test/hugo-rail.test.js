// THE ONE RAIL (VH-318-D). Typed and spoken turns share one conversation, and a Hugo turn carries the state a
// streamed answer moves through: streaming, checking, verified, withdrawn. These builders are pure, so the
// user-visible risks are pinned here: every reflected value is escaped, a spoken turn is tagged and flagged
// rather than withdrawn (audio cannot be unsaid), and a proposal card refuses anything it cannot honestly offer.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { turnHtml, turnMarkHtml, channelOf, TURN_STATES, proposalKind, proposalCardHtml, isLiveSpoken, placeHeard, appendSaid, settleSpoken, proposalFromFrame, proposalRefusal } from '../public/views/hugo-rail.js';

const HOSTILE = '<img src=x onerror=alert(1)>';

test('a turn names its speaker, escapes its text and tags only a spoken turn', () => {
  const you = turnHtml({ role: 'user', content: HOSTILE });
  assert.match(you, /class="hugo-turn hugo-turn-you"/);
  assert.match(you, /<span class="hugo-turn-who">You<\/span>/);
  assert.ok(!you.includes('<img'), 'the operator\'s text is escaped');
  assert.ok(you.includes('&lt;img'));
  assert.ok(!you.includes('hugo-turn-via'), 'typing is the default and is not tagged');
  const spoken = turnHtml({ role: 'user', content: 'Which vendors?', channel: 'spoken' });
  assert.match(spoken, /data-channel="spoken"/);
  assert.match(spoken, /You<span class="hugo-turn-via">spoken<\/span>/);
  assert.equal(channelOf({ channel: 'carrier pigeon' }), 'typed', 'an unknown channel reads as typed');
});

test('a Hugo turn keeps its name when its body is the verified answer', () => {
  const html = turnHtml({ role: 'assistant', content: 'x' }, { bodyHtml: '<div class="hugo-agent">ok</div>', afterHtml: '<span class="slot"></span>' });
  assert.match(html, /^<div class="hugo-turn hugo-turn-hugo" data-channel="typed"><span class="hugo-turn-who">Hugo<\/span><div class="hugo-agent">ok<\/div><span class="slot"><\/span><\/div>$/);
});

test('each state has its place: a live caret, a checking mark, a verdict, a withdrawal', () => {
  assert.deepEqual([...TURN_STATES], ['streaming', 'checking', 'verified', 'withdrawn']);
  const live = turnHtml({ role: 'assistant', content: 'Four in', state: 'streaming' });
  assert.match(live, /hugo-turn hugo-turn-hugo is-streaming/);
  assert.match(live, /<span class="hugo-turn-text hugo-turn-live">Four in<\/span>/);
  assert.ok(!live.includes('hugo-mark'), 'a streaming turn carries no mark; the caret says it');
  assert.match(turnHtml({ role: 'assistant', content: 'x', state: 'checking' }), /is-checking.*<span class="hugo-mark hugo-mark-checking">Checking against the dataset<\/span>/);
  assert.match(turnHtml({ role: 'assistant', content: 'x', state: 'verified' }), /hugo-verify-ok">Verified against the dataset/);
  assert.match(turnHtml({ role: 'assistant', content: 'x', state: 'withdrawn' }), /is-withdrawn.*Withdrawn: it could not be checked against the dataset/);
  assert.equal(turnHtml({ role: 'assistant', content: 'x', state: 'bogus' }).includes('is-bogus'), false, 'an unknown state is not reflected');
  assert.match(turnHtml({ role: 'assistant', content: '', state: 'streaming' }, { pending: true }), /hugo-turn-pending/);
});

test('a spoken turn is flagged, not withdrawn, because audio already played cannot be unsaid', () => {
  assert.match(turnMarkHtml('withdrawn', 'spoken'), /Flagged: Hugo said this aloud/);
  assert.match(turnMarkHtml('withdrawn', 'typed'), /^<span class="hugo-verify hugo-verify-held">Withdrawn:/);
  assert.equal(turnMarkHtml('streaming', 'typed'), '');
  assert.equal(turnMarkHtml('', 'spoken'), '');
  assert.equal(turnHtml({ role: 'user', content: 'x', state: 'withdrawn' }).includes('hugo-verify'), false, 'an operator turn never carries a verdict');
});

const VIEW = { tool: 'propose_view', requiresConfirmation: true, view: 'map', intent: { domain: 'air', view: 'map', filterSpec: {} } };
const SCAN = { tool: 'propose_scan', requiresConfirmation: true, design: { domains: ['air'] }, compiled: true };
const UPDATE = { tool: 'propose_update', requiresConfirmation: true, domain: 'maritime', id: 'acme', source: 'https://example.gov/x', changes: { before: { website: '' }, after: { website: 'https://acme.example' } } };

test('a proposal is validated at the boundary: the tool, the confirmation flag and the fields its card reads', () => {
  assert.equal(proposalKind(VIEW), 'view');
  assert.equal(proposalKind(SCAN), 'scan');
  assert.equal(proposalKind(UPDATE), 'update');
  for (const bad of [
    null, 'propose_view', [], { ...VIEW, requiresConfirmation: 'yes' }, { ...VIEW, tool: 'query_records' },
    { ...VIEW, intent: null }, { ...VIEW, view: 7 }, { ...SCAN, design: [] }, { ...UPDATE, source: 'javascript:alert(1)' },
    { ...UPDATE, id: '' }, { ...UPDATE, changes: null }, { ...UPDATE, domain: 'x'.repeat(41) },
  ]) assert.equal(proposalKind(bad), '', JSON.stringify(bad));
});

test('a proposal card offers one action that opens the confirmation surface, and escapes the update it shows', () => {
  const view = proposalCardHtml({ ...VIEW, channel: 'spoken' }, { bodyHtml: '<p>body</p>', index: 2 });
  assert.match(view, /^<div class="hugo-proposal" data-kind="view"><span class="hugo-proposal-head">Hugo offers to show you<span class="hugo-turn-via">spoken<\/span><\/span><p>body<\/p>/);
  assert.match(view, /data-hugo-proposal="2">Show me<\/button>/);
  assert.match(proposalCardHtml(SCAN, { bodyHtml: '' }), /data-hugo-proposal="0">Set up this scan</);
  const hostile = proposalCardHtml({ ...UPDATE, id: HOSTILE, source: 'https://e.x/' + HOSTILE, changes: { before: {}, after: { [HOSTILE]: HOSTILE } } });
  assert.ok(!hostile.includes('<img'), 'every reflected value in an update card is escaped');
  assert.match(hostile, /Open the company to apply/);
  assert.match(proposalCardHtml({ ...UPDATE, changes: { before: {}, after: {} } }), /That would not change anything for this company/);
  assert.equal(proposalCardHtml({ ...UPDATE, requiresConfirmation: false }), '', 'a refused proposal renders nothing');
  assert.match(proposalCardHtml(SCAN, { index: -3 }), /data-hugo-proposal="0"/, 'a bad index falls back to zero');
});

test('the rail markup puts the conversation above a pinned composer, with the settings behind one disclosure', () => {
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  const rail = html.slice(html.indexOf('<aside id="hugo-rail"'), html.indexOf('</aside>', html.indexOf('<aside id="hugo-rail"')));
  const at = (needle) => { const i = rail.indexOf(needle); assert.ok(i > 0, needle + ' is in the rail'); return i; };
  assert.ok(at('id="hugo-review"') < at('class="hugo-composer"'), 'the conversation comes before the composer');
  assert.ok(at('class="hugo-composer"') < at('id="hugo-input"'), 'the input is in the composer');
  assert.ok(at('class="hugo-composer"') < at('class="hugo-wake-row"'), 'the wake word stays in view, in the composer');
  const disclosure = rail.slice(at('<details class="hugo-settings">'), rail.indexOf('</details>'));
  for (const id of ['hugo-preflight-run', 'hugo-mute', 'hugo-voice']) assert.match(disclosure, new RegExp('id="' + id + '"'), id + ' sits behind the disclosure');
  assert.doesNotMatch(disclosure, /hugo-wake/, 'the wake word is not hidden behind it');
});

test('spoken turns join the one history: the operator before a reply under way, Hugo streaming then settled', () => {
  const history = [{ role: 'user', content: 'typed first' }];
  assert.equal(appendSaid(history, 'Four in'), true, 'the first piece opens a turn');
  assert.equal(appendSaid(history, ' Germany.'), false, 'later pieces grow it in place');
  assert.equal(isLiveSpoken(history.at(-1)), true);
  assert.equal(placeHeard(history, 'How many in Germany?'), true);
  assert.deepEqual(history.map((t) => [t.role, t.channel ?? 'typed', t.content]), [
    ['user', 'typed', 'typed first'], ['user', 'spoken', 'How many in Germany?'], ['assistant', 'spoken', 'Four in Germany.'],
  ], 'the late transcript of the question is placed before the reply it prompted');
  assert.equal(settleSpoken(history), true);
  assert.equal(history.at(-1).state, undefined, 'a settled turn carries no state');
  assert.equal(settleSpoken(history), false, 'nothing left to settle');
  assert.equal(placeHeard(history, 'And France?'), true);
  assert.equal(history.at(-1).content, 'And France?', 'with no reply under way the question goes last');
  assert.equal(appendSaid(history, ''), false);
  assert.equal(placeHeard(history, ''), false);
  assert.equal(placeHeard(null, 'x'), false);
  assert.equal(appendSaid(undefined, 'x'), false);
  assert.equal(settleSpoken('nope'), false);
});

// VH-318-H: the client half of the proposal frame's boundary. A frame off the voice socket is read only when it is
// the relay's own type and carries a proposal this rail can honestly offer; anything else is dropped, not rendered.
test('a relayed proposal frame is read only when its type and its proposal are both valid', () => {
  assert.deepEqual(proposalFromFrame({ type: 'hugo.proposal', proposal: UPDATE }), UPDATE);
  assert.deepEqual(proposalFromFrame({ type: 'hugo.proposal', proposal: VIEW }), VIEW);
  for (const bad of [
    null, 'hugo.proposal', { type: 'hugo.proposal' }, { type: 'hugo.proposal', proposal: { ...SCAN, requiresConfirmation: false } },
    { type: 'response.function_call_arguments.done', proposal: SCAN }, { type: 'hugo.proposal', proposal: { ...UPDATE, source: 'ftp://x' } },
  ]) assert.equal(proposalFromFrame(bad), null, JSON.stringify(bad));
});

test('an update for a record in another catalogue names the catalogue to switch to instead of opening the wrong store', () => {
  const labelOf = (d) => ({ maritime: 'Maritime' })[d];
  assert.equal(proposalRefusal(UPDATE, 'maritime', labelOf), '', 'the domain on screen opens');
  assert.equal(proposalRefusal(UPDATE, 'air', labelOf), 'This change is to a company in the Maritime domain. Switch to Maritime to review it.');
  assert.match(proposalRefusal({ ...UPDATE, domain: 'national_security' }, 'space', () => ''), /in the national_security domain/, 'an unnamed domain falls back to its id');
  assert.match(proposalRefusal(UPDATE, 'air', null), /in the maritime domain/);
  assert.equal(proposalRefusal(VIEW, 'space', labelOf), '', 'only an update is refused this way');
  assert.equal(proposalRefusal(null, 'space', labelOf), '');
});
