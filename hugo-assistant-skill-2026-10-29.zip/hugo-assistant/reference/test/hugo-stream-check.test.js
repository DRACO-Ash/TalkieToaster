// VH-318-E, the server half: grounding under streaming. A finished streamed answer is checked against the session's
// tool results; the verdict reaches the browser as a `vh.grounding` frame; a typed answer that fails is WITHDRAWN, a
// spoken one FLAGGED and corrected aloud once per turn; and the check fails closed.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { checkStreamedAnswer, suffixedNamesIn } from '../src/hugo/stream-check.js';
import { createLedger } from '../src/hugo/tools.js';
import { createRealtimeBridge, SPOKEN_CORRECTION_INSTRUCTIONS } from '../src/hugo/openai-realtime.js';
import { createVoiceRunner } from '../src/hugo/voice-runner.js';
import { domainIds } from '../src/domain/descriptor.js';

function ledgerWith() {
  const l = createLedger();
  l.addRow({ id: 'VH-0001', name: 'Norss Ltd', domain: 'space' });
  l.addRow({ id: 'P-1', name: 'Acme Space', domain: 'air' });
  l.addNumbers({ total: 12, shown: 3 });
  l.addLinks('https://norss.co.uk/about');
  return l;
}

test('the check passes an answer drawn from the tool results, and names each thing it cannot find', () => {
  const l = ledgerWith();
  assert.deepEqual(checkStreamedAnswer('There are 12 matching records; The Norss Ltd and Acme Space GmbH lead [R2]. See https://norss.co.uk/about.', l), { ok: true, violations: [] });
  const bad = checkStreamedAnswer('There are 14 records, Orbital Widgets Ltd among them [R9]; see https://evil.example/x', l);
  assert.equal(bad.ok, false);
  assert.deepEqual(bad.violations.sort(), [
    '"Orbital Widgets Ltd" was not returned by any tool',
    'reference [R9] was not returned by any tool',
    'the figure 14 appears in no tool result',
    'the source https://evil.example/x was not returned by any tool',
  ]);
  assert.deepEqual(checkStreamedAnswer('Hello, how can I help with the dataset today?', l), { ok: true, violations: [] }, 'a greeting states nothing');
  assert.deepEqual(suffixedNamesIn('Ltd alone. UK Space Agency.'), [], 'a suffix alone, or a name with none, is not read');
});

function mkSocket() {
  const handlers = {};
  return {
    sent: [], closed: false,
    on(ev, cb) { if (!handlers[ev]) { handlers[ev] = []; } handlers[ev].push(cb); return this; },
    send(data) { this.sent.push(data); },
    close() { this.closed = true; },
    emit(ev, data) { for (const cb of handlers[ev] || []) cb(data); },
  };
}
function harness(opts) {
  let upstream = null;
  const bridge = createRealtimeBridge({ apiKey: 'sk', wsFactory: () => { upstream = mkSocket(); return upstream; } });
  const client = mkSocket();
  bridge.connect(client, opts);
  upstream.emit('open');
  const up = (o) => upstream.emit('message', JSON.stringify(o));
  const frames = () => client.sent.map((t) => JSON.parse(t)).filter((e) => e.type === 'vh.grounding');
  const sentUp = () => upstream.sent.map((t) => JSON.parse(t));
  return { client, up, frames, sentUp, get upstream() { return upstream; } };
}
const typed = JSON.stringify({ type: 'conversation.item.create', item: { type: 'message', role: 'user', content: [{ type: 'input_text', text: 'q' }] } });
const pass = () => ({ ok: true, violations: [] });
const failing = () => ({ ok: false, violations: ['the figure 99 appears in no tool result'] });

test('a typed answer that passes is verified, after its response.done reaches the browser', () => {
  const seen = [];
  const h = harness({ checkAnswer: (t) => { seen.push(t); return pass(); } });
  h.client.emit('message', typed);
  h.up({ type: 'response.output_text.delta', response_id: 'r1', delta: 'There are ' });
  h.up({ type: 'response.output_text.delta', response_id: 'r1', delta: '12.' });
  h.up({ type: 'response.done', response: { id: 'r1', output: [{ type: 'message' }] } });
  assert.deepEqual(seen, ['There are 12.'], 'the whole answer is checked, once');
  assert.deepEqual(h.frames(), [{ type: 'vh.grounding', response_id: 'r1', modality: 'text', state: 'verified', violations: [] }]);
  const types = h.client.sent.map((t) => JSON.parse(t).type);
  assert.ok(types.indexOf('response.done') < types.indexOf('vh.grounding'));
});

test('a typed answer that FAILS the check is withdrawn, with the reasons', () => {
  const h = harness({ checkAnswer: failing });
  h.client.emit('message', typed);
  h.up({ type: 'response.output_text.delta', response_id: 'r1', delta: 'There are 99.' });
  h.up({ type: 'response.done', response: { id: 'r1', output: [{ type: 'message' }] } });
  assert.deepEqual(h.frames(), [{ type: 'vh.grounding', response_id: 'r1', modality: 'text', state: 'withdrawn', violations: ['the figure 99 appears in no tool result'] }]);
});

test('the check FAILS CLOSED: no checker, or one that throws, withdraws rather than passes', () => {
  for (const checkAnswer of [undefined, () => { throw new Error('boom'); }, () => null]) {
    const h = harness({ checkAnswer });
    h.up({ type: 'response.output_text.delta', response_id: 'r1', delta: 'Anything.' });
    h.up({ type: 'response.done', response: { id: 'r1', output: [] } });
    assert.equal(h.frames()[0].state, 'withdrawn', String(checkAnswer));
  }
});

test('a response that called a tool, or said nothing, is not checked', () => {
  const calls = [];
  const h = harness({ checkAnswer: (t) => { calls.push(t); return pass(); } });
  h.up({ type: 'response.output_text.delta', response_id: 'r1', delta: 'Let me look.' });
  h.up({ type: 'response.done', response: { id: 'r1', output: [{ type: 'function_call' }] } });
  h.up({ type: 'response.done', response: { id: 'r2', output: [] } });
  assert.deepEqual(calls, []);
  assert.deepEqual(h.frames(), []);
});

test('a SPOKEN answer that fails is flagged and corrected aloud once per turn; a new turn may be corrected again', () => {
  const h = harness({ checkAnswer: failing });
  const speak = (id) => {
    h.up({ type: 'response.output_audio_transcript.delta', response_id: id, delta: 'There are 99.' });
    h.up({ type: 'response.done', response: { id, output: [{ type: 'message' }] } });
  };
  h.up({ type: 'input_audio_buffer.committed' });
  h.upstream.sent.length = 0;
  speak('a1');
  assert.deepEqual(h.frames().map((f) => [f.modality, f.state]), [['audio', 'flagged']]);
  assert.deepEqual(h.sentUp(), [{ type: 'response.create', response: { instructions: SPOKEN_CORRECTION_INSTRUCTIONS, tool_choice: 'none' } }]);
  const corrections = () => h.sentUp().filter((e) => e.response?.instructions).length;
  h.up({ type: 'response.created', response: { id: 'a2' } });
  speak('a2'); // the correction itself fails too: flagged, never itself corrected
  assert.equal(h.frames().length, 2);
  assert.equal(corrections(), 1);
  speak('a3'); // a second failing answer in the same spoken turn is flagged, not corrected again
  assert.equal(h.frames().length, 3);
  assert.equal(corrections(), 1);
  h.up({ type: 'input_audio_buffer.committed' });
  speak('a4');
  assert.equal(corrections(), 2, 'a new turn can be corrected');
});

test('a typed turn that arrives while a spoken correction is speaking waits for it', () => {
  const h = harness({ checkAnswer: failing });
  h.up({ type: 'input_audio_buffer.committed' });
  h.up({ type: 'response.output_audio_transcript.delta', response_id: 'a1', delta: 'There are 99.' });
  h.up({ type: 'response.done', response: { id: 'a1', output: [] } });
  h.upstream.sent.length = 0;
  h.client.emit('message', typed);
  assert.deepEqual(h.sentUp().map((e) => e.type), ['conversation.item.create'], 'the correction holds the one response');
  h.up({ type: 'response.created', response: { id: 'a2' } });
  h.up({ type: 'response.done', response: { id: 'a2', output: [] } });
  assert.deepEqual(h.sentUp().at(-1), { type: 'response.create', response: { output_modalities: ['text'] } });
});

test('the voice runner checks against everything its tools returned this session, on every domain', async () => {
  for (const domain of domainIds()) {
    const repo = { queryProviders: async () => ({ rows: [], total: 7 }) };
    const runner = createVoiceRunner({
      vendorRepo: { queryByIntent: async () => ({ rows: [], total: 7 }) }, domainRepoFor: () => repo, defaultDomain: domain,
    });
    assert.equal(runner.check('There are 7 matching records.').ok, false, domain + ': nothing looked up yet');
    await runner.run('count_records', { domain });
    assert.equal(runner.check('There are 7 matching records.').ok, true, domain);
    assert.equal(runner.check('There are 8 matching records.').ok, false, domain);
  }
});

test('the upgrade listener checks every finished answer with the session runner (wired)', () => {
  // The listener moved beside its gate (VH-665); test/realtime-upgrade-gate.test.js holds that src/index.js wires it.
  const src = readFileSync(new URL('../src/hugo/realtime-upgrade-gate.js', import.meta.url), 'utf8');
  assert.match(src, /checkAnswer: \(text\) => runner\.check\(text\)/);
});
