// VH-263: CROSS-DOMAIN HUNTS AND HUGO MAP EACH DOMAIN'S OWN FACETS, NOT ONLY SPACE'S ORBITAL FACET.
//
// The cross-domain descriptor carried Space's orbital regime as its only capability facet, so a hunt "across every
// domain" naming a sensing modality, a target stratum or a resource class kept it only if Space happened to hold
// the word; and Hugo mapped no capability facet at all, on any store, although its own compile prompt listed them.
// Proved here for all 7 stores through the shared tool runner, and for the cross-domain union in both the scan's
// design normaliser and Hugo's.

import test from 'node:test';
import assert from 'node:assert/strict';

import { allDomainsDescriptor, allFacets, intentDescriptor, validateDescriptor, domainIds, getDescriptor, SPACE_DESCRIPTOR, MARITIME_DESCRIPTOR } from '../src/domain/descriptor.js';
import { normaliseScanDesign } from '../src/scan/scan-design.js';
import { normaliseViewIntent } from '../src/hugo/view-intent.js';
import { resolveDeterministic } from '../src/hugo/deterministic.js';
import { createToolRunner } from '../src/hugo/tools.js';
import { createVendorRepo } from '../src/db/vendor-repo.js';
import { createDomainRepo } from '../src/db/domain-repo.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';
import { hugoUnderstoodHtml } from '../public/views/hugo-intent.js';

const IDS = domainIds();
// Every facet each store declares, measured from the registry rather than listed from memory.
const DECLARED = [...new Set(IDS.flatMap((id) => getDescriptor(id).capabilityFacets.map((f) => f.key)))];
const firstValue = (descriptor, key) => [...descriptor.vocab[key]][0];

test('VH-263: the cross-domain descriptor carries every domain\'s facets, each resolving in the union', () => {
  const all = allDomainsDescriptor();
  assert.deepEqual(all.capabilityFacets.map((f) => f.key).sort(), [...DECLARED].sort());
  assert.ok(DECLARED.length > SPACE_DESCRIPTOR.capabilityFacets.length, 'more than the orbital regime');
  for (const id of IDS) {
    for (const f of getDescriptor(id).capabilityFacets) {
      for (const v of getDescriptor(id).vocab[f.key]) assert.ok(all.vocab[f.key].has(v), id + ' ' + f.key + ' ' + v);
    }
  }
  assert.equal(validateDescriptor(all).ok, true, validateDescriptor(all).errors.join('; '));
  assert.equal(allFacets().find((f) => f.key === 'capability_class').label, 'Capability class', 'four wordings, one neutral label');
  // The two-slot rule still binds a single domain.
  const three = { ...MARITIME_DESCRIPTOR, capabilityFacets: [...MARITIME_DESCRIPTOR.capabilityFacets, SPACE_DESCRIPTOR.capabilityFacets[0]], vocab: { ...MARITIME_DESCRIPTOR.vocab, regime_capabilities: SPACE_DESCRIPTOR.vocab.regime_capabilities } };
  assert.equal(validateDescriptor(three).ok, false);
});

test('VH-263: a cross-domain hunt design keeps every domain\'s own facet values', () => {
  const fields = {};
  for (const id of IDS) for (const f of getDescriptor(id).capabilityFacets) fields[f.key] = [...(fields[f.key] || []), firstValue(getDescriptor(id), f.key)];
  const { design, unmapped } = normaliseScanDesign({ fields }, allDomainsDescriptor());
  assert.deepEqual(unmapped, []);
  for (const [key, values] of Object.entries(fields)) assert.deepEqual([...design.fields[key]].sort(), [...new Set(values)].sort(), key);
});

test('VH-263: Hugo keeps a store\'s own facet, reports another store\'s, and keeps every store\'s across all domains', () => {
  const ids = { domainIds: IDS };
  const own = normaliseViewIntent({ filterSpec: { target_stratum: ['Seabed'] } }, MARITIME_DESCRIPTOR, ids);
  assert.deepEqual(own.intent.filterSpec.target_stratum, ['Seabed']);
  const foreign = normaliseViewIntent({ filterSpec: { regime_capabilities: ['LEO'] } }, MARITIME_DESCRIPTOR, ids);
  assert.deepEqual(foreign.unmapped, [{ field: 'regime_capabilities', value: 'LEO' }], 'never dropped in silence');
  const across = normaliseViewIntent({ filterSpec: { regime_capabilities: ['LEO'], target_stratum: ['Seabed'] } }, intentDescriptor('space', true), { ...ids, crossDomain: true });
  assert.deepEqual(across.unmapped, []);
  assert.deepEqual(across.intent.filterSpec.target_stratum, ['Seabed']);
  assert.deepEqual(across.intent.filterSpec.regime_capabilities, ['LEO']);
  assert.equal(intentDescriptor('air', false), getDescriptor('air'));
});

test('VH-263: the offline resolver reads each store\'s facets (the compile prompt went with VH-318-F)', () => {
  assert.deepEqual(resolveDeterministic('show me the Seabed providers', MARITIME_DESCRIPTOR).raw.filterSpec.target_stratum, ['Seabed']);
  assert.deepEqual(resolveDeterministic('which vendors serve LEO', SPACE_DESCRIPTOR).raw.filterSpec.regime_capabilities, ['LEO']);
  assert.match(hugoUnderstoodHtml({ filterSpec: { target_stratum: ['Seabed'] } }), /Target stratum/);
});

async function plantAll(executor) {
  const vendorRepo = createVendorRepo(executor);
  const base = { country: 'Sweden', grade: 'Unknown', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] };
  await vendorRepo.createVendor({ ...base, vendor_id: 'VH-0001', company: 'Alpha', regime_capabilities: [firstValue(SPACE_DESCRIPTOR, 'regime_capabilities')] }, 'seed');
  await vendorRepo.createVendor({ ...base, vendor_id: 'VH-0002', company: 'Beta', regime_capabilities: [] }, 'seed');
  const repos = {};
  for (const id of IDS.filter((d) => d !== 'space')) {
    const d = getDescriptor(id);
    const repo = createDomainRepo(executor, d);
    const fields = Object.fromEntries(d.capabilityFacets.map((f) => [f.key, [firstValue(d, f.key)]]));
    await repo.upsert({ identity: { legal_name: 'Alpha', website: 'https://alpha-' + id + '.example', hq_country: 'Sweden' }, fields, lines: [] }, 'test');
    await repo.upsert({ identity: { legal_name: 'Beta', website: 'https://beta-' + id + '.example', hq_country: 'Sweden' }, fields: {}, lines: [] }, 'test');
    repos[id] = repo;
  }
  return { vendorRepo, repos };
}

test('VH-263: every one of the 7 stores narrows by each of its own facets, and names another store\'s as not applied', async () => {
  const executor = await makePgliteExecutor();
  try {
    await runMigrations(executor);
    const { vendorRepo, repos } = await plantAll(executor);
    assert.equal(IDS.length, 7, 'all seven, measured from the registry');
    for (const id of IDS) {
      const runner = createToolRunner({
        runQuery: async (intent, page) => (intent.domain === 'space' ? vendorRepo.queryByIntent(intent.filterSpec, page) : repos[intent.domain].queryProviders(intent.filterSpec, page)),
        vendorRepo, domainRepoFor: (d) => repos[d] || null, defaultDomain: id,
      });
      const d = getDescriptor(id);
      for (const f of d.capabilityFacets) {
        const out = await runner.run('query_records', { domain: id, filter: { [f.key]: [firstValue(d, f.key)] } });
        assert.equal(out.ok, true, id + ': ' + out.error);
        assert.deepEqual(out.result.records.map((r) => r.name), ['Alpha'], id + ' ' + f.key + ': the facet narrows to its holder');
        assert.ok(out.result.applied.includes(f.key), id + ' ' + f.key + ': and says so');
      }
      // A facet this store does not declare, handed straight to the store (the normaliser would have unmapped it).
      const foreign = DECLARED.find((key) => !d.capabilityFacets.some((f) => f.key === key));
      const read = id === 'space' ? await vendorRepo.queryByIntent({ [foreign]: ['x'] }) : await repos[id].queryProviders({ [foreign]: ['x'] });
      assert.deepEqual(read.notApplied, [foreign], id + ': ' + foreign + ' is named, not applied and not dropped');
      assert.equal(read.total, 2, id + ': and it narrowed nothing');
    }
  } finally { await executor.close(); }
});
