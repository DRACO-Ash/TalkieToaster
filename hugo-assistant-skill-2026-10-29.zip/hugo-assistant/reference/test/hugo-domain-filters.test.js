// VH-261: HUGO AND THE BOARD FILTER EVERY DOMAIN BY PRODUCT TYPE, CAPABILITY FAMILY AND THE PIPELINE.
//
// The six product-line stores reported these clauses in `notApplied` from V1.81: honest, and still the whole
// store handed back to "the Air ADS-B feeds" or "Maritime providers stuck in contracting". Proved here on all 7
// stores in one database, through the shared tool runner (the layer the realtime relay, the agent route and the
// board's Hugo-filtered read all reach), with the same facts planted in each: a provider selling a product type
// of a named family, one selling another family, one whose only line of that type is HELD, and a stored
// pipeline row beside members whose stage is derived from their band.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner } from '../src/hugo/tools.js';
import { createVendorRepo } from '../src/db/vendor-repo.js';
import { createDomainRepo } from '../src/db/domain-repo.js';
import { domainIds, getDescriptor } from '../src/domain/descriptor.js';
import { listOf, familyKeyOfProductType } from '../src/hugo/families.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';

const IDS = domainIds();

// Per store, from its OWN vocabulary: a type in a named family, and a type in a different family.
function typesFor(id) {
  const vocab = listOf(getDescriptor(id).vocab.product_types);
  const typeA = vocab.find((t) => familyKeyOfProductType(t) !== 'OTHER');
  const family = familyKeyOfProductType(typeA);
  const typeB = vocab.find((t) => familyKeyOfProductType(t) !== family);
  return { typeA, typeB, family };
}

const line = (productType) => ({
  product_type: productType, object_domain: 'land', data_nature: 'raw-sensed', collection_vantage: 'ground',
  data_delivery: ['feed'], data_owned: 'crowdsourced-network', data_sensitivity: [], source_status: 'operational',
});

// Writes the stored pipeline row directly: this measures the READ path, as test/hugo-query-repo.test.js does.
const storePipelineRow = (executor, domain, memberId) => executor.query(
  `insert into gdm_pipeline (domain, member_id, stage, owner, priority, due, blocked, blockers, stage_entered_at, stage_confidence)
   values ($1, $2, 'contracting', 'ada', 'High', current_date - 3, true, '[{"kind":"legal"}]'::jsonb, now() - interval '90 days', 'confirmed')`,
  [domain, memberId],
);

async function plantSpace(executor) {
  const repo = createVendorRepo(executor);
  const { typeA, typeB } = typesFor('space');
  const base = { country: 'Sweden', grade: 'Unknown', section: 'TacSRT', missions: ['TacSRT'] };
  await repo.createVendor({ ...base, vendor_id: 'VH-0001', company: 'Alpha', gdm: 'In GDM', product_types: [typeA] }, 'seed');
  await repo.createVendor({ ...base, vendor_id: 'VH-0002', company: 'Beta', gdm: 'Not in GDM', product_types: [typeB] }, 'seed');
  // Space keeps no product lines, so its "held" member is quarantined whole, which the set reads leave out.
  await repo.createVendor({ ...base, vendor_id: 'VH-0003', company: 'Held', gdm: 'Not in GDM', product_types: [typeA] }, 'seed');
  await executor.query(`update vendor set data = data || '{"quarantined":true}'::jsonb where vendor_id = 'VH-0003'`);
  await storePipelineRow(executor, 'space', 'VH-0002');
  return repo;
}

async function plantDomain(executor, id) {
  const d = getDescriptor(id);
  const repo = createDomainRepo(executor, d);
  const { typeA, typeB } = typesFor(id);
  const identity = (name) => ({ legal_name: name, website: 'https://' + name.toLowerCase() + '-' + id + '.example', hq_country: 'Sweden' });
  await repo.upsert({ identity: identity('Alpha'), fields: {}, lines: [line(typeA)], gdm: { gdm_stage: 'In GDM' } }, 'test');
  const beta = await repo.upsert({ identity: identity('Beta'), fields: {}, lines: [line(typeB)] }, 'test');
  await repo.upsert({ identity: identity('Held'), fields: {}, lines: [line(typeA)] }, 'test');
  // The held line: a disposition the gate excludes, written as a restore or a later review would leave it.
  await executor.query(`update ${d.store.lines} set line_eligibility = 'excluded-policy'
    where ${id}_id = (select c.${id}_id from ${d.store.core} c join providers p on p.provider_key = c.provider_key where p.legal_name = 'Held')`);
  await storePipelineRow(executor, id, beta[id + '_id']);
  return repo;
}

const runnerFor = (vendorRepo, repos, defaultDomain) => createToolRunner({
  runQuery: async (intent, page) => (intent.domain === 'space'
    ? vendorRepo.queryByIntent(intent.filterSpec, page)
    : repos[intent.domain].queryProviders(intent.filterSpec, page)),
  vendorRepo, domainRepoFor: (id) => repos[id] || null, defaultDomain,
});

const names = (out) => out.result.records.map((r) => r.name).sort();

test('VH-261: product types, families and the pipeline narrow every one of the 7 stores', async () => {
  const executor = await makePgliteExecutor();
  try {
    await runMigrations(executor);
    const vendorRepo = await plantSpace(executor);
    const repos = {};
    for (const id of IDS.filter((d) => d !== 'space')) repos[id] = await plantDomain(executor, id);
    assert.equal(IDS.length, 7, 'all seven, measured from the registry');
    for (const id of IDS) {
      const runner = runnerFor(vendorRepo, repos, id);
      const { typeA, family } = typesFor(id);
      const ask = async (filter) => {
        const out = await runner.run('query_records', { domain: id, filter });
        assert.equal(out.ok, true, id + ': ' + out.error);
        assert.deepEqual(out.result.notApplied, [], id + ': nothing asked for is left unapplied: ' + JSON.stringify(filter));
        return out;
      };
      const byType = await ask({ productTypes: [typeA] });
      assert.deepEqual(names(byType), ['Alpha'], id + ': a product type finds its seller, and never through a held line');
      assert.ok(byType.result.applied.includes('productTypes'), id);
      const byFamily = await ask({ families: [family] });
      assert.deepEqual(names(byFamily), ['Alpha'], id + ': the ' + family + ' family expands to this store\'s own types');
      assert.ok(byFamily.result.applied.includes('families'), id);
      assert.deepEqual(names(await ask({ stages: ['live'] })), ['Alpha'], id + ': a member with no pipeline row derives live from In GDM');
      assert.deepEqual(names(await ask({ stages: ['contracting'] })), ['Beta'], id + ': and a stored row answers for itself');
      assert.deepEqual(names(await ask({ owners: ['ada'] })), ['Beta'], id + ': the owner');
      assert.deepEqual(names(await ask({ blocked: true })), ['Beta'], id + ': blocked');
      assert.deepEqual(names(await ask({ due: 'overdue' })), ['Beta'], id + ': overdue');
      assert.deepEqual(names(await ask({ blockerKinds: ['legal'] })), ['Beta'], id + ': the blocker kind');
      assert.deepEqual(names(await ask({ priorities: ['High'] })), ['Beta'], id + ': the priority');
      const aged = await ask({ ageing: 60 });
      assert.deepEqual(names(aged), ['Beta'], id + ': ninety days in contracting is over sixty');
      assert.ok(aged.result.applied.includes('ageingDays'), id);
      assert.deepEqual(names(await ask({ productTypes: [typeA], stages: ['contracting'] })), [], id + ': clauses AND together');
    }
  } finally { await executor.close(); }
});

test('VH-261: a family covering none of a store\'s product types is reported, never bound empty', async () => {
  const executor = await makePgliteExecutor();
  try {
    await runMigrations(executor);
    // Cyber's vocabulary holds no SAR type (measured: RF, AN and OTHER only), so a SAR question there has no
    // answer the store could give, and it must say so rather than return an empty board as if it had looked.
    const cyber = listOf(getDescriptor('cyber').vocab.product_types);
    assert.equal(cyber.some((t) => familyKeyOfProductType(t) === 'SAR'), false, 'the premise, measured');
    const repo = createDomainRepo(executor, getDescriptor('cyber'));
    const out = await repo.queryProviders({ families: ['SAR'] }, {});
    assert.deepEqual(out.notApplied, ['families']);
    assert.equal(out.applied.includes('families'), false);
  } finally { await executor.close(); }
});
