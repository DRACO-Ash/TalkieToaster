// A TYPED TURN, READ AS IT STREAMS (VH-777 Lane T): the client asks the agent route for its NDJSON stream, hears each
// tool as it finishes, and takes the checked answer from the last line; a refusal still arrives as JSON with its reason,
// and a stream that stops short of its answer is no answer. The words the pending turn shows are Hugo's tools in words.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { hugoAgent } from '../public/api-v3.js';
import { stepsText } from '../public/views/hugo-rail.js';

const enc = new TextEncoder();
// A body in the chunks given, which split lines anywhere, as a network does.
const streamOf = (chunks, { failAfter = Infinity } = {}) => new globalThis.ReadableStream({
  start(controller) {
    chunks.forEach((c, i) => { if (i < failAfter) controller.enqueue(enc.encode(c)); });
    if (failAfter < chunks.length) controller.error(new Error('connection reset'));
    else controller.close();
  },
});
const ndjson = (body, status = 200) => ({ status, ok: status < 400, headers: new globalThis.Headers({ 'content-type': 'application/x-ndjson; charset=utf-8' }), body });
// A real response always has a body, so the content type is what tells the client which to read.
const json = (payload, status) => ({ status, ok: status < 400, headers: new globalThis.Headers({ 'content-type': 'application/json' }), body: streamOf([JSON.stringify(payload)]), json: async () => payload });

async function withFetch(reply, fn) {
  const was = globalThis.fetch;
  const seen = [];
  globalThis.fetch = async (url, opts) => { seen.push({ url, opts }); return reply(); };
  try { return await fn(seen); } finally { globalThis.fetch = was; }
}

test('each tool is heard as its line lands, and the answer is the last line, whatever the chunks split', async () => {
  const lines = [{ type: 'step', tool: 'search_help', ok: true }, { type: 'step', tool: 'query_records', ok: false },
    { type: 'answer', answer: 'Two companies.', citations: [] }].map((l) => JSON.stringify(l) + '\n').join('');
  const chunks = [lines.slice(0, 7), lines.slice(7, 60), lines.slice(60, 61), lines.slice(61)];
  const steps = [];
  const out = await withFetch(() => ndjson(streamOf(chunks)), async (seen) => {
    const r = await hugoAgent('tok', { messages: [{ role: 'user', content: 'q' }], domain: 'space', onStep: (s) => steps.push(s) });
    assert.equal(seen[0].url, '/api/v3/hugo/agent');
    assert.equal(seen[0].opts.headers.accept, 'application/x-ndjson', 'the client asks for the stream');
    assert.equal(seen[0].opts.headers.authorization, 'Bearer tok');
    assert.deepEqual(JSON.parse(seen[0].opts.body), { messages: [{ role: 'user', content: 'q' }], domain: 'space' });
    return r;
  });
  assert.deepEqual(steps, [{ tool: 'search_help', ok: true }, { tool: 'query_records', ok: false }]);
  assert.deepEqual(out, { ok: true, status: 200, answer: 'Two companies.', citations: [] }, 'the answer line, without its type');
});

test('a stream that stops short of its answer is no answer, whether it ends or breaks', async () => {
  const unended = JSON.stringify({ type: 'answer', answer: 'Last.' });
  const last = await withFetch(() => ndjson(streamOf([unended])), () => hugoAgent('t', { messages: [], domain: 'space' }));
  assert.deepEqual(last, { ok: true, status: 200, answer: 'Last.' }, 'a last line with no newline after it is still read');
  const step = JSON.stringify({ type: 'step', tool: 'get_record', ok: true }) + '\n';
  for (const [label, body] of [['ended', streamOf([step])], ['broke', streamOf([step, step], { failAfter: 1 })]]) {
    const out = await withFetch(() => ndjson(body), () => hugoAgent('t', { messages: [], domain: 'space' }));
    assert.deepEqual(out, { ok: false, status: 'cut', reason: '' }, label);
  }
});

test('a refusal is still JSON, with the server\'s reason, and a lost connection reads as offline', async () => {
  const limited = await withFetch(() => json({ error: 'hugo_rate_limited' }, 429), () => hugoAgent('t', { messages: [], domain: 'space' }));
  assert.deepEqual(limited, { ok: false, status: 429, reason: 'hugo_rate_limited' });
  const plain = await withFetch(() => json({ answer: 'Hi.' }, 200), () => hugoAgent('t', { messages: [], domain: 'space' }));
  assert.deepEqual(plain, { ok: true, status: 200, answer: 'Hi.' }, 'a server that answers JSON is read as before');
  const offline = await withFetch(() => { throw new TypeError('Failed to fetch'); }, () => hugoAgent('t', { messages: [], domain: 'space' }));
  assert.deepEqual(offline, { ok: false, status: 'offline', reason: '' });
});

test('the pending turn names the tools in words, once each, and never by a code name', () => {
  assert.equal(stepsText([]), '');
  // An Object member's name is no tool (2.20.0 round one, security MINOR 2): nothing of Object's shows in the line.
  assert.equal(stepsText([{ tool: 'constructor' }, { tool: '__proto__' }, { tool: 'toString' }]), '');
  assert.equal(stepsText([{ tool: 'query_records' }, { tool: 'get_record' }, { tool: 'query_records' }]), 'Searching the records, reading a record…');
  assert.equal(stepsText([{ tool: 'web_lookup' }, { tool: 'not_a_tool' }]), 'Looking on the web…');
  assert.equal(stepsText([{ tool: 'not_a_tool' }]), '', 'an unknown tool is left out');
});

test('every tool Hugo has has its words', async () => {
  const { TOOL_NAMES } = await import('../src/hugo/tools.js');
  const unnamed = TOOL_NAMES.filter((name) => stepsText([{ tool: name }]) === '');
  assert.deepEqual(unnamed, [], 'a tool the pending turn could not name');
});

// The shell shows each step in the pending turn, quietly, and only while that turn is still on screen.
test('the shell hands the steps to the pending turn', async () => {
  const { readFileSync } = await import('node:fs');
  const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(app, /const live = renderHugoTranscript\(history, \{ pending: true \}\);/);
  assert.match(app, /if \(live\?\.isConnected && hugoRail\) \{ live\.textContent = hugoRail\.stepsText\(steps\); live\.classList\.add\('is-steps'\); \}/);
  const css = readFileSync(new URL('../public/styles.css', import.meta.url), 'utf8');
  assert.match(css, /\.hugo-turn-live\.is-steps \{ font-style: italic; \}/);
});
