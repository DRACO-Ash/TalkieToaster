// Hugo's tool layer and agent loop (src/hugo/tools.js, src/hugo/agent.js, V1.77 D6), against fakes: a
// scripted model and an in-memory query runner. What these pin is the GOVERNANCE, not the prose: every
// tool is read-only or confirm-first, every argument is validated, and the final answer is verified against
// what the tools actually returned, with one corrective retry and then a closed failure. Every expected
// figure was printed before it was asserted.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner, createLedger, HUGO_TOOL_DEFS, TOOL_NAMES, realtimeToolDefs, TOOL_MAX_ROWS } from '../src/hugo/tools.js';
import { runHugoAgent, deterministicAnswer, parseFinal, verifyAnswer, AGENT_CAPS, FINAL_ANSWER_RULES } from '../src/hugo/agent.js';

// The dataset the fake query runner serves: three Space records; the runner honours the `countries` clause
// and reports what it applied, as the real one does.
const ROWS = [
  { rev: 1, record: { vendor_id: 'VH-0001', company: 'Orbital Signals Ltd', country: 'United Kingdom', grade: 'Unknown', gdm: 'Not in GDM', section: 'TacSRT', website: 'orbital-signals.co.uk', capability: 'Passive RF' } },
  { rev: 1, record: { vendor_id: 'VH-0002', company: 'Nordic Radar AB', country: 'Sweden', grade: 'In JCO', gdm: 'In GDM', section: 'EMSO' } },
  { rev: 1, record: { vendor_id: 'VH-0003', company: 'Orbital Signal Limited', country: 'United Kingdom', grade: 'Unknown', gdm: 'Not in GDM', section: 'TacSRT', website: 'www.orbital-signals.co.uk' } },
];

function fakeRunner(extra = {}) {
  const seen = { queries: [] };
  const runQuery = async (intent, page) => {
    seen.queries.push({ intent, page });
    const countries = intent.filterSpec?.countries || [];
    const rows = countries.length ? ROWS.filter((r) => countries.includes(r.record.country)) : ROWS;
    return { rows: rows.slice(0, page.limit), total: rows.length, applied: countries.length ? ['countries'] : [], notApplied: [] };
  };
  const vendorRepo = {
    getVendor: async (id) => { const r = ROWS.find((x) => x.record.vendor_id === id); return r ? { rev: 1, record: r.record } : null; },
    previewUpdate: async (id, patch) => (ROWS.some((x) => x.record.vendor_id === id) ? { rev: 1, changes: { capability: { from: 'Passive RF', to: patch.capability } }, hasChanges: true } : { notFound: true }),
  };
  const runner = createToolRunner({ runQuery, vendorRepo, defaultDomain: 'space', ...extra });
  return { runner, seen };
}

// A scripted model: each call pops the next reply; a reply is either tool calls or final text.
function scriptedChat(replies) {
  const calls = [];
  const chatOnce = async ({ system, messages, tools }) => {
    calls.push({ system, messages, tools });
    const next = replies.shift() || { text: '{"answer":"(script exhausted)","cited":[],"entities":[],"numbers":[]}' };
    if (next.tools) return { message: { role: 'assistant', content: '', tool_calls: next.tools.map((t, i) => ({ id: 'c' + calls.length + '_' + i, type: 'function', function: { name: t.name, arguments: JSON.stringify(t.args) } })) }, usage: { input_tokens: 10, output_tokens: 5 }, finishReason: 'tool_calls' };
    return { message: { role: 'assistant', content: next.text, tool_calls: [] }, usage: { input_tokens: 10, output_tokens: 5 }, finishReason: 'stop' };
  };
  return { chatOnce, calls };
}

test('the tool definitions: fifteen tools, each read-only or confirm-first, in both provider shapes', () => {
  assert.deepEqual(TOOL_NAMES, ['query_records', 'count_records', 'get_record', 'find_similar', 'record_provenance', 'pipeline_summary', 'propose_scan', 'propose_update', 'explain_match', 'web_lookup', 'search_help', 'describe_app', 'app_state', 'recent_history', 'propose_view']);
  // The 4 that read the app itself (VH-777 Lane T, `src/hugo/knowledge.js`) are read-only.
  assert.deepEqual(HUGO_TOOL_DEFS.filter((t) => t.mode === 'confirm').map((t) => t.function.name), ['propose_scan', 'propose_update', 'propose_view']);
  assert.ok(HUGO_TOOL_DEFS.every((t) => t.mode === 'read' || t.mode === 'confirm'));
  const rt = realtimeToolDefs();
  assert.equal(rt.length, 15);
  assert.deepEqual(Object.keys(rt[0]), ['type', 'name', 'description', 'parameters']);
  // RAISED 10 -> 50 on 2026-09-19 (owner: Hugo "isn't in depth enough"). Ten made a 200-row question come
  // back as ten rows with nothing saying so, which is sampling presented as an answer. The number is pinned
  // here rather than left loose because it is a contract with the model: the tool description promises 50.
  assert.equal(TOOL_MAX_ROWS, 50);
});

test('query_records validates the filter through the intent normaliser, bounds the rows, and fills the ledger', async () => {
  const { runner, seen } = fakeRunner();
  const out = await runner.run('query_records', { domain: 'space', filter: { countries: ['United Kingdom', 'Narnia'], gdm: ['Not a state'] }, limit: 99 });
  assert.equal(out.ok, true);
  assert.equal(out.result.total, 2);
  assert.deepEqual(out.result.records.map((r) => [r.ref, r.id, r.name]), [[1, 'VH-0001', 'Orbital Signals Ltd'], [2, 'VH-0003', 'Orbital Signal Limited']]);
  // The normaliser dropped the unknown country and the unknown GDM state before the query ran, and the
  // limit was clamped to the tool's cap.
  assert.deepEqual(seen.queries[0].intent.filterSpec.countries, ['United Kingdom']);
  assert.deepEqual(seen.queries[0].intent.filterSpec.gdm, []);
  assert.equal(seen.queries[0].page.limit, 50); // the default limit IS the ceiling, raised with it
  // The ledger knows both rows by id, name and the figures in the result.
  assert.equal(runner.ledger.hasId('VH-0001'), true);
  assert.equal(runner.ledger.hasId('VH-0002'), false, 'Sweden was not returned');
  assert.equal(runner.ledger.hasName('orbital signals ltd'), true);
  assert.equal(runner.ledger.hasNumber(2), true, 'the total is a figure the model may state');
  assert.equal(runner.ledger.hasRef(2), true);
  assert.equal(runner.ledger.hasRef(3), false);
  // Unknown tool and thrown tool both come back as a refusal, never a throw.
  assert.deepEqual(await runner.run('drop_table', {}), { name: 'drop_table', ok: false, error: 'unknown tool drop_table' });
  const broken = createToolRunner({ defaultDomain: 'space', runQuery: async () => { throw new Error('store down'); } });
  assert.deepEqual(await broken.run('count_records', {}), { name: 'count_records', ok: false, error: 'store down' });
});

test('the confirm-first tools preview and never act: propose_update needs a source, propose_scan needs a compiler', async () => {
  let compiled = 0;
  const { runner } = fakeRunner({ compileScan: async ({ text }) => { compiled += 1; return { ok: true, design: { intent: text, depth: 'standard' }, unmapped: [] }; } });
  const noSource = await runner.run('propose_update', { id: 'VH-0001', patch: { capability: 'x' } });
  assert.equal(noSource.ok, false);
  assert.match(noSource.error, /source/);
  const preview = await runner.run('propose_update', { id: 'VH-0001', patch: { capability: 'Wideband RF' }, source: 'https://orbital-signals.co.uk/about' });
  assert.equal(preview.ok, true);
  assert.equal(preview.result.requiresConfirmation, true);
  assert.deepEqual(preview.result.changes, { capability: { from: 'Passive RF', to: 'Wideband RF' } });
  const scan = await runner.run('propose_scan', { text: 'SAR operators in the Baltics' });
  assert.equal(scan.result.requiresConfirmation, true);
  assert.equal(scan.result.design.intent, 'SAR operators in the Baltics');
  assert.equal(compiled, 1);
  const bare = fakeRunner().runner;
  assert.match((await bare.run('propose_scan', { text: 'x' })).error, /not available/);
  assert.match((await bare.run('record_provenance', { id: 'VH-0001' })).error, /not available/);
});

// HUGO CAN PREVIEW A SOURCED CHANGE ON EVERY DOMAIN (V1.81, parity gap
// `hugo.tool.propose_update.space.only`).
//
// The tool refused every non-Space domain outright, and the refusal was a WIRING gap rather than a missing
// capability: `previewProviderUpdate` had been on the domain repository for a release, the HTTP route behind
// the drawer's composer already served every wired domain, and the composer already bound to the open domain
// provider. Only Hugo's own tool said no, so an operator working in Air was told to go and do by hand what
// the app could already show them.
test('propose_update previews on a DOMAIN, in that store\'s own patch and diff shape', async () => {
  const seen = {};
  const airRepo = {
    previewProviderUpdate: async (id, patch) => {
      seen.call = { id, patch };
      if (id !== 'host:flightradar24.com') return { notFound: true };
      return {
        rev: 3,
        changes: { before: { coverage: null }, after: { coverage: 'Europe' } },
        linesBefore: 1, linesAfter: 2, hasChanges: true,
      };
    },
  };
  const { runner } = fakeRunner({ domainRepoFor: (id) => (id === 'air' ? airRepo : null) });
  const out = await runner.run('propose_update', {
    domain: 'air', id: 'host:flightradar24.com', source: 'https://flightradar24.com/about',
    patch: { fields: { coverage: 'Europe' } },
  });
  assert.equal(out.ok, true);
  assert.equal(out.result.requiresConfirmation, true, 'it is a proposal, never a write');
  assert.equal(out.result.domain, 'air');
  // A DOMAIN PATCH IS `{ fields, lines, gdm }`, not a flat record, and it reaches the store unflattened.
  assert.deepEqual(seen.call.patch, { fields: { coverage: 'Europe' } });
  // The domain diff is before/after, not the Space moved-fields map, and it is carried as the store
  // produced it: flattening one into the other would invent a diff neither store returned. `shape` says so.
  assert.equal(out.result.shape, 'domain');
  assert.deepEqual(out.result.changes, { before: { coverage: null }, after: { coverage: 'Europe' } });
  // The product-line movement rides along, because on a domain a change can add or remove lines and the
  // operator confirming it is entitled to know.
  assert.deepEqual([out.result.linesBefore, out.result.linesAfter], [1, 2]);
});

test('a line count that did NOT move is not reported, and a store that is not wired says so', async () => {
  const airRepo = {
    previewProviderUpdate: async () => ({ rev: 3, changes: { before: {}, after: {} }, linesBefore: 2, linesAfter: 2, hasChanges: false }),
  };
  const { runner } = fakeRunner({ domainRepoFor: (id) => (id === 'air' ? airRepo : null) });
  const same = await runner.run('propose_update', { domain: 'air', id: 'x', source: 'https://e.test/a', patch: { fields: {} } });
  // Reporting "0 lines changed" on every field edit would put a figure in front of the operator that
  // answers a question they did not ask.
  assert.equal('linesBefore' in same.result, false);
  assert.equal(same.result.hasChanges, false);
  // "THIS DOMAIN IS NOT CONNECTED" AND "NO SUCH RECORD" ARE DIFFERENT ANSWERS, and only one of them is the
  // operator's problem. An unwired store used to come back as a missing record, which sends someone looking
  // for a provider that is there.
  const unwired = await runner.run('propose_update', { domain: 'maritime', id: 'x', source: 'https://e.test/a', patch: { fields: {} } });
  assert.equal(unwired.ok, false);
  assert.match(unwired.error, /not connected/);
  assert.doesNotMatch(unwired.error, /no record/);
});

test('get_record, find_similar and explain_match read through the match model with an explanation', async () => {
  const { runner } = fakeRunner();
  const got = await runner.run('get_record', { id: 'VH-0001' });
  assert.equal(got.result.name, 'Orbital Signals Ltd');
  assert.equal(got.result.capability, 'Passive RF');
  assert.equal((await runner.run('get_record', { id: 'VH-9999' })).ok, false);
  const similar = await runner.run('find_similar', { id: 'VH-0001' });
  assert.equal(similar.ok, true);
  assert.equal(similar.result.candidates[0].id, 'VH-0003', 'the near-duplicate in the same country ranks first');
  assert.ok(similar.result.candidates[0].probability > 0.9, `a strong match: ${similar.result.candidates[0].probability}`);
  assert.ok(similar.result.candidates[0].agreements.includes('host'), 'the folded website host agrees');
  const explained = await runner.run('explain_match', { idA: 'VH-0001', idB: 'VH-0002' });
  assert.equal(explained.ok, true);
  assert.ok(explained.result.probability < 0.01, 'a clear non-match');
  assert.equal(explained.result.features.country, 'disagree');
  assert.ok(Array.isArray(explained.result.contributions) && explained.result.contributions.length > 0);
});

test('parseFinal and verifyAnswer: a structured answer is checked item by item, prose is checked from its text', () => {
  const ledger = createLedger();
  ledger.addRow({ id: 'VH-0001', name: 'Orbital Signals Ltd', domain: 'space' });
  ledger.addNumbers({ total: 2, records: [{ founded: 2009 }] });
  const good = parseFinal('Here you go: {"answer":"Two records [R1], one is Orbital Signals Ltd founded 2009.","cited":["VH-0001"],"entities":["Orbital Signals Ltd"],"numbers":[2, 2009]}');
  assert.equal(good.structured, true);
  assert.deepEqual(verifyAnswer(good, ledger), { ok: true, violations: [] });
  const bad = parseFinal('{"answer":"See [R7]: Acme Space made 40 sensors in 2009.","cited":["VH-0042"],"entities":["Acme Space"],"numbers":[40]}');
  const v = verifyAnswer(bad, ledger);
  assert.equal(v.ok, false);
  assert.deepEqual(v.violations, [
    'reference [R7] was not returned by any tool',
    'record VH-0042 was not returned by any tool',
    '"Acme Space" was not returned by any tool',
    'the figure 40 appears in no tool result',
  ]);
  // Prose (no JSON): the figures in the TEXT are still checked, and record ids and references are not read
  // as figures.
  const prose = parseFinal('Orbital Signals Ltd [R1] is VH-0001; it has 3 sites.');
  assert.equal(prose.structured, false);
  assert.deepEqual(verifyAnswer(prose, ledger).violations, ['the figure 3 appears in no tool result']);
  assert.deepEqual(verifyAnswer(parseFinal('Orbital Signals Ltd [R1] is VH-0001.'), ledger), { ok: true, violations: [] });
});

test('the loop: tool calls run through the runner, the final JSON is verified, and the trail is kept', async () => {
  const { runner } = fakeRunner();
  const chat = scriptedChat([
    { tools: [{ name: 'query_records', args: { domain: 'space', filter: { countries: ['United Kingdom'] } } }] },
    { text: '{"answer":"There are 2 UK records: Orbital Signals Ltd [R1] and Orbital Signal Limited [R2].","cited":["VH-0001","VH-0003"],"entities":["Orbital Signals Ltd","Orbital Signal Limited"],"numbers":[2]}' },
  ]);
  const out = await runHugoAgent({ chat, runner, system: ['persona', FINAL_ANSWER_RULES], messages: [{ role: 'user', content: 'which UK records do we hold?' }] });
  assert.equal(out.verification.ok, true);
  assert.equal(out.verification.retried, false);
  assert.match(out.answer, /2 UK records/);
  assert.deepEqual(out.citations.map((c) => c.id), ['VH-0001', 'VH-0003']);
  assert.deepEqual(out.steps.map((s) => [s.tool, s.ok]), [['query_records', true]]);
  assert.deepEqual(out.usage, { input_tokens: 20, output_tokens: 10 });
  // The second model call carried the assistant tool-call turn and the tool result, in order.
  const second = chat.calls[1].messages;
  assert.equal(second.at(-2).role, 'assistant');
  assert.equal(second.at(-1).role, 'tool');
  assert.match(second.at(-1).content, /Orbital Signals Ltd/);
  assert.equal(chat.calls[0].tools.length, 15, 'the tools were offered');
});

test('a fabrication is caught: one corrective retry with the violations named, then a closed failure', async () => {
  const { runner } = fakeRunner();
  // Retry succeeds: the model removes the invented company and figure.
  const fixed = scriptedChat([
    { tools: [{ name: 'query_records', args: { filter: { countries: ['Sweden'] } } }] },
    { text: '{"answer":"Nordic Radar AB [R1] and Acme Space; 12 in total.","cited":["VH-0002"],"entities":["Nordic Radar AB","Acme Space"],"numbers":[12]}' },
    { text: '{"answer":"Nordic Radar AB [R1]; 1 in total.","cited":["VH-0002"],"entities":["Nordic Radar AB"],"numbers":[1]}' },
  ]);
  const ok = await runHugoAgent({ chat: fixed, runner, system: 'p', messages: [{ role: 'user', content: 'Sweden?' }] });
  assert.equal(ok.verification.ok, true);
  assert.equal(ok.verification.retried, true);
  assert.match(fixed.calls[2].messages.at(-1).content, /"Acme Space" was not returned by any tool; the figure 12 appears in no tool result/);
  assert.deepEqual(fixed.calls[2].tools, [], 'the correction turn offers no tools');
  // Retry fails again: nothing unverified reaches the operator.
  const { runner: r2 } = fakeRunner();
  const stubborn = scriptedChat([
    { tools: [{ name: 'query_records', args: { filter: { countries: ['Sweden'] } } }] },
    { text: '{"answer":"Acme Space leads with 12.","cited":[],"entities":["Acme Space"],"numbers":[12]}' },
    { text: '{"answer":"Acme Space leads with 12.","cited":[],"entities":["Acme Space"],"numbers":[12]}' },
  ]);
  const closed = await runHugoAgent({ chat: stubborn, runner: r2, system: 'p', messages: [{ role: 'user', content: 'Sweden?' }] });
  assert.equal(closed.verification.ok, false);
  assert.equal(closed.verification.retried, true);
  assert.doesNotMatch(closed.answer, /Acme|12/, 'the unverified content is withheld');
  assert.match(closed.answer, /could not verify part of that answer/);
  assert.match(closed.answer, /Nordic Radar AB \[R1\]/, 'what the tools DID return is offered instead');
  assert.deepEqual(closed.verification.violations, ['"Acme Space" was not returned by any tool', 'the figure 12 appears in no tool result']);
});

test('the caps hold: steps, tool calls and the clock; a run out of budget still closes with an answer', async () => {
  const { runner } = fakeRunner();
  const endless = { chatOnce: async ({ tools }) => (tools.length > 0
    ? { message: { role: 'assistant', content: '', tool_calls: [{ id: 'x', type: 'function', function: { name: 'count_records', arguments: '{}' } }] }, usage: { input_tokens: 1, output_tokens: 1 } }
    : { message: { role: 'assistant', content: '{"answer":"Stopped.","cited":[],"entities":[],"numbers":[]}', tool_calls: [] }, usage: { input_tokens: 1, output_tokens: 1 } }) };
  const out = await runHugoAgent({ chat: endless, runner, system: 'p', messages: [{ role: 'user', content: 'loop' }], caps: { ...AGENT_CAPS, maxSteps: 3, maxToolCalls: 2 } });
  assert.equal(out.steps.length, 2, 'two tool calls ran, the third step got no tools and closed');
  assert.equal(out.answer, 'Stopped.');
  // ONE reply carrying more calls than the budget has left: the calls past the budget are refused, not run,
  // and the refusal is what the model reads back. (The first version of this test could not tell this
  // branch from the per-step gate above, and a mutation that removed it passed.)
  const { runner: r3, seen: seen3 } = fakeRunner();
  const greedy = scriptedChat([
    { tools: [{ name: 'count_records', args: {} }, { name: 'count_records', args: {} }, { name: 'count_records', args: {} }] },
    { text: '{"answer":"Done.","cited":[],"entities":[],"numbers":[]}' },
  ]);
  const capped = await runHugoAgent({ chat: greedy, runner: r3, system: 'p', messages: [{ role: 'user', content: 'x' }], caps: { ...AGENT_CAPS, maxToolCalls: 2 } });
  assert.deepEqual(capped.steps.map((s) => s.ok), [true, true, false]);
  assert.equal(capped.steps[2].result, 'tool budget for this turn is spent');
  assert.equal(seen3.queries.length, 2, 'the third call never reached the store');
  // The wall clock: a clock that has already expired offers no tools on the first step.
  let t = 0;
  const clock = () => { t += 100_000; return t; };
  const seen = [];
  const noteTools = { chatOnce: async ({ tools }) => { seen.push(tools.length); return { message: { role: 'assistant', content: '{"answer":"Late.","cited":[],"entities":[],"numbers":[]}', tool_calls: [] }, usage: {} }; } };
  const late = await runHugoAgent({ chat: noteTools, runner: fakeRunner().runner, system: 'p', messages: [{ role: 'user', content: 'x' }], now: clock });
  assert.deepEqual(seen, [0]);
  assert.equal(late.answer, 'Late.');
});

test('the deterministic fallback answers from the tools alone, with references, and says when it cannot', async () => {
  const { runner } = fakeRunner();
  const out = await deterministicAnswer({ runner, question: 'show me vendors in the United Kingdom', domain: 'space' });
  assert.equal(out.fallback, true);
  assert.equal(out.model, false);
  assert.equal(out.answer, '2 records match (countries): Orbital Signals Ltd (United Kingdom) [R1]; Orbital Signal Limited (United Kingdom) [R2].');
  assert.deepEqual(out.citations.map((c) => c.id), ['VH-0001', 'VH-0003']);
  assert.deepEqual(out.steps.map((s) => s.tool), ['query_records']);
  const none = await deterministicAnswer({ runner: fakeRunner().runner, question: 'tell me a joke', domain: 'space' });
  assert.match(none.answer, /could not read that as a question about the dataset/);
  assert.deepEqual(none.steps, []);
  // VH-608: a price question is refused for the reason it is unanswerable, not as unreadable, and no query runs.
  const price = await deterministicAnswer({ runner: fakeRunner().runner, question: 'how much does a GNSS receiver cost', domain: 'space' });
  assert.match(price.answer, /^The dataset holds no prices or costs/);
  assert.deepEqual(price.steps, []);
  assert.equal(price.proposal, null);
  const down = await deterministicAnswer({ runner: createToolRunner({ defaultDomain: 'space', runQuery: async () => { throw new Error('down'); } }), question: 'vendors in Sweden', domain: 'space' });
  assert.match(down.answer, /did not complete/);
});

// VH-777: "hey hugo" with no model read as Hugo not working at all. A message that is wholly small talk is answered as
// Hugo would answer it, in one domain and across all of them; one that also asks a question still reaches the tools.
test('the floor without a model answers a greeting, thanks and "what can you do", and only those', async () => {
  const { deterministicAnswerAll } = await import('../src/hugo/agent.js');
  const hello = await deterministicAnswer({ runner: fakeRunner().runner, question: 'Hey Hugo!', domain: 'space' });
  assert.equal(hello.answer, 'Hello, I am Hugo. My AI service is not answering just now, so I cannot chat freely, but I can still find companies in Space by country, GDM state, section or mission. For example, "companies in Sweden" or "scoped vendors not in the GDM".');
  assert.deepEqual(hello.steps, [], 'no lookup for a greeting');
  assert.equal(hello.fallback, true);
  assert.equal((await deterministicAnswer({ runner: fakeRunner().runner, question: 'thanks hugo', domain: 'space' })).answer,
    'You are welcome. Ask me about the companies in Space whenever you like.');
  assert.match((await deterministicAnswer({ runner: fakeRunner().runner, question: 'What can you do?', domain: 'space' })).answer, /^I am Hugo, the data co-pilot for this app\./);
  const all = await deterministicAnswerAll({ runner: fakeRunner().runner, question: 'good morning', domains: ['space', 'air'] });
  assert.match(all.answer, /^Hello, I am Hugo\. .* find companies in all 2 domains by country/);
  const mixed = await deterministicAnswer({ runner: fakeRunner().runner, question: 'hi, show me vendors in the United Kingdom', domain: 'space' });
  assert.deepEqual(mixed.steps.map((s) => s.tool), ['query_records'], 'a greeting with a question in it is still a question');
});

// --- propose_view and the consent proposal (owner decision, V1.79) -----------------------------------------
//
// "if a specific question is answerable by Hugo driving the app to display analytics or an answer - then a
// popup simply says - allow Hugo to show you." Before this, the conversation could not offer a view at all:
// driving the app was a separate route with its own button, and the persona's instruction was to tell the
// operator to press it. These cases pin the three things that make the offer safe rather than merely
// possible - the view name fails closed, the filter goes through the SAME normaliser the Apply path uses,
// and the row count is taken BEFORE the operator is asked.

test('propose_view offers a validated view, counts it first, and never acts', async () => {
  const { runner, seen } = fakeRunner();
  const out = await runner.run('propose_view', {
    view: 'map', domain: 'space', filter: { countries: ['United Kingdom', 'Narnia'] }, reason: 'The UK records on the map',
  });
  assert.equal(out.ok, true);
  assert.equal(out.result.requiresConfirmation, true, 'it is an offer, never an action');
  assert.equal(out.result.view, 'map');
  assert.equal(out.result.hasFilter, true);
  // MEASURED against the fake store, which holds two United Kingdom rows: the count is taken before the
  // operator is asked, so an empty view is never offered as though it had content.
  assert.equal(out.result.total, 2);
  assert.deepEqual(out.result.applied, ['countries']);
  // The unknown country was dropped by the shared normaliser, not passed through to the view.
  assert.deepEqual(out.result.intent.filterSpec.countries, ['United Kingdom']);
  assert.deepEqual(out.result.unmapped, [{ field: 'countries', value: 'Narnia' }]);
  // A count query, not a rows query: the offer reads one row at most.
  assert.equal(seen.queries.at(-1).page.limit, 1);
});

test('propose_view FAILS CLOSED on a view it does not know, rather than defaulting to the board', () => {
  // An offer to show the operator something other than what the model meant is worse than no offer, because
  // they will accept it. Both verdicts: every real view is accepted, everything else is refused.
  const { runner } = fakeRunner();
  return Promise.all([
    // MEASURED, not assumed: the shared string coercion trims and lower-cases, so "MAP " IS the map. That
    // tolerance is right for a model's argument and is pinned here rather than left to be rediscovered.
    ...[['board', 'board'], ['map', 'map'], ['analytics', 'analytics'], ['pipeline', 'pipeline'], ['MAP ', 'map']].map(async ([view, resolved]) => {
      const out = await runner.run('propose_view', { view });
      assert.equal(out.ok, true, `${view} is a real view`);
      assert.equal(out.result.view, resolved);
    }),
    ...['', 'settings', 'dashboard', '../admin', 'the map'].map(async (view) => {
      const out = await runner.run('propose_view', { view });
      assert.equal(out.ok, false, `${JSON.stringify(view)} must be refused`);
      assert.match(out.error, /view must be one of/);
    }),
  ]);
});

test('propose_view still offers when the count cannot be taken, saying nothing about the figure', async () => {
  // A count failure must not read as "no records", which is why `total` is null rather than 0 here and the
  // client's count line renders nothing for it.
  const runner = createToolRunner({ runQuery: async () => { throw new Error('store down'); }, defaultDomain: 'space' });
  const out = await runner.run('propose_view', { view: 'board' });
  assert.equal(out.ok, true, 'the offer survives a failed count');
  assert.equal(out.result.total, null);
});

test('THE AGENT SURFACES THE PROPOSAL, and the last offer replaces the first', async () => {
  const { runner } = fakeRunner();
  const chat = scriptedChat([
    { tools: [{ name: 'propose_view', args: { view: 'board', filter: { countries: ['United Kingdom'] } } }] },
    { tools: [{ name: 'propose_view', args: { view: 'map', filter: { countries: ['United Kingdom'] } } }] },
    { text: '{"answer":"2 UK records. I can show you on the map.","cited":[],"entities":[],"numbers":[2]}' },
  ]);
  const out = await runHugoAgent({ chat, runner, system: ['s'], messages: [{ role: 'user', content: 'show me the UK ones' }] });
  assert.equal(out.proposal.tool, 'propose_view');
  assert.equal(out.proposal.view, 'map', 'the SECOND offer is the pending one: two stacked popups is how the wrong one gets tapped');
  assert.equal(out.verification.ok, true);
});

test('a read tool and a FAILED confirm tool both raise no proposal', async () => {
  // Two ways a popup could appear over nothing, and neither may. A read tool cannot become a consent prompt
  // by returning a `requiresConfirmation`-shaped result, and a confirm tool that refused has nothing to offer.
  //
  // The first half needs a runner whose READ tool returns the confirm-shaped result, because no real read
  // tool does: asserted against the real ones, the mode check could only ever report clean, which is an
  // assertion that measures nothing. This one CAN fail, and was seen to when the mode check was removed.
  const impostor = {
    defs: [], ledger: createLedger(),
    modeOf: () => 'read',
    run: async (name) => ({ name, ok: true, result: { requiresConfirmation: true, view: 'map', intent: {} } }),
  };
  const posing = scriptedChat([
    { tools: [{ name: 'query_records', args: {} }] },
    { text: '{"answer":"Nothing to offer.","cited":[],"entities":[],"numbers":[]}' },
  ]);
  const impostered = await runHugoAgent({ chat: posing, runner: impostor, system: ['s'], messages: [{ role: 'user', content: 'how many' }] });
  assert.equal(impostered.proposal, null, 'a READ tool cannot become a consent popup by returning the right-looking key');

  const { runner } = fakeRunner();
  const readOnly = scriptedChat([
    { tools: [{ name: 'query_records', args: { filter: { countries: ['United Kingdom'] } } }] },
    { text: '{"answer":"Two match.","cited":[],"entities":[],"numbers":[2]}' },
  ]);
  const a = await runHugoAgent({ chat: readOnly, runner, system: ['s'], messages: [{ role: 'user', content: 'how many' }] });
  assert.equal(a.proposal, null, 'and a real read tool returns nothing to offer in the first place');

  const { runner: r2 } = fakeRunner();
  const refused = scriptedChat([
    { tools: [{ name: 'propose_view', args: { view: 'nowhere' } }] },
    { text: '{"answer":"I could not offer that view.","cited":[],"entities":[],"numbers":[]}' },
  ]);
  const b = await runHugoAgent({ chat: refused, runner: r2, system: ['s'], messages: [{ role: 'user', content: 'show me' }] });
  assert.equal(b.proposal, null, 'a refused offer is not an offer');
});

test('THE OFFER SURVIVES WITH NO MODEL: the deterministic fallback proposes the view too', async () => {
  // This is what lets the panel drop its separate compile-and-Apply buttons without taking board-driving
  // away from a deployment that has no model key. The resolver already reads a view cue and a filter out of
  // the sentence, so the same consent popup is available with no model at all.
  const { runner } = fakeRunner();
  const out = await deterministicAnswer({ runner, question: 'which vendors are in the United Kingdom, on a map', domain: 'space' });
  assert.equal(out.model, false);
  assert.equal(out.proposal.tool, 'propose_view');
  assert.equal(out.proposal.view, 'map', 'the view cue in the sentence is honoured');
  assert.deepEqual(out.proposal.intent.filterSpec.countries, ['United Kingdom']);
  assert.equal(out.proposal.total, 2, 'MEASURED against the fake store: two United Kingdom rows');
  // No view cue falls back to the board rather than offering nothing, which is where "show me" belongs.
  const plain = await deterministicAnswer({ runner: fakeRunner().runner, question: 'vendors in Sweden', domain: 'space' });
  assert.equal(plain.proposal.view, 'board');
});

test('a sentence the resolver cannot read offers nothing, rather than offering the whole dataset', async () => {
  // The one case that must NOT produce an offer: nothing was understood, so there is nothing to consent to,
  // and an unfiltered board is the widest possible answer to a question nobody could parse.
  const { runner } = fakeRunner();
  const out = await deterministicAnswer({ runner, question: 'what do you reckon then', domain: 'space' });
  assert.equal(out.proposal, null);
  assert.match(out.answer, /could not read that as a question about the dataset/);
});

// THE PROVENANCE TOOLS CALLED A METHOD THE REPOSITORY HAS NEVER HAD.
//
// Both sites asked for `provenanceRepo.read(...)`; `src/db/provenance-repo.js` exposes `recordAssertions`,
// `recordSource`, `current` and `byField`, and no `read`. The two failed differently and the quieter one
// was worse: `record_provenance` threw a TypeError that the runner's catch turned into "provenanceRepo.read
// is not a function" as the model's answer about a named vendor, while `get_record` reached the same absent
// method through optional chaining, short-circuited, and reported `provenance: null` for every record on
// every deployment for ever.
//
// The fake below is deliberately the REAL repository's method surface, not a convenient one: it offers
// `current` and nothing else, so a future call to any method the repository lacks fails here rather than in
// production. Every asserted figure was printed from the runner before it was written down.
const PROV_ROWS = [
  { field: 'country', value: 'United Kingdom', verdict: 'supported', source_key: 'https://orbital-signals.co.uk/about' },
  { field: 'country', value: 'United Kingdom', verdict: 'unclear', source_key: 'https://example.test/other' },
  { field: 'website', value: 'orbital-signals.co.uk', verdict: 'supported', source_key: 'https://orbital-signals.co.uk/' },
];

test('record_provenance reads the repository method that exists, and folds the claims by field', async () => {
  const asked = [];
  const provenanceRepo = {
    current: async (domain, id) => { asked.push([domain, id]); return id === 'VH-0001' ? PROV_ROWS : []; },
  };
  const { runner } = fakeRunner({ provenanceRepo });

  const out = await runner.run('record_provenance', { domain: 'space', id: 'VH-0001' });
  assert.equal(out.ok, true, 'the tool must not fail on a record that has provenance: ' + JSON.stringify(out));
  assert.deepEqual(asked, [['space', 'VH-0001']], 'and it must ask `current`, the method that exists');
  assert.equal(out.result.claims, 3, 'every claim row is counted');
  // Two claims on `country` with different verdicts fold into ONE field carrying both, which is the
  // contested case the popover was written for; `website` has one.
  assert.deepEqual(out.result.fields, [
    { field: 'country', sources: 2, state: 'supported/unclear' },
    { field: 'website', sources: 1, state: 'supported' },
  ], JSON.stringify(out.result.fields));
  // No invented grade. Nothing in the tree computes a provenance band, so the reply carries none rather
  // than a letter nobody measured.
  assert.equal('band' in out.result, false, 'the reply must not carry a band no code computes');

  // A record with no claims is a clean refusal, not a throw.
  const none = await runner.run('record_provenance', { domain: 'space', id: 'VH-0003' });
  assert.equal(none.ok, false);
  assert.match(none.error, /no provenance for VH-0003/);
});

test('record_provenance counts a person\'s uncited edit as a claim with no source behind it (VH-605)', async () => {
  const uncited = { field: 'website', value: 'orbital-signals.co.uk', verdict: 'unclear', source_key: null, method: 'human' };
  const { runner } = fakeRunner({ provenanceRepo: { current: async () => [...PROV_ROWS, uncited] } });
  const out = await runner.run('record_provenance', { domain: 'space', id: 'VH-0001' });
  assert.equal(out.result.claims, 4, 'it is still a claim');
  assert.deepEqual(out.result.fields.find((f) => f.field === 'website'), { field: 'website', sources: 1, state: 'supported/unclear' }, 'but not a source');
});

test('get_record reports real provenance rather than a silent null', async () => {
  const provenanceRepo = { current: async (_d, id) => (id === 'VH-0001' ? PROV_ROWS : []) };
  const { runner } = fakeRunner({ provenanceRepo });

  const withProv = await runner.run('get_record', { domain: 'space', id: 'VH-0001' });
  assert.equal(withProv.ok, true);
  // Three claims over two distinct fields. Pre-fix this was `null` however much provenance existed.
  assert.deepEqual(withProv.result.provenance, { claims: 3, fields: 2 }, JSON.stringify(withProv.result.provenance));

  // Null is still the right answer where there genuinely is nothing, and where no repository is wired at
  // all, so the fix has not turned an honest absence into a claim.
  const without = await runner.run('get_record', { domain: 'space', id: 'VH-0003' });
  assert.equal(without.result.provenance, null, 'a record with no claims reports null');
  const { runner: bare } = fakeRunner();
  const unwired = await bare.run('get_record', { domain: 'space', id: 'VH-0001' });
  assert.equal(unwired.ok, true, 'a deployment with no provenance repository still answers');
  assert.equal(unwired.result.provenance, null);
});
