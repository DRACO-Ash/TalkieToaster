// HUGO'S FAILURES NAME THEIR CAUSE (V1.82). The owner reported, twice, that Hugo "will not converse" and
// could not tell me why - and the reason they could not is in this file.
//
// There are four ways a Hugo turn fails and only one of them said anything useful. A sign-in without the
// `agent` role got 403 on every turn, which the rail rendered as "Hugo could not answer that just now. Try
// again." - a permanent refusal dressed as a transient one, inviting a retry that can never work - and a 403
// is under 500 so it left no trace in the fault ring either. It was invisible from both ends at once, and
// under Entra an unmapped role claim yields `roles: []` silently, which makes it the best candidate for the
// live report.
//
// These are SOURCE assertions rather than DOM ones because the mapping is a pure function inside the shell,
// which has no unit-testable seam; the wiring is driven in the browser smoke. What is pinned here is that
// each cause is named, that no cause offers a retry that cannot work, and that the server's own reason is
// carried rather than discarded.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (rel) => readFileSync(new URL(rel, import.meta.url), 'utf8');

test('every Hugo failure status is named, and none of the permanent ones offers a retry', () => {
  const app = read('../public/app-v3.js');
  const fn = /function hugoChatError\(result\) \{[\s\S]*?\n\}/.exec(app)[0];
  // The four causes an operator can actually meet, each distinguishable.
  for (const status of ['403', '401', '503', '429', '502', '400']) {
    assert.ok(fn.includes(status), 'no branch names status ' + status);
  }
  // THE 403 IS THE ONE THAT COST THE OWNER A WEEK. It must name the capability and must say retrying will
  // not help, because the previous message said the opposite.
  const forbidden = /if \(result\.status === 403\) \{[\s\S]*?\n {2}\}/.exec(fn)[0];
  assert.match(forbidden, /agent role/, 'the 403 must name the role that is missing');
  assert.match(forbidden, /retrying will not change it/, 'and must not invite a retry that cannot work');
  // The generic "Try again" survives ONLY as the last resort, so a genuinely unknown failure still reads
  // sensibly. Both verdicts therefore exist in this function.
  assert.match(fn, /return 'Hugo could not answer that just now\. Try again\.';\n\}/, 'the fallback is last');
});

test('the transport carries the server reason instead of discarding it', () => {
  const api = read('../public/api-v3.js');
  const fn = /export async function hugoAgent\([\s\S]*?\n\}/.exec(api)[0];
  assert.match(fn, /payload\?\.error/, 'the server sentence must be read off the payload');
  assert.match(fn, /return \{ ok: false, status, reason \}/, 'and returned to the rail');
  // BOUNDED, because it is rendered beside a generic sentence and comes from a route's error body.
  assert.match(fn, /\.slice\(0, 160\)/, 'the reason must be length-bounded before it reaches the screen');
  // And the rail must actually use it, or carrying it achieves nothing.
  assert.match(read('../public/app-v3.js'), /typeof result\.reason === 'string'/, 'the rail must render the reason');
});

test('a 403 names the capability it wanted, on every route and not just the one that prompted it', () => {
  const api = read('../src/api-v3.js');
  // `requireRole` and `requireAnyRole` are the only two producers of a 403 in this file, and the fix is a
  // class fix: both name what was missing. A bare "forbidden" is a dead end for a signed-in operator.
  const single = /function requireRole\(principal, role\) \{[\s\S]*?\n\}/.exec(api)[0];
  const any = /function requireAnyRole\(principal, roles\) \{[\s\S]*?\n\}/.exec(api)[0];
  assert.match(single, /needs the ' \+ role \+ ' role/, 'requireRole must name the role');
  assert.match(any, /needs one of the ' \+ roles\.join/, 'requireAnyRole must name the roles');
  for (const fn of [single, any]) assert.match(fn, /statusCode: 403/, 'the status is unchanged');
  // NO BARE 'forbidden' LEFT ANYWHERE in the throw sites, which is what makes this a swept class rather than
  // a patched instance.
  assert.doesNotMatch(api, /new Error\('forbidden'\)/, 'a bare forbidden throw survives somewhere');
});
