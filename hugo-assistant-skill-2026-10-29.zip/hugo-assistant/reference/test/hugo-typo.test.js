// READING A MISSPELT COUNTRY (src/hugo/deterministic.js), owner 2026-09-19: Hugo "can't accept poor
// spelling".
//
// THE MEASUREMENT THAT CHOSE THE ALGORITHM IS PART OF THE TEST, because the obvious tool was wrong and
// nothing in the code would otherwise say so. The duplicate detector matches misspelt COMPANY names by
// trigram Jaccard, so reusing it looked free. On country names it is not: "Germny" against "Germany"
// scores well BELOW "Niger" against "Nigeria", so any threshold that read the typo would fold two real
// countries together. Trigrams need length; country names are short. That is pinned below so nobody
// "simplifies" this back to the shared matcher.
//
// The cases are the ways a fuzzy pass goes wrong while looking right: it reads a real country as a
// different real country, it guesses at something far too short, it resolves an ambiguous token to
// whichever name the canon happens to list first, or it applies a guess silently.

import test from 'node:test';
import assert from 'node:assert/strict';

import { resolveDeterministic, closestCountry } from '../src/hugo/deterministic.js';
import { canonicalCountries, isRecognisedCountry } from '../src/domain/country-canon.js';
import { nameTrigrams, trigramJaccard } from '../src/domain/duplicates.js';
import { SPACE_DESCRIPTOR } from '../src/domain/descriptor.js';

const CANON = canonicalCountries();
const countriesFor = (text) => resolveDeterministic(text, SPACE_DESCRIPTOR).raw.filterSpec.countries;
const readingsFor = (text) => resolveDeterministic(text, SPACE_DESCRIPTOR).readings;

test('the trigram matcher really is the wrong tool here, which is why this one exists', () => {
  const typo = trigramJaccard(nameTrigrams('Germny'), nameTrigrams('Germany'));
  const realPair = trigramJaccard(nameTrigrams('Niger'), nameTrigrams('Nigeria'));
  // The ordering is the finding: a threshold low enough to accept the TYPO would also accept a pair of
  // genuinely different countries. Asserted as an inequality rather than as two figures, so it keeps
  // meaning the same thing if the canon or the tokeniser shifts.
  assert.ok(typo < realPair,
    `a misspelling scores ${typo.toFixed(2)} and two real countries score ${realPair.toFixed(2)};`
    + ' trigrams cannot separate them on names this short');
});

test('an ordinary typo resolves', () => {
  assert.deepEqual(countriesFor('who is in Germny'), ['Germany']);
  assert.deepEqual(countriesFor('vendors in Polnd'), ['Poland']);
  // A transposition, which is the other half of "poor spelling" and needs the two-edit bound.
  assert.deepEqual(countriesFor('anything in Frnace'), ['France']);
});

test('a real country is NEVER read as a different real country', () => {
  // NEAREST-WINS, on pairs that are genuinely INSIDE the fuzzy bound. Two earlier versions of this test
  // proved nothing and both were caught by breaking the code on purpose: Iran/Iraq and Mali/Malta are four
  // characters and excluded by the length guard, and deleting exact-first changes no verdict here either,
  // because a recognised name is distance 0 from itself and nothing can beat that. What this pins is the
  // OUTCOME - a real country resolves to itself alone - which is the property an operator depends on
  // however the implementation gets there. Pairs found by running the matcher over the whole canon:
  //   Ireland <-> Iceland   one edit
  //   Canada  <-> Panama    two edits
  //   Slovenia<-> Slovakia  two edits
  // Each is a pair of REAL names, so only "try the canon first" keeps them apart.
  for (const [typed, forbidden] of [['Ireland', 'Iceland'], ['Canada', 'Panama'], ['Slovenia', 'Slovakia']]) {
    assert.ok(isRecognisedCountry(typed), typed + ' is a real country, so it must resolve exactly');
    assert.deepEqual(countriesFor('vendors in ' + typed), [typed],
      typed + ' must resolve to itself and to nothing else, never to ' + forbidden);
  }
});

test('a token too short to be a typo is not guessed at', () => {
  // At four characters one edit is most of the word, so "Chad" must not become "Chile" and a stray short
  // word must not become a country at all.
  assert.equal(closestCountry('Chad', CANON), '', 'a real short name is left alone by the fuzzy pass');
  assert.equal(closestCountry('data', CANON), '');
  assert.equal(closestCountry('list', CANON), '');
  assert.equal(closestCountry('the', CANON), '');
});

test('an ambiguous token is refused rather than resolved to the first match', () => {
  // Guard 2, on a case that is ambiguous UNDER THE REAL BOUND. The first version of this test used
  // "spian" and was vacuous: at five characters the bound is one edit and Spain is two away, so nothing
  // matched at all and the test passed with the tie guard deleted. "banada" is six characters, so the
  // bound is two. "banada" was the second attempt and was also wrong: it is ONE edit from Canada and two
  // from Panama, so Canada legitimately wins and nothing is ambiguous. A real tie has to be EQUIDISTANT,
  // and "panada" is: one edit from Canada (p->c) and one from Panama (d->m).
  assert.equal(closestCountry('panada', CANON), '',
    'one edit from Canada and one from Panama, so it means neither');
  // The assertion can reach both verdicts: a six-letter token with ONE neighbour does resolve.
  assert.equal(closestCountry('germny', CANON), 'Germany');
});

test('a guess is reported, never applied silently', () => {
  const readings = readingsFor('who is in Germny');
  assert.equal(readings.length, 1);
  assert.deepEqual(readings[0], { typed: 'Germny', read: 'Germany', kind: 'country' });
  // And an exactly-spelt question reports nothing, so the confirm surface has nothing to explain.
  assert.deepEqual(readingsFor('who is in Germany'), []);
});
