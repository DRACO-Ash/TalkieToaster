// The version-keyed live-record cache (V0.97).
//
// The cache is keyed on the highest `audit_log` id, on the strength of the claim that this repository
// writes an audit row inside every write transaction. If that claim is false for even one write path, that
// path leaves the cache serving data the operator has already changed, and no amount of testing the cache
// itself would reveal it.
//
// So these tests do NOT assert "the version was bumped". They assert what an operator would actually
// notice: that after each write, the analytics reflect it. That way the assertion fails whether the cause
// is a missing audit row, a broken key, or a cache that never invalidates.
//
// Every expected value here was printed from the running code before it was asserted.

import test from 'node:test';
import assert from 'node:assert/strict';

import { readFileSync } from 'node:fs';

import { createVendorRepo } from '../src/db/vendor-repo.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';

// Wraps an executor to count the queries that actually reach storage, so a cache HIT is measured rather
// than inferred from a timing or from the cache's own bookkeeping.
function counting(executor) {
  const counts = { total: 0, liveReads: 0, versionReads: 0 };
  return {
    ...executor,
    query: (sql, params) => {
      counts.total += 1;
      if (typeof sql === 'string') {
        if (sql.includes('from vendor where') && sql.includes('select data')) counts.liveReads += 1;
        if (sql.includes('max(id)') && sql.includes('audit_log')) counts.versionReads += 1;
      }
      return executor.query(sql, params);
    },
    counts,
  };
}

async function freshRepo() {
  const base = await makePgliteExecutor();
  await runMigrations(base);
  const executor = counting(base);
  return { repo: createVendorRepo(executor), counts: executor.counts };
}

const seed = (id, over = {}) => ({
  vendor_id: id, company: 'Co ' + id, country: 'United Kingdom', section: 'EMSO',
  grade: 'Unknown', gdm: 'Not in GDM', ...over,
});

test('a repeated analytics read is served from cache, and one write is enough to invalidate it', async () => {
  const { repo, counts } = await freshRepo();
  await repo.createVendor(seed('VH-0001'), 'seed');

  const first = await repo.analyticsReport();
  const afterFirst = counts.liveReads;
  assert.equal(afterFirst, 1, 'the first read must hit storage');

  // Three more identical reads. If the cache works, storage is not touched again.
  await repo.analyticsReport();
  await repo.analyticsReport();
  const second = await repo.analyticsReport();
  assert.equal(counts.liveReads, afterFirst, 'a repeated read must not re-read the whole table');
  assert.deepEqual(second, first, 'a cached read must return the same answer as the uncached one');

  // A different window is a different fold over the SAME cached records, so it still must not re-read.
  await repo.analyticsReport({ from: '2026-01', to: '2026-02' });
  assert.equal(counts.liveReads, afterFirst, 'a different window folds cached records, it does not re-read');

  // And now a write. The next read must see it.
  await repo.createVendor(seed('VH-0002', { country: 'France' }), 'seed');
  const third = await repo.analyticsReport();
  assert.equal(counts.liveReads, afterFirst + 1, 'a write must force exactly one re-read');
  assert.equal(third.heat.total, 2, 'the read after a write must include the write');
  assert.notDeepEqual(third, first, 'the answer must have changed, or the cache is stale');
});

test('the growth report shares the cache rather than issuing a second identical whole-table read', async () => {
  const { repo, counts } = await freshRepo();
  await repo.createVendor(seed('VH-0001', { gdm: 'In GDM', gdm_onboarded_at: '2026-01-15' }), 'seed');

  await repo.analyticsReport();
  const afterAnalytics = counts.liveReads;
  await repo.gdmGrowthReport();
  assert.equal(counts.liveReads, afterAnalytics,
    'the growth report reads the same live set, so painting one screen must not read the table twice');
});

// The load-bearing test. Each of these is a distinct write path, and each must invalidate. A path that
// audits nothing would pass a cache-mechanism test and fail this one.
test('every write path invalidates the cache, because every write path audits', async () => {
  const { repo } = await freshRepo();
  await repo.createVendor(seed('VH-0001'), 'seed');
  await repo.createVendor(seed('VH-0002', { company: 'Co VH-0001' }), 'seed');
  await repo.createVendor(seed('VH-0003', { country: 'France' }), 'seed');

  const totalNow = async () => (await repo.analyticsReport()).heat.total;
  // The analytics dimension is the DATA TYPE since V1.84, so an invalidation is observed by a data type
  // appearing rather than by a JCO mission appearing. The property under test is the cache, not the axis.
  const typesOf = async () => (await repo.analyticsReport()).metrics.groups
    .filter((s) => s.total > 0).map((s) => s.dataType).sort((a, b) => (a > b) - (a < b));

  assert.equal(await totalNow(), 3, 'baseline');

  // 1. createVendor
  await repo.createVendor(seed('VH-0004'), 'seed');
  assert.equal(await totalNow(), 4, 'createVendor must invalidate');

  // 2. updateVendor (a field the analytics fold reads)
  const loaded = await repo.getVendor('VH-0004');
  await repo.updateVendor('VH-0004', loaded.rev, { product_types: ['Radar'] }, 'tester');
  assert.ok((await typesOf()).includes('Radar'), 'updateVendor must invalidate');

  // 3. bulkUpdate
  await repo.bulkUpdate(['VH-0003'], { product_types: ['Infrared'] }, 'tester', { auditAction: 'bulk-edit' });
  assert.ok((await typesOf()).includes('Infrared'), 'bulkUpdate must invalidate');

  // 4. soft delete, which REMOVES a record from the live set
  await repo.bulkUpdate(['VH-0003'], { lifecycle_status: 'deleted' }, 'tester', { auditAction: 'bulk-delete' });
  assert.equal(await totalNow(), 3, 'a soft delete must invalidate');

  // 5. un-delete, which puts it back in the live set.
  //
  // NOT `restoreVendors`, which is the backup-restore path and takes RECORDS: called with ids it returns
  // `{ restored: 0, invalidCount: 1 }` and validly audits anyway. The first version of this test called it
  // with ids, read the unchanged total, and reported a cache defect that did not exist. The diagnosis is
  // worth keeping: the version had moved from 2 to 3 and the audit row was present, so the cache was
  // correct and the test was wrong.
  await repo.bulkUpdate(['VH-0003'], { lifecycle_status: 'active' }, 'tester', { auditAction: 'bulk-restore' });
  assert.equal(await totalNow(), 4, 'an un-delete must invalidate');

  // 6. enqueueProposal then approveProposal, which mints a new live record
  const { id } = await repo.enqueueProposal({ company: 'Zeta', country: 'Italy', grade: 'Unknown', gdm: 'Not in GDM' }, 'hunt', 'scan');
  await repo.approveProposal(id, 'tester');
  assert.equal(await totalNow(), 5, 'approving a proposal must invalidate');

  // 7. merge, which collapses two live records into one
  const before = await totalNow();
  const revs = {};
  for (const vid of ['VH-0001', 'VH-0002']) revs[vid] = (await repo.getVendor(vid)).rev;
  const merged = await repo.mergeVendors({ survivorId: 'VH-0001', victimIds: ['VH-0002'], revs }, 'tester');
  assert.ok(!merged?.badRequest && !merged?.conflict, 'the merge must have applied: ' + JSON.stringify(merged));
  assert.equal(await totalNow(), before - 1, 'a merge must invalidate');
});

test('a dataset over the cache cap is not held in memory, and the answer is identical either way', async () => {
  // The cap exists because the container caps its heap (--max-old-space-size), so an unbounded cache would
  // trade a slow read for an out-of-memory kill, which is a worse failure than a slow screen.
  //
  // This test genuinely crosses the cap rather than describing it. The first version of it asserted only
  // the small-dataset case while its NAME claimed to test the decline, which is precisely the kind of
  // assertion that can reach only one verdict. The cap is a constructor option, so the boundary is reached
  // with two records instead of five thousand and one.
  const base = await makePgliteExecutor();
  await runMigrations(base);
  const executor = counting(base);
  const capped = createVendorRepo(executor, { rowCacheMax: 1 });

  await capped.createVendor(seed('VH-0001'), 'seed');
  // One record, at the cap: cached.
  const one = await capped.analyticsReport();
  const afterOne = executor.counts.liveReads;
  await capped.analyticsReport();
  assert.equal(executor.counts.liveReads, afterOne, 'at the cap the dataset is still cached');

  // Two records, over the cap: every read must go to storage.
  await capped.createVendor(seed('VH-0002', { country: 'France' }), 'seed');
  const overA = await capped.analyticsReport();
  const afterOverA = executor.counts.liveReads;
  const overB = await capped.analyticsReport();
  assert.equal(executor.counts.liveReads, afterOverA + 1, 'over the cap nothing is cached');

  // Correctness must not depend on whether caching happened.
  assert.deepEqual(overB, overA, 'the uncached answer must be stable');
  assert.equal(overA.heat.total, 2);
  assert.notDeepEqual(overA, one, 'and it must reflect the second record');

  // liveRecords is exposed, so the parsed set can be inspected without going through the analytics.
  const records = await capped.liveRecords();
  assert.equal(records.length, 2);
  assert.deepEqual(records.map((r) => r.company).sort((a, b) => (a > b) - (a < b)), ['Co VH-0001', 'Co VH-0002']);
});

test('a dataset over the BYTE cap is not held either, because rows do not bound memory', async () => {
  // The security gate's MAJOR: a row cap alone does not bound memory. It measured a single record accepting
  // a 970 KB evidence string, and 200 records of about 100 KB retaining 20.4 MB after an explicit collection,
  // which extrapolates to roughly 510 MB at the row cap against a 384 MB heap. Break-even is about 77 KB per
  // row, which is inside plausible organic data. So the byte cap is the real bound and this crosses it.
  //
  // The row cap is left generous here on purpose, so the ONLY thing that can decline the cache is bytes. A
  // test that trips both caps at once cannot tell you which one worked.
  const base = await makePgliteExecutor();
  await runMigrations(base);
  const executor = counting(base);
  const capped = createVendorRepo(executor, { rowCacheMax: 1000, rowCacheMaxBytes: 4096 });

  await capped.createVendor(seed('VH-0001'), 'seed');
  const small = await capped.analyticsReport();
  const afterSmall = executor.counts.liveReads;
  await capped.analyticsReport();
  assert.equal(executor.counts.liveReads, afterSmall, 'a small dataset is under both caps, so it is cached');

  // One fat record pushes the dataset over the byte cap while staying far under the row cap.
  await capped.createVendor(seed('VH-0002', { country: 'France', evidence: 'x'.repeat(8000) }), 'seed');
  const fatA = await capped.analyticsReport();
  const afterFatA = executor.counts.liveReads;
  const fatB = await capped.analyticsReport();
  assert.equal(executor.counts.liveReads, afterFatA + 1,
    'over the BYTE cap nothing may be held, however few rows there are');

  // Correctness cannot depend on whether caching happened.
  assert.deepEqual(fatB, fatA, 'the uncached answer must be stable');
  assert.equal(fatA.heat.total, 2);
  assert.notDeepEqual(fatA, small, 'and it must reflect the second record');

  // Proof the byte cap is what declined it: the same data under a generous byte cap IS cached. Without this
  // the test above would pass for any reason at all, including a cache that never worked.
  // The round-two gate noted this block CLAIMED the generous cap caches but only asserted the answers match.
  // The claim was true and unproven, which is its own defect: the live-read count is now asserted.
  const gCount = counting(base);
  const generous = createVendorRepo(gCount, { rowCacheMax: 1000, rowCacheMaxBytes: 32 * 1024 * 1024 });
  const g1 = await generous.analyticsReport();
  const afterG1 = gCount.counts.liveReads;
  await generous.analyticsReport();
  await generous.analyticsReport();
  assert.equal(gCount.counts.liveReads, afterG1,
    'under a generous byte cap the SAME data must be cached, or the decline above was not the byte cap');
  const gExec = await generous.liveRecords();
  assert.equal(gExec.length, 2);
  assert.deepEqual(g1, fatA, 'both configurations must compute the same answer');
});

test('an unreadable dataset version declines to cache rather than serving data with no invalidation signal', async () => {
  // Fail-closed, and the direction matters: a cache whose invalidation signal is broken must stop caching,
  // never keep serving. Proved by breaking the version read itself and confirming BOTH that the answer
  // stays correct and that every read goes back to storage.
  const base = await makePgliteExecutor();
  await runMigrations(base);
  let breakVersion = false;
  const executor = counting({
    ...base,
    query: (sql, params) => {
      if (breakVersion && typeof sql === 'string' && sql.includes('max(id)') && sql.includes('audit_log')) {
        return Promise.reject(new Error('audit log unreadable'));
      }
      return base.query(sql, params);
    },
  });
  const repo = createVendorRepo(executor);
  await repo.createVendor(seed('VH-0001'), 'seed');

  assert.equal((await repo.datasetVersion()) > 0, true, 'a healthy version is a positive number');

  breakVersion = true;
  assert.equal(await repo.datasetVersion(), null, 'an unreadable version reports null, not a stale number');

  const a = await repo.analyticsReport();
  const readsAfterA = executor.counts.liveReads;
  const b = await repo.analyticsReport();
  assert.deepEqual(b, a, 'the answer must stay correct with no version available');
  assert.equal(executor.counts.liveReads, readsAfterA + 1,
    'with no invalidation signal every read must go to storage, or the cache is serving blind');
});

test('every function that writes the vendor table also audits, as a structural rule not an enumeration', () => {
  // WHY THIS EXISTS. The cache is keyed on the highest audit id, so a write path that does not audit leaves
  // the cache serving data an operator has already changed. The test above enumerates seven paths and both
  // gates verified about fifteen, but enumeration never terminates: the next write path added is the one
  // nobody remembers to list. This asserts the CLASS instead.
  //
  // The three statements that mutate the vendor table are insertRow, upsertRow and updateRow, and nothing
  // outside vendor-repo.js touches it. So: every function containing a call to one of them must also contain
  // an auditTx call. Verified by brace-matched block extraction rather than by proximity, because a regex
  // over a 3,400-line file would match an audit in the next function along.
  const src = readFileSync(new URL('../src/db/vendor-repo.js', import.meta.url), 'utf8');
  const lines = src.split('\n');

  // Every function body in the file, as [name, text], by matching braces from its opening line.
  const bodies = [];
  const header = /^\s*(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(/;
  for (let i = 0; i < lines.length; i += 1) {
    const m = header.exec(lines[i]);
    if (!m) continue;
    let depth = 0;
    let started = false;
    const chunk = [];
    for (let j = i; j < lines.length; j += 1) {
      chunk.push(lines[j]);
      for (const ch of lines[j]) {
        if (ch === '{') { depth += 1; started = true; } else if (ch === '}') depth -= 1;
      }
      if (started && depth <= 0) break;
    }
    bodies.push([m[1], chunk.join('\n')]);
  }
  assert.ok(bodies.length > 40, 'the body extractor found only ' + bodies.length + ' functions, so it is broken');

  const WRITERS = /\b(?:insertRow|upsertRow|updateRow)\s*\(/;
  const AUDITS = /\bauditTx(?:Returning)?\s*\(/;
  // The three writers themselves issue the SQL and are called by the audited functions; they are the
  // primitives, not paths.
  const PRIMITIVES = new Set(['insertRow', 'upsertRow', 'updateRow']);

  const unaudited = bodies
    .filter(([name, body]) => !PRIMITIVES.has(name) && WRITERS.test(body) && !AUDITS.test(body))
    .map(([name]) => name);

  assert.deepEqual(unaudited, [],
    'these functions write the vendor table without auditing in the same body, so the version-keyed cache '
    + 'would serve stale data for them: ' + unaudited.join(', '));

  // The guard must be able to fail, or it is decoration. There must be functions it actually inspected.
  const writers = bodies.filter(([name, body]) => !PRIMITIVES.has(name) && WRITERS.test(body));
  assert.ok(writers.length >= 5,
    'the guard found only ' + writers.length + ' write paths to check, so it is not looking at the real file');
});
