// HUGO'S PAIR EXPLANATION WORDS "NONE IN COMMON" AS THE MATCH PANEL DOES (checker MINOR on 667e54b). The panel's
// stored explanation comes from `matchPair`, which sets `noneShared` on other names, people and memberships through
// `markNoneShared`; Hugo's `explain_match` scored the pair with `scorePair` alone, so its contributions carried no
// `noneShared` and could not tell "a side held nothing" from "both held values and shared none". Driven on all 7.
import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner } from '../src/hugo/tools.js';
import { domainIds } from '../src/domain/descriptor.js';
import { matchPair, LABELLED_WEIGHTS, LABELLED_PRIOR } from '../src/domain/er-model.js';

const A = { name: 'Acme Ltd', company: 'Acme Ltd', country: 'Norway', hq_country: 'Norway', website: 'acme.example', people: ['Ada Lovelace'], memberships: ['NATO DIANA'] };
const B = { name: 'Acme Ltd', company: 'Acme Ltd', country: 'Norway', hq_country: 'Norway', website: 'acme.example', people: ['Grace Hopper'], memberships: [] };

function runner(domain) {
  const recs = { 'id-a': { ...A, provider_key: 'id-a' }, 'id-b': { ...B, provider_key: 'id-b' } };
  return createToolRunner({
    runQuery: async () => ({ rows: [], total: 0 }),
    vendorRepo: { getVendor: async (id) => (recs[id] ? { record: recs[id] } : null) },
    domainRepoFor: () => ({ get: async (id) => recs[id] || null }),
    defaultDomain: domain,
  });
}

for (const domain of domainIds()) {
  test(`${domain}: explain_match carries noneShared on the three comparisons, the same as the match panel`, async () => {
    const out = await runner(domain).run('explain_match', { domain, idA: 'id-a', idB: 'id-b' });
    assert.equal(out.ok, true, JSON.stringify(out));
    const by = Object.fromEntries(out.result.contributions.map((c) => [c.feature, c]));
    assert.equal(by.people.noneShared, true, 'both name people and share none');
    assert.equal(by.membership.noneShared, false, 'one side holds no membership');
    assert.equal(by.aka.noneShared, false, 'neither side holds another name');
    // The panel's own path over the same pair words the three the same way.
    const panel = matchPair(A, B, { weights: LABELLED_WEIGHTS, prior: LABELLED_PRIOR }).contributions;
    for (const c of panel.filter((x) => Object.hasOwn(x, 'noneShared'))) assert.equal(by[c.feature].noneShared, c.noneShared, c.feature);
  });
}
