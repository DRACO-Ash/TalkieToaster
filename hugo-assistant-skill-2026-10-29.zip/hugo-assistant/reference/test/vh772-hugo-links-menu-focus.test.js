// VH-772 (Development 2, 2026-10-20): Hugo's opening links clear AA on the rail, and a menu item's hover and focus fill
// can be seen in both appearances and spans its menu. Read from the stylesheet and measured on the token pairs.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bodyOf, ratio, THEMES, token } from './helpers/stylesheet.js';

const mix = (a, b, p) => '#' + [1, 3, 5].map((i) => Math.round(p * Number.parseInt(a.slice(i, i + 2), 16) + (1 - p) * Number.parseInt(b.slice(i, i + 2), 16)).toString(16).padStart(2, '0')).join('');

test('Hugo\'s opening links are --brand-strong at the intro\'s size, and clear 4.5:1 on the rail\'s accent wash', () => {
  assert.match(bodyOf('.hugo-example-line'), /font-size: var\(--text-sm\);/);
  assert.match(bodyOf('.hugo-example-line .link-btn'), /color: var\(--brand-strong\);/);
  for (const [name, where] of THEMES) {
    const rail = mix(token(where, 'accent'), token(where, 'surface-2'), 0.05);
    const r = ratio(token(where, 'brand-strong'), rail);
    assert.ok(r >= 4.5, name + ' link on the rail is ' + r.toFixed(2));
  }
});

test('a menu item spans its menu, and its hover and focus are lit over --surface-2, not a --surface-3 well', () => {
  assert.match(bodyOf('.menu-item'), /width: 100%;/);
  assert.match(bodyOf('.menu-item:hover'), /background: color-mix\(in srgb, var\(--accent\) 14%, var\(--surface-2\)\);/);
  assert.match(bodyOf('.menu-item:focus'), /background: color-mix\(in srgb, var\(--accent\) 18%, var\(--surface-2\)\);/);
  assert.match(bodyOf('.menu-item:focus-visible'), /outline: 2px solid var\(--accent\);/, 'keyboard focus keeps its outline');
  assert.match(bodyOf('.dtx-ctx .menu-item[aria-expanded="true"]'), /background: color-mix\(in srgb, var\(--accent\) 14%, var\(--surface-2\)\);/, 'an open submenu\'s row lit like the rest');
  for (const [name, where] of THEMES) {
    const r = ratio(token(where, 'text'), mix(token(where, 'accent'), token(where, 'surface-2'), 0.18));
    assert.ok(r >= 4.5, name + ' text on the focus fill is ' + r.toFixed(2));
  }
});
