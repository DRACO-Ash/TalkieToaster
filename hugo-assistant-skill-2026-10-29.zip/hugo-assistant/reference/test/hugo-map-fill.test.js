// VH-391: A DOMAIN MAP DRAWN FROM HUGO'S FILTERED SET JUDGES A PROVIDER BY ITS OWN STORE'S FIELDS.
//
// The unfiltered map's row has carried each store's own fill count since VH-258, so the coverage panel's "Core
// fields filled" judged a provider on its own fields. The row a map draws from Hugo's filtered set
// (`providerMapRow`) carried none, so the panel fell back to Space's ten core fields, which no provider holds, and
// a complete provider read about a tenth filled. Proved on all six product-line stores: the filtered read carries
// the same count the map read does, the map row keeps it, and the panel reads it. Space's records are judged on
// Space's own core fields by design, so the seventh store has no projection to align and is not part of this.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createDomainRepo } from '../src/db/domain-repo.js';
import { domainIds, getDescriptor } from '../src/domain/descriptor.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';
import { providerMapRow } from '../public/views/domain-board-more.js';
import { coverageFor } from '../public/views/coverage.js';

const SIX = domainIds().filter((id) => id !== 'space');
const first = (d, key) => [...d.vocab[key]][0];

test('VH-391: a filtered read carries the map read\'s own-store fill, and the panel reads it, on all 6 stores', async () => {
  const executor = await makePgliteExecutor();
  try {
    await runMigrations(executor);
    assert.equal(SIX.length, 6, 'the six product-line stores, measured from the registry');
    for (const id of SIX) {
      const d = getDescriptor(id);
      const repo = createDomainRepo(executor, d);
      const facets = Object.fromEntries(d.capabilityFacets.map((f) => [f.key, [first(d, f.key)]]));
      const fields = { ...facets, chain: [first(d, 'chain')], size_band: first(d, 'size_band') };
      await repo.upsert({ identity: { legal_name: 'Full', website: 'https://full-' + id + '.example', hq_country: 'Sweden' }, fields, lines: [] }, 'test');
      await repo.upsert({ identity: { legal_name: 'Bare', website: null, hq_country: 'Sweden' }, fields: {}, lines: [] }, 'test');
      const filtered = await repo.queryProviders({ countries: ['Sweden'] }, { limit: 50 });
      const mapped = await repo.mapRows();
      for (const name of ['Full', 'Bare']) {
        const fromFilter = filtered.rows.find((r) => r.name === name);
        const fromMap = mapped.rows.find((r) => r.name === name);
        assert.deepEqual(fromFilter.fill, fromMap.fill, id + ' ' + name + ': the filtered read counts as the map read does');
        assert.deepEqual(providerMapRow(fromFilter).record.fill, fromMap.fill, id + ' ' + name + ': and the map row keeps it');
      }
      const full = filtered.rows.find((r) => r.name === 'Full').fill;
      assert.ok(full.filled > filtered.rows.find((r) => r.name === 'Bare').fill.filled, id + ': the fuller provider counts more');
      const report = coverageFor({ key: 'se', label: 'Sweden', countries: ['Sweden'] }, [providerMapRow(filtered.rows.find((r) => r.name === 'Full'))], Date.now());
      assert.equal(report.completenessPct, Math.round((full.filled / full.of) * 100), id + ': the panel reads the store\'s own count, not Space\'s ten');
    }
  } finally { await executor.close(); }
});

test('VH-391: a row with no count, or a malformed one, carries none rather than a guess', () => {
  assert.equal('fill' in providerMapRow({ name: 'X', hq_country: 'Sweden' }).record, false);
  assert.equal('fill' in providerMapRow({ name: 'X', fill: { filled: 'all', of: 12 } }).record, false);
  assert.deepEqual(providerMapRow({ name: 'X', fill: { filled: 3, of: 12, extra: 1 } }).record.fill, { filled: 3, of: 12 });
});
