// Route tests for POST /api/v3/hugo/find (Hugo web-find: fill one vendor's gaps from the web, staged for
// human confirm). In-process via createApp with a stub scan and vendorRepo, so no DB or model is needed.
// Covers the agent role, the spend PIN, server-side target resolution, the forced deep-complete + stageOnly
// params, and the fail-closed refusals (no scan, no vendorId, unknown vendor).

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';

function listen(handler) {
  return new Promise((resolve) => {
    const server = http.createServer(handler);
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}
function request(server, path, { method = 'GET', headers = {}, body } = {}) {
  const { port } = server.address();
  const payload = body === undefined ? null : JSON.stringify(body);
  const allHeaders = payload ? { 'content-type': 'application/json', ...headers } : headers;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method, headers: allHeaders }, (res) => {
      let text = '';
      res.on('data', (chunk) => (text += chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: text }));
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

const verify = createStaticVerifier({
  'agent-tok': { subject: 'ada', roles: ['agent'] },
  'lead-tok': { subject: 'lena', roles: ['gdm_lead'] },
});
const agent = { authorization: 'Bearer agent-tok' };
const lead = { authorization: 'Bearer lead-tok' };

// A stub scan that records what it was started with, and a repo whose deep-complete cohort resolves one
// known vendor id to a single-record cohort.
function stubs() {
  const seen = { started: null, cohortArgs: null, audit: null };
  const scan = { start: (params) => { seen.started = params; return { started: true }; } };
  const vendorRepo = {
    singleVendorCohort: async (args) => {
      seen.cohortArgs = args;
      return args.vendorId === 'VH-0001' ? [{ vendor_id: 'VH-0001', company: 'Gapful Co', needsFields: ['hq'] }] : [];
    },
    // Mirror the REAL auditHugoFind's destructuring ({ vendorId, cohortSize }), so this test can only pass
    // when the route hands those exact fields to the auditor. Persistence fidelity is proven separately, in
    // vendor-repo.test.js against a real database. (A stub that echoed the raw detail would give false
    // confidence, the mistake the gate caught.)
    auditHugoFind: async (actor, { vendorId = '', cohortSize = 0 } = {}) => { seen.audit = { actor, vendorId, cohortSize }; },
    // The find must NOT route through the query auditor; fail loudly if it ever does.
    auditHugoQuery: async () => { throw new Error('a find must not be audited as a query'); },
  };
  return { scan, vendorRepo, seen };
}
function appWith(vendorRepo, scan, scanConfig, extra = {}) {
  return createApp({ env: {}, vendorRepo, scan, scanConfig, verify, allowedOrigin: ORIGIN, ...extra });
}

test('/hugo/find sits on the strict paid rate tier: a refusing scanRateLimit returns 429 before any spend', async () => {
  const { scan, vendorRepo, seen } = stubs();
  // The strict paid tier refuses; the broad limiter would allow. The find must be blocked like a manual hunt.
  const server = await listen(appWith(vendorRepo, scan, null, { scanRateLimit: () => false }));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: agent, body: { vendorId: 'VH-0001', domain: 'space' } });
    assert.equal(res.status, 429);
    assert.match(res.body, /scan rate limited/);
    assert.equal(seen.started, null, 'a rate-limited find never spends');
  } finally { server.close(); }
});

test('a non-agent is refused', async () => {
  const { scan, vendorRepo } = stubs();
  const server = await listen(appWith(vendorRepo, scan));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: lead, body: { vendorId: 'VH-0001', domain: 'space' } });
    assert.equal(res.status, 403);
  } finally { server.close(); }
});

test('a find with no scan agent configured is 503', async () => {
  const { vendorRepo } = stubs();
  const server = await listen(appWith(vendorRepo, null));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: agent, body: { vendorId: 'VH-0001', domain: 'space' } });
    assert.equal(res.status, 503);
  } finally { server.close(); }
});

test('a find with no vendorId is refused 400 before any spend', async () => {
  const { scan, vendorRepo, seen } = stubs();
  const server = await listen(appWith(vendorRepo, scan));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: agent, body: {} });
    assert.equal(res.status, 400);
    assert.equal(seen.started, null, 'no scan started');
  } finally { server.close(); }
});

test('a find for an unknown or non-live vendor is 404, and no scan starts', async () => {
  const { scan, vendorRepo, seen } = stubs();
  const server = await listen(appWith(vendorRepo, scan));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: agent, body: { vendorId: 'VH-9999', domain: 'space' } });
    assert.equal(res.status, 404);
    assert.equal(seen.started, null, 'a missing target never spends');
  } finally { server.close(); }
});

test('a wrong spend PIN is refused 403 when a PIN is configured', async () => {
  const { scan, vendorRepo, seen } = stubs();
  const server = await listen(appWith(vendorRepo, scan, { pin: 'right' }));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: agent, body: { vendorId: 'VH-0001', pin: 'wrong', domain: 'space' } });
    assert.equal(res.status, 403);
    assert.equal(seen.started, null);
  } finally { server.close(); }
});

test('a valid find starts a deep-complete, stage-only run over the resolved cohort and audits it', async () => {
  const { scan, vendorRepo, seen } = stubs();
  const server = await listen(appWith(vendorRepo, scan));
  try {
    const res = await request(server, '/api/v3/hugo/find', { method: 'POST', headers: agent, body: { vendorId: 'VH-0001', domain: 'space' } });
    assert.equal(res.status, 202);
    const out = JSON.parse(res.body);
    assert.equal(out.started, true);
    assert.equal(out.stageOnly, true);
    assert.equal(out.vendorId, 'VH-0001');
    assert.equal(out.cohortSize, 1);
    // The run the scan was actually handed: forced deep-complete + stageOnly, with the server-resolved cohort.
    assert.equal(seen.started.mode, 'deep-complete');
    assert.equal(seen.started.stageOnly, true);
    assert.equal(seen.started.depth, 'deep', 'deep-complete fixes the depth server-side');
    assert.equal(seen.started.cohort.length, 1);
    assert.equal(seen.started.cohort[0].vendor_id, 'VH-0001');
    // The target id was resolved server-side, never a client-supplied record.
    assert.deepEqual(seen.cohortArgs, { vendorId: 'VH-0001' });
    // The permissioned action is audited through the dedicated find auditor, carrying the target vendor.
    assert.equal(seen.audit.vendorId, 'VH-0001');
    assert.equal(seen.audit.cohortSize, 1);
  } finally { server.close(); }
});
