// HUGO'S ONE TOOL REGISTRY AND ONE BRIEF (VH-777 Lane T): the interfaces the typed loop, the spoken relay and the
// GPT-Live sideband (Development 4) share. The definitions in each wire shape, a call run once per call id, and one
// brief per channel and scope.

import test from 'node:test';
import assert from 'node:assert/strict';
import { createHugoSession, hugoToolDefinitions, TOOL_SHAPES } from '../src/hugo/registry.js';
import { chatToolDefs, TOOL_NAMES } from '../src/hugo/tools.js';
import { hugoInstructions, allDomainsBrief, TYPED_INSTRUCTIONS, REALTIME_SESSION_INSTRUCTIONS } from '../src/hugo/persona.js';
import { buildSessionUpdate } from '../src/hugo/openai-realtime.js';

test('the definitions come in each wire shape, every tool in each, and an unknown shape is refused', () => {
  assert.deepEqual(TOOL_SHAPES, ['chat', 'realtime', 'responses']);
  assert.deepEqual(hugoToolDefinitions('chat'), chatToolDefs());
  for (const shape of ['realtime', 'responses']) {
    const defs = hugoToolDefinitions(shape);
    assert.deepEqual(defs.map((d) => d.name), [...TOOL_NAMES], shape + ': every tool, by name');
    assert.ok(defs.every((d) => d.type === 'function' && d.parameters?.type === 'object' && !('function' in d)), shape + ': flat');
  }
  assert.throws(() => hugoToolDefinitions('xml'), /unknown shape/);
});

test('a session runs each call id once, hands a repeat the first result, and refuses a call with no id', async () => {
  let queries = 0;
  const vendorRepo = { async queryByIntent() { queries += 1; return { rows: [], total: 7, applied: [], notApplied: [] }; } };
  const session = createHugoSession({ vendorRepo, defaultDomain: 'space' });
  const first = await session.runCall({ callId: 'call_1', name: 'count_records', args: { domain: 'space' } });
  const again = await session.runCall({ callId: 'call_1', name: 'count_records', args: { domain: 'space' } });
  assert.equal(first.result.total, 7);
  assert.equal(again, first, 'the same result, not a second run');
  assert.equal(queries, 1);
  await session.runCall({ callId: 'call_2', name: 'count_records', args: { domain: 'space' } });
  assert.equal(queries, 2, 'a new call id runs');
  const none = await session.runCall({ name: 'count_records', args: {} });
  assert.deepEqual([none.ok, none.error, queries], [false, 'a call needs its id', 2]);
  assert.equal((await session.runCall({ callId: 'bad id with spaces', name: 'count_records' })).ok, false);
  assert.ok(session.ledger && typeof session.check === 'function' && typeof session.newTurn === 'function', 'the voice runner\'s parts too');
  assert.deepEqual(session.definitions('responses'), hugoToolDefinitions('responses'));
  assert.throws(() => createHugoSession({ vendorRepo }), /domain the conversation is in/);
});

test('one brief per channel and scope, and every channel takes it from there', () => {
  assert.equal(hugoInstructions({ channel: 'typed', scope: 'air' }), TYPED_INSTRUCTIONS);
  assert.equal(hugoInstructions({ channel: 'spoken' }), REALTIME_SESSION_INSTRUCTIONS);
  assert.equal(hugoInstructions({ channel: 'typed', scope: 'all' }), TYPED_INSTRUCTIONS + ' ' + allDomainsBrief());
  assert.equal(hugoInstructions({ channel: 'spoken', scope: 'all' }), REALTIME_SESSION_INSTRUCTIONS + ' ' + allDomainsBrief());
  assert.equal(hugoInstructions(), TYPED_INSTRUCTIONS, 'typed and one domain by default');
  assert.equal(buildSessionUpdate({}).session.instructions, hugoInstructions({ channel: 'spoken' }), 'the spoken relay is briefed from it');
});
