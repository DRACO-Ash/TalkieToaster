// VH-318-C, the client half: the typed turn's event, the stream it reads, the session URL and voice, and the
// operator's words when a turn gets no answer. Pure helpers, so pinned in node; the monolith calling them is
// pinned by source where it has to be.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { textTurnEvent, textStreamAction, realtimeUrl, textTurnErrorText, createTextSession, answerOutcome, applySpokenCheck, spokenCheck, reasonsHtml, typedTurn, REALTIME_VOICES_CLIENT, TEXT_TURN_MAX, TALK_EXPIRING, TALK_EXTENDED, TALK_EXTEND, TALK_RESUMED, sessionLengthWords, clockTime, talkOfferCopy, watchTalkSession } from '../public/views/hugo-stream.js';
import { turnHtml, placeHeard, appendSaid, settleSpoken } from '../public/views/hugo-rail.js';
import { realtimeVoiceAction } from '../public/views/hugo-voice-codec.js';
import { textTurnItem, REALTIME_VOICES, DEFAULT_REALTIME_VOICE, SESSION_EXPIRING_TYPE, SESSION_EXTENDED_TYPE, SESSION_EXTEND_TYPE, SESSION_RESUMED_TYPE } from '../src/hugo/openai-realtime.js';

test('the typed turn the client sends is exactly what the relay rebuilds, so nothing is lost on the way', () => {
  const ev = textTurnEvent('Which Cyber vendors are UK-owned?');
  assert.deepEqual(textTurnItem(ev), ev);
  assert.equal(textTurnEvent('x'.repeat(TEXT_TURN_MAX + 10)).item.content[0].text.length, TEXT_TURN_MAX);
});

test('the stream: deltas append as produced, a tool-call response does not end the turn, an answer does', () => {
  assert.deepEqual(textStreamAction({ type: 'response.output_text.delta', response_id: 'r1', delta: 'Four ' }), { delta: 'Four ', responseId: 'r1' });
  assert.equal(textStreamAction({ type: 'response.output_text.delta', delta: '' }), null);
  assert.deepEqual(textStreamAction({ type: 'response.done', response: { id: 'r1', status: 'completed', output: [{ type: 'function_call', name: 'count_records' }] } }),
    { done: { responseId: 'r1', toolCall: true, status: 'completed' } });
  assert.deepEqual(textStreamAction({ type: 'response.done', response: { id: 'r2', status: 'completed', output: [{ type: 'message' }] } }),
    { done: { responseId: 'r2', toolCall: false, status: 'completed' } });
  assert.deepEqual(textStreamAction({ type: 'error', error: { type: 'invalid_request_error', code: 'rate_limit_exceeded' } }), { error: 'rate_limit_exceeded' });
  assert.deepEqual(textStreamAction({ type: 'error', error: {} }), { error: 'provider-error' });
  assert.equal(textStreamAction({ type: 'response.output_audio.delta', delta: 'AAAA' }), null, 'audio is Talk\'s, not the typed stream\'s');
  assert.equal(textStreamAction(null), null);
});

test('the session URL names the domain and a Realtime voice, marin when the pick is not one', () => {
  assert.equal(realtimeUrl('https://vh.example', 'natural_resources', 'cedar'), 'wss://vh.example/api/v3/hugo/realtime?domain=natural_resources&voice=cedar');
  assert.equal(realtimeUrl('http://localhost:8080', 'air', 'fable'), 'ws://localhost:8080/api/v3/hugo/realtime?domain=air&voice=marin');
  assert.equal(realtimeUrl('http://h', 'a&b', undefined), 'ws://h/api/v3/hugo/realtime?domain=a%26b&voice=marin');
});

test('the client\'s voices, the server\'s and the picker\'s are one list, marin first and selected', () => {
  assert.deepEqual([...REALTIME_VOICES_CLIENT], [...REALTIME_VOICES]);
  assert.equal(REALTIME_VOICES_CLIENT[0], DEFAULT_REALTIME_VOICE);
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  const picker = /<select id="hugo-voice"[^>]*>([\s\S]*?)<\/select>/.exec(html)[1];
  assert.deepEqual([...picker.matchAll(/<option value="([^"]+)"/g)].map((m) => m[1]), [...REALTIME_VOICES]);
  assert.match(picker, /<option value="marin" selected>/);
  for (const gone of ['fable', 'onyx', 'nova']) assert.doesNotMatch(picker, new RegExp('value="' + gone + '"'), gone + ' is not a Realtime voice');
});

test('every way a typed turn can fail has its own words, and an unknown code the generic ones', () => {
  const codes = ['connect', 'closed', 'cut', 'timeout', 'superseded', 'no-answer', 'insufficient_quota', 'rate_limit_exceeded'];
  const said = codes.map(textTurnErrorText);
  assert.equal(new Set(said).size, codes.length, 'no two causes read the same');
  for (const s of said) assert.doesNotMatch(s, /[—–]/, 'house voice: no dashes');
  assert.equal(textTurnErrorText('something-new'), 'Hugo could not answer that just now. Try again.');
  assert.equal(textTurnErrorText('constructor'), 'Hugo could not answer that just now. Try again.', 'no prototype key reads as a cause');
});

test('the client sends typed turns over the live session where it is wired, and Talk honours the pick (wired)', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  // The phone's Hugo asks across all domains (VH-765), which the per-domain Realtime session cannot, so "all" goes typed.
  assert.match(src, /async function chatWithHugoTools\(review\) \{\n.*\n {2}const scope = phoneHugo \? phoneHugo\.scope : state\.domain;\n {2}if \(scope !== 'all' && hugoRealtimeReady\(\)\) \{ await chatWithHugoRealtime\(review\); return; \}/);
  assert.match(src, /voiceSocket\(m\.realtimeUrl\(location\.origin, state\.domain, el\.hugoVoice\?\.value\)\)/);
  assert.match(src, /importFresh\('\.\/views\/hugo-stream\.js'\)/, 'through the shell\'s one retrying loader');
  assert.match(src, /if \(event\) hugoText\?\.onEvent\(event\);/, 'a typed turn on Talk\'s session is heard');
  assert.match(src, /hugoText\?\.close\(\);/, 'sign-out closes the typed session');
  assert.doesNotMatch(src, /from '\.\/views\/hugo-stream\.js'/, 'loaded on first use, not with the board');
});

// A fake socket the session opens; `refuse` fails the open as a refused upgrade does.
function fakeWs({ refuse = false, shut = false, sendThrows = false } = {}) {
  const ws = { readyState: 0, sent: [], closed: false, url: '' };
  ws.send = (d) => {
    if (sendThrows) throw new Error('gone');
    ws.sent.push(JSON.parse(d));
  };
  ws.close = () => { ws.closed = true; ws.readyState = 3; ws.onclose?.(); };
  setImmediate(() => {
    if (refuse) { ws.onerror?.(); ws.readyState = 3; ws.onclose?.(); return; }
    if (shut) { ws.readyState = 3; ws.onclose?.(); return; } // closed before it opened, with no error event (VH-777)
    ws.readyState = 1;
    ws.onopen?.();
  });
  return ws;
}
function session(over = {}) {
  const made = [];
  const timers = [];
  let dom = 'air';
  const s = createTextSession({
    makeSocket: (url) => { const ws = fakeWs(over.ws); ws.url = url; made.push(ws); return ws; },
    domain: () => dom, voice: () => 'cedar', origin: 'https://vh.example',
    setTimer: (fn, ms) => { const t = { fn, ms }; timers.push(t); return t; }, clearTimer: (t) => { t.cleared = true; },
    ...over.opts,
  });
  return { s, made, timers, setDomain: (d) => { dom = d; } };
}
const until = () => new Promise((r) => { setImmediate(() => setImmediate(r)); });
const ev = (o) => JSON.stringify(o);

test('a typed turn streams as produced, survives a tool call, and ends on the answer', async () => {
  const { s, made } = session();
  const seen = [];
  const p = s.ask('How many Land vendors?', (t) => seen.push(t));
  await until();
  const ws = made[0];
  assert.equal(ws.url, 'wss://vh.example/api/v3/hugo/realtime?domain=air&voice=cedar');
  assert.deepEqual(ws.sent, [textTurnEvent('How many Land vendors?')]);
  ws.onmessage({ data: ev({ type: 'response.done', response: { id: 'r1', output: [{ type: 'function_call' }] } }) });
  ws.onmessage({ data: ev({ type: 'response.output_text.delta', response_id: 'r2', delta: 'There are ' }) });
  ws.onmessage({ data: 'not json' });
  ws.onmessage({ data: ev({ type: 'response.output_text.delta', response_id: 'r2', delta: '4.' }) });
  ws.onmessage({ data: ev({ type: 'response.done', response: { id: 'r2', output: [{ type: 'message' }] } }) });
  ws.onmessage({ data: ev({ type: 'vh.grounding', modality: 'text', state: 'verified', violations: [] }) });
  assert.deepEqual(await p, { text: 'There are 4.', state: 'verified' });
  assert.deepEqual(seen, ['There are ', 'There are 4.']);
  // The next turn reuses the open session; a domain change reopens it.
  const q = s.ask('and Cyber?');
  await until();
  assert.equal(made.length, 1);
  made[0].onmessage({ data: ev({ type: 'response.output_text.delta', delta: 'Two.' }) });
  made[0].onmessage({ data: ev({ type: 'response.done', response: { id: 'r3', output: [] } }) });
  made[0].onmessage({ data: ev({ type: 'vh.grounding', modality: 'text', state: 'verified', violations: [] }) });
  assert.equal((await q).text, 'Two.');
});

test('every way a typed turn fails resolves with its cause, never hangs and never throws', async () => {
  const refused = await session({ ws: { refuse: true } }).s.ask('x');
  assert.deepEqual(refused, { error: 'connect', said: textTurnErrorText('connect') }, 'a refused upgrade, in the operator\'s words');
  const shut = await session({ ws: { shut: true } }).s.ask('x');
  assert.deepEqual(shut, { error: 'connect', said: textTurnErrorText('connect') }, 'a socket closed before it opened is a failed connect, not a turn that never ends');
  const one = session();
  const p1 = one.s.ask('x');
  await until();
  one.made[0].onmessage({ data: ev({ type: 'error', error: { code: 'insufficient_quota' } }) });
  assert.equal((await p1).error, 'insufficient_quota', 'a provider error');
  const p2 = one.s.ask('y');
  await until();
  one.made[0].close();
  assert.equal((await p2).error, 'closed', 'the session ended mid-turn');
  const two = session();
  const p3 = two.s.ask('z');
  await until();
  two.timers.at(-1).fn();
  assert.equal((await p3).error, 'timeout', 'no answer in time');
  const p4 = two.s.ask('first');
  await until();
  const p5 = two.s.ask('second');
  assert.equal((await p4).error, 'superseded', 'a newer message ends the older turn');
  await until();
  two.made.at(-1).onmessage({ data: ev({ type: 'response.done', response: { id: 'r', output: [] } }) });
  assert.equal((await p5).error, 'no-answer', 'finished with no text');
  assert.equal((await session({ ws: { sendThrows: true } }).s.ask('q')).error, 'closed', 'the send failed');
});

test('a typed turn while Talk is on goes on Talk\'s session; a repaint that throws does not end the turn', async () => {
  const talk = { readyState: 1, sent: [], send(d) { this.sent.push(JSON.parse(d)); } };
  const { s, made } = session({ opts: { talkSocket: () => talk } });
  const p = s.ask('spoken context, typed question', () => { throw new Error('rail gone'); });
  await until();
  assert.equal(made.length, 0, 'no second session');
  assert.equal(talk.sent[0].type, 'conversation.item.create');
  s.onEvent({ type: 'response.output_text.delta', delta: 'Yes.' });
  s.onEvent({ type: 'response.done', response: { output: [] } });
  s.onEvent({ type: 'vh.grounding', modality: 'audio', state: 'verified' });
  s.onEvent({ type: 'vh.grounding', modality: 'text', state: 'verified', violations: [] });
  assert.equal((await p).text, 'Yes.', 'a spoken answer\'s verdict does not end the typed turn; its own does');
});

test('a domain change reopens the session, and close() ends it', async () => {
  const { s, made, setDomain } = session();
  const p = s.ask('a');
  await until();
  made[0].onmessage({ data: ev({ type: 'response.output_text.delta', delta: 'ok' }) });
  made[0].onmessage({ data: ev({ type: 'response.done', response: { output: [] } }) });
  made[0].onmessage({ data: ev({ type: 'vh.grounding', modality: 'text', state: 'verified', violations: [] }) });
  await p;
  setDomain('national_security');
  s.ask('b');
  await until();
  assert.equal(made.length, 2);
  assert.equal(made[0].closed, true, 'the Air session is closed, not left open');
  assert.match(made[1].url, /domain=national_security/);
  s.close();
  assert.equal(made[1].closed, true);
  s.close();
});

// ---- VH-318-E, the client half: the checking mark, and a failed check that really withdraws the text.

test('A FAILED CHECK WITHDRAWS THE TEXT: the streamed answer leaves the turn with no text, only the reasons', async () => {
  const { s: sess, made } = session();
  const streamed = [];
  const p = sess.ask('How many Natural Resources vendors?', (t) => streamed.push(t));
  await until();
  made[0].onmessage({ data: ev({ type: 'response.output_text.delta', delta: 'There are 99 of them.' }) });
  made[0].onmessage({ data: ev({ type: 'response.done', response: { id: 'r1', output: [{ type: 'message' }] } }) });
  made[0].onmessage({ data: ev({ type: 'vh.grounding', modality: 'text', state: 'withdrawn', violations: ['the figure 99 appears in no tool result'] }) });
  const out = await p;
  assert.deepEqual(streamed, ['There are 99 of them.'], 'it streamed as produced');
  assert.equal(out.withdrawn, true);
  assert.equal(out.state, 'withdrawn');
  assert.equal(Object.hasOwn(out, 'text'), false, 'no text survives the withdrawal');
  assert.doesNotMatch(JSON.stringify(out), /There are 99 of them/, 'not in the outcome at all');
  // And the one rail paints it as the shell does: the rail's own mark, the reasons as the body, no answer text.
  const html = turnHtml({ role: 'assistant', content: out.text || '', state: out.state }, { bodyHtml: out.reasonsHtml });
  assert.match(html, /Withdrawn: it could not be checked against the dataset/);
  assert.match(html, /<li>the figure 99 appears in no tool result<\/li>/);
  assert.doesNotMatch(html, /There are 99/);
});

test('the verdict is fail closed, its reasons escaped, and never blank', () => {
  assert.deepEqual(answerOutcome('Fine.', { state: 'verified' }), { text: 'Fine.', state: 'verified' });
  for (const bad of [{ state: 'something' }, null, { state: 'checking' }]) assert.equal(answerOutcome('Gone.', bad).withdrawn, true, JSON.stringify(bad));
  assert.match(reasonsHtml(['"<b>x</b>" was not returned by any tool']), /&lt;b&gt;x&lt;\/b&gt;/);
  assert.notEqual(reasonsHtml([]), '', 'a withdrawn body is never empty');
  assert.deepEqual(textStreamAction({ type: 'vh.grounding', modality: 'text', state: 'verified', violations: [1, 'a'] }), { check: { state: 'verified', violations: ['a'] } });
  assert.equal(textStreamAction({ type: 'vh.grounding', modality: 'audio', state: 'verified' }), null, 'Talk\'s verdicts are Talk\'s');
});

test('a spoken verdict lands on Hugo\'s latest spoken turn: verified, or flagged with the words kept', () => {
  const history = [
    { role: 'user', content: 'q', channel: 'spoken' },
    { role: 'assistant', content: 'There are 7.', channel: 'spoken' },
    { role: 'assistant', content: 'typed', state: 'verified' },
  ];
  assert.equal(applySpokenCheck(history, { type: 'vh.grounding', modality: 'audio', state: 'verified' }), true);
  assert.equal(history[1].state, 'verified');
  assert.equal(applySpokenCheck(history, { type: 'vh.grounding', modality: 'audio', state: 'flagged', violations: ['the figure 7 appears in no tool result'] }), true);
  assert.equal(history[1].state, 'withdrawn', 'the rail\'s withdrawn, which reads as flagged on a spoken turn');
  const html = turnHtml(history[1], { afterHtml: history[1].reasonsHtml });
  assert.match(html, /Flagged: Hugo said this aloud/);
  assert.match(html, /There are 7\./, 'audio already heard cannot be unsaid, so the words stay');
  assert.match(html, /the figure 7 appears in no tool result/);
  assert.equal(applySpokenCheck(history, { type: 'vh.grounding', modality: 'text', state: 'verified' }), false, 'a typed verdict is not Talk\'s');
  assert.equal(applySpokenCheck([], { type: 'vh.grounding', modality: 'audio', state: 'verified' }), false);
  assert.equal(applySpokenCheck(history, { type: 'response.done' }), false);
});

test('a flagged spoken reply is struck where it stands before the rail repaints; a verified one is repainted unstruck (VH-712)', async () => {
  const doc = { createElement: (tag) => ({ tag, className: '', textContent: '' }) };
  const said = { ownerDocument: doc, textContent: 'There are 7.', kids: null, replaceChildren(...n) { this.kids = n; } };
  const asked = [];
  const review = { querySelectorAll: (sel) => { asked.push(sel); return [said]; } };
  const history = [{ role: 'user', content: 'q', channel: 'spoken' }, { role: 'assistant', content: 'There are 7.', channel: 'spoken' }];
  let painted = 0;
  const repainted = new Promise((resolve) => {
    assert.equal(spokenCheck(history, { type: 'vh.grounding', modality: 'audio', state: 'verified' }, review, () => { painted += 1; resolve(); }), true);
  });
  await repainted;
  assert.equal(painted, 1);
  assert.equal(said.kids, null, 'a verified reply is never struck');
  const again = new Promise((resolve) => {
    assert.equal(spokenCheck(history, { type: 'vh.grounding', modality: 'audio', state: 'flagged' }, review, () => { painted += 1; resolve(said.kids); }), true);
  });
  assert.deepEqual(await again, [{ tag: 'span', className: 'hugo-strike', textContent: 'There are 7.' }], 'struck before the repaint');
  assert.deepEqual(asked, ['.hugo-turn-hugo[data-channel="spoken"] .hugo-turn-text']);
  assert.equal(spokenCheck(history, { type: 'response.done' }, review, () => { painted += 1; }), false);
  await Promise.resolve();
  assert.equal(painted, 2, 'a frame that is not a spoken verdict repaints nothing');
});

test('a typed turn on the rail: checking from its first word, written in place, then the verdict; a failure leaves no trace', async () => {
  const written = [];
  // The live text node the stream writes into; the strike (VH-712) wraps what it holds in one span, as text.
  const doc = { createElement: (tag) => ({ tag, className: '', textContent: '' }) };
  const live = { ownerDocument: doc, kids: null, said: '', get textContent() { return this.said; }, set textContent(t) { this.said = t; written.push(t); }, replaceChildren(...n) { this.kids = n; } };
  const review = { scrollTop: 0, scrollHeight: 9, querySelectorAll: () => [live] };
  const paints = [];
  const repaint = (h) => paints.push(h.map((t) => t.role + ':' + (t.state || '') + ':' + t.content));
  const fakeSession = (out, deltas = []) => ({
    ask: async (q, onText) => {
      for (const d of deltas) onText(d);
      return out;
    },
  });
  const history = [{ role: 'user', content: 'Which Cyber vendors?' }];
  assert.equal(await typedTurn(fakeSession({ text: 'Three.', state: 'verified' }, ['Thr', 'Three.']), history, { repaint, review }), '');
  assert.deepEqual(paints, [['user::Which Cyber vendors?', 'assistant:checking:'], ['user::Which Cyber vendors?', 'assistant:verified:Three.']]);
  assert.deepEqual(written, ['Thr', 'Three.']);
  assert.equal(review.scrollTop, 9);
  // Withdrawn: the turn stays, with no text and the reasons.
  history.push({ role: 'user', content: 'How many?' });
  assert.equal(live.kids, null, 'a verified answer is never struck');
  await typedTurn(fakeSession(answerOutcome('99.', { state: 'withdrawn', violations: ['x'] }), ['<b>99.</b>']), history, { repaint, review });
  assert.deepEqual(live.kids, [{ tag: 'span', className: 'hugo-strike', textContent: '<b>99.</b>' }], 'the refused words are struck where they stand, as text, before the verdict');
  assert.deepEqual(history.at(-1), { role: 'assistant', content: '', state: 'withdrawn', reasonsHtml: reasonsHtml(['x']) });
  // A failure removes the question and its answer, and only those, and returns the words to show.
  history.push({ role: 'user', content: 'And Land?' });
  const before = history.length;
  const said = await typedTurn(fakeSession({ error: 'timeout', said: textTurnErrorText('timeout') }), history, { repaint, review });
  assert.equal(said, textTurnErrorText('timeout'));
  assert.equal(history.length, before - 1);
  assert.equal(history.at(-1).state, 'withdrawn', 'the earlier turns stand');
  // VH-777: a socket that will not open hands the turn on. The question stays for the typed route, the empty answer
  // goes, and what the hand-over returns is what the rail shows.
  history.push({ role: 'user', content: 'And Air?' });
  const asked = history.at(-1);
  let handed = 0;
  const onNoSocket = async () => { handed += 1; return ''; };
  assert.equal(await typedTurn(fakeSession({ error: 'connect', said: textTurnErrorText('connect') }), history, { repaint, review, onNoSocket }), '');
  assert.equal(handed, 1);
  assert.equal(history.at(-1), asked, 'the question stays for the typed route');
  // Any other failure is still the error line, with the hand-over offered.
  const timedOut = await typedTurn(fakeSession({ error: 'timeout', said: textTurnErrorText('timeout') }), history, { repaint, review, onNoSocket });
  assert.equal(timedOut, textTurnErrorText('timeout'));
  assert.equal(handed, 1, 'a turn that reached the socket is not asked twice');
});

test('the rail paints a withdrawal as its reasons alone, and Talk hears its verdicts (wired)', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(src, /said = await m\.typedTurn\(hugoText, history, \{ repaint: renderHugoTranscript, review, onNoSocket \}\)/);
  assert.match(src, /const onNoSocket = async \(\) => \{ setHugoThinking\(false\); await chatWithHugoAgent\(review, state\.domain\); return ''; \};/);
  assert.match(src, /bodyHtml: turn\.state === 'withdrawn' \? reasons : ''/);
  assert.match(src, /if \(hugoStreamView\?\.spokenCheck\(hugoTurns\(\), event, el\.hugoReview, \(\) => renderHugoTranscript\(state\.hugoChatHistory\)\)\) return;/);
});

test('a proposal frame on the typed session reaches the rail, as on Talk\'s; a throwing rail does not end the session', async () => {
  const frames = [];
  const { s: sess, made } = session({ opts: { onFrame: (e) => { frames.push(e.type); if (e.type === 'boom') throw new Error('rail'); } } });
  const p = sess.ask('show me the UK ones on the map');
  await until();
  made[0].onmessage({ data: ev({ type: 'hugo.proposal', proposal: { tool: 'propose_view' } }) });
  made[0].onmessage({ data: ev({ type: 'boom' }) });
  made[0].onmessage({ data: 'not json' });
  made[0].onmessage({ data: ev({ type: 'response.output_text.delta', delta: 'Here.' }) });
  made[0].onmessage({ data: ev({ type: 'response.done', response: { output: [] } }) });
  made[0].onmessage({ data: ev({ type: 'vh.grounding', modality: 'text', state: 'verified' }) });
  assert.equal((await p).text, 'Here.');
  assert.deepEqual(frames, ['hugo.proposal', 'boom', 'response.output_text.delta', 'response.done', 'vh.grounding']);
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(src, /onFrame: \(e\) => \{ const p = hugoRail\?\.proposalFromFrame\(e\); if \(p\) showHugoProposal\(p\); \}/, 'wired');
});

// A REPLY CUT OFF BY THE UPSTREAM (V2.8 W40). The relay recovers an unasked end mid-reply with a fresh upstream and says
// so with `vh.session.resumed`; before it said nothing, the cut turn stayed live, and the probe on the shipped client read
// [["user","How many in Norway?"],["user","And Sweden?"],["assistant","Two areFour are listed.","verified"]].
// `talk` is the shell's dispatch for one Talk event (`onHugoVoiceEvent`, public/app-v3.js), pinned to it below.
function talk(history, event) {
  if (spokenCheck(history, event, null, () => {})) return;
  const action = realtimeVoiceAction(event);
  if (action?.heard) placeHeard(history, action.heard);
  else if (action?.transcript) appendSaid(history, action.transcript);
  else if (action?.done) settleSpoken(history);
}

test('a spoken reply cut off is settled unmarked, so the next question and reply take turns of their own, in order', () => {
  const history = [];
  talk(history, { type: 'conversation.item.input_audio_transcription.completed', transcript: 'How many in Norway?' });
  talk(history, { type: 'response.output_audio_transcript.delta', delta: 'Two are' });
  talk(history, { type: SESSION_RESUMED_TYPE, cut: ['r1'] });
  talk(history, { type: 'conversation.item.input_audio_transcription.completed', transcript: 'And Sweden?' });
  talk(history, { type: 'response.output_audio_transcript.delta', delta: 'Four are listed.' });
  talk(history, { type: 'response.output_audio_transcript.done' });
  talk(history, { type: 'vh.grounding', modality: 'audio', state: 'verified', violations: [] });
  assert.deepEqual(history.map((t) => [t.role, t.content, t.state ?? '']), [
    ['user', 'How many in Norway?', ''],
    ['assistant', 'Two are', ''],
    ['user', 'And Sweden?', ''],
    ['assistant', 'Four are listed.', 'verified'],
  ], 'the cut turn carries no mark; the verdict lands on the reply it was given for');
  // A cut with no reply on screen changes nothing.
  const quiet = [{ role: 'user', content: 'Hello', channel: 'spoken' }];
  talk(quiet, { type: SESSION_RESUMED_TYPE, cut: [] });
  assert.deepEqual(quiet, [{ role: 'user', content: 'Hello', channel: 'spoken' }]);
  // The frame names are the relay's, and the shell settles the turn on the codec's `done`.
  assert.equal(TALK_RESUMED, SESSION_RESUMED_TYPE);
  // And says so, with the next step, in the typed turn's style (VH-653, the owner's option B).
  const cutLine = 'Hugo\'s reply was cut off by the connection. Ask again to hear the rest.';
  assert.deepEqual(realtimeVoiceAction({ type: SESSION_RESUMED_TYPE }), { done: true, cut: cutLine });
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(src, /if \(hugoStreamView\?\.spokenCheck\(hugoTurns\(\), event, el\.hugoReview, \(\) => renderHugoTranscript\(state\.hugoChatHistory\)\)\) return;\n[^\n]*\n[^\n]*\n {2}const action = hugoCodec\.realtimeVoiceAction\(event\);\n {2}if \(action\?\.audio\) playAudioDelta\(action\.audio\);\n {2}else if \(action\?\.heard\) onHugoHeard\(action\.heard\);\n {2}else if \(action\?\.transcript\) onHugoSaid\(action\.transcript\);\n {2}else if \(action\?\.done\) settleHugoSpoken\(action\.cut\);/, 'the shell dispatches as `talk` does (wired)');
  assert.match(src, /function settleHugoSpoken\(cut\) \{\n {2}if \(!hugoRail\?\.settleSpoken\(state\.hugoChatHistory\)\) return;\n {2}renderHugoTranscript\(state\.hugoChatHistory\);\n {2}if \(cut\) el\.hugoReview\?\.insertAdjacentHTML\('beforeend', '<div class="hugo-turn hugo-turn-hugo"><span class="dim">' \+ esc\(cut\) \+ '<\/span><\/div>'\);\n\}/, 'a settled cut turn is followed by its line, in the typed turn\'s markup (wired)');
});

test('a typed turn whose reply is cut ends at once, in words that keep the session open, on its own session or on Talk\'s', async () => {
  assert.deepEqual(textStreamAction({ type: SESSION_RESUMED_TYPE, cut: ['r1'] }), { error: 'cut' });
  // VH-650: the relay keeps the session after a cut, so the words say so and never send the operator to reopen it.
  assert.equal(textTurnErrorText('cut'), 'Hugo\'s answer was cut off by the connection. Send the message again to hear the rest.');
  const { s, made, timers } = session();
  const p = s.ask('How many in Norway?');
  await until();
  made[0].onmessage({ data: ev({ type: 'response.output_text.delta', response_id: 'r1', delta: 'Two are' }) });
  made[0].onmessage({ data: ev({ type: SESSION_RESUMED_TYPE, cut: ['r1'] }) });
  assert.deepEqual(await p, { error: 'cut', said: textTurnErrorText('cut') });
  assert.equal(timers.at(-1).cleared, true, 'it did not wait out the 75 seconds');
  assert.equal(made[0].closed, false, 'the session stays open for the retry');
  // The retry goes on the same session and is answered on a turn of its own.
  const q = s.ask('How many in Norway?');
  await until();
  assert.equal(made.length, 1);
  made[0].onmessage({ data: ev({ type: 'response.output_text.delta', response_id: 'r2', delta: 'Four.' }) });
  made[0].onmessage({ data: ev({ type: 'vh.grounding', modality: 'text', state: 'verified', violations: [] }) });
  assert.equal((await q).text, 'Four.');
  // On Talk's session the shell hands the frame on (`hugoText?.onEvent`, pinned above), with the same outcome.
  const sock = { readyState: 1, send() {} };
  const t = session({ opts: { talkSocket: () => sock } });
  const r = t.s.ask('And Sweden?');
  await until();
  t.s.onEvent({ type: SESSION_RESUMED_TYPE, cut: [] });
  assert.equal((await r).error, 'cut');
});

// TALK'S CONTINUATION (owner ruling, 2026-10-07): the dialog's words follow the setting and the relay's times, and the
// controller answers one offer once, ends Talk on End now, and unhooks itself when the socket closes.
test('the continuation dialog says the setting\'s length and the relay\'s times, on the relay\'s own frame names', () => {
  assert.deepEqual([TALK_EXPIRING, TALK_EXTENDED, TALK_EXTEND], [SESSION_EXPIRING_TYPE, SESSION_EXTENDED_TYPE, SESSION_EXTEND_TYPE]);
  assert.deepEqual([120, 60, 90, 1, 0, 'x', 180].map(sessionLengthWords), ['2 hours', '1 hour', '90 minutes', '1 minute', '1 minute', '1 minute', '3 hours']);
  const ends = Date.UTC(2026, 9, 7, 15, 55);
  const copy = talkOfferCopy({ type: TALK_EXPIRING, ends_at: new Date(ends).toISOString(), extend_minutes: 120 });
  assert.match(clockTime(ends), /^\d\d:\d\d$/, 'a 24-hour clock time');
  assert.deepEqual(copy, {
    title: 'Continue Talk for another 2 hours?',
    lede: 'Talk ends at ' + clockTime(ends) + '. Continue keeps it going until ' + clockTime(ends + 120 * 60_000)
      + '. If you do not answer, Talk ends at ' + clockTime(ends) + '. Today\'s usage cap still applies.',
  });
  assert.deepEqual(talkOfferCopy({ ends_at: 'not a time', extend_minutes: 90 }), {
    title: 'Continue Talk for another 90 minutes?',
    lede: 'Talk is about to end. Continue keeps it going for another 90 minutes. Today\'s usage cap still applies.',
  }, 'a frame with no readable time still says something true');
  assert.equal(clockTime(Number.NaN), '');
});

const listen = (map, ev, cb) => {
  if (!map[ev]) { map[ev] = new Set(); }
  map[ev].add(cb);
};
function fakeTalk() {
  const handlers = {};
  const ws = {
    sent: [],
    send(d) { this.sent.push(JSON.parse(d)); },
    addEventListener(ev, cb) { listen(handlers, ev, cb); },
    removeEventListener(ev, cb) { handlers[ev]?.delete(cb); },
    emit(ev, data) { for (const cb of handlers[ev] || []) cb({ data }); },
  };
  const node = () => {
    const on = {};
    return { textContent: '', hidden: true, addEventListener(ev, cb) { listen(on, ev, cb); }, removeEventListener(ev, cb) { on[ev]?.delete(cb); }, click() { for (const cb of on.click || []) cb(); } };
  };
  const nodes = { 'hugo-talk-dialog': node(), 'hugo-talk-title': node(), 'hugo-talk-lede': node(), 'hugo-talk-continue': node(), 'hugo-talk-end': node(), 'sr-status': node(), 'hugo-rail-sub': node() };
  const doc = { getElementById: (id) => nodes[id] || null, querySelector: (sel) => (sel === '#hugo-rail .hugo-rail-sub' ? nodes['hugo-rail-sub'] : null) };
  const log = { opened: [], closed: 0, ended: 0 };
  const ui = {
    doc,
    openPanel: (panel, focus) => { panel.hidden = false; log.opened.push(focus); },
    closePanel: (panel) => { panel.hidden = true; log.closed += 1; },
    end: () => { log.ended += 1; },
  };
  return { ws, nodes, ui, log };
}
const offerFrame = (minutes = 120) => JSON.stringify({ type: 'vh.session.expiring', ends_at: '2026-10-07T15:55:00.000Z', extend_minutes: minutes });

test('Continue answers one offer once, however often it is pressed, and the extension is announced; End now ends Talk', () => {
  const t = fakeTalk();
  const raf = globalThis.requestAnimationFrame;
  globalThis.requestAnimationFrame = (fn) => fn();
  try {
    watchTalkSession(t.ws, t.ui);
    t.ws.emit('message', 'not json');
    t.ws.emit('message', JSON.stringify({ type: 'response.output_audio.delta', delta: 'AAAA' }));
    assert.equal(t.nodes['hugo-talk-dialog'].hidden, true, 'nothing but the offer opens it');
    t.ws.emit('message', offerFrame(90));
    assert.equal(t.nodes['hugo-talk-dialog'].hidden, false);
    assert.deepEqual(t.log.opened, ['#hugo-talk-title'], 'focus lands on the title, so a stray Space or Enter extends nothing (VH-651)');
    assert.equal(t.nodes['hugo-talk-title'].textContent, 'Continue Talk for another 90 minutes?');
    assert.match(t.nodes['hugo-talk-lede'].textContent, /^Talk ends at \d\d:\d\d\. Continue keeps it going until \d\d:\d\d\./);
    t.nodes['hugo-talk-continue'].click();
    t.nodes['hugo-talk-continue'].click();
    assert.deepEqual(t.ws.sent, [{ type: 'vh.session.extend' }], 'one extend, nothing else on it');
    assert.equal(t.nodes['hugo-talk-dialog'].hidden, true);
    t.ws.emit('message', JSON.stringify({ type: 'vh.session.extended', ends_at: '2026-10-07T17:25:00.000Z' }));
    assert.equal(t.nodes['sr-status'].textContent, 'Talk continues until ' + clockTime(Date.parse('2026-10-07T17:25:00.000Z')) + '.');
    // And seen, on the line under Hugo's name (VH-652, the owner's option B).
    assert.equal(t.nodes['hugo-rail-sub'].textContent, 'Listening. Talk continues until ' + clockTime(Date.parse('2026-10-07T17:25:00.000Z')) + '.');
    t.ws.emit('message', JSON.stringify({ type: 'vh.session.extended' }));
    assert.equal(t.nodes['sr-status'].textContent, 'Talk continues.');
    assert.equal(t.nodes['hugo-rail-sub'].textContent, 'Listening. Talk continues.');
    // The next offer, answered End now: Talk ends, nothing is sent.
    t.ws.emit('message', offerFrame());
    t.nodes['hugo-talk-end'].click();
    assert.equal(t.log.ended, 1);
    assert.equal(t.nodes['hugo-talk-dialog'].hidden, true);
    assert.equal(t.ws.sent.length, 1);
  } finally {
    globalThis.requestAnimationFrame = raf;
  }
});

test('an unanswered offer closes with the session, and a closed session leaves nothing listening', () => {
  const t = fakeTalk();
  watchTalkSession(t.ws, t.ui);
  t.ws.emit('message', offerFrame());
  t.ws.emit('close');
  assert.equal(t.nodes['hugo-talk-dialog'].hidden, true, 'the dialog goes with the session');
  assert.equal(t.log.closed, 1);
  t.ws.emit('message', offerFrame());
  t.nodes['hugo-talk-continue'].click();
  t.nodes['hugo-talk-end'].click();
  assert.equal(t.nodes['hugo-talk-dialog'].hidden, true, 'no offer after the close');
  assert.deepEqual([t.ws.sent.length, t.log.ended, t.log.closed], [0, 0, 1], 'and no button answers');
  // Dismissed with Escape (the shell closes the panel itself): the close does not close it twice.
  const e = fakeTalk();
  watchTalkSession(e.ws, e.ui);
  e.ws.emit('message', offerFrame());
  e.nodes['hugo-talk-dialog'].hidden = true;
  e.ws.emit('close');
  assert.equal(e.log.closed, 0);
  // A page without the dialog takes the offer quietly.
  const bare = fakeTalk();
  watchTalkSession(bare.ws, { ...bare.ui, doc: { getElementById: () => null } });
  bare.ws.emit('message', offerFrame());
  assert.deepEqual(bare.log.opened, []);
});

test('Talk hands its socket to the continuation, and the page ships the dialog it opens (wired)', () => {
  const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(app, /hugoVoice\.ws = ws;\n {2}m\.watchTalkSession\(ws, \{ openPanel, closePanel, end: stopHugoTalk \}\);\n/);
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  const dialog = /<dialog id="hugo-talk-dialog"([^>]*)>([\s\S]*?)<\/dialog>/.exec(html);
  assert.ok(dialog, 'the dialog is in the page');
  assert.match(dialog[2], /<h2 id="hugo-talk-title" tabindex="-1">/, 'the title takes focus when the offer opens (VH-651)');
  for (const attr of ['role="alertdialog"', 'aria-modal="true"', 'aria-labelledby="hugo-talk-title"', 'aria-describedby="hugo-talk-lede"', 'data-opener="hugo-talk-btn"', 'hidden']) {
    assert.ok(dialog[1].includes(attr), attr);
  }
  assert.match(dialog[2], /<button id="hugo-talk-end" type="button" class="btn btn-tonal btn-sm">End now<\/button>/);
  assert.match(dialog[2], /<button id="hugo-talk-continue" type="button" class="btn btn-accent btn-sm">Continue<\/button>/);
});

// 2.15.0 ENGINEERING ROUND ONE: a second message while the first turn's socket was still connecting closed that
// socket, the close read as a failed connect, and the hand-over posted the whole history, ending in the SECOND question:
// "hey hugo" was never answered, and a 400 then removed the good answer. A replaced socket supersedes its turn, and
// only the newest question is handed over.
test('a socket replaced while connecting supersedes its turn, and only the newest question is handed over', async () => {
  const made = [];
  const s = createTextSession({
    makeSocket: (url) => {
      const ws = { readyState: 0, url, sent: [], send() {}, close() { this.readyState = 3; this.onerror?.(); this.onclose?.(); } };
      made.push(ws);
      return ws;
    },
    domain: () => 'air', origin: 'https://vh.example', setTimer: () => ({}), clearTimer: () => {},
  });
  const first = s.ask('hey hugo');
  await until();
  const second = s.ask('thanks');
  await until();
  assert.equal((await first).error, 'superseded', 'the replaced turn is superseded, not a failed connect');
  made[1].close();
  assert.equal((await second).error, 'connect', 'the newest turn\'s own failure is still a failed connect');
  // The rail: a connect failure is handed over only while its question is the newest one asked.
  const repaint = () => {};
  const review = { scrollTop: 0, scrollHeight: 0, querySelectorAll: () => [] };
  const older = { role: 'user', content: 'hey hugo' };
  const history = [older];
  let handed = 0;
  const failing = { ask: async () => { history.push({ role: 'user', content: 'thanks' }); return { error: 'connect', said: textTurnErrorText('connect') }; } };
  const said = await typedTurn(failing, history, { repaint, review, onNoSocket: async () => { handed += 1; return ''; } });
  assert.equal(handed, 0, 'an older question is not handed over once a newer one is asked');
  assert.equal(said, textTurnErrorText('connect'));
  assert.equal(history.includes(older), false, 'and it leaves the rail as any failed turn does');
});
