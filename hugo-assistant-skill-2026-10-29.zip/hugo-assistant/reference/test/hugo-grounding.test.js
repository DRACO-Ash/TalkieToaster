// THE GROUNDING CHECK, NARROWED TO RECORD CLAIMS (VH-777 Lane T, owner, 2026-10-26: Hugo must "talk freely and
// naturally about what it knows (with regards the app - everything from database, to help files)"). Measured on 2.19.1:
// "The app covers 7 domains" was withdrawn, and so was a help answer about export formats, because every figure in an
// answer had to appear in a tool result. Now a RECORD claim is still checked, both ways: a record reference, a cited
// record id, a named organisation, a link, and a figure about records (one beside a word for records, or in a sentence
// citing one). A figure about the app or how to use it is answered freely.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { verifyAnswer, recordFiguresInText } from '../src/hugo/agent.js';
import { checkStreamedAnswer } from '../src/hugo/stream-check.js';
import { createLedger } from '../src/hugo/tools.js';

const answer = (text, extra = {}) => ({ answer: text, cited: [], entities: [], numbers: [], ...extra });

test('the app and its help are answered freely: a figure about the app is not a record claim', () => {
  const ledger = createLedger();
  for (const text of [
    'The app covers 7 domains and has 8 views.',
    'Excel exports a sheet per domain; text must clear 4.5:1 contrast, and a page shows up to 50 rows.',
    'Version 2.20.0 is running.',
  ]) {
    assert.deepEqual(verifyAnswer(answer(text), ledger), { ok: true, violations: [] }, text);
    assert.equal(checkStreamedAnswer(text, ledger).ok, true, 'streamed: ' + text);
  }
});

test('a record claim is still checked: a figure about records, a reference, a record id, a name and a link', () => {
  const ledger = createLedger();
  const cases = [
    ['There are 12 vendors in France.', /the figure 12/],
    ['I found 3 Space companies in Norway.', /the figure 3/],
    ['40% of the companies are In GDM.', /the figure 40/],
    ['Orbital Signals [R1] holds 6 data types.', /\[R1\]/],
    ['See https://example.com/vendor for more.', /example\.com/],
  ];
  for (const [text, why] of cases) {
    const v = verifyAnswer(answer(text), ledger);
    assert.equal(v.ok, false, text);
    assert.match(v.violations.join(' | '), why, text);
    assert.equal(checkStreamedAnswer(text, ledger).ok, false, 'streamed: ' + text);
  }
  assert.equal(verifyAnswer(answer('Done.', { cited: ['VH-0001'] }), ledger).ok, false, 'a cited id no tool returned');
  assert.equal(verifyAnswer(answer('Done.', { entities: ['Acme'] }), ledger).ok, false, 'a named organisation no tool returned');
  assert.equal(verifyAnswer(answer('Done.', { numbers: [9] }), ledger).ok, false, 'a figure the model declares is always checked');
  assert.equal(checkStreamedAnswer('Norss Ltd builds radars.', ledger).ok, false, 'a suffixed name in streamed prose');
});

test('the same claims pass once a tool returned them', () => {
  const ledger = createLedger();
  ledger.addNumbers({ total: 12, shown: 3 });
  assert.equal(verifyAnswer(answer('There are 12 vendors in France; here are 3 of the companies.'), ledger).ok, true);
});

test('which figures in a text are record figures', () => {
  assert.deepEqual(recordFiguresInText('The app covers 7 domains. There are 12 vendors, 9 in GDM, and 1,204 records.'), [12, 9, 1204]);
  assert.deepEqual(recordFiguresInText('Acme [R2] was founded in 1998 and lists 4 offices.'), [1998, 4], 'every figure in a sentence citing a record');
  assert.deepEqual(recordFiguresInText('Press Export, then choose 1 of 4 formats.'), []);
  assert.deepEqual(recordFiguresInText('VH-0012 is the record.'), [], 'a record id is not a figure');
});

// THE STEP CAP NEVER ENDS IN SILENCE: a turn that spends every step on tools is asked once more, with no tools, for its
// answer; and an empty answer is never marked verified.
test('at the step cap the loop asks for the answer, and an empty one is never verified', async () => {
  const { runHugoAgent } = await import('../src/hugo/agent.js');
  const { createToolRunner } = await import('../src/hugo/tools.js');
  const runQuery = async () => ({ rows: [], total: 5, applied: [], notApplied: [] });
  const call = { role: 'assistant', content: null, tool_calls: [{ id: 'c', type: 'function', function: { name: 'count_records', arguments: '{"domain":"space"}' } }] };
  const caps = { maxSteps: 3, maxToolCalls: 24, wallMs: 60_000, answerMaxChars: 4000 };
  const chatWith = (closing) => {
    const calls = [];
    return { calls, chatOnce: async (req) => { calls.push(req); return { message: req.tools.length ? call : { role: 'assistant', content: closing }, usage: {} }; } };
  };
  const answered = chatWith('{"answer":"There are 5 companies in Space.","numbers":[5]}');
  const out = await runHugoAgent({ chat: answered, runner: createToolRunner({ runQuery, defaultDomain: 'space' }), system: ['s'], messages: [{ role: 'user', content: 'how many' }], caps });
  assert.equal(answered.calls.length, 4, 'three steps of tools, then one closing call');
  assert.deepEqual(answered.calls.at(-1).tools, []);
  assert.match(answered.calls.at(-1).messages.at(-1).content, /You have used every step this turn allows/, 'the closing request, not a correction');
  assert.deepEqual([out.answer, out.verification.ok, out.verification.retried], ['There are 5 companies in Space.', true, false]);
  const silent = chatWith('');
  const empty = await runHugoAgent({ chat: silent, runner: createToolRunner({ runQuery, defaultDomain: 'space' }), system: ['s'], messages: [{ role: 'user', content: 'how many' }], caps });
  assert.equal(empty.verification.ok, false);
  assert.ok(empty.answer.length > 0, 'the operator is told, never shown nothing');
});
