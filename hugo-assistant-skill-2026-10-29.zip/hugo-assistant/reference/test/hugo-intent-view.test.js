// The Hugo confirm-first surface builders: pure, DOM-free, every reflected value escaped. Confirm-first means
// nothing here applies anything; it only renders what Hugo understood, for the operator to confirm.

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  hugoUnderstoodHtml, hugoUnmappedHtml, hugoNotAppliedHtml, hugoPartialHtml, hugoResultSummary, hugoSpokenSummary,
  hugoShowProposalHtml, wakeUtterance,
  isKnownView, viewTarget, VIEW_KEYS,
} from '../public/views/hugo-intent.js';

// THE PARTIAL-COVERAGE NOTICE (V1.81, parity gap `hugo.crossdomain.applied.space`). Once `applied` is the
// union across seven stores, a clause that ran in some and not others is in NEITHER list, so without this
// notice an operator gets no warning at all for the stores that ignored it.
const MIXED = {
  countries: { ran: ['space', 'air'], missed: ['maritime', 'cyber'] },
  productTypes: { ran: ['maritime'], missed: [] },
  families: { ran: [], missed: ['space'] },
};

test('hugoPartialHtml names the clause and the stores that did not run it', () => {
  const html = hugoPartialHtml(MIXED);
  assert.match(html, /intent-partial/);
  assert.match(html, /Countries/, 'the clause reads in words, not its field key');
  assert.match(html, /maritime/);
  assert.match(html, /cyber/);
  // NOT the stores that DID run it: this notice is the exception list, and naming both would read as a
  // warning about stores that filtered correctly.
  assert.doesNotMatch(html, /space/);
});

test('hugoPartialHtml reports the MIXED clauses only', () => {
  const html = hugoPartialHtml(MIXED);
  // A clause every store ran needs no notice; one no store ran is already reported by hugoNotAppliedHtml,
  // and repeating it here would be two notices for one fact.
  assert.doesNotMatch(html, /Product types/, 'a clause with no missed store is not a partial result');
  assert.doesNotMatch(html, /Capability families/, 'a clause no store ran belongs to the notApplied notice');
});

test('hugoPartialHtml is empty when there is nothing partial to report, and on a missing map', () => {
  // The single-domain path sends no coverage at all, and a notice raised over an answer with no exceptions
  // would be a warning about nothing.
  assert.equal(hugoPartialHtml(null), '');
  assert.equal(hugoPartialHtml(undefined), '');
  assert.equal(hugoPartialHtml({}), '');
  assert.equal(hugoPartialHtml({ countries: { ran: ['space'], missed: [] } }), '');
  assert.equal(hugoPartialHtml({ families: { ran: [], missed: ['space'] } }), '');
});

test('hugoPartialHtml uses the labeller, and escapes whatever it returns', () => {
  const html = hugoPartialHtml({ countries: { ran: ['space'], missed: ['air'] } }, (id) => (id === 'air' ? 'Air Domain' : id));
  assert.match(html, /Air Domain/, 'the store reads as the app names it');
  // A labeller is app code, but the domain id on the wire is not, and a notice is reflected markup.
  const hostile = hugoPartialHtml({ countries: { ran: ['space'], missed: ['<img src=x onerror=alert(1)>'] } });
  assert.doesNotMatch(hostile, /<img/);
  assert.match(hostile, /&lt;img/);
});

test('hugoSpokenSummary voices the populated clauses and the view as plain text (H-5)', () => {
  const said = hugoSpokenSummary({ filterSpec: { countries: ['France'], gdm: ['Not in GDM'] }, view: 'map' });
  assert.match(said, /^Hugo understood: /);
  assert.match(said, /Countries France/);
  assert.match(said, /GDM Not in GDM/);
  assert.match(said, /on the Map/);
  assert.match(said, /Check it, then apply\.$/);
  // Plain text for TTS: no markup.
  assert.doesNotMatch(said, /[<>]/);
});

test('hugoSpokenSummary prompts a rephrase when nothing mapped, never a misleadingly empty confirmation (H-5)', () => {
  assert.match(hugoSpokenSummary({ filterSpec: {} }), /could not map that/i);
  assert.match(hugoSpokenSummary(null), /could not map that/i);
});

test('hugoUnderstoodHtml renders each populated clause and the view', () => {
  const html = hugoUnderstoodHtml({
    filterSpec: { countries: ['United Kingdom'], gdm: ['Not in GDM'], families: ['SAR'] }, view: 'map', confidence: 'high',
  });
  assert.match(html, /Hugo understood/);
  assert.match(html, /Countries/);
  assert.match(html, /United Kingdom/);
  assert.match(html, /Not in GDM/);
  assert.match(html, /Capability families/);
  assert.match(html, /SAR/);
  assert.match(html, /On <b>the Map<\/b>/);
  assert.match(html, /Confidence: <b>high<\/b>/);
});

test('hugoUnderstoodHtml returns empty when there is nothing to show', () => {
  assert.equal(hugoUnderstoodHtml({ filterSpec: {}, view: '' }), '');
  assert.equal(hugoUnderstoodHtml(null), '');
});

test('hugoUnderstoodHtml escapes an untrusted value', () => {
  const html = hugoUnderstoodHtml({ filterSpec: { countries: ['<script>x</script>'] } });
  assert.doesNotMatch(html, /<script>x<\/script>/);
  assert.match(html, /&lt;script&gt;/);
});

test('hugoUnmappedHtml lists dropped phrases, empty when none', () => {
  assert.equal(hugoUnmappedHtml([]), '');
  const html = hugoUnmappedHtml([{ field: 'countries', value: 'Atlantis' }]);
  assert.match(html, /Not mapped to a known value/);
  assert.match(html, /Atlantis/);
  assert.match(html, /countries/);
});

test('hugoNotAppliedHtml names the deferred clauses in words, empty when none', () => {
  assert.equal(hugoNotAppliedHtml([]), '');
  // A domain facet stands in for the size band this used, retired in VH-824.
  const html = hugoNotAppliedHtml(['families', 'target_stratum']);
  assert.match(html, /Not yet filterable/);
  assert.match(html, /Capability families/);
  assert.match(html, /Target stratum/);
});

test('hugoResultSummary counts honestly and never fabricates', () => {
  assert.match(hugoResultSummary({ total: 0 }), /No companies match/);
  assert.match(hugoResultSummary({ total: 1 }), /<b>1<\/b> company match/);
  assert.match(hugoResultSummary({ total: 42 }), /<b>42<\/b> companies match/);
});

test('hugoResultSummary notes cross-domain unseeded coverage', () => {
  const html = hugoResultSummary({ total: 3, crossDomain: true, domainsUnseeded: ['air', 'maritime'] });
  assert.match(html, /<b>3<\/b> companies match/);
  assert.match(html, /2 other domains are not seeded/);
});

// --- The consent popup body (owner decision, V1.79) -------------------------------------------------------
//
// "a popup simply says - allow Hugo to show you". The body has one job: say what the operator is consenting
// to before the app moves under them. Three things, therefore, and each has a case: where they will land,
// what the filter is, and how many records are behind it. An empty '' return is the caller's signal NOT to
// raise the popup at all, which is why the refusal cases matter as much as the rendering one.

const viewProposal = (over = {}) => ({
  tool: 'propose_view',
  view: 'map',
  crossDomain: false,
  hasFilter: true,
  total: 12,
  reason: 'The UK SAR vendors outside the GDM',
  intent: { domain: 'space', view: 'map', filterSpec: { countries: ['United Kingdom'], gdm: ['Not in GDM'] } },
  ...over,
});

test('hugoShowProposalHtml states the destination, the filter and the count', () => {
  const html = hugoShowProposalHtml(viewProposal());
  assert.match(html, /take you to <b>the Map<\/b>/);
  assert.match(html, /The UK SAR vendors outside the GDM/);
  assert.match(html, /United Kingdom/);
  assert.match(html, /Not in GDM/);
  // PLURALISED FROM THE COUNT, both verdicts, because this string is in the consent popup and "1
  // record(s)" is the first thing an operator sees Hugo say.
  assert.match(html, /<b>12<\/b> records behind it/);
  assert.match(hugoShowProposalHtml(viewProposal({ total: 1 })), /<b>1<\/b> record behind it/);
  assert.doesNotMatch(html, /record\(s\)/);
});

test('a count of zero WARNS rather than hiding it, because an empty view reads as a bug', () => {
  const html = hugoShowProposalHtml(viewProposal({ total: 0 }));
  assert.match(html, /No records match this/);
  assert.match(html, /the view will be empty/);
  // And a count the server could not take says nothing about the figure, rather than reading as zero.
  const unknown = hugoShowProposalHtml(viewProposal({ total: null }));
  assert.doesNotMatch(unknown, /No records match this/);
  assert.doesNotMatch(unknown, /record\(s\) behind it/);
});

test('an unfiltered offer says so, so "show me" is never mistaken for a narrowed view', () => {
  const html = hugoShowProposalHtml(viewProposal({ hasFilter: false, intent: { domain: 'space', view: 'board', filterSpec: {} }, view: 'board' }));
  assert.match(html, /the Master board/);
  assert.match(html, /No filter: this shows the whole set/);
});

test('the cross-domain scope is stated, not left to be discovered', () => {
  assert.match(hugoShowProposalHtml(viewProposal({ crossDomain: true })), /across every domain/);
});

test('THE REFUSALS: anything this body cannot state honestly returns empty, and the popup is not raised', () => {
  for (const [label, proposal] of [
    ['nothing', null],
    ['a non-object', 'map'],
    ['another tool\'s proposal', { tool: 'propose_scan', requiresConfirmation: true, design: {} }],
    ['no intent', { tool: 'propose_view', view: 'map' }],
    ['a view with no label', viewProposal({ view: 'nowhere' })],
  ]) {
    assert.equal(hugoShowProposalHtml(proposal), '', `${label} must not raise a consent popup`);
  }
});

test('a hostile reason or filter value cannot reach the markup unescaped', () => {
  // The proposal is server-validated, so a filter value is already a controlled one; the REASON is free text
  // the model wrote, and this popup is a second reflection point for it.
  const html = hugoShowProposalHtml(viewProposal({ reason: '<img src=x onerror=alert(1)>' }));
  assert.doesNotMatch(html, /<img src=x/);
  assert.match(html, /&lt;img src=x/);
});

// --- The wake phrase (owner decision, V1.79) --------------------------------------------------------------
//
// "Hugo doesnt work on wake word". Three causes were measured; this pins the third, which is the one with a
// pure function behind it: the old handler recognised the phrase and then threw the REST of the utterance
// away, so "Hey Hugo, which UK vendors are not in the GDM" opened a blank box and the operator had to type
// the question they had just asked.

test('the wake phrase is recognised in the forms people actually say it', () => {
  for (const said of ['hey hugo', 'Hey Hugo', 'hi Hugo', 'hello Hugo', 'ok hugo', 'okay, Hugo',
    'Hey, Hugo.', 'and then hey hugo']) {
    assert.equal(wakeUtterance(said).woke, true, `${JSON.stringify(said)} must wake him`);
  }
  // AND THE OTHER VERDICT, so this cannot only say yes: a near miss does not wake him.
  for (const said of ['hugo', 'hey there', 'hey hugos', 'heyhugo', '', null, 42]) {
    assert.equal(wakeUtterance(said).woke, false, `${JSON.stringify(said)} must not wake him`);
  }
});

test('THE QUESTION SURVIVES THE WAKE, in its original casing', () => {
  const heard = wakeUtterance('Hey Hugo, which UK vendors are not in the GDM?');
  assert.equal(heard.woke, true);
  assert.equal(heard.question, 'which UK vendors are not in the GDM?');
  assert.equal(heard.send, true, 'three words or more is clearly a question, so it is sent');
});

test('a short remainder or a false wake FILLS the box and waits rather than acting', () => {
  // "acting on a misheard fragment is worse than asking", so the send flag is the whole point of this case.
  const one = wakeUtterance('hey hugo map');
  assert.equal(one.woke, true);
  assert.equal(one.question, 'map');
  assert.equal(one.send, false, 'one word is not clearly a question');
  const none = wakeUtterance('hey Hugo');
  assert.equal(none.question, '');
  assert.equal(none.send, false);
  // Two words is still below the bar; three is the line, and both sides of it are pinned.
  assert.equal(wakeUtterance('hey hugo french vendors').send, false);
  assert.equal(wakeUtterance('hey hugo the french vendors').send, true);
});

test('the punctuation a recogniser inserts is stripped from the question', () => {
  assert.equal(wakeUtterance('Hey Hugo: show me the French vendors').question, 'show me the French vendors');
  assert.equal(wakeUtterance('hey hugo - show me the French vendors').question, 'show me the French vendors');
  assert.equal(wakeUtterance('hey hugo,,, show me the French vendors').question, 'show me the French vendors');
});

// THE REVIEW PROMISES A DESTINATION AND THE APPLY PATH CHOOSES ONE, and they were two objects that disagreed
// in both directions. A security gate measured the consequence: `pipeline` had a label here and no entry in
// `hugoTargetView`, so the confirm-first dialog printed "On the Onboarding pipeline" and Apply landed on the
// board - the one thing a confirm step exists to prevent. In the other direction `dashboard` and `master`
// had destinations and no label, so a Dashboard proposal in the approved Hugo popup printed no destination
// line at all.
//
// One table now. This asserts the property rather than the contents, so it keeps holding as views are added.
test('every view that can be NAMED can be REACHED, and the reverse', () => {
  assert.ok(VIEW_KEYS.length >= 4, 'measured: five keys at this commit');
  for (const key of VIEW_KEYS) {
    assert.ok(isKnownView(key), key + ' is in the table');
    assert.notEqual(hugoUnderstoodHtml({ filterSpec: {}, view: key }), '', key + ' prints a destination line');
    assert.ok(viewTarget(key), key + ' resolves to a view the app can land on');
  }
});

// ONBOARDING IS ABSENT BY DECISION, not by omission: it does not honour a Hugo filter and shows no banner, so
// landing there would apply a narrowing nothing displays. The review must therefore not offer it.
test('a view the app cannot filter is neither named nor reachable', () => {
  assert.equal(isKnownView('pipeline'), false);
  assert.equal(hugoUnderstoodHtml({ filterSpec: {}, view: 'pipeline' }), '', 'no promise is printed');
  assert.equal(viewTarget('pipeline'), 'master', 'and it falls back rather than navigating nowhere');
});

// A MODEL CHOOSES `view`, so a prototype key is a shape it can send. A bare object index answers
// `constructor` with the Object function, which is truthy, so the `|| 'master'` fallback would never fire.
test('a prototype key is not a view', () => {
  for (const key of ['constructor', '__proto__', 'toString', 'valueOf', 'hasOwnProperty', 'prototype']) {
    assert.equal(isKnownView(key), false, key);
    assert.equal(viewTarget(key), 'master', key + ' falls back to the board');
    assert.doesNotMatch(hugoUnderstoodHtml({ filterSpec: { countries: ['France'] }, view: key }), /On <b>/,
      key + ' prints no destination line');
  }
});
