// KEYBOARD FOCUS IS NOT HIDDEN UNDER HUGO'S BOTTOM SHEET (VH-207, WCAG 2.2 AA 2.4.11, owner decision 1: option A,
// scroll clear). The document is the scrolling element, so the page's `scroll-padding-bottom` on the one `:root`
// is what makes the browser scroll a focused control above whatever covers the foot of the screen. The rule it
// supersedes sat on `.main`, which never scrolls, and did nothing.
//
// Measured in a browser (`e2e/probe.mjs`) at 700 x 844 with Hugo open, eight Shift+Tab steps from Minimise on
// Space and on Air: 0 of 8 focused controls under the sheet with this rule, 8 of 8 without the open-sheet line.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const CSS = readFileSync(new URL('../public/styles.css', import.meta.url), 'utf8').replaceAll(/\/\*[\s\S]*?\*\//g, '');

test('VH-207: the root scrolls focus clear of the bar and the open sheet at 900px and under', () => {
  const root = CSS.slice(CSS.indexOf(':root {'), CSS.indexOf('}', CSS.indexOf(':root {')));
  assert.match(root, /scroll-padding-top: calc\(var\(--chrome-h\) \+ var\(--space-2\)\);\s+--sheet-cover: 0px;\s+scroll-padding-bottom: var\(--sheet-cover\);/,
    'beside the scroll-padding-top the locked banner already uses, and nothing covered on a wide screen');
  const start = CSS.indexOf('@media (max-width: 900px) {');
  const block = CSS.slice(start, CSS.indexOf('\n}\n', start));
  assert.ok(start > 0, 'the 900px block was found');
  // VH-671: the collapsed bar measured 73px at 390, 700 and 900 wide (72 of spine and a 1px top border), so a cover of
  // 72 left a focused control's bottom pixel under it; the border is in the cover now.
  assert.match(block, /:root \{ --sheet-cover: calc\(4rem \+ var\(--space-2\) \+ 1px\); \}/, 'the collapsed bar, border included');
  assert.match(block, /:root:has\(#app\.hugo-open\) \{ --sheet-cover: calc\(70vh \+ var\(--space-2\)\); \}/, 'the open sheet, at its own max-height');
  // One rule since V2.8 merged the two duplicate `.hugo-rail` rules at this width (height and max-height together).
  assert.match(block, /#app\.hugo-open \.hugo-rail \{ max-height: 70vh;[^}]*\}/, 'which is still 70vh');
  assert.doesNotMatch(CSS, /\.main \{[^}]*scroll-padding-bottom/, 'the dead rule on a box that never scrolls is gone');
});
