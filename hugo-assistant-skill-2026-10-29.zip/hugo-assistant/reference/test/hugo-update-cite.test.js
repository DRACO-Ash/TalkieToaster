// HUGO'S SOURCED UPDATE KEEPS ITS SOURCE (VH-605; the first of the provenance gaps VH-504 measured).
//
// Hugo's composer will not preview a change without a source, and until VH-605 the apply then dropped it: the
// ordinary update wrote the change and `field_provenance` recorded nothing, because only a source cited IN the
// edit vouches for it. The citation now rides BESIDE the patch, so it vouches for what moved and never overwrites
// the record's own source. These drive the real route over real Postgres, the client call and the app's wiring.

import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { readFileSync } from 'node:fs';
import path from 'node:path';

import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';
import { createVendorRepo } from '../src/db/vendor-repo.js';
import { createProvenanceRepo } from '../src/db/provenance-repo.js';
import { createDomainRepo } from '../src/db/domain-repo.js';
import { getDescriptor, domainIds } from '../src/domain/descriptor.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';
import { updateVendor, domainUpdateProvider } from '../public/api-v3.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';
const agent = { authorization: 'Bearer agent-tok', origin: ORIGIN };
const CITED = 'https://registry.example/meridian/grade';
const DOMAINS = domainIds().filter((id) => id !== 'space');

function request(server, url, { method = 'GET', body } = {}) {
  const { port } = server.address();
  const payload = body === undefined ? null : JSON.stringify(body);
  const headers = payload ? { 'content-type': 'application/json', ...agent } : agent;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: url, method, headers }, (res) => {
      let text = '';
      res.on('data', (chunk) => (text += chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: text }));
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function served() {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const vendorRepo = createVendorRepo(executor, { provenance: createProvenanceRepo(executor) });
  const verify = createStaticVerifier({ 'agent-tok': { subject: 'ada', roles: ['agent'] } });
  const repos = new Map(DOMAINS.map((id) => [id, createDomainRepo(executor, getDescriptor(id))]));
  const app = createApp({ env: {}, vendorRepo, domainRepoFor: (id) => repos.get(id) ?? null, verify, allowedOrigin: ORIGIN });
  const server = await new Promise((resolve) => { const s = http.createServer(app); s.listen(0, '127.0.0.1', () => resolve(s)); });
  await vendorRepo.createVendor({ vendor_id: 'VH-6050', company: 'Meridian Optics', country: 'Spain', grade: 'Unknown', gdm: 'Not in GDM', source: 'https://meridian.example/about' }, 'ada');
  return { executor, server, repos };
}

const rows = (executor, field) => executor.query(
  "select value, method, source_key, asserted_by from field_provenance where member_id = 'VH-6050' and field = $1 and superseded_at is null",
  [field],
).then((r) => r.rows);

test('a sourced update writes a human row from its citation, and the record keeps its own source', async () => {
  const { executor, server } = await served();
  try {
    const res = await request(server, '/api/v3/vendors/VH-6050', { method: 'PATCH', body: { rev: 1, patch: { hq: 'Madrid' }, cite: CITED } });
    assert.equal(res.status, 200);
    assert.equal(JSON.parse(res.body).record.source, 'https://meridian.example/about', 'the citation did not overwrite the record\'s source');
    assert.deepEqual(await rows(executor, 'hq'), [{ value: 'Madrid', method: 'human', source_key: CITED, asserted_by: 'ada' }]);
    // A grade is the operator's assessment, not a claim a page makes, so no citation vouches for it.
    await request(server, '/api/v3/vendors/VH-6050', { method: 'PATCH', body: { rev: 2, patch: { grade: 'Ready for JCO' }, cite: CITED } });
    assert.deepEqual(await rows(executor, 'grade'), []);
  } finally { server.close(); await executor.close(); }
});

test('an update with no citation writes a sourceless row, and a citation that is not a bounded string is refused', async () => {
  const { executor, server } = await served();
  try {
    assert.equal((await request(server, '/api/v3/vendors/VH-6050', { method: 'PATCH', body: { rev: 1, patch: { hq: 'Madrid' } } })).status, 200);
    // The record's older source is not credited with a value it never gave; the row says only who set it (VH-605).
    assert.deepEqual(await rows(executor, 'hq'), [{ value: 'Madrid', method: 'human', source_key: null, asserted_by: 'ada' }]);
    for (const cite of [42, ['x'], 'h'.repeat(2049)]) {
      const refused = await request(server, '/api/v3/vendors/VH-6050', { method: 'PATCH', body: { rev: 2, patch: { hq: 'Seville' }, cite } });
      assert.equal(refused.status, 400, JSON.stringify(cite).slice(0, 20));
    }
    const at = await request(server, '/api/v3/vendors/VH-6050', { method: 'PATCH', body: { rev: 2, patch: { hq: 'Seville' }, cite: 'h'.repeat(2048) } });
    assert.equal(at.status, 200, 'the bound is inclusive');
  } finally { server.close(); await executor.close(); }
});

const domainRows = (executor, domain) => executor.query(
  'select field, value, method, source_key, asserted_by from field_provenance where domain = $1 and superseded_at is null order by field',
  [domain],
).then((r) => r.rows);

test('the preview holds its source to the bound Apply holds the citation to, so a previewed change is never refused at Apply', async () => {
  const { executor, server } = await served();
  try {
    const ask = (source) => request(server, '/api/v3/hugo/suggest-update', { method: 'POST', body: { domain: 'space', id: 'VH-6050', patch: { hq: 'Seville' }, source } });
    assert.equal((await ask('h'.repeat(2049))).status, 400, 'one over the bound');
    assert.equal((await ask('h'.repeat(2048))).status, 200, 'the bound is inclusive');
  } finally { server.close(); await executor.close(); }
});

test('every product-line domain: a sourced update writes a human row for each claim field it moved, the domain\'s own facets among them', async () => {
  const { executor, server, repos } = await served();
  try {
    for (const id of DOMAINS) {
      const d = getDescriptor(id);
      const missions = [...d.vocab.missions];
      const stored = await repos.get(id).upsert({ identity: { legal_name: 'Cited ' + id, hq_country: 'Sweden' }, fields: { missions: [missions[0]] } }, 'seed');
      const url = '/api/v3/domains/' + id + '/providers/' + encodeURIComponent(stored.provider_key);
      // The mission is resent unchanged and the facet is new: only what moved is vouched for (VH-824 retired the size band this used).
      const facet = d.capabilityFacets.find((f) => d.vocab[f.key]?.size);
      const fields = { missions: [missions[0]], ...(facet ? { [facet.key]: [[...d.vocab[facet.key]][0]] } : {}) };
      const res = await request(server, url, { method: 'PATCH', body: { rev: 1, patch: { fields }, cite: CITED } });
      assert.equal(res.status, 200, id + ': ' + res.body);
      const written = await domainRows(executor, id);
      const expected = [...(facet ? [facet.key] : [])].sort();
      assert.deepEqual(written.map((r) => r.field), expected, id);
      for (const r of written) assert.deepEqual([r.method, r.source_key, r.asserted_by], ['human', CITED, 'ada'], id);
      // No citation, no row; and a citation that is not a bounded string is refused on this store too.
      // No citation: the mission that moved gets a sourceless row saying who set it (VH-605), and nothing cited moves.
      const quiet = await request(server, url, { method: 'PATCH', body: { rev: 2, patch: { fields: { missions: [missions[0], missions[1]] } } } });
      assert.equal(quiet.status, 200, id);
      const after = await domainRows(executor, id);
      assert.equal(after.filter((r) => r.source_key === CITED).length, expected.length, id + ': the cited rows stand');
      assert.deepEqual(after.filter((r) => r.source_key === null).map((r) => [r.field, r.method, r.asserted_by]), [['missions', 'human', 'ada']], id);
      assert.equal((await request(server, url, { method: 'PATCH', body: { rev: 3, patch: { fields: {} }, cite: 7 } })).status, 400, id);
    }
  } finally { server.close(); await executor.close(); }
});

test('the client sends the citation beside the patch only when there is one', async () => {
  const sent = [];
  const real = globalThis.fetch;
  globalThis.fetch = async (url, opts) => { sent.push(JSON.parse(opts.body)); return { status: 200, ok: true, json: async () => ({}) }; };
  try {
    await updateVendor('tok', 'VH-1', 3, { grade: 'x' }, CITED);
    await updateVendor('tok', 'VH-1', 3, { grade: 'x' });
    await domainUpdateProvider('tok', 'maritime', 'k', 3, { fields: {} }, CITED);
    await domainUpdateProvider('tok', 'maritime', 'k', 3, { fields: {} });
  } finally { globalThis.fetch = real; }
  assert.deepEqual(sent, [{ rev: 3, patch: { grade: 'x' }, cite: CITED }, { rev: 3, patch: { grade: 'x' } },
    { rev: 3, patch: { fields: {} }, cite: CITED }, { rev: 3, patch: { fields: {} } }]);
});

test('Hugo\'s apply passes the source the operator confirmed on the preview', () => {
  const app = readFileSync(path.resolve(import.meta.dirname, '..', 'public', 'app-v3.js'), 'utf8');
  const at = app.indexOf('async function applyHugoUpdate(');
  assert.ok(at >= 0, 'applyHugoUpdate not found: this guard would measure nothing');
  const body = app.slice(at, app.indexOf('\n}\n', at));
  assert.match(body, /api\.updateVendor\(state\.token, ctx\.id, ctx\.rev, patch, preview\.source\)/);
  assert.match(body, /api\.domainUpdateProvider\(state\.token, ctx\.domain, ctx\.id, ctx\.rev, patch, preview\.source\)/);
});
