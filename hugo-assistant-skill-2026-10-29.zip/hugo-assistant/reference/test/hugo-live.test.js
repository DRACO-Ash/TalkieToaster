// VH-777 Lane V: Hugo's voice on GPT-Live. The session is created from the browser's offer on THIS server, and the
// server holds an outbound sideband that runs every tool exactly once, meters the spend and ends the session. Every
// shape asserted here is the one read from OpenAI's published specification and SDK (docs/VH-777-LIVE-FACTS.md); what
// the live service does with them is the connection check's to prove at deploy, with the key.
import test from 'node:test';
import assert from 'node:assert/strict';
import { Readable } from 'node:stream';

import {
  validSdpOffer, buildLiveSessionRequest, createLiveClient, liveVoice, liveModels, SDP_OFFER_MAX_BYTES,
  FRONTEND_CLIENT_EVENTS, DEFAULT_LIVE_MODEL, DEFAULT_LIVE_BRAIN,
} from '../src/hugo/live-session.js';
import { attachSideband, sidebandUrl, functionCallOf, brainUsageOf, PROBE_TEXT, SIDEBAND_OPEN_TIMEOUT_MS, SIDEBAND_CLOSE_GRACE_MS } from '../src/hugo/live-sideband.js';
import { tryHugoLive, createLiveService, liveDomain, liveKeyOf, liveFailure, LIVE_ROUTE, LIVE_END_ROUTE, LIVE_CHECK_ROUTE } from '../src/hugo/live-route.js';
import { modelPriced, ratesFor } from '../src/scan/cost.js';
import { hugoInstructions } from '../src/hugo/persona.js';

const OFFER = ['v=0', 'o=- 1 2 IN IP4 127.0.0.1', 's=-', 't=0 0', 'm=audio 9 UDP/TLS/RTP/SAVPF 111', 'a=mid:0', 'm=application 9 UDP/DTLS/SCTP webrtc-datachannel', 'a=mid:1'].join('\r\n') + '\r\n';
const ANSWER = 'v=0\r\no=- 3 4 IN IP4 0.0.0.0\r\n';
// Built at run time, so no key-shaped literal sits in source (the pre-write secret scan refuses one, rightly).
const FAKE_KEY = ['sk', 'proj', 'FAKEFAKE00000000'].join('-');

// ---- the offer and the session body ----------------------------------------------------------------------

test('an offer is forwarded only when it is SDP with an audio and a data section, within the cap', () => {
  assert.equal(validSdpOffer(OFFER), OFFER);
  assert.equal(validSdpOffer(OFFER.replaceAll('\r\n', '\n')), OFFER, 'LF line ends are normalised to CRLF');
  assert.equal(validSdpOffer(''), '');
  assert.equal(validSdpOffer(42), '');
  assert.equal(validSdpOffer('hello'), '', 'not SDP');
  assert.equal(validSdpOffer(OFFER.replace('m=application 9 UDP/DTLS/SCTP webrtc-datachannel\r\n', '')), '', 'no data channel: no captions, no lock');
  assert.equal(validSdpOffer(OFFER.replace('m=audio 9 UDP/TLS/RTP/SAVPF 111\r\n', '')), '', 'no audio');
  assert.equal(validSdpOffer(OFFER + 'a=x\u0000y\r\n'), '', 'a control character');
  assert.equal(validSdpOffer(OFFER + 'Z=upper\r\n'), '', 'a line that is not <letter>=');
  const big = OFFER + ('a=' + 'x'.repeat(1000) + '\r\n').repeat(Math.ceil(SDP_OFFER_MAX_BYTES / 1000));
  assert.equal(validSdpOffer(big), '', 'over the cap');
});

test('the session is the SERVER\'s: Live speaks, Astra thinks with our tools, and the browser may only mute', () => {
  const tools = [{ type: 'function', name: 'count_records', description: 'Count.', parameters: { type: 'object', properties: {} }, mode: 'read' }];
  const body = buildLiveSessionRequest({ sdp: OFFER, voice: 'CEDAR', tools });
  assert.equal(body.transport.type, 'webrtc');
  assert.equal(body.transport.sdp, OFFER);
  assert.equal(body.session.model, 'gpt-live-1');
  assert.equal(body.session.audio.output.voice, 'cedar');
  assert.equal(body.session.delegation.type, 'responses');
  assert.equal(body.session.delegation.responses.model, 'gpt-6-astra');
  assert.deepEqual(body.session.delegation.responses.tools, [{ type: 'function', name: 'count_records', description: 'Count.', parameters: { type: 'object', properties: {} } }], 'our annotation (mode) is never sent');
  assert.ok(body.session.instructions.includes('Hugo'));
  assert.ok(body.session.delegation.responses.instructions.includes('tool result'));
  // THE LOCK: no session.update, no response.*, so the browser cannot re-instruct Hugo or answer a tool itself.
  const allowed = body.session.client.data_channel.allowed_client_events;
  assert.deepEqual(allowed, [...FRONTEND_CLIENT_EVENTS]);
  for (const forbidden of ['session.update', 'response.create', 'response.item.create', 'session.instructions.append']) assert.ok(!allowed.includes(forbidden), forbidden);
  assert.ok(body.session.client.data_channel.allowed_server_events.every((e) => e.type !== 'response.event'), 'the brain\'s raw stream, tool arguments included, stays on the sideband');
});

test('a voice off the list is the default; the models come from the environment only when they are model-shaped', () => {
  assert.equal(liveVoice('nope'), 'marin');
  assert.equal(liveVoice(undefined), 'marin');
  assert.deepEqual(liveModels({}), { model: DEFAULT_LIVE_MODEL, brain: DEFAULT_LIVE_BRAIN });
  assert.deepEqual(liveModels({ OPENAI_LIVE_MODEL: 'gpt-live-2', OPENAI_LIVE_BRAIN_MODEL: 'gpt-6-sol' }), { model: 'gpt-live-2', brain: 'gpt-6-sol' });
  assert.deepEqual(liveModels({ OPENAI_LIVE_MODEL: 'bad id/../x' }).model, DEFAULT_LIVE_MODEL);
});

// ---- the client ------------------------------------------------------------------------------------------

const reply = (status, body) => ({ ok: status >= 200 && status < 300, status, text: async () => (typeof body === 'string' ? body : JSON.stringify(body)) });

test('create posts the offer to /v1/live/sessions with the key, and hands back the answer and the session id', async () => {
  const seen = [];
  const client = createLiveClient({ apiKey: 'k-1', env: {}, fetchImpl: async (url, init) => { seen.push({ url, init }); return reply(201, { session: { id: 'live_123' }, transport: { type: 'webrtc', sdp: ANSWER } }); } });
  const out = await client.create({ sdp: OFFER, voice: 'marin', tools: [] });
  assert.deepEqual(out, { sessionId: 'live_123', sdp: ANSWER, model: 'gpt-live-1', brain: 'gpt-6-astra' });
  assert.equal(seen[0].url, 'https://api.openai.com/v1/live/sessions');
  assert.equal(seen[0].init.method, 'POST');
  assert.equal(seen[0].init.headers.authorization, 'Bearer k-1');
  assert.equal(JSON.parse(seen[0].init.body).transport.sdp, OFFER);
});

test('create refuses a bad offer before any call, and names a refusal by status and code only', async () => {
  let calls = 0;
  const refusing = createLiveClient({ apiKey: 'k', env: {}, fetchImpl: async () => { calls += 1; return reply(401, { error: { code: 'invalid_api_key', message: 'Incorrect API key provided: ' + FAKE_KEY } }); } });
  await assert.rejects(refusing.create({ sdp: 'nonsense' }), (e) => e.statusCode === 400);
  assert.equal(calls, 0);
  await assert.rejects(refusing.create({ sdp: OFFER }), (e) => {
    assert.equal(e.providerStatus, 401);
    assert.equal(e.providerCode, 'invalid_api_key');
    assert.ok(!e.message.includes(FAKE_KEY), 'the provider\'s prose never reaches message');
    return true;
  });
  const malformed = createLiveClient({ apiKey: 'k', env: {}, fetchImpl: async () => reply(201, { session: { id: '../x' }, transport: { sdp: ANSWER } }) });
  await assert.rejects(malformed.create({ sdp: OFFER }), (e) => e.providerCode === 'malformed');
  const unconfigured = createLiveClient({ apiKey: '', env: {}, fetchImpl: async () => reply(201, {}) });
  assert.equal(unconfigured.configured, false);
  await assert.rejects(unconfigured.create({ sdp: OFFER }), (e) => e.statusCode === 503);
});

test('a hung create is given up and named a timeout; an unreachable host is named egress', async () => {
  const hung = createLiveClient({ apiKey: 'k', env: {}, timeoutMs: 5, fetchImpl: (url, init) => new Promise((_, reject) => init.signal.addEventListener('abort', () => reject(new Error('aborted')))) });
  await assert.rejects(hung.create({ sdp: OFFER }), (e) => e.timedOut === true && liveFailure(e).kind === 'timeout');
  const down = createLiveClient({ apiKey: 'k', env: {}, fetchImpl: async () => { throw new Error('ENOTFOUND'); } });
  await assert.rejects(down.create({ sdp: OFFER }), (e) => e.egress === true && liveFailure(e).kind === 'egress');
});

test('reachableModels names which of Hugo\'s models the key reaches and which it does not, never the full list', async () => {
  const client = createLiveClient({ apiKey: 'k', env: {}, fetchImpl: async (url) => { assert.equal(url, 'https://api.openai.com/v1/models'); return reply(200, { data: [{ id: 'gpt-6-astra' }, { id: 'ft:secret-model' }, { id: 'gpt-realtime-2.1' }] }); } });
  const out = await client.reachableModels();
  assert.deepEqual(out, { reached: ['gpt-6-astra', 'gpt-realtime-2.1'], missing: ['gpt-live-1'] });
  assert.ok(!JSON.stringify(out).includes('secret'));
});

// ---- the sideband ----------------------------------------------------------------------------------------

function fakeSocket() {
  const handlers = {};
  return {
    sent: [], closed: false, url: '', opts: null,
    on(ev, cb) {
      if (!handlers[ev]) handlers[ev] = [];
      handlers[ev].push(cb);
      return this;
    },
    send(d) { this.sent.push(JSON.parse(d)); },
    close() { this.closed = true; },
    emit(ev, ...a) { for (const cb of handlers[ev] || []) cb(...a); },
    msg(o) { this.emit('message', Buffer.from(JSON.stringify(o)), false); },
  };
}
const tick = () => new Promise((r) => setImmediate(r));
function fakeTimers() {
  const timers = [];
  return {
    timers,
    setTimer: (fn, ms) => { const t = { fn, ms, live: true }; timers.push(t); return t; },
    clearTimer: (t) => { if (t) t.live = false; },
    fire: (ms) => { for (const t of timers.filter((x) => x.live && x.ms === ms)) { t.live = false; t.fn(); } },
  };
}
function attach(over = {}) {
  const ws = fakeSocket();
  const t = fakeTimers();
  const booked = [];
  const runs = [];
  const closes = [];
  const sb = attachSideband({
    apiKey: 'k-2', sessionId: 'live_9', liveModel: 'gpt-live-1', brainModel: 'gpt-6-astra',
    wsFactory: (url, opts) => { ws.url = url; ws.opts = opts; return ws; },
    runTool: async (name, args) => { runs.push({ name, args }); return { total: 7 }; },
    onUsage: (u, m) => booked.push({ u, m }),
    onClose: (reason, detail) => closes.push({ reason, detail }),
    setTimer: t.setTimer, clearTimer: t.clearTimer,
    ...over,
  });
  return { ws, t, sb, booked, runs, closes };
}
const fcDone = (callId, name = 'count_records', args = '{"domain":"space"}', delegation = 'del_1') => ({ type: 'response.event', delegation_id: delegation, event: { type: 'response.output_item.done', item: { type: 'function_call', call_id: callId, name, arguments: args } } });
const USAGE = Object.freeze({ input_tokens: 100, output_tokens: 20 });
const completed = (delegation = 'del_1', usage = USAGE) => ({ type: 'response.event', delegation_id: delegation, event: { type: 'response.completed', response: { status: 'completed', usage } } });
const created = (delegation = 'del_1') => ({ type: 'response.event', delegation_id: delegation, event: { type: 'response.created' } });

test('the sideband dials OUT to the session\'s attach URL with the key as a bearer header', async () => {
  const { ws, sb } = attach();
  assert.equal(ws.url, 'wss://api.openai.com/v1/live/sessions/live_9/attach');
  assert.equal(ws.opts.headers.authorization, 'Bearer k-2');
  assert.equal(sidebandUrl('a/b'), 'wss://api.openai.com/v1/live/sessions/a%2Fb/attach');
  ws.emit('open');
  await sb.ready;
});

test('a delegated tool call runs ON THIS SERVER exactly once, its answer goes back, and the response continues once', async () => {
  const { ws, sb, runs, booked } = attach();
  ws.emit('open');
  await sb.ready;
  ws.msg(created());
  ws.msg(fcDone('call_1'));
  ws.msg(fcDone('call_1')); // a repeated delivery of the same call
  ws.msg(completed());
  await tick(); await tick();
  assert.deepEqual(runs, [{ name: 'count_records', args: { domain: 'space' } }]);
  const outputs = ws.sent.filter((e) => e.type === 'response.item.create');
  assert.equal(outputs.length, 1);
  assert.deepEqual(outputs[0].item, { type: 'function_call_output', call_id: 'call_1', output: '{"total":7}' });
  assert.equal(ws.sent.filter((e) => e.type === 'response.create').length, 1);
  assert.deepEqual(booked, [{ u: { input_tokens: 100, output_tokens: 20 }, m: 'gpt-6-astra' }], 'the brain\'s tokens at the brain\'s row');
  // A response with no tool call is never continued (that would make the brain talk again unasked).
  ws.msg(created('del_2'));
  ws.msg(completed('del_2'));
  await tick();
  assert.equal(ws.sent.filter((e) => e.type === 'response.create').length, 1);
});

test('the continuation waits for every parallel call, and a malformed or throwing tool still answers', async () => {
  let release;
  const gate = new Promise((r) => { release = r; });
  const { ws, sb } = attach({ runTool: async (name) => {
    if (name === 'slow') await gate;
    if (name === 'boom') throw new Error('x');
    return { ok: name };
  } });
  ws.emit('open');
  await sb.ready;
  ws.msg(created());
  ws.msg(fcDone('c1', 'slow'));
  ws.msg(fcDone('c2', 'boom', 'not json'));
  ws.msg(completed());
  await tick();
  assert.equal(ws.sent.filter((e) => e.type === 'response.create').length, 0, 'one call is still running');
  release();
  await tick(); await tick();
  assert.equal(ws.sent.filter((e) => e.type === 'response.create').length, 1);
  const out = Object.fromEntries(ws.sent.filter((e) => e.type === 'response.item.create').map((e) => [e.item.call_id, e.item.output]));
  assert.deepEqual(out, { c1: '{"ok":"slow"}', c2: '{"error":"tool_failed"}' });
});

test('audio seconds are booked as the increase on a CUMULATIVE figure, at the Live row', async () => {
  const { ws, sb, booked } = attach();
  ws.emit('open');
  await sb.ready;
  ws.msg({ type: 'session.usage.updated', usage: { seconds: 10 } });
  ws.msg({ type: 'session.usage.updated', usage: { seconds: 10 } });
  ws.msg({ type: 'session.usage.updated', usage: { seconds: 32.5 } });
  ws.msg({ type: 'session.closed', reason: 'close_requested', usage: { seconds: 40 } });
  await tick();
  assert.deepEqual(booked.map((b) => [b.m, b.u.audio_seconds]), [['gpt-live-1', 10], ['gpt-live-1', 22.5], ['gpt-live-1', 7.5]]);
});

test('a spent day ends the session: a tool is refused and the session is asked to close', async () => {
  let allowed = true;
  const { ws, sb, runs, t, closes } = attach({ turnAllowed: async () => allowed });
  ws.emit('open');
  await sb.ready;
  allowed = false;
  ws.msg(created());
  ws.msg(fcDone('c9'));
  await tick(); await tick();
  assert.equal(runs.length, 0, 'no tool runs on a spent day');
  assert.equal(ws.sent.find((e) => e.type === 'response.item.create').item.output, '{"error":"daily_cap_reached"}');
  assert.ok(ws.sent.some((e) => e.type === 'session.close'));
  // No session.closed arrives: the socket is dropped after the grace period anyway, so nothing is orphaned.
  t.fire(5000);
  assert.equal(ws.closed, true);
  assert.equal(closes[0].reason, 'daily_cap_reached');
});

test('a usage report on a spent day closes the session too', async () => {
  const { ws, sb } = attach({ turnAllowed: async () => false });
  ws.emit('open');
  await sb.ready;
  ws.msg({ type: 'session.usage.updated', usage: { seconds: 3 } });
  await tick(); await tick();
  assert.ok(ws.sent.some((e) => e.type === 'session.close'));
});

test('the session length is bounded, and an attach that never opens is given up and named', async () => {
  const a = attach({ maxSessionMs: 1000 });
  a.ws.emit('open');
  await a.sb.ready;
  a.t.fire(1000);
  assert.ok(a.ws.sent.some((e) => e.type === 'session.close'));
  const b = attach({ openTimeoutMs: 50 });
  b.t.fire(50);
  await assert.rejects(b.sb.ready, (e) => e.timedOut === true);
  assert.equal(b.closes[0].reason, 'open_timeout');
  const c = attach();
  c.ws.emit('close', 1008);
  await assert.rejects(c.sb.ready, (e) => e.refused === true);
});

// A DROPPED LINK STILL ENDS ITS SESSION (2.20.0 security gate, MAJOR): the server's socket is what meters a session and holds
// its length, so a drop after the session opened dials a second link to send `session.close`, and the session is not let go
// until that link reports back, closes, or the grace period ends. Measured before the fix: no second link, nothing sent.
test('a link that drops after open dials once more to close the session, and lets it go only when that link reports', async () => {
  const sockets = [];
  const a = attach({ wsFactory: (url, opts) => { const w = fakeSocket(); w.url = url; w.opts = opts; sockets.push(w); return w; } });
  sockets[0].emit('open');
  await a.sb.ready;
  sockets[0].emit('close', 1006);
  assert.equal(sockets.length, 2, 'a second link is dialled');
  assert.equal(sockets[1].url, sockets[0].url);
  assert.equal(sockets[1].opts.headers.authorization, 'Bearer k-2');
  assert.deepEqual(a.closes, [], 'and the session is not let go yet');
  sockets[1].emit('open');
  assert.ok(sockets[1].sent.some((e) => e.type === 'session.close'), 'it asks the session to close');
  sockets[1].msg({ type: 'session.closed', usage: { seconds: 9 } });
  assert.deepEqual(a.closes.map((c) => [c.reason, c.detail.code, c.detail.reclosed]), [['upstream_closed', 1006, true]]);
  assert.equal(a.booked.at(-1).u.audio_seconds, 9, 'the seconds it reports are booked');
  assert.ok(sockets[1].closed, 'and the second link is closed');
  // A second link that never answers is given up at the grace period, and the session is let go then.
  const q = [];
  const b = attach({ wsFactory: () => { const w = fakeSocket(); q.push(w); return w; } });
  q[0].emit('open');
  await b.sb.ready;
  q[0].emit('close', 1006);
  assert.deepEqual(b.closes, []);
  b.t.fire(SIDEBAND_OPEN_TIMEOUT_MS + SIDEBAND_CLOSE_GRACE_MS);
  assert.deepEqual(b.closes.map((c) => c.reason), ['upstream_closed']);
  // A drop after this server asked to close, before `session.closed` came, is redialled too (2.20.0 round two, security
  // MINOR 5 and engineering MINOR 8): the close was asked, never confirmed, and the session may still be running.
  const r = [];
  const c = attach({ wsFactory: () => { const w = fakeSocket(); r.push(w); return w; } });
  r[0].emit('open');
  await c.sb.ready;
  c.sb.close('operator_left');
  r[0].emit('close', 1000);
  assert.equal(r.length, 2, 'a second link after a close asked for and never confirmed');
  r[1].emit('open');
  assert.ok(r[1].sent.some((e) => e.type === 'session.close'));
  r[1].msg({ type: 'session.closed', usage: { seconds: 3 } });
  assert.deepEqual(c.closes.map((x) => x.reason), ['operator_left'], 'and it ends under the reason it was asked for');
  // A close called while the second link is dialling keeps that link's longer grace, so the session is not let go at 5
  // seconds, before the second link could have opened.
  const d = [];
  const e = attach({ wsFactory: () => { const w = fakeSocket(); d.push(w); return w; } });
  d[0].emit('open');
  await e.sb.ready;
  d[0].emit('close', 1006);
  e.sb.close('operator_left');
  e.t.fire(SIDEBAND_CLOSE_GRACE_MS);
  assert.deepEqual(e.closes, [], 'not let go at the short grace while the second link dials');
  e.t.fire(SIDEBAND_OPEN_TIMEOUT_MS + SIDEBAND_CLOSE_GRACE_MS);
  assert.equal(e.closes.length, 1, 'let go at the second link\'s own grace');
  // A session that reported `session.closed` is over: a drop after it dials nothing.
  const f = [];
  const g = attach({ wsFactory: () => { const w = fakeSocket(); f.push(w); return w; } });
  f[0].emit('open');
  await g.sb.ready;
  f[0].msg({ type: 'session.closed', usage: { seconds: 1 } });
  f[0].emit('close', 1000);
  assert.equal(f.length, 1, 'no second link once the session said it closed');
});

// A SECOND LINK THAT CANNOT EVEN BE OPENED ends the session there (2.20.0 round two, engineering MINOR 9): the branch had
// no test, and it is the one place the redial gives up at once.
test('a second link whose socket cannot be made lets the session go at once, under the drop\'s reason', async () => {
  let made = 0;
  const first = fakeSocket();
  const a = attach({ wsFactory: () => { made += 1; if (made === 1) { return first; } throw new Error('no socket'); } });
  first.emit('open');
  await a.sb.ready;
  first.emit('close', 1006);
  assert.equal(made, 2, 'the second link was tried');
  assert.deepEqual(a.closes.map((c) => [c.reason, c.detail.code, c.detail.reclosed]), [['upstream_closed', 1006, false]]);
  assert.equal(a.sb.state().ended, true);
});

test('the check\'s delegated turn passes only when a tool ran AND the brain answered after it', async () => {
  const { ws, sb } = attach();
  ws.emit('open');
  await sb.ready;
  const probe = sb.probeTurn(1000);
  assert.equal(ws.sent[0].type, 'response.item.create');
  assert.equal(ws.sent[0].item.content[0].text, PROBE_TEXT);
  assert.equal(ws.sent[1].type, 'response.create');
  ws.msg(created());
  ws.msg(fcDone('p1'));
  ws.msg(completed());
  await tick(); await tick();
  ws.msg(created());
  ws.msg(completed());
  const out = await probe;
  assert.equal(out.ok, true);
  assert.equal(out.tool, 'count_records');
});

test('the check\'s delegated turn fails by name: an answer with no tool never passes, an error or a timeout fails', async () => {
  const a = attach();
  a.ws.emit('open');
  await a.sb.ready;
  const noTool = a.sb.probeTurn(1000);
  a.ws.msg(created());
  a.ws.msg(completed());
  a.t.fire(1000);
  assert.equal((await noTool).kind, 'timeout', 'a reply with no tool is not proof the tools work');
  const b = attach();
  b.ws.emit('open');
  await b.sb.ready;
  const refused = b.sb.probeTurn(1000);
  b.ws.msg({ type: 'error', error: { type: 'invalid_request_error', code: 'model_not_found', message: 'x' } });
  assert.deepEqual({ ...(await refused), latencyMs: 0 }, { ok: false, kind: 'refused', code: 'model_not_found', latencyMs: 0 });
});

test('functionCallOf and brainUsageOf read only their own events', () => {
  assert.equal(functionCallOf({ type: 'response.output_item.done', item: { type: 'message' } }), null);
  assert.equal(functionCallOf({ type: 'response.output_item.added', item: { type: 'function_call', call_id: 'c', name: 'n' } }), null);
  assert.equal(brainUsageOf({ type: 'response.output_text.delta' }), null);
  assert.deepEqual(brainUsageOf({ type: 'response.failed', response: { usage: { input_tokens: 5 } } }), { input_tokens: 5, output_tokens: 0 });
});

// ---- the route and the service ---------------------------------------------------------------------------

function jsonReq(body) {
  const r = Readable.from([Buffer.from(JSON.stringify(body))]);
  r.headers = { 'content-type': 'application/json' };
  return r;
}
function fakeRes() {
  return { status: 0, body: null, writeHead(s) { this.status = s; return this; }, setHeader() {}, end(b) { this.body = b ? JSON.parse(String(b)) : null; } };
}
const agent = { subject: 'op-1', roles: ['agent'] };
async function call(path, body, over = {}) {
  const res = fakeRes();
  const opens = [];
  const hugoLive = {
    configured: true,
    open: async (a) => { opens.push(a); return { sessionId: 'live_1', sdp: ANSWER, model: 'gpt-live-1', brain: 'gpt-6-astra' }; },
    end: () => true,
    checkResult: async () => ({ ok: true, tool: 'count_records', latencyMs: 9 }),
    ...over.hugoLive,
  };
  const handled = await tryHugoLive(jsonReq(body), res, { method: 'POST', path, principal: over.principal ?? agent, hugoLive, paidCallAllowed: over.paidCallAllowed ?? (async () => true) });
  return { handled, res, opens };
}

test('the route answers only its own three POST paths', async () => {
  const res = fakeRes();
  assert.equal(await tryHugoLive(jsonReq({}), res, { method: 'GET', path: LIVE_ROUTE, principal: agent }), false);
  assert.equal(await tryHugoLive(jsonReq({}), res, { method: 'POST', path: '/api/v3/hugo/livex', principal: agent }), false);
});

test('refusals come in order: role 403, off 503, bad request 400, spent day 429, all before anything is dialled', async () => {
  await assert.rejects(call(LIVE_ROUTE, { sdp: OFFER, domain: 'space' }, { principal: { subject: 'x', roles: ['viewer'] } }), (e) => e.statusCode === 403);
  const off = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'space' }, { hugoLive: { configured: false, offReason: 'unpriced' } });
  assert.deepEqual([off.res.status, off.res.body.reason, off.res.body.link], [503, 'unpriced', 'config']);
  const noDomain = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'atlantis' });
  assert.equal(noDomain.res.status, 400);
  const noSdp = await call(LIVE_ROUTE, { domain: 'space' });
  assert.equal(noSdp.res.status, 400);
  const spent = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'space' }, { paidCallAllowed: async () => false });
  assert.deepEqual([spent.res.status, spent.res.body.limit], [429, 'daily spend cap']);
  assert.equal(spent.opens.length, 0);
});

test('an accepted offer opens the session with the operator, the domain (All domains included) and the voice', async () => {
  const ok = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'all', voice: 'cedar', check: true, tab: 'tab-aaaaaaaa' });
  assert.equal(ok.res.status, 201);
  assert.deepEqual(ok.res.body, { sessionId: 'live_1', sdp: ANSWER, model: 'gpt-live-1', brain: 'gpt-6-astra' });
  assert.deepEqual(ok.opens[0], { principal: agent, sdp: OFFER, domain: 'all', voice: 'cedar', check: true, tab: 'tab-aaaaaaaa' }, 'the tab id reaches the service');
});

test('a failed open names the LINK that broke and its class, never the provider\'s prose', async () => {
  const handshake = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'space' }, { hugoLive: { open: async () => { throw Object.assign(new Error('hugo live session error 404 model_not_found'), { providerStatus: 404, providerCode: 'model_not_found', ringDetail: 'secret prose' }); } } });
  assert.deepEqual(handshake.res.body, { error: 'live handshake failed', link: 'handshake', kind: 'model', code: 'model_not_found' });
  const sideband = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'space' }, { hugoLive: { open: async () => { throw Object.assign(new Error('x'), { link: 'sideband', timedOut: true }); } } });
  assert.deepEqual([sideband.res.status, sideband.res.body.link, sideband.res.body.kind], [504, 'sideband', 'timeout']);
  const bad = await call(LIVE_ROUTE, { sdp: OFFER, domain: 'space' }, { hugoLive: { open: async () => { throw Object.assign(new Error('invalid sdp offer'), { statusCode: 400 }); } } });
  assert.equal(bad.res.status, 400);
});

test('end and check need a session id, and answer for the caller\'s own session', async () => {
  assert.equal((await call(LIVE_END_ROUTE, {})).res.status, 400);
  assert.deepEqual((await call(LIVE_END_ROUTE, { sessionId: 'live_1' })).res.body, { ended: true });
  const chk = await call(LIVE_CHECK_ROUTE, { sessionId: 'live_1' });
  assert.deepEqual(chk.res.body, { delegation: { ok: true, tool: 'count_records', latencyMs: 9 } });
  assert.equal((await call(LIVE_CHECK_ROUTE, { sessionId: 'live_1' }, { hugoLive: { checkResult: async () => null } })).res.status, 404);
});

test('liveDomain takes a registered id or All domains, nothing else', () => {
  assert.equal(liveDomain('space'), 'space');
  assert.equal(liveDomain('ALL'), 'all');
  assert.equal(liveDomain('natural-resources'), 'natural_resources');
  assert.equal(liveDomain('mars'), '');
});

function service(over = {}) {
  const sockets = [];
  const calls = [];
  const audits = [];
  const svc = createLiveService({
    client: { model: 'gpt-live-1', brain: 'gpt-6-astra', create: async () => ({ sessionId: 'live_' + (sockets.length + 1), sdp: ANSWER, model: 'gpt-live-1', brain: 'gpt-6-astra' }), reachableModels: async () => ({ reached: [], missing: [] }) },
    apiKey: 'k', wsFactory: () => { const ws = fakeSocket(); sockets.push(ws); setImmediate(() => ws.emit('open')); return ws; },
    spendGuards: { noteUsage: () => {}, flushSpendToLedger: async () => {}, paidCallAllowed: async () => true },
    runnerFor: (domain) => ({ domain, runCall: async (c) => { calls.push(c); return { counted: 3 }; }, newTurn: () => {} }),
    toolDefs: () => [],
    audit: async (s, info) => { audits.push({ s, ...info }); },
    ...over,
  });
  return { svc, sockets, audits, calls };
}

test('one session per operator: a second open closes the first, and only the owner can end or read a session', async () => {
  const { svc, sockets, audits } = service();
  const a = await svc.open({ principal: agent, sdp: OFFER, domain: 'space' });
  assert.equal(svc.count(), 1);
  await svc.open({ principal: agent, sdp: OFFER, domain: 'space' });
  assert.ok(sockets[0].sent.some((e) => e.type === 'session.close'), 'the first session is asked to close');
  assert.equal(svc.end({ principal: { subject: 'someone-else' }, sessionId: a.sessionId }), false);
  assert.equal(await svc.checkResult({ principal: agent, sessionId: 'live_2' }), null, 'not a check session');
  assert.deepEqual(audits.map((x) => x.via), ['live', 'live']);
  sockets[0].msg({ type: 'session.closed', reason: 'close_requested', usage: { seconds: 1 } });
  assert.equal(svc.count(), 1, 'a closed session is forgotten');
  svc.closeAll();
  assert.ok(sockets[1].sent.some((e) => e.type === 'session.close'));
});

// ONE SESSION PER OPERATOR AND TAB (2.20.0 round one, security MINOR 4): on the shared team token two operators are one
// subject, so a second tab's open must not close the first; the same tab opening again still replaces its own.
test('two tabs on one sign-in each keep their own session; the same tab again replaces its own', async () => {
  const { svc, sockets } = service();
  await svc.open({ principal: agent, sdp: OFFER, domain: 'space', tab: 'tab-aaaaaaaa' });
  await svc.open({ principal: agent, sdp: OFFER, domain: 'space', tab: 'tab-bbbbbbbb' });
  assert.equal(svc.count(), 2);
  assert.ok(!sockets[0].sent.some((e) => e.type === 'session.close'), 'another tab\'s Talk leaves the first session open');
  await svc.open({ principal: agent, sdp: OFFER, domain: 'space', tab: 'tab-aaaaaaaa' });
  assert.ok(sockets[0].sent.some((e) => e.type === 'session.close'), 'the same tab opening again closes its own first session');
  assert.ok(!sockets[1].sent.some((e) => e.type === 'session.close'));
  svc.closeAll();
});

test('the tab id is validated: a malformed one keys by the sign-in alone, as before', () => {
  assert.equal(liveKeyOf(agent, 'tab-aaaaaaaa'), agent.subject + '\u0000tab-aaaaaaaa');
  for (const bad of ['short', 'x'.repeat(65), 'has space id', 42, null, undefined]) assert.equal(liveKeyOf(agent, bad), agent.subject + '\u0000');
});

test('the browser sends one tab id for the tab\'s life, kept across a reload', async () => {
  // A fresh copy of the module: the id is held for the page's life, so in one process another file's Live session has
  // already set it (2.22.2: the platform's single-process run).
  const { liveTabId } = await import('../public/views/hugo-live.js?tab-life');
  const held = new Map();
  const store = { getItem: (k) => held.get(k) ?? null, setItem: (k, v) => held.set(k, v) };
  const id = liveTabId(store, () => 'abcdef12-3456');
  assert.equal(id, 'abcdef12-3456');
  assert.equal(held.get('vh_live_tab'), id, 'kept in the tab\'s own storage');
  assert.equal(liveTabId(store, () => 'never-used-1'), id, 'the same id for the rest of the page');
});

test('a dropped link keeps the session held, so End and shutdown still reach it, and the length travels to the browser', async () => {
  // Fake timers: a real 10-minute length timer would hold the process open if an assertion below failed.
  const { svc, sockets } = service({ maxSessionMs: 600_000, setTimer: () => ({}), clearTimer: () => {} });
  const opened = await svc.open({ principal: agent, sdp: OFFER, domain: 'space' });
  assert.equal(opened.maxSessionMs, 600_000, 'the browser is told the session\'s length');
  sockets[0].emit('close', 1006);
  await tick();
  assert.equal(svc.count(), 1, 'still held while the second link closes it');
  assert.equal(svc.end({ principal: agent, sessionId: opened.sessionId }), true, 'and its owner can still end it');
  assert.equal(sockets.length, 2);
  sockets[1].msg({ type: 'session.closed', usage: { seconds: 2 } });
  assert.equal(svc.count(), 0, 'let go once the second link reports');
  const { svc: plain } = service();
  assert.equal('maxSessionMs' in await plain.open({ principal: agent, sdp: OFFER, domain: 'space' }), false, 'no limit set, none sent');
});

test('a sideband that cannot attach fails the open by name, so no session runs without the server holding it', async () => {
  const { svc } = service({ wsFactory: () => { const ws = fakeSocket(); setImmediate(() => ws.emit('close', 1006)); return ws; } });
  await assert.rejects(svc.open({ principal: agent, sdp: OFFER, domain: 'space' }), (e) => e.link === 'sideband' && e.refused === true);
  assert.equal(svc.count(), 0);
});

test('a delegated turn is audited without its words, and a check session runs the probe', async () => {
  const { svc, sockets, audits } = service();
  await svc.open({ principal: agent, sdp: OFFER, domain: 'space', check: true });
  assert.equal(sockets[0].sent[0].item.content[0].text, PROBE_TEXT);
  sockets[0].msg({ type: 'session.delegation.created', delegation: { id: 'del_1' } });
  assert.deepEqual(audits.at(-1), { s: 'op-1', domain: 'voice', turns: 1, via: 'live' });
  assert.ok(audits.some((x) => x.via === 'live-check'));
  svc.closeAll();
});

test('GPT-Live is priced, per second, so a daily cap can hold a Live session', () => {
  assert.equal(modelPriced('gpt-live-1'), true);
  assert.equal(ratesFor('gpt-live-1').rates.perSecond, 0.05 / 60);
  assert.equal(modelPriced('gpt-6-astra'), true);
});

test('one brief and one registry (Lane T): the brain is Hugo\'s spoken brief for the scope, and a call reaches runCall with its id', async () => {
  const all = buildLiveSessionRequest({ sdp: OFFER, scope: 'all' });
  assert.equal(all.session.delegation.responses.instructions, hugoInstructions({ channel: 'spoken', scope: 'all' }));
  assert.equal(buildLiveSessionRequest({ sdp: OFFER, scope: 'space' }).session.delegation.responses.instructions, hugoInstructions({ channel: 'spoken', scope: 'space' }));
  const scopes = [];
  const { svc, sockets, calls } = service({ client: { model: 'gpt-live-1', brain: 'gpt-6-astra', create: async (a) => { scopes.push(a.scope); return { sessionId: 'live_1', sdp: ANSWER, model: 'gpt-live-1', brain: 'gpt-6-astra' }; } } });
  await svc.open({ principal: agent, sdp: OFFER, domain: 'all' });
  assert.deepEqual(scopes, ['all']);
  sockets[0].msg(created());
  sockets[0].msg(fcDone('call_7'));
  await tick(); await tick();
  assert.deepEqual(calls, [{ callId: 'call_7', name: 'count_records', args: { domain: 'space' } }]);
  assert.equal(sockets[0].sent.find((e) => e.type === 'response.item.create').item.output, '{"counted":3}');
  svc.closeAll();
});
