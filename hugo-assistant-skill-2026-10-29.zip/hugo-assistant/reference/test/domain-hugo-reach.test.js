// HUGO FILTERS WHAT IT SAYS IT FILTERS, ON ALL 7 DOMAINS (VH-226). The banner said "Hugo is filtering the view"
// over a domain board and a domain map that read nothing but their own narrowing; only the Space board and Space
// analytics read `state.hugoFilter`. The board and the map now read it on every domain, and since VH-226 part 2 and
// VH-320 the Analytics and the Dashboard do too, so the banner shows wherever the filter is read, on all seven.
//
// The reads are in the deferred module `public/views/domain-board-more.js`, which takes the shell's state and
// API client as `shell`, so they are driven here with a stub API. What stays in `public/app-v3.js` needs a DOM and
// exports nothing, so the banner's reach is a source assertion. The behaviour was measured in a browser
// (`e2e/probe.mjs`): "vendors in France" on Air drew the one Air provider in France, the Air map plotted one node,
// and the banner was hidden on Air's dashboard and analytics and shown on Space's.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { fetchDomainPage, readDomainBoardRows, readDomainMapRows } from '../public/views/domain-board-more.js';

const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
const between = (from, to) => {
  const start = app.indexOf(from);
  const end = app.indexOf(to, start + from.length);
  assert.ok(start >= 0 && end > start, 'found ' + from);
  return app.slice(start, end);
};

// A shell whose API records what it was asked. `pageRows` answers each Hugo page; the store answers `storeRows`.
function shellWith({ hugoFilter = null, total = 1, pageRows = 1, storeRows = 2 } = {}) {
  const asked = { hugo: [], store: [], map: 0 };
  const rows = (n, offset) => Array.from({ length: n }, (_, i) => ({ air_id: 'host:p' + (offset + i) + '.example', name: 'P' + (offset + i) }));
  const shell = {
    state: { token: 't', hugoFilter, domainLoaded: null },
    api: {
      hugoQuery: async (token, body) => { asked.hugo.push(body); return { status: 200, payload: { rows: rows(pageRows, body.offset), total, notApplied: ['sizeBands'] } }; },
      domainProviders: async (token, domain, q) => { asked.store.push({ domain, ...q }); return { ok: true, status: 200, providers: rows(storeRows, q.offset), total: storeRows }; },
      domainMap: async () => { asked.map += 1; return { ok: true, status: 200, rows: [{ id: 'n1' }, { id: 'n2' }], total: 2, capped: false }; },
    },
    masterMapRow: (n) => ({ master: n.id }),
  };
  return { shell, asked };
}

test('VH-226: a domain board page comes from Hugo\'s server-validated query while a filter is live', async () => {
  const filter = { filterSpec: { countries: ['France'] } };
  const { shell, asked } = shellWith({ hugoFilter: filter, total: 7 });
  const page = await fetchDomainPage(shell, 'air', { sort: 'name', dir: 'asc', search: 'ignored' }, 0);
  assert.deepEqual(asked.hugo, [{ filterSpec: { countries: ['France'] }, domain: 'air', crossDomain: false, offset: 0, limit: 500, sort: 'name', dir: 'asc' }],
    'the filter, scoped to this store, with the board\'s own sort');
  assert.equal(asked.store.length, 0, 'and not the ordinary read');
  assert.equal(page.providers.length, 1);
  assert.equal(page.total, 7);
  assert.equal(filter.total, 7, 'the banner gets the match count');
  assert.deepEqual(filter.notApplied, ['sizeBands']);
  // Without a filter, the ordinary board read, and the rows held for a repaint are keyed on the filter, so
  // clearing or changing it starts again at one page.
  const plain = shellWith();
  await fetchDomainPage(plain.shell, 'maritime', { sort: '' }, 0);
  assert.equal(plain.asked.store[0].domain, 'maritime');
  assert.equal(plain.asked.hugo.length, 0);
  const keyed = await readDomainBoardRows(shell, 'air', {});
  assert.match(keyed.key, /France/);
});

test('VH-226: a domain map plots Hugo\'s matches while a filter is live, to 1,000, and the whole store otherwise', async () => {
  const { shell, asked } = shellWith({ hugoFilter: { filterSpec: {} }, total: 1200, pageRows: 500 });
  const filtered = await readDomainMapRows(shell, 'air');
  assert.deepEqual(asked.hugo.map((b) => b.offset), [0, 500], 'a page at a time, to the Space map\'s 1,000');
  assert.equal(filtered.rows.length, 1000);
  assert.equal(filtered.rows[0].record.vendor_id, 'host:p0.example', 'each match as the wrapped map row');
  assert.equal(filtered.total, 1200, 'the true match count');
  assert.equal(asked.map, 0);
  const whole = shellWith();
  const store = await readDomainMapRows(whole.shell, 'air');
  assert.equal(whole.asked.map, 1, 'one read of the map projection');
  assert.deepEqual(store.rows, [{ master: 'n1' }, { master: 'n2' }]);
  assert.match(between('async function renderDomainMap(', 'async function renderDomainAnalytics('), /await more\.readDomainMapRows\(domainShell, domain\)/);
});

test('VH-226: the banner and an apply only claim the screens that read the filter', () => {
  // Analytics joined in V2.6 (VH-226 part 2), when a store's report began folding Hugo's matches, and the Dashboard in
  // VH-320, when it began drawing the store's matches alone: every view Hugo drives on Space it drives on all seven.
  assert.match(app, /const HUGO_VIEWS = new Set\(\['master', 'map', 'dashboard', 'analytics'\]\);/);
  assert.match(app, /function hugoReaches\(view\) \{\n {2}return HUGO_VIEWS\.has\(view\);\n\}/, 'no view is Space\'s alone');
  assert.doesNotMatch(app, /HUGO_DOMAIN_VIEWS/);
  assert.match(between('function renderHugoBanner(', 'async function clearHugoFilter('), /!state\.hugoFilter \|\| !hugoReaches\(state\.view\)/);
  assert.match(between('async function applyHugo(', 'function editHugoFilter('), /const target = hugoReaches\(wanted\) \? wanted : 'master';/);
});
