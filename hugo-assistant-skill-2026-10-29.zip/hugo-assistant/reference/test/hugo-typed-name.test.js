// VH-181: HUGO NARROWS A VIEW BY A TYPED NAME, ON EVERY DOMAIN.
//
// A company name is not a controlled value, so until this clause no vocabulary could admit it and the
// normaliser dropped it: "show me Flightradar24" came back as the whole domain. The clause is the board
// search box's own free text, so it is proved here end to end through the SHARED tool layer (the one the
// realtime relay, the agent route and the deterministic fallback all call), on all 7 stores in one database,
// rather than in the chat loop VH-318 retires.

import test from 'node:test';
import assert from 'node:assert/strict';

import { normaliseViewIntent, intentHasFilter } from '../src/hugo/view-intent.js';
import { buildIntentWhere } from '../src/hugo/query-plan.js';
import { resolveDeterministic } from '../src/hugo/deterministic.js';
import { createToolRunner } from '../src/hugo/tools.js';
import { createVendorRepo } from '../src/db/vendor-repo.js';
import { createDomainRepo } from '../src/db/domain-repo.js';
import { SPACE_DESCRIPTOR, AIR_DESCRIPTOR, domainIds, getDescriptor } from '../src/domain/descriptor.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';
import { hugoUnderstoodHtml, hugoSpokenSummary } from '../public/views/hugo-intent.js';

const IDS = domainIds();
const norm = (raw, descriptor = SPACE_DESCRIPTOR) => normaliseViewIntent(raw, descriptor, { domainIds: IDS });

test('VH-181: a typed name survives normalisation, folded to one line and bounded', () => {
  const { intent, unmapped } = norm({ filterSpec: { search: '  Flight\tradar\n24  ' } });
  assert.equal(intent.filterSpec.search, 'Flight radar 24');
  assert.deepEqual(unmapped, []);
  assert.equal(intentHasFilter({ filterSpec: { search: 'Airbus' } }), true, 'a name alone is a narrowing');
  assert.equal(intentHasFilter({ filterSpec: { search: '' } }), false);
  assert.equal(norm({ filterSpec: { search: 'x'.repeat(500) } }).intent.filterSpec.search.length, 120);
  assert.equal(norm({ filterSpec: { name: 'Thales' } }).intent.filterSpec.search, 'Thales', '`name` is read as a synonym');
  assert.equal('search' in norm({ filterSpec: { search: '   ' } }).intent.filterSpec, false, 'whitespace is no clause');
  const odd = norm({ filterSpec: { search: ['Airbus'] } });
  assert.equal('search' in odd.intent.filterSpec, false, 'a list is never coerced into a name');
  assert.deepEqual(odd.unmapped, [{ field: 'search', value: 'Airbus' }]);
});

test('VH-181: the Space plan matches the folded record with the wildcards escaped, through the stored fold where present', () => {
  const plan = buildIntentWhere({ search: '100%_Air' });
  assert.deepEqual(plan.applied, ['search']);
  assert.equal(plan.params.at(-1), String.raw`%100\%\_air%`);
  assert.ok(plan.sql.includes('vh_search_fold(lower(jsonb_path_query_array(data, '), 'the folded record projection');
  assert.match(plan.sql, /::text\)\) like vh_search_fold\(\$2\)$/, 'compared with the folded, bound pattern');
  assert.match(buildIntentWhere({ search: 'a' }, { storedFold: true }).sql, / search_fold like vh_search_fold\(\$2\)/);
  assert.doesNotMatch(buildIntentWhere({}).sql, /like/, 'no name, no LIKE');
});

test('VH-181: the offline resolver reads a quoted or "called" name, and not a bare capitalised word', () => {
  assert.equal(resolveDeterministic('show me "Flightradar24" on the map', AIR_DESCRIPTOR).raw.filterSpec.search, 'Flightradar24');
  assert.equal(resolveDeterministic('the firm called Open Sky Network', AIR_DESCRIPTOR).raw.filterSpec.search, 'Open Sky Network');
  const plain = resolveDeterministic('show me the UK vendors', AIR_DESCRIPTOR);
  assert.equal(plain.raw.filterSpec.search, '');
  assert.equal(resolveDeterministic('called Airbus', SPACE_DESCRIPTOR).resolved, true, 'a name alone resolves the question');
});

// The model-merge case went with the intent compiler, retired by VH-318-F: Hugo now reads a typed name through
// the shared tools on the Realtime session, which the query_records and propose_view case below proves.

test('VH-181: the review, the spoken summary and the not-applied chip all say the name', () => {
  const html = hugoUnderstoodHtml({ filterSpec: { search: '<Airbus>' }, view: 'board' });
  assert.match(html, /Name or text/);
  assert.match(html, /&lt;Airbus&gt;/, 'through the one escaper');
  assert.match(hugoSpokenSummary({ filterSpec: { search: 'Airbus' } }), /Name or text Airbus/);
});

// ---- End to end, all 7 stores in one database ------------------------------------------------------------

async function plantAll(executor) {
  const vendorRepo = createVendorRepo(executor);
  await vendorRepo.createVendor({ vendor_id: 'VH-0001', company: 'Flightradar Space', country: 'Sweden', grade: 'Unknown', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await vendorRepo.createVendor({ vendor_id: 'VH-0002', company: 'Other Space Firm', country: 'France', grade: 'Unknown', gdm: 'In GDM', section: 'EMSO', missions: ['EMSO'] }, 'seed');
  const repos = {};
  for (const id of IDS.filter((d) => d !== 'space')) {
    const d = getDescriptor(id);
    const repo = createDomainRepo(executor, d);
    await repo.upsert({ identity: { legal_name: 'Flightradar ' + d.label, website: 'https://fr-' + id + '.example', hq_country: 'Sweden' }, fields: {}, lines: [] }, 'test');
    await repo.upsert({ identity: { legal_name: 'Other ' + d.label + ' Firm', website: 'https://other-' + id + '.example', hq_country: 'France' }, fields: {}, lines: [] }, 'test');
    repos[id] = repo;
  }
  return { vendorRepo, domainRepoFor: (id) => repos[id] || null };
}

// The runner exactly as `src/index.js` composes it for the realtime relay: Space through the master, a domain
// through its own store.
const runnerFor = ({ vendorRepo, domainRepoFor }, defaultDomain) => createToolRunner({
  runQuery: async (intent, page) => {
    if (intent.domain === 'space') return vendorRepo.queryByIntent(intent.filterSpec, page);
    return domainRepoFor(intent.domain).queryProviders(intent.filterSpec, page);
  },
  vendorRepo, domainRepoFor, defaultDomain,
});

test('VH-181: query_records and propose_view narrow to a typed name on all 7 domains', async () => {
  const executor = await makePgliteExecutor();
  try {
    await runMigrations(executor);
    const stores = await plantAll(executor);
    assert.equal(IDS.length, 7, 'all seven, measured from the registry');
    for (const id of IDS) {
      const runner = runnerFor(stores, id);
      const all = await runner.run('count_records', { domain: id, filter: {} });
      assert.equal(all.result.total, 2, id + ': two records before the name');
      const named = await runner.run('query_records', { domain: id, filter: { search: 'flightRADAR' } });
      assert.equal(named.ok, true, id + ': ' + named.error);
      assert.equal(named.result.total, 1, id + ': the typed name narrows to its one record');
      assert.match(named.result.records[0].name, /^Flightradar /, id);
      assert.ok(named.result.applied.includes('search'), id + ': and says it applied the name');
      const offer = await runner.run('propose_view', { view: 'board', domain: id, filter: { name: 'Other' } });
      assert.equal(offer.result.total, 1, id + ': the view offer counts the named set before it is accepted');
      assert.equal(offer.result.intent.filterSpec.search, 'Other', id);
    }
  } finally { await executor.close(); }
});
