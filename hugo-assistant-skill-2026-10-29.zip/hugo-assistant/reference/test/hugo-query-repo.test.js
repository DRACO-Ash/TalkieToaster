// The Hugo query executor over real Postgres (pglite): a validated filterSpec runs as one server-side query
// on the live master and returns the matching rows, the total and the applied/notApplied report.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createVendorRepo } from '../src/db/vendor-repo.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';
import { createDataTypeRepo } from '../src/db/data-type-repo.js';

async function seedRepo() {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Alpha', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'Beta', country: 'France', grade: 'Ready for JCO', gdm: 'In GDM', section: 'EMSO', missions: ['EMSO'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0003', company: 'Gamma', country: 'United Kingdom', grade: 'Unknown', gdm: 'In GDM', section: 'P&D SDA', missions: ['PAIR'] }, 'seed');
  repo.executor = executor;
  return repo;
}

const names = (result) => result.rows.map((r) => r.record.company).sort();

test('an empty filterSpec returns the whole live master', async () => {
  const repo = await seedRepo();
  const r = await repo.queryByIntent({});
  assert.equal(r.total, 3);
  assert.deepEqual(names(r), ['Alpha', 'Beta', 'Gamma']);
});

test('a country clause narrows to that country', async () => {
  const repo = await seedRepo();
  const r = await repo.queryByIntent({ countries: ['United Kingdom'] });
  assert.equal(r.total, 2);
  assert.deepEqual(names(r), ['Alpha', 'Gamma']);
  assert.deepEqual(r.applied, ['countries']);
});

test('country AND gdm compose', async () => {
  const repo = await seedRepo();
  const r = await repo.queryByIntent({ countries: ['United Kingdom'], gdm: ['Not in GDM'] });
  assert.deepEqual(names(r), ['Alpha']);
});

test('an IN-list within a clause is a union ("UK or France")', async () => {
  const repo = await seedRepo();
  const r = await repo.queryByIntent({ countries: ['United Kingdom', 'France'] });
  assert.equal(r.total, 3);
});

test('a mission is Mission Alignment\'s: a data type carries it, and the stored section or list no longer matches (VH-801)', async () => {
  const repo = await seedRepo();
  // Beta's section is EMSO and Gamma's stored list holds PAIR: until VH-801 each matched. Neither supplies a data type.
  assert.deepEqual(names(await repo.queryByIntent({ missions: ['EMSO'] })), []);
  assert.deepEqual(names(await repo.queryByIntent({ missions: ['PAIR'] })), []);
  // Alpha supplies Synthetic Aperture Radar, which Mission Alignment gives PAIR.
  const { rows } = await repo.executor.query("select rev from vendor where vendor_id = 'VH-0001'");
  await repo.updateVendor('VH-0001', rows[0].rev, { product_types: ['Synthetic Aperture Radar'] }, 'seed');
  await createDataTypeRepo(repo.executor).alignment.setCells('space', [{ dataType: 'Synthetic Aperture Radar', mission: 'pair', on: true }], 'seed');
  assert.deepEqual(names(await repo.queryByIntent({ missions: ['PAIR'] })), ['Alpha']);
  assert.deepEqual(names(await repo.queryByIntent({ missions: ['pair', 'EMSO'] })), ['Alpha'], 'any of them, in any case');
});

test('a clause that resolves to nothing is reported and does not filter, other clauses still apply', async () => {
  // Until V1.82 this used `families: ['EO']`, which was DEFERRED: resolved, reported, never SQL. RT-Q4 wired
  // the five capability clauses, so the not-applied case is now a family the vocabulary does not cover - it
  // expands to no product type and is reported rather than bound as an empty list that would match nothing.
  const repo = await seedRepo();
  const r = await repo.queryByIntent({ families: ['NOT-A-FAMILY'], countries: ['France'] });
  assert.deepEqual(names(r), ['Beta']);
  assert.deepEqual(r.applied, ['countries']);
  assert.deepEqual(r.notApplied, ['families']);
});

test('a value matching nothing returns an empty set, not everything', async () => {
  const repo = await seedRepo();
  const r = await repo.queryByIntent({ countries: ['Atlantis'] });
  assert.equal(r.total, 0);
  assert.deepEqual(r.rows, []);
});

// W3: the filtered board is sortable and pageable, so a column header and the pager work under a Hugo filter.
const order = (result) => result.rows.map((r) => r.record.company);

test('a filtered board sorts by an allow-listed column and direction (W3)', async () => {
  const repo = await seedRepo(); // Alpha, Beta, Gamma
  const asc = await repo.queryByIntent({}, { sort: 'company', dir: 'asc' });
  assert.deepEqual(order(asc), ['Alpha', 'Beta', 'Gamma']);
  const desc = await repo.queryByIntent({}, { sort: 'company', dir: 'desc' });
  assert.deepEqual(order(desc), ['Gamma', 'Beta', 'Alpha']);
});

test('an unknown sort column falls back to the default, never reaching the SQL (W3)', async () => {
  const repo = await seedRepo();
  const r = await repo.queryByIntent({}, { sort: 'company); drop table vendor; --', dir: 'asc' });
  // The injection string is not an allow-listed column, so it defaults to company order; nothing is executed.
  assert.deepEqual(order(r), ['Alpha', 'Beta', 'Gamma']);
});

test('a filtered board pages with limit and offset under the sort (W3)', async () => {
  const repo = await seedRepo();
  const page2 = await repo.queryByIntent({}, { limit: 1, offset: 1, sort: 'company', dir: 'asc' });
  assert.deepEqual(order(page2), ['Beta']);
  assert.equal(page2.total, 3);
});

// H-4 governance backstop: a row EXPLICITLY tagged with an excluded eligibility disposition, or quarantined,
// never leaves through Hugo, and both the rows and the total reflect the exclusion (the clause is in the
// WHERE, so they cannot disagree). An untagged row admits (the vendor core is tracking data, not an
// eligibility-gated product line).
async function seedWithEligibility() {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Clean', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'Excluded', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0003', company: 'Quarantined', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await executor.query(`update vendor set data = data || '{"line_eligibility":"excluded-policy"}'::jsonb where vendor_id = 'VH-0002'`);
  await executor.query(`update vendor set data = data || '{"quarantined":true}'::jsonb where vendor_id = 'VH-0003'`);
  return repo;
}

test('an excluded-disposition row and a quarantined row are dropped; both rows and total reflect it', async () => {
  const repo = await seedWithEligibility();
  const r = await repo.queryByIntent({});
  assert.deepEqual(names(r), ['Clean']);
  assert.equal(r.total, 1);
});

test('the quarantined stop is fail-closed across encodings (W5)', async () => {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Clean', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'QBool', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0003', company: 'QNum', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0004', company: 'QFalse', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT', missions: ['TacSRT'] }, 'seed');
  await executor.query(`update vendor set data = data || '{"quarantined":true}'::jsonb where vendor_id = 'VH-0002'`);
  await executor.query(`update vendor set data = data || '{"quarantined":1}'::jsonb where vendor_id = 'VH-0003'`);
  await executor.query(`update vendor set data = data || '{"quarantined":false}'::jsonb where vendor_id = 'VH-0004'`);
  const r = await repo.queryByIntent({});
  // Clean (no tag) and QFalse (explicit false) admit; the boolean-true and the numeric-1 encodings both drop.
  assert.deepEqual(names(r), ['Clean', 'QFalse']);
  assert.equal(r.total, 2);
});

test('the eligibility backstop drops an excluded-adint row too', async () => {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Clean', country: 'France', grade: 'In JCO', gdm: 'In GDM', section: 'EMSO', missions: ['EMSO'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'Adint', country: 'France', grade: 'In JCO', gdm: 'In GDM', section: 'EMSO', missions: ['EMSO'] }, 'seed');
  await executor.query(`update vendor set data = data || '{"line_eligibility":"excluded-adint"}'::jsonb where vendor_id = 'VH-0002'`);
  const r = await repo.queryByIntent({ countries: ['France'] });
  assert.deepEqual(names(r), ['Clean']);
  assert.equal(r.total, 1);
});

test('analyticsReport aggregates over the filtered records when a clause is present (W2b)', async () => {
  const repo = await seedRepo(); // Alpha(UK), Beta(France), Gamma(UK)
  const all = await repo.analyticsReport({});
  assert.equal(all.metrics.total, 3);
  const france = await repo.analyticsReport({ filterSpec: { countries: ['France'] } });
  assert.equal(france.metrics.total, 1); // only Beta
  const uk = await repo.analyticsReport({ filterSpec: { countries: ['United Kingdom'] } });
  assert.equal(uk.metrics.total, 2); // Alpha and Gamma
});

test('analyticsReport returns an empty report for an unseeded domain (W2b)', async () => {
  const repo = await seedRepo();
  const empty = await repo.analyticsReport({ empty: true });
  assert.equal(empty.metrics.total, 0);
  assert.equal(empty.heat.total, 0);
});

test('analyticsReport applies the eligibility backstop on a deferred-only intent, not just when a clause applies (W2b)', async () => {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Clean', country: 'France', grade: 'In JCO', gdm: 'In GDM', section: 'EMSO', missions: ['EMSO'] }, 'seed');
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'Quar', country: 'France', grade: 'In JCO', gdm: 'In GDM', section: 'EMSO', missions: ['EMSO'] }, 'seed');
  await executor.query(`update vendor set data = data || '{"quarantined":true}'::jsonb where vendor_id = 'VH-0002'`);
  // A family the vocabulary does not cover: the filterSpec is real (Hugo is driving) but normalises to zero
  // APPLIED clauses (until V1.82 `families` itself was deferred and served this role). The report must still
  // run the query plan, which always carries the fail-closed quarantine and excluded-disposition backstop,
  // rather than fall to the un-backstopped cached whole-set path. So the quarantined row is not counted even
  // though nothing narrowed the set.
  const r = await repo.analyticsReport({ filterSpec: { families: ['NOT-A-FAMILY'] } });
  assert.equal(r.metrics.total, 1); // only Clean; Quar is dropped by the backstop
});

test('auditHugoQuery writes one hugo-query audit row with the resolved clauses, not the sentence', async () => {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  await repo.auditHugoQuery('ada', { domain: 'space', crossDomain: false, applied: ['countries'], notApplied: ['families'], total: 7 });
  const { rows } = await executor.query("select actor, action, entity, entity_id, detail from audit_log where action = 'hugo-query'");
  assert.equal(rows.length, 1);
  assert.equal(rows[0].actor, 'ada');
  assert.equal(rows[0].action, 'hugo-query');
  assert.equal(rows[0].entity_id, 'space');
  const detail = typeof rows[0].detail === 'string' ? JSON.parse(rows[0].detail) : rows[0].detail;
  assert.deepEqual(detail.applied, ['countries']);
  assert.deepEqual(detail.notApplied, ['families']);
  assert.equal(detail.total, 7);
  // The free-text sentence is never stored: the detail carries only resolved clause names and counts.
  assert.equal(JSON.stringify(detail).includes('sentence'), false);
});

// --- THE PIPELINE CLAUSES OVER REAL POSTGRES (V1.77 W1-3) -------------------------------------------------
//
// These run against pglite rather than pattern-matching the generated string, and that is the point: the
// clauses are correlated EXISTS subqueries over `gdm_pipeline` with a `make_interval` call, a
// `jsonb_array_elements` existence and a CASE over the coarse band. A string assertion would pass on SQL
// Postgres refuses to parse, and the one thing worth knowing about a query builder is whether the database
// accepts what it builds.
//
// THE CASE THESE EXIST FOR: A MEMBER WITH NO PIPELINE ROW STILL HAS A STAGE. `lazyBase` treats it as holding
// a row derived from the coarse band (In GDM -> live, Onboarding -> identified, otherwise unengaged), so a
// filter that consulted only stored rows would silently omit most of the dataset. VH-0002 below is In GDM
// with NO pipeline row, and it must answer a query for `live`.

async function seedPipelineRepo() {
  const executor = await makePgliteExecutor();
  await runMigrations(executor);
  const repo = createVendorRepo(executor);
  // VH-0001: Not in GDM, and given a STORED row in contracting, owned, blocked, overdue.
  await repo.createVendor({ vendor_id: 'VH-0001', company: 'Alpha', country: 'United Kingdom', grade: 'In JCO', gdm: 'Not in GDM', section: 'TacSRT' }, 'seed');
  // VH-0002: In GDM with NO pipeline row, so its stage is DERIVED as live. Made the way a record banded before V2.8
  // arose, by a band no writer enrolled: since V2.8 a banded create enrols the vendor (test/pipeline-enrol.test.js),
  // and this suite pins the derived path, which still serves such records.
  await repo.createVendor({ vendor_id: 'VH-0002', company: 'Beta', country: 'France', grade: 'Ready for JCO', gdm: 'Not in GDM', section: 'EMSO' }, 'seed');
  await executor.query("update vendor set gdm = 'In GDM', data = jsonb_set(data, '{gdm}', '\"In GDM\"') where vendor_id = 'VH-0002'", []);
  // VH-0003: Not in GDM with no row, so DERIVED as unengaged.
  await repo.createVendor({ vendor_id: 'VH-0003', company: 'Gamma', country: 'United Kingdom', grade: 'Unknown', gdm: 'Not in GDM', section: 'P&D SDA' }, 'seed');
  // The stored row, written directly: this suite is testing the READ path, and going through the pipeline
  // repository's own validation would test that instead. The values are the ones its writer produces.
  await executor.query(
    `insert into gdm_pipeline (domain, member_id, stage, owner, priority, due, blocked, blockers, stage_entered_at, stage_confidence)
     values ('space', 'VH-0001', 'contracting', 'ada', 'High', current_date - 3, true,
             '[{"kind":"legal","note":"counsel review"}]'::jsonb, now() - interval '90 days', 'confirmed')`,
    [],
  );
  return { repo, executor };
}

const idsOf = (res) => res.rows.map((r) => r.record.vendor_id).sort();

test('a stage query answers for BOTH a stored pipeline row and a derived one', async () => {
  const { repo } = await seedPipelineRepo();
  // The stored row's stage.
  assert.deepEqual(idsOf(await repo.queryByIntent({ stages: ['contracting'] })), ['VH-0001']);
  // The DERIVED stage of a member the pipeline has never been touched for. This is the assertion that would
  // have failed had the clause looked only at gdm_pipeline.
  assert.deepEqual(idsOf(await repo.queryByIntent({ stages: ['live'] })), ['VH-0002']);
  assert.deepEqual(idsOf(await repo.queryByIntent({ stages: ['unengaged'] })), ['VH-0003']);
  // A stored row's stage WINS over the band it would otherwise derive: VH-0001 is Not in GDM, which derives
  // to unengaged, and it is not in that answer above because its stored stage is contracting.
  const both = await repo.queryByIntent({ stages: ['contracting', 'live'] });
  assert.deepEqual(idsOf(both), ['VH-0001', 'VH-0002']);
  assert.deepEqual(both.applied, ['stages']);
});

test('owners, priorities, blocker kinds and due windows match stored rows exactly', async () => {
  const { repo } = await seedPipelineRepo();
  assert.deepEqual(idsOf(await repo.queryByIntent({ owners: ['ada'] })), ['VH-0001']);
  assert.deepEqual(idsOf(await repo.queryByIntent({ owners: ['nobody'] })), []);
  assert.deepEqual(idsOf(await repo.queryByIntent({ priorities: ['High'] })), ['VH-0001']);
  assert.deepEqual(idsOf(await repo.queryByIntent({ priorities: ['Low'] })), []);
  // The blocker kind is read from inside the blockers array, so an entry with extra keys still matches.
  assert.deepEqual(idsOf(await repo.queryByIntent({ blockerKinds: ['legal'] })), ['VH-0001']);
  assert.deepEqual(idsOf(await repo.queryByIntent({ blockerKinds: ['security'] })), []);
  // `due` is a relative window resolved by the database's own clock.
  assert.deepEqual(idsOf(await repo.queryByIntent({ due: 'overdue' })), ['VH-0001']);
  assert.deepEqual(idsOf(await repo.queryByIntent({ due: 'today' })), []);
  // "nobody has scheduled it" is a different question from "not overdue", and it is the members with no
  // stored row plus any stored row with a null due date.
  assert.deepEqual(idsOf(await repo.queryByIntent({ due: 'none' })), []);
});

test('blocked is a tristate, and "not blocked" includes the members with no pipeline row at all', async () => {
  const { repo } = await seedPipelineRepo();
  assert.deepEqual(idsOf(await repo.queryByIntent({ blocked: true })), ['VH-0001']);
  // The assertion that pins the NEGATED existence: written as "exists a row with blocked = false" this
  // would have returned nothing at all, because the two unblocked members have no row to carry the false.
  assert.deepEqual(idsOf(await repo.queryByIntent({ blocked: false })), ['VH-0002', 'VH-0003']);
  // Absent means "do not filter on it", which is the third state and the reason this is not a boolean.
  assert.equal((await repo.queryByIntent({})).rows.length, 3);
});

test('ageing measures days in stage, from the stored entry or the record update where there is none', async () => {
  const { repo, executor } = await seedPipelineRepo();
  // The stored row entered its stage 90 days ago.
  assert.deepEqual(idsOf(await repo.queryByIntent({ ageingDays: 30 })), ['VH-0001']);
  assert.deepEqual(idsOf(await repo.queryByIntent({ ageingDays: 365 })), []);
  // The derived fallback: age a record's own updated_at and it answers the same question. This is the stated
  // approximation (see the note in src/hugo/query-plan.js) rather than a stage entry the data does not hold.
  await executor.query("update vendor set updated_at = now() - interval '200 days' where vendor_id = 'VH-0003'", []);
  assert.deepEqual(idsOf(await repo.queryByIntent({ ageingDays: 100 })), ['VH-0003']);
});

test('pipeline clauses compose with the ordinary ones, and the bound parameters stay in step', async () => {
  const { repo } = await seedPipelineRepo();
  // A country clause is pushed BEFORE the pipeline domain, so every pipeline parameter index shifts. If the
  // indices were fixed rather than computed this query would bind the wrong values or refuse to parse.
  const res = await repo.queryByIntent({ countries: ['United Kingdom'], stages: ['contracting'] });
  assert.deepEqual(idsOf(res), ['VH-0001']);
  assert.deepEqual(res.applied, ['countries', 'stages']);
  // France is not the country, so the same stage yields nothing: both clauses are ANDed, not ORed.
  assert.deepEqual(idsOf(await repo.queryByIntent({ countries: ['France'], stages: ['contracting'] })), []);
  // Every clause at once, which is the shape that would expose an index or an alias mistake.
  const all = await repo.queryByIntent({
    // `grades` was in this list until V1.80 deleted the clause from the query plan. `gdm` takes its
    // place so the "every clause at once" shape stays a full one - with the value the fixture actually
    // holds for VH-0001, which is 'Not in GDM'. Measured, not assumed: 'In GDM' matches VH-0002, and
    // this query must still resolve to the one row every other clause here selects.
    countries: ['United Kingdom'], gdm: ['Not in GDM'], stages: ['contracting'], owners: ['ada'],
    priorities: ['High'], blockerKinds: ['legal'], due: 'overdue', blocked: true, ageingDays: 30,
  });
  assert.deepEqual(idsOf(all), ['VH-0001']);
  assert.deepEqual(all.applied,
    ['countries', 'gdm', 'stages', 'blockerKinds', 'priorities', 'owners', 'due', 'blocked', 'ageingDays']);
});
