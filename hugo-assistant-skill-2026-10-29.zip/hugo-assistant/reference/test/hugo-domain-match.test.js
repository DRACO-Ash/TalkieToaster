// VH-232: HUGO'S MATCH TOOLS READ A DOMAIN RECORD'S OWN NAME AND COUNTRY. The comparators read `company` and
// `country`, the Space row's field names; a domain record carries `legal_name` (or `name`) and `hq_country`.
// Measured before the fix on two domain records with the same name and country: `explain_match` scored name
// and country "missing", leaving the website as the one feature compared, and `find_similar` reported
// agreements ["host"] alone. The domain repository already had the mapping for its ingest path; it was not
// reused here (VH-220 audit, A8).
import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner } from '../src/hugo/tools.js';

const A = { provider_key: 'host:acme.example', air_id: 'host:acme.example', name: 'Acme Air Ltd', hq_country: 'Norway', website: 'acme.example' };
const B = { provider_key: 'host:acme2.example', air_id: 'host:acme2.example', legal_name: 'Acme Air Ltd', hq_country: 'Norway', website: 'acme.example' };
const RECORDS = { [A.provider_key]: A, [B.provider_key]: B };

const runner = () => createToolRunner({
  runQuery: async () => ({ rows: [B], total: 1 }),
  vendorRepo: {},
  domainRepoFor: () => ({ get: async (id) => RECORDS[id] || null }),
  defaultDomain: 'air',
});

test('explain_match compares a domain record\'s name and country, not "missing"', async () => {
  const out = await runner().run('explain_match', { domain: 'air', idA: A.provider_key, idB: B.provider_key });
  assert.equal(out.ok, true);
  assert.notEqual(out.result.features.name, 'missing', 'name was compared: ' + JSON.stringify(out.result.features));
  assert.notEqual(out.result.features.country, 'missing', 'country was compared: ' + JSON.stringify(out.result.features));
});

test('find_similar counts a domain record\'s name and country among its agreements', async () => {
  const out = await runner().run('find_similar', { domain: 'air', id: A.provider_key });
  const top = out.result.candidates[0];
  assert.ok(top, 'a candidate came back');
  assert.ok(top.agreements.length > 1, 'more than the website agreed: ' + JSON.stringify(top.agreements));
});

test('what the model is shown is the record as stored, not the matcher\'s field names', async () => {
  const out = await runner().run('find_similar', { domain: 'air', id: A.provider_key });
  assert.equal(out.result.base.company, undefined, 'no `company` key leaks into a domain record: ' + JSON.stringify(out.result.base));
});
