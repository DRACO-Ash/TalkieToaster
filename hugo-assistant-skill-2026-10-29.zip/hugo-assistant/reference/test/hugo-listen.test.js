// VH-318-F: Whisper retired; "Hey Hugo" moves onto a Realtime transcription-only session (gpt-live-transcribe,
// falling back to gpt-transcribe), and the paid always-on listener stays OFF until its price per hour is read.
// The relay is driven with a fake socket pair and the client listener with fake media, so nothing touches a
// network or a microphone.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import {
  createRealtimeBridge, buildTranscriptionSessionUpdate, transcriptionRefused, realtimeModeFromUrl,
  DEFAULT_TRANSCRIPTION_MODEL, FALLBACK_TRANSCRIPTION_MODEL,
} from '../src/hugo/openai-realtime.js';
import { listeningPrice, LISTENING_USD_PER_HOUR, PRICING_BY_MODEL } from '../src/scan/cost.js';
import { listenUrl, heardText, startLiveListener } from '../public/views/hugo-stream.js';

function mkSocket() {
  const handlers = {};
  return {
    sent: [], closed: false,
    on(ev, cb) { if (!handlers[ev]) { handlers[ev] = []; } handlers[ev].push(cb); return this; },
    send(data) { this.sent.push(data); },
    close() { this.closed = true; },
    emit(ev, data) { for (const cb of handlers[ev] || []) cb(data); },
  };
}
function bridgeWith(opts) {
  let upstream = null;
  let url = '';
  const booked = [];
  const bridge = createRealtimeBridge({ apiKey: 'sk', model: 'gpt-realtime-2', wsFactory: (u) => { url = u; upstream = mkSocket(); return upstream; }, onUsage: (u, m) => booked.push(m) });
  const client = mkSocket();
  bridge.connect(client, opts);
  upstream.emit('open');
  const sentUp = () => upstream.sent.map((t) => JSON.parse(t));
  return { client, booked, sentUp, get url() { return url; }, up: (o) => upstream.emit('message', JSON.stringify(o)), get upstream() { return upstream; } };
}

test('Whisper is retired: the operator\'s speech is transcribed by gpt-live-transcribe, with "Hugo" as a keyword', () => {
  assert.equal(DEFAULT_TRANSCRIPTION_MODEL, 'gpt-live-transcribe');
  assert.equal(FALLBACK_TRANSCRIPTION_MODEL, 'gpt-transcribe');
  const talk = bridgeWith({});
  assert.deepEqual(talk.sentUp()[0].session.audio.input.transcription, { model: 'gpt-live-transcribe', keywords: ['Hugo', 'Hey Hugo'] });
});

test('the listener is a TRANSCRIPTION session: no model in the URL, no replies, no tools', () => {
  assert.deepEqual(buildTranscriptionSessionUpdate(), {
    type: 'session.update',
    session: {
      type: 'transcription',
      audio: {
        input: {
          format: { type: 'audio/pcm', rate: 24000 },
          transcription: { model: 'gpt-live-transcribe', keywords: ['Hugo', 'Hey Hugo'] },
          turn_detection: { type: 'server_vad' },
          noise_reduction: { type: 'far_field' },
        },
      },
    },
  });
  const h = bridgeWith({ mode: 'listen' });
  assert.match(h.url, /\?intent=transcription$/);
  assert.equal(h.sentUp()[0].session.type, 'transcription');
  h.upstream.sent.length = 0;
  // The listener only streams the microphone: a typed turn, a response or a commit from the browser goes nowhere.
  h.client.emit('message', JSON.stringify({ type: 'conversation.item.create', item: { type: 'message', role: 'user', content: [{ type: 'input_text', text: 'hi' }] } }));
  h.client.emit('message', JSON.stringify({ type: 'response.create' }));
  h.client.emit('message', JSON.stringify({ type: 'input_audio_buffer.commit' }));
  assert.deepEqual(h.sentUp(), []);
  h.client.emit('message', JSON.stringify({ type: 'input_audio_buffer.append', audio: 'AAAA' }));
  assert.deepEqual(h.sentUp(), [{ type: 'input_audio_buffer.append', audio: 'AAAA' }]);
  // What it hears is booked at the transcription model, by the second if that is how it is billed.
  h.up({ type: 'conversation.item.input_audio_transcription.completed', transcript: 'hey hugo', usage: { type: 'duration', seconds: 2 } });
  assert.deepEqual(h.booked, ['gpt-live-transcribe']);
});

test('a refused transcription model falls back to gpt-transcribe once, on either session, and books at it', () => {
  for (const mode of ['talk', 'listen']) {
    const h = bridgeWith({ mode });
    h.upstream.sent.length = 0;
    h.up({ type: 'error', error: { type: 'invalid_request_error', code: 'invalid_value', param: 'session.audio.input.transcription.model' } });
    const again = h.sentUp();
    assert.equal(again.length, 1, mode + ': the session is reconfigured once');
    assert.equal(again[0].session.audio.input.transcription.model, 'gpt-transcribe', mode);
    h.up({ type: 'error', error: { code: 'model_not_found' } });
    assert.equal(h.sentUp().length, 1, mode + ': no second fallback, no loop');
    h.up({ type: 'conversation.item.input_audio_transcription.completed', usage: { type: 'tokens', input_tokens: 3, output_tokens: 1 } });
    assert.deepEqual(h.booked, ['gpt-transcribe'], mode);
  }
  assert.equal(transcriptionRefused({ type: 'error', error: { code: 'rate_limit_exceeded' } }), false, 'not every error is the model');
  assert.equal(transcriptionRefused({ type: 'response.done' }), false);
});

test('the upgrade names its mode; anything but listen is Talk', () => {
  assert.equal(realtimeModeFromUrl('/api/v3/hugo/realtime?domain=air&mode=listen'), 'listen');
  for (const u of ['/api/v3/hugo/realtime?domain=air', '/x?mode=LISTEN', '/x?mode=talk', '::bad']) assert.equal(realtimeModeFromUrl(u), 'talk', u);
});

// SWITCHED ON BY THE OWNER, 2026-10-19 (VH-769, "Switch on paid listener"). The hour is the per-minute row times 60, so
// the figure beside the tickbox and the rate the ledger books cannot drift apart; anything but a finite, positive
// figure still turns the listener off.
test('THE PAID LISTENER IS PRICED AT ITS PER-MINUTE RATE TIMES 60, and an unreadable figure still fails closed', () => {
  assert.equal(LISTENING_USD_PER_HOUR, 1.02, 'TBC, re-verify against OpenAI\'s list');
  assert.ok(Math.abs(LISTENING_USD_PER_HOUR - PRICING_BY_MODEL['gpt-live-transcribe'].perSecond * 3600) < 1e-9, 'the hour the ledger books');
  assert.deepEqual(listeningPrice(), { priced: true, usdPerHour: 1.02 });
  assert.deepEqual(listeningPrice(null), { priced: false, usdPerHour: null });
  // `undefined` is the default parameter, so it reads the written price; `null` above is the unwritten one.
  for (const bad of [0, -1, Number.NaN, Number.POSITIVE_INFINITY, '1.2']) assert.equal(listeningPrice(bad).priced, false, String(bad));
  assert.deepEqual(listeningPrice(1.2), { priced: true, usdPerHour: 1.2 });
  // Wired: the upgrade listener hands this price to the gate (VH-523 moved the gate to its own module, where
  // test/realtime-upgrade-gate.test.js proves the 503 comes before any credential is checked or socket dialled).
  const src = readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
  assert.match(src, /listeningPriced: \(\) => listeningPrice\(\)\.priced,/, 'refused at the upgrade (wired)');
});

// ---- the client listener

function fakeMedia() {
  const tracks = [{ stopped: false, stop() { this.stopped = true; } }];
  return { tracks, getTracks: () => tracks };
}
function fakeCtx(log) {
  return class {
    constructor(o) { log.ctx = { rate: o?.sampleRate, closed: false }; }
    get sampleRate() { return 48000; }
    createMediaStreamSource() { return { connect: () => { log.sourceConnected = true; } }; }
    createScriptProcessor() { const p = { connect: () => {}, disconnect: () => { log.procDisconnected = true; } }; log.proc = p; return p; }
    get destination() { return {}; }
    close() { log.ctx.closed = true; }
  };
}
const codec = { floatToPcm16: (f) => f, bytesToBase64: (b) => 'B64:' + b.length, createResampler: (rate) => (f) => (rate === 48000 ? f.filter((_, i) => i % 2 === 0) : f) };

test('the client listener streams the microphone once open, hears transcripts, and stop() releases everything', async () => {
  const log = {};
  const media = fakeMedia();
  const ws = { readyState: 0, sent: [], send(d) { this.sent.push(JSON.parse(d)); }, close() { this.closed = true; this.onclose?.(); } };
  const heard = [];
  let ended = 0;
  const rec = await startLiveListener({
    makeSocket: (url) => { ws.url = url; return ws; }, url: listenUrl('https://vh.example', 'cyber'),
    getUserMedia: async (c) => { log.asked = c; return media; }, AudioContext: fakeCtx(log), codec,
    onHeard: (t) => heard.push(t), onEnd: () => { ended += 1; },
  });
  assert.equal(rec.live, true);
  assert.equal(ws.url, 'wss://vh.example/api/v3/hugo/realtime?domain=cyber&voice=marin&mode=listen');
  assert.deepEqual(log.asked, { audio: true });
  assert.equal(log.ctx.rate, undefined, 'the engine runs at the device rate (VH-764)');
  ws.readyState = 1;
  ws.onopen();
  log.proc.onaudioprocess({ inputBuffer: { getChannelData: () => [0, 0, 0, 0] } });
  assert.deepEqual(ws.sent, [{ type: 'input_audio_buffer.append', audio: 'B64:2' }], 'a 48 kHz frame is sent at 24 kHz');
  ws.onmessage({ data: JSON.stringify({ type: 'conversation.item.input_audio_transcription.completed', transcript: ' Hey Hugo, which vendors? ' }) });
  ws.onmessage({ data: JSON.stringify({ type: 'input_audio_buffer.speech_started' }) });
  ws.onmessage({ data: 'not json' });
  assert.deepEqual(heard, ['Hey Hugo, which vendors?']);
  rec.stop();
  rec.stop();
  assert.equal(media.tracks[0].stopped, true, 'the microphone is released');
  assert.equal(ws.closed, true);
  assert.equal(log.ctx.closed, true);
  assert.equal(log.procDisconnected, true);
  assert.equal(ended, 0, 'a stop the operator asked for is not an unexpected end');
  log.proc.onaudioprocess({ inputBuffer: { getChannelData: () => [0] } });
  assert.equal(ws.sent.length, 1, 'nothing streams after stop');
});

test('the client listener says when the session ends by itself, and never leaves the microphone open on a failed start', async () => {
  const log = {};
  const media = fakeMedia();
  const ws = { readyState: 1, send() {}, close() {} };
  let ended = 0;
  await startLiveListener({ makeSocket: () => ws, url: 'u', getUserMedia: async () => media, AudioContext: fakeCtx(log), codec, onHeard: () => {}, onEnd: () => { ended += 1; } });
  ws.onclose(); // refused at the upgrade (503 until priced), capped, or dropped
  assert.equal(ended, 1);
  assert.equal(media.tracks[0].stopped, true);
  await assert.rejects(() => startLiveListener({ makeSocket: () => ws, url: 'u', getUserMedia: async () => { throw new Error('denied'); }, AudioContext: fakeCtx({}), codec, onHeard: () => {} }), /denied/);
  const media2 = fakeMedia();
  await assert.rejects(() => startLiveListener({ makeSocket: () => { throw new Error('no socket'); }, url: 'u', getUserMedia: async () => media2, AudioContext: fakeCtx({}), codec, onHeard: () => {} }), /no socket/);
  assert.equal(media2.tracks[0].stopped, true, 'the microphone is released when the session cannot start');
  assert.equal(heardText('{"type":"conversation.item.input_audio_transcription.completed","transcript":7}'), '');
});

// A SPEECH API WITH NO SERVICE BEHIND IT IS NOT A MISSING MICROPHONE (VH-764). DuckDuckGo and other Chromium builds
// without Google's speech service, and embedded WebKit, carry the API and fail every start (measured with a stand-in in
// `e2e/probe.mjs`: error `network`, then an end). The back-off then said "the microphone is not available" and the chip
// still read "Listens on this device, free". Now the failure's code decides the words, and the engine stops being
// `local`, so the tickbox, its note and the chip say what this browser can really do. Red: any of the 4 lines reverted.
test('a recogniser that fails for want of a speech service is named as such, and the tickbox stops offering it', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(src, /if \(speechRecognitionCtor\(\) && !hugoWakeNoService\) return 'local';/);
  assert.match(src, /const Ctor = !hugoWakeNoService && speechRecognitionCtor\(\);/);
  assert.match(src, /rec\.onerror = \(e\) => \{ failed = String\(e\?\.error\); \};/);
  const backOff = src.slice(src.indexOf('if (restarts > WAKE_RESTART_LIMIT) {'), src.indexOf('startedAt = Date.now();\n      try { rec.start()'));
  assert.match(backOff, /hugoWakeNoService = \/network\|service\|language\/\.test\(failed\);/);
  assert.match(backOff, /no speech service for "Hey Hugo"\. ' \+ instead/);
  // Where the paid listener is offered, the notice points at its note rather than saying Talk is all there is (VH-769).
  assert.match(backOff, /const instead = wakeEngine\(\) === 'live' \? 'It can listen through a paid live session: read the note by the tickbox first\.' : 'Use Talk instead\.';/);
  assert.match(backOff, /showHugoWakeIfSupported\(\);/);
});

// NOBODY TICKS IT WITHOUT SEEING WHAT IT SENDS AND COSTS (owner, VH-769). The note sits beside the tickbox, in the row
// that is drawn before anything is ticked, and says in plain words that every sound in the room goes to OpenAI and the
// price an hour, read from the probe. Red: either phrase or the price taken out.
test('the paid listener\'s note says every sound in the room goes to OpenAI, and what an hour costs (VH-769)', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const note = src.slice(src.indexOf("live: 'This browser cannot listen on its own"), src.indexOf("unpriced: 'This browser cannot listen on its own"));
  assert.match(note, /While this is ticked, '\n\s+\+ 'every sound in the room goes to OpenAI, at up to \$' \+ Number\(hugoListener\?\.usdPerHour\)\.toFixed\(2\) \+ ' an hour\.',/);
  assert.match(src, /if \(el\.hugoWakeNote\) \{/, 'the note is painted with the row, before any tick');
});

test('the shell: Speak and the server wake engine are gone; the tickbox is live only where the listener is priced (wired)', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  assert.doesNotMatch(html, /id="hugo-mic"/);
  for (const gone of ['api.hugoStt', 'startServerWake', 'toggleHugoMic', 'transcribeAndAsk']) assert.ok(!src.includes(gone), gone);
  assert.match(src, /return hugoListener \? 'live' : 'unpriced';/);
  assert.match(src, /el\.hugoWake\.disabled = engine !== 'local' && engine !== 'live';/);
  assert.match(src, /stays off until '\n {8}\+ 'its price per hour has been read\. Use Talk instead\.'/);
  assert.match(src, /hugoListener = res\.ok && res\.listener\?\.available === true \? res\.listener : null;/);
  const api = readFileSync(new URL('../public/api-v3.js', import.meta.url), 'utf8');
  for (const gone of ['/api/v3/hugo/stt', '/api/v3/hugo/chat', '/api/v3/hugo/compile']) assert.ok(!api.includes(gone), gone);
});
