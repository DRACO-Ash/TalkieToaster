// VH-765: HUGO ASKED ACROSS EVERY DOMAIN, the phone's Hugo (the owner's rule: "a HUGO interface that allows questions to be
// asked across all domains"; his brief: "short, plain English"). The route takes `domain: "all"` only as that exact word,
// reads the question in each domain's own vocabulary, and names the domain beside every figure. VH-280 still holds: a
// missing or empty domain is refused with the reason, so "all" is never the silent default.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';
import { deterministicAnswerAll } from '../src/hugo/agent.js';
import { domainIds } from '../src/domain/descriptor.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';
const verify = createStaticVerifier({ 'agent-tok': { subject: 'ada', roles: ['agent'] } });
const agent = { authorization: 'Bearer agent-tok' };
const AGENT = '/api/v3/hugo/agent';

function listen(handler) {
  return new Promise((resolve) => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => resolve(s)); });
}
function post(server, body) {
  const { port } = server.address();
  const payload = JSON.stringify(body);
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: AGENT, method: 'POST', headers: { 'content-type': 'application/json', ...agent } }, (res) => {
      let text = '';
      res.on('data', (c) => { text += c; });
      res.on('end', () => { let p = null; try { p = JSON.parse(text); } catch { p = null; } resolve({ status: res.statusCode, payload: p }); });
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

// Space holds two vendors in Norway; Maritime holds one; the other five stores are not set up here, so they answer none.
const SPACE = [
  { rev: 1, record: { vendor_id: 'VH-0001', company: 'Example vendor A', country: 'Norway', gdm: 'Not in GDM' } },
  { rev: 1, record: { vendor_id: 'VH-0002', company: 'Example vendor B', country: 'Norway', gdm: 'Not in GDM' } },
];
const MARITIME = [{ provider_key: 'MAR-0001', legal_name: 'Example vendor C', hq_country: 'Norway' }];

function app() {
  const seen = { audit: null, asked: [] };
  const vendorRepo = {
    queryByIntent: async (spec, page) => { seen.asked.push('space'); return { rows: SPACE.slice(0, page.limit), total: SPACE.length, applied: ['countries'], notApplied: [] }; },
    getVendor: async () => null,
    auditHugoChat: async (actor, detail) => { seen.audit = { actor, detail }; },
    auditHugoQuery: async () => {},
  };
  const domainRepoFor = (id) => (id === 'maritime' ? {
    queryProviders: async (spec, page) => { seen.asked.push('maritime'); return { rows: MARITIME.slice(0, page.limit), total: MARITIME.length, applied: ['countries'], notApplied: [] }; },
  } : null);
  return { handler: createApp({ env: {}, vendorRepo, domainRepoFor, verify, allowedOrigin: ORIGIN }), seen };
}
const turn = (domain) => ({ messages: [{ role: 'user', content: 'vendors in Norway' }], domain });

test('"all" answers across every domain, names each domain with its count, and tags every reference with its domain', async () => {
  const { handler, seen } = app();
  const server = await listen(handler);
  try {
    const res = await post(server, turn('all'));
    assert.equal(res.status, 200);
    const out = res.payload;
    assert.equal(out.scope, 'all');
    assert.equal(out.answer, '3 companies match. Space: 2 [R1] [R2]. Maritime: 1 [R3]. The other 5 domains have none.');
    assert.deepEqual(out.citations.map((c) => [c.ref, c.id, c.domain]), [[1, 'VH-0001', 'space'], [2, 'VH-0002', 'space'], [3, 'MAR-0001', 'maritime']]);
    assert.deepEqual(seen.asked, ['space', 'maritime'], 'each set-up store is asked once');
    assert.equal(out.steps.length, domainIds().length, 'one lookup per domain, shown in the trail');
    assert.equal(seen.audit.detail.domain, 'all', 'the audit row says the turn spanned every domain');
  } finally { server.close(); }
});

test('VH-280 holds: a missing, empty or near-miss domain is refused, never read as "all"', async () => {
  const { handler } = app();
  const server = await listen(handler);
  try {
    for (const domain of [undefined, '', 'All', ' all', 'everything']) {
      const res = await post(server, turn(domain));
      assert.equal(res.status, 400, JSON.stringify(domain));
    }
  } finally { server.close(); }
});

test('the all-domains answer is short and plain whatever comes back', async () => {
  const runner = (results) => {
    const refs = [];
    return {
      ledger: { get refs() { return refs.map((r) => ({ ...r })); } },
      run: async (name, args) => {
        const r = results[args.domain];
        if (r === 'fail') return { ok: false, error: 'store down' };
        const records = (r?.ids || []).map((id) => { refs.push({ ref: refs.length + 1, id, name: id, domain: args.domain }); return { ref: refs.length, id }; });
        return { ok: true, result: { total: r?.total ?? records.length, records } };
      },
    };
  };
  const domains = ['space', 'air', 'maritime'];
  const none = await deterministicAnswerAll({ runner: runner({}), question: 'vendors in Norway', domains });
  assert.equal(none.answer, 'No companies match in any of the 3 domains.');
  const one = await deterministicAnswerAll({ runner: runner({ air: { ids: ['A1'] } }), question: 'vendors in Norway', domains });
  assert.equal(one.answer, '1 company matches. Air: 1 [R1]. The other 2 domains have none.');
  const capped = await deterministicAnswerAll({ runner: runner({ space: { ids: ['S1'], total: 24 }, air: 'fail' }), question: 'vendors in Norway', domains });
  assert.equal(capped.answer, '24 companies match. Space: 24 (showing 1) [R1]. The other 1 domain has none. Air could not be read.');
  const price = await deterministicAnswerAll({ runner: runner({}), question: 'how much does it cost?', domains });
  assert.match(price.answer, /no prices or costs/);
  // VH-777: "hello there" is a greeting now, answered by the floor (test/hugo-agent.test.js), so the unreadable case is another sentence.
  const unread = await deterministicAnswerAll({ runner: runner({}), question: 'tell me a joke', domains });
  assert.match(unread.answer, /^I could not read that as a question about the dataset\./);
});
