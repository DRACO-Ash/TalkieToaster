// ALL DOMAINS TREATED EQUALLY (VH-320, owner, 2026-09-29): HUGO'S FILTER NARROWS A DOMAIN DASHBOARD. It narrowed the
// store's Analytics and board but not its Dashboard, whose banner was hidden there; measured on the seeded app before
// the change: "providers in Norway" on Air left the Air Dashboard at "2 vendors tracked" with the banner hidden. The
// Dashboard now draws the store's matches alone. The halves in the deferred module `public/views/domain-board-more.js`
// are driven here with a stub shell, on every product-line store (VH-341: this was Air and Cyber); the browser half,
// on Space, Air and Cyber, is `e2e/domain-equal-pass.mjs`.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { ensureDomainHugoRows, domainDashState, domainAnFor, domainReadFailedHtml } from '../public/views/domain-board-more.js';
import { hugoDashboardPhase } from '../public/views/hugo-intent.js';
import { buildDashboardHtml } from '../public/views/dashboard-v3.js';
import { domainIds } from '../src/domain/descriptor.js';

// EVERY product-line store, from the registry rather than typed in (VH-341).
const STORES = domainIds().filter((id) => id !== 'space');

const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');

// A store of three analysed records; Hugo matches the ids it is given. `hugoStatus` refuses the match read.
function shellFor(domain, { matches = [], hugoStatus = 200, gen = 1 } = {}) {
  const idCol = domain + '_id';
  const records = ['a', 'b', 'c'].map((k) => ({ vendor_id: 'host:' + k + '.example', company: k.toUpperCase(), country: 'Norway', gdm: 'In GDM' }));
  const asked = { hugo: 0, store: 0, exports: [] };
  const toasts = [];
  const downloads = [];
  let generation = gen;
  const shell = {
    state: { token: 't', domain, hugoFilter: { filterSpec: { countries: ['Norway'] } }, domainAn: null },
    hugoGen: () => generation,
    bump: () => { generation += 1; },
    providerRowId: (p) => p[idCol],
    toast: (msg, tone) => toasts.push({ msg, tone }),
    api: {
      hugoQuery: async () => {
        asked.hugo += 1;
        if (hugoStatus !== 200) return { status: hugoStatus, payload: null };
        return { status: 200, payload: { rows: matches.map((m) => ({ [idCol]: m })), total: matches.length, notApplied: [] } };
      },
      domainAnalytics: async () => { asked.store += 1; return { status: 200, payload: { rows: records, entries: [] } }; },
      domainExport: async (token, d, opts) => { asked.exports.push({ d, ...opts }); return shell.exportAnswer; },
    },
    exportAnswer: { ok: true, blob: 'BLOB', cutAt: 0 },
  };
  return { shell, asked, toasts, downloads, download: (blob, name) => downloads.push({ blob, name }) };
}

for (const domain of STORES) {
  test(`VH-320: Hugo's filter narrows the ${domain} Dashboard to the store's matches`, async () => {
    const { shell, asked } = shellFor(domain, { matches: ['host:a.example', 'host:c.example'] });
    const held = await ensureDomainHugoRows(shell);
    assert.equal(held.failed, false);
    assert.deepEqual(held.rows.map((r) => r.record.vendor_id), ['host:a.example', 'host:c.example']);
    const dash = domainDashState(shell.state, shell.state.domainAn, { label: 'X' });
    assert.equal(dash.allRows.length, 2, 'the Dashboard draws the matches alone');
    assert.equal(dash.hugoActive, true, 'and its growth trend says it is the whole store\'s');
    assert.equal(shell.state.hugoFilter.total, 2, 'the banner gets the match count');
    // Held for its generation: a second paint reads nothing again.
    await ensureDomainHugoRows(shell);
    assert.equal(asked.hugo, 1);
    // Cleared, the whole store again.
    shell.state.hugoFilter = null;
    const whole = domainDashState(shell.state, shell.state.domainAn, { label: 'X' });
    assert.equal(whole.allRows.length, 3);
    assert.equal(whole.hugoActive, false);
  });
}

test('VH-320: a refused match read is answered as refused and read again, and a newer filter never takes an older one\'s rows', async () => {
  for (const domain of STORES) {
    const refused = shellFor(domain, { hugoStatus: 500 });
    const held = await ensureDomainHugoRows(refused.shell);
    assert.equal(held.failed, true, domain);
    assert.equal(held.status, 500, domain);
    assert.deepEqual(held.rows, [], domain);
    // Try again reads again rather than repainting the refusal.
    await ensureDomainHugoRows(refused.shell);
    assert.equal(refused.asked.hugo, 2, domain);
    // The filter moves on while the read is in flight: the answer is dropped.
    const moved = shellFor(domain, { matches: ['host:a.example'] });
    const reading = ensureDomainHugoRows(moved.shell);
    moved.shell.bump();
    assert.equal(await reading, null, domain);
    assert.equal(domainAnFor(moved.shell, domain).hugo, undefined, domain);
  }
  // And the shell draws the refusal rather than an empty Dashboard, and lets the banner reach a domain Dashboard.
  assert.match(app, /if \(d\.rowsFailed \|\| hugo\?\.failed\) \{ el\.view\.innerHTML = await readFailedHtml\(descriptor, hugo\?\.failed \? hugo\.status : 500, 'dashboard'\)/);
  assert.match(app, /function hugoReaches\(view\) \{\n {2}return HUGO_VIEWS\.has\(view\);\n\}/);
});


// VH-324: SPACE'S DASHBOARD UNDER A REFUSED HUGO READ IS A REFUSED DASHBOARD, NOT "NO VENDORS YET". Measured before the
// change on the running app: a 500 from /api/v3/hugo/query left Space's headline at "No vendors yet. Run MARKET Search
// or import a starter file.", which tells the operator to spend money on a dataset that is merely unreadable, while
// Air drew "The Air dashboard could not be loaded. Nothing in the dataset has changed." with Try again. The browser
// half, refused and empty on Space and Air, is `e2e/domain-equal-pass.mjs`; the decision and the wiring are pinned here.
test('VH-324: the Space Dashboard tells a refused Hugo read from one still being read, from the matches, and from no filter', () => {
  const refusal = { gen: 4, status: 500 };
  assert.equal(hugoDashboardPhase({ filtered: false, rows: null, refusal: null, gen: 4 }), 'whole');
  assert.equal(hugoDashboardPhase({ filtered: true, rows: null, refusal: null, gen: 4 }), 'loading');
  assert.equal(hugoDashboardPhase({ filtered: true, rows: null, refusal, gen: 4 }), 'refused');
  // Held rows win, EMPTY ones included: a filter that matched nothing is an answer, not a refusal.
  assert.equal(hugoDashboardPhase({ filtered: true, rows: [], refusal, gen: 4 }), 'matches');
  assert.equal(hugoDashboardPhase({ filtered: true, rows: [{}], refusal: null, gen: 4 }), 'matches');
  // A refusal made under an older filter generation (cleared, replaced, switched, or a write) is stale, so it is read again.
  assert.equal(hugoDashboardPhase({ filtered: true, rows: null, refusal, gen: 5 }), 'loading');
  // No filter, no refusal, whatever an old one left behind.
  assert.equal(hugoDashboardPhase({ filtered: false, rows: null, refusal, gen: 4 }), 'whole');
});

test('VH-324: Space\'s refused Dashboard is the domains\' panel, word for word, and a genuinely empty one is still empty', () => {
  const space = domainReadFailedHtml({ label: 'Space' }, 500, 'dashboard');
  const air = domainReadFailedHtml({ label: 'Air' }, 500, 'dashboard');
  assert.equal(space.replaceAll('Space', 'Air'), air, 'one component: the two differ by the domain\'s name alone');
  assert.match(space, /The Space dashboard could not be loaded\. Nothing in the dataset has changed\./);
  assert.match(space, /data-retry="domain-board"/, 'with the Try again the shell maps to a fresh render');
  assert.doesNotMatch(space, /No companies yet/, 'a refusal never advises a paid search');
  // A status the client cannot read at all is still a refusal (the network dropped), never an unseeded store.
  assert.match(domainReadFailedHtml({ label: 'Space' }, 'offline', 'dashboard'), /could not be loaded/);
  // AND THE OTHER VERDICT, or this measures nothing: the same dashboard over a dataset that is genuinely empty says so.
  const empty = buildDashboardHtml({ allRows: [], allRowsFailed: null, countryPolicy: {}, countryMeta: {} });
  assert.match(empty, /No companies yet\./);
  assert.doesNotMatch(empty, /could not be loaded/);
});

test('VH-324: the shell records a refused read, paints it through the domains\' component, and lets nothing paint over it', () => {
  // VH-333: a 200 with no rows array is recorded as a refusal too, so it cannot read as "no vendors match".
  assert.match(app, /if \(r\.status !== 200 \|\| !Array\.isArray\(r\.payload\?\.rows\)\) \{ hugoPlotRefusal = \{ gen, status: r\.status === 200 \? 'malformed' : r\.status \}; return false; \}/);
  // VH-333 item 5: the continuation draws only the CURRENT refusal, on the Dashboard still. Removing either half of this
  // guard lets a superseded refusal paint over a newer view, and until now no assertion noticed.
  assert.match(app, /if \(!signedOutUi\(\) && state\.view === 'dashboard' && refused\.gen === hugoGen && hugoPlotRefusal === refused\) el\.view\.innerHTML = html;/);
  assert.match(app, /readFailedHtml\(descriptor, refused\.status, 'dashboard'\)/);
  // Every Space Dashboard paint goes through the one painter, so a late growth or whole-set read cannot draw over it.
  assert.equal(app.match(/DV\.renderDashboard\(el\.view, plotState\(\)/g)?.length, 1, 'only the painter draws the Space Dashboard');
  assert.equal(app.match(/(?<!function )paintSpaceDashboard\(dashHandlers\)/g)?.length, 4, 'the first paint, the growth read, the whole-set read and the matches\' read');
  assert.match(app, /\.then\(\(changed\) => paintHugoDashboard\(changed, dashHandlers\)\)/, 'the last of them through its own wrapper');
  // Every render asks for the matches again, so Try again (which renders) reads again rather than repainting the refusal.
  assert.match(app, /hugoPlotRefusal = null;[^\n]*\n {4}paintSpaceDashboard\(dashHandlers\);/);
});

// VH-333 item 1: the Space-only MAP under a refused Hugo read draws the refused map with Try again, as the six domains do.
test('VH-333: the Space-only map paints a refused Hugo read through the same component, with the same guards', () => {
  assert.match(app, /hugoPlotRefusal = null;[^\n]*\n {4}ensureHugoPlotRows\(\)\.then\(\(changed\) => \{/, 'every map render asks again');
  assert.match(app, /else if \(!changed\) paintHugoMapRefusal\(\);/);
  // And the Space board's own read of the matches refuses a 200 with no rows array, as the plotted views do.
  assert.match(app, /return r\.status === 200 && Array\.isArray\(r\.payload\?\.rows\)\n\s+\? \{ status: 200, rows: r\.payload\.rows/);
  const start = app.indexOf('function paintHugoMapRefusal(');
  const body = app.slice(start, app.indexOf('\n}\n', start));
  assert.match(body, /readFailedHtml\(domainDescriptor\(\), refused\.status, 'map'\)/);
  assert.match(body, /refused\.gen === hugoGen && hugoPlotRefusal === refused\) el\.view\.innerHTML = html;/);
});

// VH-333 item 3: Space is never unseeded, so a 404 on it is a failed read; every other domain keeps its ready-for-data panel.
for (const domain of domainIds()) {
  test(`VH-333: a 404 read on ${domain} ${domain === 'space' ? 'is a failed read' : 'is the unseeded panel'}`, () => {
    const html = domainReadFailedHtml({ id: domain, label: domain }, 404, 'dashboard');
    if (domain === 'space') {
      assert.match(html, /state-error/);
      assert.doesNotMatch(html, /ready for data/);
    } else {
      assert.match(html, /ready for data/);
    }
  });
}

// VH-333 item 4: a Hugo filter that matched nothing on a populated dataset is not "No vendors yet".
for (const domain of domainIds()) {
  test(`VH-333: ${domain} Dashboard under a filter that matched nothing names the question, not an empty dataset`, () => {
    const state = { domain, allRows: [], hugoActive: true, summary: null, gdmGrowth: null, boardError: null };
    const html = buildDashboardHtml(state);
    assert.match(html, /No companies match your question/);
    assert.doesNotMatch(html, /no companies yet/i);
    assert.doesNotMatch(html, /MARKET Search or import a starter file/);
    const bare = buildDashboardHtml({ ...state, hugoActive: false });
    assert.match(bare, /No companies yet/, 'and the genuinely empty verdict is unchanged');
  });
}
