// HUGO'S OWN RATE TIER (VH-777 Lane T). A typed turn shared the 3-a-minute scan tier with deep search, summaries and
// read-aloud, so the 4th message in a minute was refused and the client called it the day's cap. It now has a tier of its
// own, named in its refusal, and the client says which of the three limits a 429 met.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { readFileSync } from 'node:fs';
import { createApp, HUGO_TURNS_PER_MINUTE } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';
const verify = createStaticVerifier({ 'agent-tok': { subject: 'ada', roles: ['agent'] } });
const agent = { authorization: 'Bearer agent-tok', 'content-type': 'application/json' };

function listen(handler) {
  return new Promise((resolve) => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => resolve(s)); });
}
function post(server, path, body) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port: server.address().port, path, method: 'POST', headers: agent }, (res) => {
      const chunks = []; res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    req.end(JSON.stringify(body));
  });
}

test('a typed Hugo turn is on its own tier, not the scan tier, and its refusal names it', async () => {
  assert.equal(HUGO_TURNS_PER_MINUTE, 30);
  const turn = { messages: [{ role: 'user', content: 'hello' }], domain: 'space' };
  // The scan tier refuses everything: a Hugo turn no longer meets it, and a scan route still does.
  const scanShut = await listen(createApp({ env: {}, vendorRepo: {}, verify, allowedOrigin: ORIGIN, scanRateLimit: () => false, hugoRateLimit: () => true }));
  try {
    assert.notEqual((await post(scanShut, '/api/v3/hugo/agent', turn)).status, 429);
    const find = await post(scanShut, '/api/v3/hugo/find', { vendorId: 'VH-0001', domain: 'space' });
    assert.deepEqual([find.status, JSON.parse(find.body).error], [429, 'scan rate limited']);
  } finally { scanShut.close(); }
  // Hugo's tier refuses: the turn says so in the server's own words.
  const hugoShut = await listen(createApp({ env: {}, vendorRepo: {}, verify, allowedOrigin: ORIGIN, scanRateLimit: () => true, hugoRateLimit: () => false }));
  try {
    const res = await post(hugoShut, '/api/v3/hugo/agent', turn);
    assert.deepEqual([res.status, JSON.parse(res.body).error], [429, 'hugo rate limited']);
  } finally { hugoShut.close(); }
});

test('the client names which limit a refused turn met, and only the spent day says tomorrow', () => {
  const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(app, /if \(result\.status === 429\) return hugoLimitLine\(result\.reason\);/);
  const fn = /function hugoLimitLine\(reason\) \{[\s\S]*?\n\}/.exec(app)?.[0] || '';
  assert.match(fn, /'daily_cap_reached'\) return "Hugo has reached today's usage cap\. It resets tomorrow\."/);
  assert.match(fn, /'hugo rate limited'\) return 'That is more messages to Hugo than it takes in a minute/);
  assert.equal((fn.match(/tomorrow/g) || []).length, 1, 'tomorrow is said for the spent day alone');
  const index = readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
  assert.match(index, /hugoRateLimit: createRateLimiter\(\{ windowMs: 60_000, max: HUGO_TURNS_PER_MINUTE \}\)/);
});

// TALK IS A HUGO TURN, NOT A SCAN (VH-904, owner, 2026-10-28: Talk stopped after one 10-second use). The Live open sat on
// the 3-a-minute scan tier with deep search and summaries, so the 4th Talk start in a minute was refused. It rides
// Hugo's tier now, and the daily spend ledger still guards it (`paidCallAllowed` in src/hugo/live-route.js).
test('4 Talk starts in a minute pass the tiers, and Talk past Hugo\'s own tier is refused by name', async () => {
  const { createRateLimiter } = await import('../src/rate-limit.js');
  const offer = { sdp: 'v=0', domain: 'space' };
  const real = await listen(createApp({ env: {}, vendorRepo: {}, verify, allowedOrigin: ORIGIN,
    scanRateLimit: createRateLimiter({ windowMs: 60_000, max: 3 }), hugoRateLimit: createRateLimiter({ windowMs: 60_000, max: HUGO_TURNS_PER_MINUTE }) }));
  try {
    const statuses = [];
    for (let i = 0; i < 4; i += 1) statuses.push((await post(real, '/api/v3/hugo/live', offer)).status);
    assert.ok(!statuses.includes(429), 'a Talk start was refused by a rate tier: ' + statuses.join(', '));
  } finally { real.close(); }
  const hugoShut = await listen(createApp({ env: {}, vendorRepo: {}, verify, allowedOrigin: ORIGIN, scanRateLimit: () => true, hugoRateLimit: () => false }));
  try {
    const res = await post(hugoShut, '/api/v3/hugo/live', offer);
    assert.deepEqual([res.status, JSON.parse(res.body).error], [429, 'hugo rate limited']);
  } finally { hugoShut.close(); }
});

// A REFUSED SUMMARY SAYS WHICH LIMIT IT MET TOO (VH-902's sweep). The summary rides the scan tier, so its 429 is as often
// the minute as the day; only the server's 'daily_cap_reached' says tomorrow.
test('a refused summary names the minute unless the server named the spent day', () => {
  const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const fn = /async function writeRecordSummary\(btn\) \{[\s\S]*?\n\}/.exec(app)?.[0] || '';
  assert.match(fn, /res\.status === 429 && res\.payload\?\.error !== 'daily_cap_reached' \? SUMMARY_BUSY : SUMMARY_REFUSED\[res\.status\]/);
  assert.match(app, /const SUMMARY_BUSY = '[^']*in the last minute[^']*'/);
  assert.doesNotMatch(/const SUMMARY_BUSY = '[^']*'/.exec(app)?.[0] || '', /tomorrow|spending/);
});
