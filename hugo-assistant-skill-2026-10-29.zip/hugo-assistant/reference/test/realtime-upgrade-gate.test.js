// THE REALTIME UPGRADE GATE, EACH REFUSAL AND ITS ORDER (VH-523). The VH-372 deep dive counted this gate among
// the security controls no test held. Every refusal below is checked twice: that it fires, and that the steps
// AFTER it (the credential and the spend cap, which cost a lookup and a ledger read) are never reached.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { realtimeUpgradeGate, handleRealtimeUpgrade, REALTIME_PATH } from '../src/hugo/realtime-upgrade-gate.js';
import { REALTIME_SUBPROTOCOL } from '../src/hugo/openai-realtime.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';
function req({ path = REALTIME_PATH, query = '?domain=space', origin = ORIGIN, token = 'agent-tok' } = {}) {
  const headers = { host: 'vendor-hunter.apps.bluestaq.com', origin };
  if (token) headers['sec-websocket-protocol'] = REALTIME_SUBPROTOCOL + ', ' + token;
  return { url: path + query, headers };
}
function deps({ priced = false, capOk = true } = {}) {
  const calls = { verify: 0, cap: 0 };
  return {
    calls,
    allowedOrigin: ORIGIN,
    verify: async (shim) => {
      calls.verify += 1;
      const roles = shim.headers.authorization === 'Bearer agent-tok' ? ['agent'] : ['gdm_lead'];
      return { subject: 'ada', roles };
    },
    paidCallAllowed: async () => { calls.cap += 1; return capOk; },
    listeningPriced: () => priced,
  };
}

test('a well-formed upgrade from this site by an agent within the cap passes, naming its domain and mode', async () => {
  const d = deps();
  const out = await realtimeUpgradeGate(req({ query: '?domain=maritime' }), d);
  assert.deepEqual({ domain: out.domain, listen: out.listen, subject: out.principal.subject }, { domain: 'maritime', listen: false, subject: 'ada' });
  assert.deepEqual(d.calls, { verify: 1, cap: 1 });
});

test('another path is not ours and is closed without a status line', async () => {
  const d = deps();
  assert.deepEqual(await realtimeUpgradeGate(req({ path: '/api/v3/other' }), d), { stray: true });
  assert.deepEqual(d.calls, { verify: 0, cap: 0 });
});

test('each refusal fires, in order, before the credential and the cap are touched', async () => {
  const cases = [
    ['a page on another site', req({ origin: 'https://evil.example' }), '403 Forbidden'],
    ['no domain named', req({ query: '' }), '400 Bad Request'],
    ['an unknown domain', req({ query: '?domain=moon' }), '400 Bad Request'],
    ['the always-on listener while its price is unread', req({ query: '?domain=space&mode=listen' }), '503 Service Unavailable'],
  ];
  for (const [what, r, code] of cases) {
    const d = deps();
    assert.deepEqual(await realtimeUpgradeGate(r, d), { refuse: code }, what);
    assert.deepEqual(d.calls, { verify: 0, cap: 0 }, what + ': nothing after it ran');
  }
});

test('no bearer, or a principal without the agent role, is refused before the spend cap is read', async () => {
  for (const [what, r] of [['no bearer', req({ token: '' })], ['not an agent', req({ token: 'lead-tok' })]]) {
    const d = deps();
    assert.deepEqual(await realtimeUpgradeGate(r, d), { refuse: '403 Forbidden' }, what);
    assert.equal(d.calls.cap, 0, what);
  }
});

test('the daily spend cap refuses with 429, and a priced listener is let through', async () => {
  assert.deepEqual(await realtimeUpgradeGate(req(), deps({ capOk: false })), { refuse: '429 Too Many Requests' });
  const out = await realtimeUpgradeGate(req({ query: '?domain=space&mode=listen' }), deps({ priced: true }));
  assert.equal(out.listen, true);
});

// THE LISTENER AROUND THE GATE (VH-665), moved out of `src/index.js`, the process entry no test imports. A stray path
// is a closed socket with nothing written, a refusal its status line then a closed socket, a throw a 500, and an
// accepted socket a relay session of the mode the URL names, audited, logging one line when it ends.
function wire({ gate = deps(), handleUpgrade, failWrite = false, failStores = false } = {}) {
  const seen = { writes: [], destroyed: 0, upgrades: [], connects: [], audits: [], runners: [], flushes: 0 };
  const socket = {
    write: (s) => {
      if (failWrite) throw new Error('socket gone');
      seen.writes.push(s);
    },
    destroy: () => { seen.destroyed += 1; },
  };
  const runner = { run: (name, args) => ['run', name, args], newTurn: () => 'new turn', check: (text) => ['check', text] };
  const stored = () => (failStores ? Promise.reject(new Error('store down')) : Promise.resolve());
  const upgradeDeps = {
    gateDeps: gate,
    wss: { handleUpgrade: handleUpgrade || ((r, s, head, accept) => { seen.upgrades.push(head); accept('client-ws'); }) },
    bridge: { connect: (ws, opts) => { seen.connects.push({ ws, opts }); } },
    spendGuards: { flushSpendToLedger: () => { seen.flushes += 1; return stored(); } },
    vendorRepo: { auditHugoChat: (subject, row) => { seen.audits.push([subject, row]); return stored(); } },
    runnerFor: (domain) => { seen.runners.push(domain); return runner; },
    toolDefs: () => ['the tool layer'],
    turnAllowed: async () => true,
  };
  return { seen, turnAllowed: upgradeDeps.turnAllowed, upgrade: (r) => handleRealtimeUpgrade(r, socket, 'head', upgradeDeps) };
}

test('the listener closes a stray path with nothing written and accepts no socket', async () => {
  const w = wire();
  await w.upgrade(req({ path: '/api/v3/other' }));
  assert.deepEqual({ writes: w.seen.writes, destroyed: w.seen.destroyed, upgrades: w.seen.upgrades }, { writes: [], destroyed: 1, upgrades: [] });
});

test('the listener answers each refusal with its status line, then closes the socket, accepting nothing', async () => {
  const cases = [
    [req({ origin: 'https://evil.example' }), deps(), '403 Forbidden'],
    [req({ query: '' }), deps(), '400 Bad Request'],
    [req({ query: '?domain=space&mode=listen' }), deps(), '503 Service Unavailable'],
    [req({ token: 'lead' }), deps(), '403 Forbidden'],
    [req(), deps({ capOk: false }), '429 Too Many Requests'],
  ];
  for (const [r, gate, code] of cases) {
    const w = wire({ gate });
    await w.upgrade(r);
    assert.deepEqual(w.seen.writes, ['HTTP/1.1 ' + code + '\r\n\r\n'], code);
    assert.deepEqual({ destroyed: w.seen.destroyed, upgrades: w.seen.upgrades }, { destroyed: 1, upgrades: [] }, code);
  }
});

test('a socket already gone is still closed, and a throw in the gate or the accept is a 500', async () => {
  const gone = wire({ gate: deps({ capOk: false }), failWrite: true });
  await gone.upgrade(req());
  assert.equal(gone.seen.destroyed, 1, 'a write to a dead socket does not stop it being closed');
  const verifyThrows = { ...deps(), verify: async () => { throw new Error('verifier down'); } };
  const acceptThrows = () => { throw new Error('handshake failed'); };
  for (const w of [wire({ gate: verifyThrows }), wire({ handleUpgrade: acceptThrows })]) {
    await w.upgrade(req());
    assert.deepEqual({ writes: w.seen.writes, destroyed: w.seen.destroyed }, { writes: ['HTTP/1.1 500 Internal Server Error\r\n\r\n'], destroyed: 1 });
  }
});

test('an accepted Talk session gets the tool layer for its domain, the turn gate and the voice picked, and is audited', async () => {
  const w = wire();
  await w.upgrade(req({ query: '?domain=maritime&voice=Cedar' }));
  assert.deepEqual({ upgrades: w.seen.upgrades, runners: w.seen.runners, writes: w.seen.writes }, { upgrades: ['head'], runners: ['maritime'], writes: [] });
  const [{ ws, opts }] = w.seen.connects;
  assert.equal(ws, 'client-ws');
  assert.deepEqual(Object.keys(opts), ['tools', 'onToolCall', 'onUserTurn', 'turnAllowed', 'checkAnswer', 'voice', 'onClose']);
  assert.deepEqual([opts.tools, opts.onToolCall('find', { q: 1 }), opts.onUserTurn(), opts.checkAnswer('an answer'), opts.voice],
    [['the tool layer'], ['run', 'find', { q: 1 }], 'new turn', ['check', 'an answer'], 'cedar']);
  assert.equal(opts.turnAllowed, w.turnAllowed);
  assert.deepEqual(w.seen.audits, [['ada', { domain: 'voice', turns: 0 }]]);
});

test('an accepted listener session is transcription only: no tools, no runner, the turn gate, audited as listen', async () => {
  const w = wire({ gate: deps({ priced: true }) });
  await w.upgrade(req({ query: '?domain=space&mode=listen' }));
  const [{ ws, opts }] = w.seen.connects;
  assert.deepEqual({ ws, keys: Object.keys(opts), mode: opts.mode, runners: w.seen.runners }, { ws: 'client-ws', keys: ['mode', 'onClose', 'turnAllowed'], mode: 'listen', runners: [] });
  assert.equal(opts.turnAllowed, w.turnAllowed);
  assert.deepEqual(w.seen.audits, [['ada', { domain: 'voice', turns: 0, via: 'listen' }]]);
});

// VH-777: the connection check's socket. The same gate, every refusal in the same order; accepted, one frame and closed,
// with no relay session, no runner and no audit, because nothing is asked of the speech service.
test('a check upgrade passes the same gate, gets one frame and is closed, and dials nothing', async () => {
  const sent = [];
  let closed = null;
  const checkWs = { send: (t) => sent.push(JSON.parse(t)), close: (code) => { closed = code; } };
  const w = wire({ handleUpgrade: (r, s, head, accept) => { w.seen.upgrades.push(head); accept(checkWs); } });
  await w.upgrade(req({ query: '?domain=space&mode=check' }));
  assert.deepEqual(sent, [{ type: 'vh.check', ok: true }]);
  assert.equal(closed, 1000);
  assert.deepEqual({ connects: w.seen.connects, runners: w.seen.runners, audits: w.seen.audits }, { connects: [], runners: [], audits: [] });
  for (const [r, gate, code] of [[req({ query: '?domain=space&mode=check', token: 'lead' }), deps(), '403 Forbidden'],
    [req({ query: '?domain=space&mode=check', origin: 'https://evil.example' }), deps(), '403 Forbidden'],
    [req({ query: '?domain=space&mode=check' }), deps({ capOk: false }), '429 Too Many Requests']]) {
    const refused = wire({ gate });
    await refused.upgrade(r);
    assert.deepEqual(refused.seen.writes, ['HTTP/1.1 ' + code + '\r\n\r\n'], 'a check is refused as any upgrade is: ' + code);
    assert.deepEqual(refused.seen.upgrades, []);
  }
});

test('a session that ends logs one line, naming a listener, and flushes the spend; a failed flush or audit never escapes', async (t) => {
  const escaped = [];
  const onEscape = (e) => { escaped.push(e); };
  process.on('unhandledRejection', onEscape);
  t.after(() => process.off('unhandledRejection', onEscape));
  const logged = [];
  t.mock.method(console, 'log', (line) => { logged.push(JSON.parse(line)); });
  for (const [query, gate] of [['?domain=space', deps()], ['?domain=space&mode=listen', deps({ priced: true })]]) {
    const w = wire({ gate, failStores: true });
    await w.upgrade(req({ query }));
    w.seen.connects[0].opts.onClose('client-closed', { code: 1000 });
    assert.equal(w.seen.flushes, 1, query);
  }
  await new Promise((resolve) => { setImmediate(resolve); });
  assert.deepEqual(logged, [
    { event: 'realtime-closed', reason: 'client-closed', code: 1000 },
    { event: 'realtime-closed', reason: 'client-closed', mode: 'listen', code: 1000 },
  ]);
  assert.deepEqual(escaped, [], 'audit must never break the session, nor a failed flush');
});

test('the entrypoint registers this listener for the upgrade event, with the dependencies it names (wired)', () => {
  const src = readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
  assert.match(src, /server\.on\('upgrade', \(req, socket, head\) => handleRealtimeUpgrade\(req, socket, head, upgradeDeps\)\);/);
  assert.match(src, /\n {4}wss, bridge, spendGuards, vendorRepo: deps\.vendorRepo, runnerFor: realtimeRunner, toolDefs: \(\) => hugoToolDefinitions\('realtime'\), turnAllowed,\n/);
});

// VH-873: an operator signed in through the platform's own identity holds no app token, so the browser sends the
// subprotocol alone and the upgrade request's own headers decide, through the same verifier an HTTP call meets.
test('no bearer, but the upgrade carries the platform identity of an agent: let through; carrying none: refused', async () => {
  const seen = [];
  const platform = (identity) => ({
    allowedOrigin: ORIGIN, listeningPriced: () => true, paidCallAllowed: async () => true,
    verify: async (shim, raw) => {
      seen.push({ authorization: shim.headers.authorization, raw: raw?.headers?.['x-forwarded-email'] });
      return raw?.headers?.['x-forwarded-email'] === identity ? { subject: identity, roles: ['agent'] } : null;
    },
  });
  const bare = req({ token: '', query: '?domain=space&mode=listen' });
  bare.headers['sec-websocket-protocol'] = REALTIME_SUBPROTOCOL;
  bare.headers['x-forwarded-email'] = 'ada@example.org';
  const out = await realtimeUpgradeGate(bare, platform('ada@example.org'));
  assert.equal(out.principal?.subject, 'ada@example.org');
  assert.equal(out.listen, true);
  assert.deepEqual(seen.at(-1), { authorization: undefined, raw: 'ada@example.org' }, 'no bearer was invented, and the upgrade itself was read');
  assert.deepEqual(await realtimeUpgradeGate(bare, platform('someone@example.org')), { refuse: '403 Forbidden' }, 'an identity that verifies as no one is refused');
});
