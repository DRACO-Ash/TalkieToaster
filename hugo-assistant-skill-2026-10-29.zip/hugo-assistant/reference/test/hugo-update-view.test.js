// WS2 client view: the pure helpers behind Hugo's permissioned single-record update. These build the
// preview request, render the diff-confirm card, and derive the patch the ordinary update endpoint
// then writes. Pure and DOM-free, so they are unit-tested here; the wiring lives in app-v3.js.

import test from 'node:test';
import assert from 'node:assert/strict';

import { suggestBody, patchFromPreview, previewCardHtml, composerHtml } from '../public/views/hugo-update.js';

test('suggestBody refuses an incomplete composer and needs a field, value, id and source', () => {
  assert.equal(suggestBody({ domain: 'space', id: 'VH-1', field: 'grade', value: '' , source: 'x' }), null, 'no value');
  assert.equal(suggestBody({ domain: 'space', id: 'VH-1', field: '', value: 'Ready for JCO', source: 'x' }), null, 'no field');
  assert.equal(suggestBody({ domain: 'space', id: 'VH-1', field: 'grade', value: 'Ready for JCO', source: '' }), null, 'no source');
  assert.equal(suggestBody({ domain: 'space', id: '', field: 'grade', value: 'Ready for JCO', source: 'x' }), null, 'no id');
});

test('suggestBody shapes a Space patch flat and a domain patch under fields', () => {
  const space = suggestBody({ domain: 'space', id: 'VH-1', field: 'grade', value: 'Ready for JCO', source: 'https://example.gov/x' });
  assert.deepEqual(space, { domain: 'space', id: 'VH-1', patch: { grade: 'Ready for JCO' }, source: 'https://example.gov/x' });

  const air = suggestBody({ domain: 'air', id: 'host:x', field: 'coverage', value: 'Global', source: 'https://example.gov/x' });
  assert.deepEqual(air, { domain: 'air', id: 'host:x', patch: { fields: { coverage: 'Global' } }, source: 'https://example.gov/x' });

  // A comma-separated value becomes an array so an array facet (missions) is set, not a string.
  const missions = suggestBody({ domain: 'space', id: 'VH-1', field: 'missions', value: 'EMSO, TacSRT', source: 'x' });
  assert.deepEqual(missions.patch.missions, ['EMSO', 'TacSRT']);
});

test('patchFromPreview mirrors the confirmed diff, flat for Space and under fields for a domain', () => {
  const space = patchFromPreview({ domain: 'space', changes: { after: { grade: 'Ready for JCO' } } });
  assert.deepEqual(space, { grade: 'Ready for JCO' });
  const air = patchFromPreview({ domain: 'air', changes: { after: { coverage: 'Global' } } });
  assert.deepEqual(air, { fields: { coverage: 'Global' } });
  assert.equal(patchFromPreview({ domain: 'space', changes: { after: {} } }), null, 'nothing to apply');
});

test('previewCardHtml lists the moved fields, cites the source, and offers apply', () => {
  const html = previewCardHtml({
    domain: 'space', source: 'https://example.gov/x', hasChanges: true,
    changes: { before: { grade: 'Potential for JCO' }, after: { grade: 'Ready for JCO' } },
  });
  assert.match(html, /Potential for JCO/);
  assert.match(html, /Ready for JCO/);
  assert.match(html, /example\.gov/);
  assert.match(html, /data-act="hugo-update-apply"/);
});

test('previewCardHtml says nothing would change on a no-op, and offers no apply', () => {
  const html = previewCardHtml({ hasChanges: false });
  assert.match(html, /would not change anything/);
  assert.doesNotMatch(html, /hugo-update-apply/);
});

test('previewCardHtml escapes a hostile source', () => {
  const html = previewCardHtml({ hasChanges: true, source: '<img src=x onerror=alert(1)>', changes: { before: {}, after: { grade: 'X' } } });
  assert.doesNotMatch(html, /<img/);
  assert.match(html, /&lt;img/);
});

test('composerHtml renders the three inputs and a preview button', () => {
  const html = composerHtml();
  assert.match(html, /id="hugo-update-field"/);
  assert.match(html, /id="hugo-update-value"/);
  assert.match(html, /id="hugo-update-source"/);
  assert.match(html, /data-act="hugo-update-preview"/);
});
