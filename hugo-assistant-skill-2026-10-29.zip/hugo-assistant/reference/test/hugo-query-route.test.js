// Route tests for POST /api/v3/hugo/query (the Hugo query executor endpoint). In-process via createApp with a
// stub vendorRepo.queryByIntent, so no DB is needed. Covers auth, role, the client-intent re-validation (an
// invented value never reaches the repo), the cross-domain shape and the unseeded-domain behaviour.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';

function listen(handler) {
  return new Promise((resolve) => {
    const server = http.createServer(handler);
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}
function request(server, path, { method = 'GET', headers = {}, body } = {}) {
  const { port } = server.address();
  const payload = body === undefined ? null : JSON.stringify(body);
  const allHeaders = payload ? { 'content-type': 'application/json', ...headers } : headers;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method, headers: allHeaders }, (res) => {
      let text = '';
      res.on('data', (chunk) => (text += chunk));
      res.on('end', () => resolve({ status: res.statusCode, body: text }));
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

const verify = createStaticVerifier({
  'agent-tok': { subject: 'ada', roles: ['agent'] },
  'lead-tok': { subject: 'lena', roles: ['gdm_lead'] },
});
const agent = { authorization: 'Bearer agent-tok' };
const lead = { authorization: 'Bearer lead-tok' };

// A stub repo that records the filterSpec it was handed and returns one row.
function stubRepo() {
  const seen = { calls: 0, filterSpec: null, opts: null, audit: null };
  const repo = {
    queryByIntent: async (filterSpec, opts) => {
      seen.calls += 1; seen.filterSpec = filterSpec; seen.opts = opts || {};
      return { rows: [{ rev: 1, record: { company: 'X' } }], total: 1, applied: ['countries'], notApplied: ['families'] };
    },
    auditHugoQuery: async (actor, detail) => { seen.audit = { actor, detail }; },
    analyticsReport: async (opts) => { seen.analytics = opts || {}; return { matrix: { total: 1 }, growth: { series: [] } }; },
  };
  return { repo, seen };
}
function appWith(vendorRepo, domainRepoFor) {
  return createApp({ env: {}, vendorRepo, domainRepoFor, verify, allowedOrigin: ORIGIN });
}

// Two product-line stores with DELIBERATELY DIFFERENT clause coverage from Space and from each other, which
// is the whole point: the seven stores do not honour the same clause set, and an answer that cannot tell them
// apart is the defect. Space runs `countries` and defers `families`; Air runs `countries` and defers
// `productTypes`; Maritime runs `productTypes` and defers `countries`. So every branch is distinguishable:
// `countries` ran in two of three, `productTypes` ran in one of two that considered it, and `families` ran
// nowhere.
function coverageStores() {
  const byDomain = {
    air: { applied: ['countries'], notApplied: ['productTypes'] },
    maritime: { applied: ['productTypes'], notApplied: ['countries'] },
  };
  return (id) => (byDomain[id]
    ? { queryProviders: async () => ({ rows: [], total: 0, ...byDomain[id] }) }
    : null);
}

test('POST /hugo/query runs a Space intent and returns rows', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    const res = await request(server, '/api/v3/hugo/query', {
      method: 'POST', headers: agent, body: { domain: 'space', filterSpec: { countries: ['United Kingdom'] } },
    });
    assert.equal(res.status, 200);
    const out = JSON.parse(res.body);
    assert.equal(out.total, 1);
    assert.equal(out.rows[0].record.company, 'X');
    assert.deepEqual(out.domainsQueried, ['space']);
    assert.equal(seen.calls, 1);
    assert.deepEqual(seen.filterSpec.countries, ['United Kingdom']);
    // H-4: the query is audited with the resolved clauses and count, keyed to the authenticated subject.
    assert.equal(seen.audit.actor, 'ada');
    assert.equal(seen.audit.detail.domain, 'space');
    assert.deepEqual(seen.audit.detail.applied, ['countries']);
    assert.deepEqual(seen.audit.detail.notApplied, ['families']);
    assert.equal(seen.audit.detail.total, 1);
  } finally { server.close(); }
});

test('POST /hugo/analytics re-validates the intent and aggregates the filtered report (W2b)', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    const res = await request(server, '/api/v3/hugo/analytics', {
      method: 'POST', headers: agent,
      body: { domain: 'space', filterSpec: { countries: ['United Kingdom', 'Atlantis'] }, from: '2026-01', to: '2026-06' },
    });
    assert.equal(res.status, 200);
    const out = JSON.parse(res.body);
    assert.equal(out.matrix.total, 1);
    // The invented country is dropped by re-validation before the aggregate; the window passes through.
    assert.deepEqual(seen.analytics.filterSpec.countries, ['United Kingdom']);
    assert.equal(seen.analytics.empty, false);
    assert.equal(seen.analytics.from, '2026-01');
  } finally { server.close(); }
});

// A NON-SPACE DOMAIN IS TOLD, NOT HANDED ZEROES (V1.81, parity gap `hugo.analytics.domain.empty`).
//
// This report's shape - the sector-by-mission matrix, the per-sector metrics, the GDM growth trend - is
// built on the Space flat record and has no meaning over a product-line store, which has its own aggregate
// at `GET /api/v3/domains/:domain/summary`. A report of zeros looked like an answer: a caller could not tell
// "this domain holds nothing" from "this surface does not aggregate this domain", and the client wrote those
// zeros over the figures and the map heat it already held for SPACE - one store's absence rendered as
// another's.
test('POST /hugo/analytics SAYS a non-Space single domain is not aggregated here, rather than answering zero', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    const res = await request(server, '/api/v3/hugo/analytics', {
      method: 'POST', headers: agent, body: { domain: 'air', filterSpec: {} },
    });
    assert.equal(res.status, 200, 'a 200 with a reason, not an error: nothing went wrong');
    assert.equal(seen.analytics.empty, true, 'and no Space aggregate was computed for it');
    const out = JSON.parse(res.body);
    assert.match(out.unavailable, /Space master/, 'the answer names the surface it belongs to');
    assert.match(out.unavailable, /air/, 'and the domain it was asked about');
    assert.equal(out.domain, 'air');
  } finally { server.close(); }
});

test('a cross-domain filter and Space itself are aggregated as before, with no unavailable marker', async () => {
  // The marker must not appear on the paths that DO aggregate, or a client would discard a real report.
  const { repo } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    for (const body of [{ domain: 'space', filterSpec: {} }, { domain: 'air', filterSpec: {}, crossDomain: true }]) {
      const res = await request(server, '/api/v3/hugo/analytics', { method: 'POST', headers: agent, body });
      assert.equal(JSON.parse(res.body).unavailable, undefined, JSON.stringify(body));
    }
  } finally { server.close(); }
});

test('POST /hugo/analytics is agent-gated', async () => {
  const { repo } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    const res = await request(server, '/api/v3/hugo/analytics', { method: 'POST', headers: lead, body: { domain: 'space', filterSpec: {} } });
    assert.equal(res.status, 403);
  } finally { server.close(); }
});

test('the board sort column and direction reach the repo (W3)', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    await request(server, '/api/v3/hugo/query', {
      method: 'POST', headers: agent,
      body: { domain: 'space', filterSpec: { countries: ['United Kingdom'] }, sort: 'company', dir: 'desc' },
    });
    assert.equal(seen.opts.sort, 'company');
    assert.equal(seen.opts.dir, 'desc');
  } finally { server.close(); }
});

test('the client intent is re-validated: an invented value never reaches the repo', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    await request(server, '/api/v3/hugo/query', {
      method: 'POST', headers: agent,
      body: { domain: 'space', filterSpec: { countries: ['United Kingdom', 'Atlantis'], sections: ['bogus'] } },
    });
    assert.deepEqual(seen.filterSpec.countries, ['United Kingdom']);
    assert.deepEqual(seen.filterSpec.sections, []);
  } finally { server.close(); }
});

test('a non-Space single domain returns an empty result without touching the repo', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    const res = await request(server, '/api/v3/hugo/query', {
      method: 'POST', headers: agent, body: { domain: 'air', filterSpec: { countries: ['France'] } },
    });
    const out = JSON.parse(res.body);
    assert.equal(out.total, 0);
    assert.deepEqual(out.rows, []);
    assert.deepEqual(out.domainsQueried, []);
    assert.equal(seen.calls, 0);
  } finally { server.close(); }
});

test('a cross-domain query hits Space and names the unseeded domains', async () => {
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    const res = await request(server, '/api/v3/hugo/query', {
      method: 'POST', headers: agent, body: { domain: 'air', crossDomain: true, filterSpec: { countries: ['France'] } },
    });
    const out = JSON.parse(res.body);
    assert.equal(seen.calls, 1);
    assert.deepEqual(out.domainsQueried, ['space']);
    assert.ok(out.domainsUnseeded.includes('air'));
    assert.ok(!out.domainsUnseeded.includes('space'));
  } finally { server.close(); }
});

// A CROSS-DOMAIN QUERY REPORTED SPACE'S COVERAGE (V1.81, parity gap `hugo.crossdomain.applied.space`).
//
// The query fans across seven stores that do not honour the same clause set, and the answer named only what
// the Space master ran. An operator was shown one store's account of a question asked of all of them: the
// same shape as the stale ribbon and the Space-heat layer this release already fixed twice.
async function crossDomain(server) {
  const res = await request(server, '/api/v3/hugo/query', {
    method: 'POST', headers: agent, body: { domain: 'air', crossDomain: true, filterSpec: { countries: ['France'] } },
  });
  return JSON.parse(res.body);
}

test('applied is the UNION across the stores, not Space alone', async () => {
  const { repo } = stubRepo();
  const server = await listen(appWith(repo, coverageStores()));
  try {
    const out = await crossDomain(server);
    // `productTypes` is a clause SPACE NEVER REPORTED. It reaches the answer only because Maritime ran it,
    // which is the union this gap is about: a clause that narrowed the result somewhere did narrow it.
    assert.ok(out.applied.includes('productTypes'), 'a clause only a product-line store ran is reported applied');
    assert.ok(out.applied.includes('countries'), 'and the clause Space ran is still there');
    // Reported once, however many stores ran it: this is a set of clauses, not a tally.
    assert.equal(out.applied.filter((c) => c === 'countries').length, 1);
  } finally { server.close(); }
});

test('notApplied is what NO store ran, and never contradicts applied', async () => {
  const { repo } = stubRepo();
  const server = await listen(appWith(repo, coverageStores()));
  try {
    const out = await crossDomain(server);
    assert.deepEqual(out.notApplied, ['families'], 'only the clause every store deferred');
    // The two lists cannot both claim a clause. Maritime deferred `countries` and Air deferred
    // `productTypes`, and both of those ran somewhere, so a report that listed them as unapplied would tell
    // an operator their filter was ignored when it was not.
    for (const clause of out.applied) {
      assert.ok(!out.notApplied.includes(clause), clause + ' is claimed by both lists');
    }
  } finally { server.close(); }
});

test('coverage names the stores per clause, which is what a mixed result actually needs', async () => {
  const { repo } = stubRepo();
  const server = await listen(appWith(repo, coverageStores()));
  try {
    const out = await crossDomain(server);
    const sorted = (list) => [...(list || [])].sort((a, b) => a.localeCompare(b));
    assert.deepEqual(sorted(out.coverage.countries.ran), ['air', 'space'], 'two stores ran countries');
    assert.deepEqual(sorted(out.coverage.countries.missed), ['maritime'], 'and one did not');
    assert.deepEqual(sorted(out.coverage.productTypes.ran), ['maritime']);
    assert.deepEqual(sorted(out.coverage.productTypes.missed), ['air']);
    assert.deepEqual(sorted(out.coverage.families.ran), [], 'a clause no store ran has an empty ran list');
    assert.deepEqual(sorted(out.coverage.families.missed), ['space']);
  } finally { server.close(); }
});

test('a SINGLE-domain query carries no coverage map: the two lists are the whole account', async () => {
  // The marker must not appear where there is only one store, or a client would raise a partial-coverage
  // notice over an answer that has no exceptions to report.
  const { repo } = stubRepo();
  const server = await listen(appWith(repo, coverageStores()));
  try {
    const res = await request(server, '/api/v3/hugo/query', {
      method: 'POST', headers: agent, body: { domain: 'space', filterSpec: { countries: ['United Kingdom'] } },
    });
    assert.equal(JSON.parse(res.body).coverage, undefined);
  } finally { server.close(); }
});

test('the AUDIT records the union too, not the Space row', async () => {
  // H-4 records which clauses the database applied. An audit that named Space's clauses for a seven-store
  // read would be a governance record of a query that did not happen.
  const { repo, seen } = stubRepo();
  const server = await listen(appWith(repo, coverageStores()));
  try {
    await crossDomain(server);
    assert.ok(seen.audit.detail.applied.includes('productTypes'));
    assert.deepEqual(seen.audit.detail.notApplied, ['families']);
  } finally { server.close(); }
});

test('an unauthenticated request is 401 and a non-agent is 403', async () => {
  const { repo } = stubRepo();
  const server = await listen(appWith(repo));
  try {
    assert.equal((await request(server, '/api/v3/hugo/query', { method: 'POST', body: { domain: 'space' } })).status, 401);
    assert.equal((await request(server, '/api/v3/hugo/query', { method: 'POST', headers: lead, body: { domain: 'space' } })).status, 403);
  } finally { server.close(); }
});
