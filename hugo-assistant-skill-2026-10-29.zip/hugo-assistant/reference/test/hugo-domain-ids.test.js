// VH-171: HUGO NAMES EVERY DOMAIN BY ITS REAL ID. The tool text told the model the ids were
// `natural-resources` and `national-security`; the real ids use underscores, and `domainOf` fell back to the
// default domain for anything it did not recognise, so a Natural Resources or National Security question was
// answered from another catalogue without a word said. Found by the VH-220 audit (A1) and reproduced by a run.
// The class is a hand-typed id list, so the lists are now built from the registry, and a hyphenated id the
// model has already been taught still reaches its own domain.
import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner, HUGO_TOOL_DEFS } from '../src/hugo/tools.js';
import { SEARCH_ALL_DEF, MARKET_DEEP_SYSTEM } from '../src/scan/market-deep-search.js';
import { domainIds } from '../src/domain/descriptor.js';

const idsNamedIn = (text) => String(text).match(/[a-z]+(?:[-_][a-z]+)*/g) || [];

test('every domain id a tool description names is a registered domain, and every registered domain is named', () => {
  const ids = domainIds();
  const described = [
    ...HUGO_TOOL_DEFS.map((t) => t.function.parameters?.properties?.domain?.description)
      .filter((d) => typeof d === 'string' && d.startsWith('A domain id:')),
    SEARCH_ALL_DEF.function.description,
  ];
  assert.ok(described.length >= 2, 'the check found the descriptions it is meant to read: ' + described.length);
  for (const text of described) {
    const named = idsNamedIn(text);
    for (const id of ids) assert.ok(named.includes(id), JSON.stringify(id) + ' is not named in: ' + text);
    assert.ok(!/natural-resources|national-security/.test(text), 'a hyphenated id is still taught in: ' + text);
  }
});

test('the MARKET search briefing does not call the seven-domain dataset space and electromagnetic', () => {
  assert.doesNotMatch(String(MARKET_DEEP_SYSTEM), /space and electromagnetic vendors/);
  for (const id of domainIds()) assert.match(String(MARKET_DEEP_SYSTEM), new RegExp('\\b' + id + '\\b'), id + ' is not named');
});

for (const [asked, expected] of [['natural_resources', 'natural_resources'], ['natural-resources', 'natural_resources'],
  ['national-security', 'national_security'], ['space', 'space'], ['nonsense', 'air']]) {
  test('get_record for domain ' + JSON.stringify(asked) + ' reads the ' + expected + ' store', async () => {
    const read = [];
    const runner = createToolRunner({
      runQuery: async () => ({ rows: [], total: 0 }),
      vendorRepo: { getVendor: async () => { read.push('space'); return null; } },
      domainRepoFor: (d) => ({ get: async () => { read.push(d); return null; } }),
      defaultDomain: 'air',
    });
    await runner.run('get_record', { domain: asked, id: 'x' });
    assert.deepEqual(read, [expected]);
  });
}
