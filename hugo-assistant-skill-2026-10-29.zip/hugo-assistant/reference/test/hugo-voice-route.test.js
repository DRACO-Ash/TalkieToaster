// Route tests for Hugo's voice probe (H-5) and GPT-Live through the app (VH-777). Both server speech routes are
// retired: speech-to-text with VH-318-F, and the read-aloud (POST /api/v3/hugo/tts) with the design interview it read
// for (VH-838, VH-839); Talk speaks over Realtime and Live. In-process via createApp with a stubbed voice status, so no
// provider and no network are needed.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';

function listen(handler) {
  return new Promise((resolve) => {
    const server = http.createServer(handler);
    server.listen(0, '127.0.0.1', () => resolve(server));
  });
}
// A request helper that sends a Buffer or string body and returns the RAW response buffer plus the status and
// content-type, so a binary (audio) response is read faithfully.
function request(server, path, { method = 'GET', headers = {}, body } = {}) {
  const { port } = server.address();
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method, headers }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, type: res.headers['content-type'], buf: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    if (body !== undefined) req.write(body);
    req.end();
  });
}

const verify = createStaticVerifier({
  'agent-tok': { subject: 'ada', roles: ['agent'] },
  'lead-tok': { subject: 'lena', roles: ['gdm_lead'] },
  'admin-tok': { subject: 'aled', roles: ['agent', 'admin'] },
});
const agent = { authorization: 'Bearer agent-tok' };
const lead = { authorization: 'Bearer lead-tok' };

// The voice status the composition root gives the app. `speak` is a spy for the retired read-aloud: no route may reach it.
function fakeVoice(overrides = {}) {
  const seen = { speakCalls: 0, text: '' };
  return {
    seen,
    configured: true,
    fault: '',
    speak: async (text) => { seen.speakCalls += 1; seen.text = text; return { audio: Buffer.from('MP3BYTES'), contentType: 'audio/mpeg' }; },
    ...overrides,
  };
}
function auditRepo() {
  const seen = { audits: [] };
  return { seen, auditHugoQuery: async (actor, detail) => { seen.audits.push({ actor, detail }); } };
}
function appWith({ voice, vendorRepo, env = {}, paidCallAllowed, flushSpend } = {}) {
  return createApp({ env, voice, vendorRepo: vendorRepo || auditRepo(), verify, allowedOrigin: ORIGIN, paidCallAllowed, flushSpend });
}
const probeOf = async (server) => JSON.parse((await request(server, '/api/v3/hugo/voice', { headers: agent })).buf.toString());

test('the speech-to-text route is retired: a clip posted to it reaches no provider (VH-318-F)', async () => {
  const voice = fakeVoice();
  const server = await listen(appWith({ voice }));
  try {
    const res = await request(server, '/api/v3/hugo/stt', { method: 'POST', headers: { ...agent, 'content-type': 'audio/webm' }, body: Buffer.from('OGGorWEBMbytes') });
    assert.equal(res.status, 404);
    assert.equal(voice.seen.speakCalls, 0);
  } finally { server.close(); }
});

test('the read-aloud route is retired: text posted to it reaches no provider, and the probe offers no read-aloud (VH-839)', async () => {
  const voice = fakeVoice();
  let asked = 0;
  const server = await listen(appWith({ voice, paidCallAllowed: async () => { asked += 1; return true; } }));
  try {
    const res = await request(server, '/api/v3/hugo/tts', { method: 'POST', headers: { ...agent, 'content-type': 'application/json' }, body: JSON.stringify({ text: 'What is the mission?' }) });
    assert.equal(res.status, 404);
    assert.equal(voice.seen.speakCalls, 0, 'no provider call');
    assert.equal(asked, 0, 'no spend asked of the daily cap');
    const probe = await probeOf(server);
    assert.equal('readAloud' in probe, false);
    assert.equal(probe.configured, true, 'the voice key still gates the voice row');
  } finally { server.close(); }
});

test('the probe reports the paid listener with its price per hour, and available only where realtime is wired (VH-769)', async () => {
  for (const realtimeConfigured of [true, false]) {
    const server = await listen(createApp({ env: {}, voice: fakeVoice(), vendorRepo: auditRepo(), verify, allowedOrigin: ORIGIN, realtimeConfigured }));
    try {
      const probe = JSON.parse((await request(server, '/api/v3/hugo/voice', { headers: agent })).buf.toString());
      assert.deepEqual(probe.listener, { priced: true, usdPerHour: 1.02, available: realtimeConfigured }, String(realtimeConfigured));
    } finally { server.close(); }
  }
});

test('GET /hugo/voice reports whether the provider is configured, without leaking on /status', async () => {
  // Authenticated status probe (V1.65): the client learns voice availability here, not on the
  // unauthenticated /status, so the deployment's capability is not leaked.
  const on = await listen(createApp({ env: {}, voice: fakeVoice(), vendorRepo: auditRepo(), verify, allowedOrigin: ORIGIN, realtimeConfigured: true }));
  try {
    const res = await request(on, '/api/v3/hugo/voice', { headers: agent });
    assert.equal(res.status, 200);
    const body = JSON.parse(res.buf.toString());
    assert.equal(body.configured, true);
    // The realtime (Talk-to-Hugo) capability is reported separately, so the client only offers the
    // Talk control where the bridge is wired.
    assert.equal(body.realtime, true);
  } finally { on.close(); }
  // realtime off is reported false even when read-aloud is on (the two are distinct capabilities).
  const noRt = await listen(createApp({ env: {}, voice: fakeVoice(), vendorRepo: auditRepo(), verify, allowedOrigin: ORIGIN, realtimeConfigured: false }));
  try {
    const res = await request(noRt, '/api/v3/hugo/voice', { headers: agent });
    assert.equal(JSON.parse(res.buf.toString()).realtime, false);
  } finally { noRt.close(); }
  const off = await listen(appWith({ voice: undefined }));
  try {
    const res = await request(off, '/api/v3/hugo/voice', { headers: agent });
    assert.equal(res.status, 200);
    assert.equal(JSON.parse(res.buf.toString()).configured, false);
    // And the capability never appears on the unauthenticated /status.
    const status = await request(off, '/status');
    assert.equal('voice' in JSON.parse(status.buf.toString()), false);
  } finally { off.close(); }
});

test('GET /hugo/voice requires the agent role', async () => {
  const server = await listen(appWith({ voice: fakeVoice() }));
  try {
    const res = await request(server, '/api/v3/hugo/voice'); // no bearer
    assert.equal(res.status, 401);
  } finally { server.close(); }
});

// VH-777 Lane V: GPT-Live through the REAL app, so the route is proved reachable (WIRED), not only callable. The
// composition root's Live service is faked; the route, the voice probe's `live`, the role gate, the cross-site refusal
// and the daily cap are the app's own.
test('GPT-Live is reachable through the app: the probe says so, an offer opens, a cross-site page and a spent day are refused', async () => {
  const opened = [];
  const hugoLive = {
    configured: true,
    open: async (a) => { opened.push({ subject: a.principal.subject, domain: a.domain }); return { sessionId: 'live_x', sdp: 'v=0\r\n', model: 'gpt-live-1', brain: 'gpt-6-astra' }; },
    end: () => true,
    checkResult: async () => null,
  };
  let allowed = true;
  const server = await listen(createApp({ env: {}, voice: fakeVoice(), vendorRepo: auditRepo(), verify, allowedOrigin: ORIGIN, hugoLive, paidCallAllowed: async () => allowed }));
  const post = (headers, body) => request(server, '/api/v3/hugo/live', { method: 'POST', headers: { ...agent, 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });
  const offer = { sdp: 'v=0\r\nm=audio 9 x\r\nm=application 9 y\r\n', domain: 'space' };
  try {
    assert.equal((await probeOf(server)).live, true);
    const ok = await post({}, offer);
    assert.equal(ok.status, 201);
    assert.equal(JSON.parse(ok.buf.toString()).sessionId, 'live_x');
    assert.deepEqual(opened, [{ subject: 'ada', domain: 'space' }]);
    assert.equal((await post({ origin: 'https://evil.example' }, offer)).status, 403, 'judged cross-site like every mutating route');
    assert.equal((await request(server, '/api/v3/hugo/live', { method: 'POST', headers: { ...lead, 'content-type': 'application/json' }, body: JSON.stringify(offer) })).status, 403, 'the agent role only');
    allowed = false;
    assert.equal((await post({}, offer)).status, 429);
    assert.equal(opened.length, 1, 'nothing is opened once refused');
  } finally { server.close(); }
  const off = await listen(createApp({ env: {}, voice: fakeVoice(), vendorRepo: auditRepo(), verify, allowedOrigin: ORIGIN }));
  try {
    assert.equal((await probeOf(off)).live, false);
    const res = await request(off, '/api/v3/hugo/live', { method: 'POST', headers: { ...agent, 'content-type': 'application/json' }, body: JSON.stringify(offer) });
    assert.equal(res.status, 503);
  } finally { off.close(); }
});

// VH-865: the probe says whether THIS caller can fix a voice that is off, so Talk's reason names the setting for an
// administrator and says "ask your administrator" to anyone else.
test('the voice probe tells an administrator they can fix it, and no one else', async () => {
  const server = await listen(appWith({ voice: fakeVoice({ configured: false, fault: 'no-key' }) }));
  try {
    assert.equal((await probeOf(server)).canFix, false, 'an agent');
    const admin = JSON.parse((await request(server, '/api/v3/hugo/voice', { headers: { authorization: 'Bearer admin-tok' } })).buf.toString());
    assert.equal(admin.canFix, true, 'an administrator');
  } finally { server.close(); }
});
