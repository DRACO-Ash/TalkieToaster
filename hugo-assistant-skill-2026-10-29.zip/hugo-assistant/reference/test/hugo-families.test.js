// The Hugo family keys and the query-term resolver. Since VH-775 the keys are read live from the glyph module's
// registry rather than held here as a parallel copy, so the test pins that they ARE the registry's, in its order.

import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

import { hugoFamilyKeys, familyKeyFromTerm, familiesInText, familyKeyOfProductType, productTypesForFamilies } from '../src/hugo/families.js';
import { FAMILY, familyKey, applyFamilyOverrides } from '../public/views/fingerprint-glyph.js';
import { SPACE_DESCRIPTOR, getDescriptor, domainIds } from '../src/domain/descriptor.js';
import { applyTypeFamilies } from '../src/domain/type-families.js';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';
import { createVendorRepo } from '../src/db/vendor-repo.js';
import { createDataTypeRepo } from '../src/db/data-type-repo.js';
import { runMigrations } from '../src/db/migrate.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';

test('the Hugo family keys are the registry\'s, in its order', () => {
  assert.deepEqual(hugoFamilyKeys(), Object.keys(FAMILY), 'the Hugo family keys are read from public/views/fingerprint-glyph.js FAMILY');
  assert.deepEqual(hugoFamilyKeys(), ['EO', 'SAR', 'RF', 'IR', 'HSI', 'SDA', 'WX', 'AN', 'OTHER'], 'the shipped nine, with no store');
});

test('familyKeyFromTerm maps names, acronyms and phrases to keys', () => {
  assert.equal(familyKeyFromTerm('EO'), 'EO');
  assert.equal(familyKeyFromTerm('electro-optical'), 'EO');
  assert.equal(familyKeyFromTerm('electro optical'), 'EO');
  assert.equal(familyKeyFromTerm('SAR'), 'SAR');
  assert.equal(familyKeyFromTerm('synthetic aperture radar'), 'SAR');
  assert.equal(familyKeyFromTerm('radar'), 'SAR');
  assert.equal(familyKeyFromTerm('hyperspectral'), 'HSI');
  assert.equal(familyKeyFromTerm('thermal'), 'IR');
  assert.equal(familyKeyFromTerm('SIGINT'), 'RF');
  assert.equal(familyKeyFromTerm('space domain awareness'), 'SDA');
  assert.equal(familyKeyFromTerm('data fusion'), 'AN');
  assert.equal(familyKeyFromTerm('weather'), 'WX');
});

test('familyKeyFromTerm returns null for a non-family term and bad input', () => {
  assert.equal(familyKeyFromTerm('bananas'), null);
  assert.equal(familyKeyFromTerm(''), null);
  assert.equal(familyKeyFromTerm(null), null);
  assert.equal(familyKeyFromTerm(42), null);
});

test('the most specific rule wins over a shorter one', () => {
  // "synthetic aperture radar" must be SAR, not shadowed, and a bare "radar" is still SAR.
  assert.equal(familyKeyFromTerm('synthetic aperture radar'), 'SAR');
  // "hyperspectral" must not be swallowed by any optical rule.
  assert.equal(familyKeyFromTerm('hyperspectral imagery'), 'HSI');
});

test('familiesInText finds every named family, in canonical order, deduped', () => {
  assert.deepEqual(familiesInText('the SAR and EO vendors'), ['EO', 'SAR']);
  assert.deepEqual(familiesInText('EO, eo, electro-optical'), ['EO']);
  assert.deepEqual(familiesInText('radar plus hyperspectral plus thermal'), ['SAR', 'IR', 'HSI']);
  assert.deepEqual(familiesInText('vendors in the UK'), []);
  assert.deepEqual(familiesInText(''), []);
  assert.deepEqual(familiesInText(null), []);
});

test('the server copy of the product_type -> family RULES agrees with the glyph for every product type (V1.82, RT-Q4)', () => {
  // The parallel-copy pattern this file already guards for the KEYS, extended to the RULES, because the
  // families clause now expands a family to product types on the server and a rule that drifted would filter
  // a different set from the one the glyph paints. Every Space product type is classified by both copies.
  const vocab = SPACE_DESCRIPTOR.vocab.product_types;
  const types = [...vocab];
  assert.ok(types.length > 30, 'the Space vocabulary was read (' + types.length + ' types)');
  for (const t of types) assert.equal(familyKeyOfProductType(t), familyKey(t), t);
  // And the expansion returns only the types the client would badge with that family.
  const sar = productTypesForFamilies(['SAR'], types);
  assert.ok(sar.length > 0);
  for (const t of sar) assert.equal(familyKey(t), 'SAR', t);
  assert.deepEqual(productTypesForFamilies(['NOPE'], types), []);
  assert.deepEqual(productTypesForFamilies(['sar', 'SAR'], types), sar, 'case-insensitive, de-duplicated');
});

// ONE MAPPING, EVERY DOMAIN (VH-623). The parity above held for Space alone, and the sweep for VH-623 measured the
// server copy disagreeing with the cards on 97 of 247 product types across the other 6 domains, because the cards
// carry an exact-name table the copy never had: Hugo, search and Explore filed those values under one family while
// the cards drew another. The server now reads the cards' own mapping, so this holds for every domain and for a
// value no schema holds yet, which is what a type added at runtime is.
test('the server files every product type on every domain exactly as the cards do, a runtime value included', () => {
  let n = 0;
  for (const d of domainIds()) {
    for (const t of getDescriptor(d)?.vocab?.product_types || []) {
      n += 1;
      assert.equal(familyKeyOfProductType(t), familyKey(t), d + ': ' + t);
    }
  }
  assert.ok(n > 240, 'every domain was read (' + n + ' types)');
  for (const t of ['Passive radar tracks (added at runtime)', 'Unheard-of data product']) assert.equal(familyKeyOfProductType(t), familyKey(t), t);
});

// AN ADMIN'S FAMILY, AS THE SERVER FILTERS AND AS A PAGE DRAWS IT (VH-705 S4). The server puts the stored rows in force at
// load; a page puts the placements the vocabulary route serves for each domain (`familyDomains`) in force with the same
// function. So a page holding what it was served must answer every product type on every domain as the server does, the
// moved one included, and on its own domain only (Families per domain: Land and Air both hold NAME; only Land moved it).
test('an overridden name: the server and a page holding the served rows file every product type the same', async () => {
  const ex = await makePgliteExecutor();
  let server = null;
  const NAME = 'Wide-Area Motion Imagery';
  const everyType = () => new Map(domainIds().flatMap((d) => [...getDescriptor(d).vocab.product_types].map((t) => [d + ': ' + t, familyKey(t, d)])));
  try {
    await runMigrations(ex);
    const dataTypeRepo = createDataTypeRepo(ex);
    await dataTypeRepo.load();
    assert.equal(familyKeyOfProductType(NAME, 'land'), 'EO', 'the exact table, measured');
    assert.equal((await dataTypeRepo.families.set('land', NAME, { family: 'SAR', rev: 0 }, 'owner')).ok, true);
    assert.equal(familyKeyOfProductType(NAME, 'land'), 'SAR', "the server's answer moved");
    assert.equal(familyKeyOfProductType(NAME, 'air'), 'EO', 'on Land alone');
    const serverAnswers = everyType();

    server = await new Promise((resolve) => {
      const s = http.createServer(createApp({ vendorRepo: createVendorRepo(ex), dataTypeRepo, allowedOrigin: 'http://localhost',
        verify: createStaticVerifier({ 'agent-tok': { subject: 'ada', roles: ['agent'] } }) }));
      s.listen(0, '127.0.0.1', () => resolve(s));
    });
    const served = await new Promise((resolve, reject) => {
      http.get({ host: '127.0.0.1', port: server.address().port, path: '/api/v3/vocab', headers: { authorization: 'Bearer agent-tok' } }, (res) => {
        let text = ''; res.on('data', (c) => { text += c; }); res.on('end', () => resolve(JSON.parse(text)));
      }).on('error', reject);
    });

    // A page that has drawn nothing yet holds no row, then puts in force what it was served, each domain's on its own.
    for (const d of domainIds()) applyFamilyOverrides([], undefined, d);
    assert.equal(familyKey(NAME, 'land'), 'EO', 'the premise: a page holding nothing draws the table answer');
    for (const d of domainIds()) applyFamilyOverrides(served.familyDomains[d].overrides, undefined, d);
    assert.equal(familyKey(NAME, 'land'), 'SAR');
    assert.deepEqual(everyType(), serverAnswers, 'every product type on every domain, filed the same on both sides');
  } finally {
    applyTypeFamilies([]);
    if (server) await new Promise((r) => server.close(r));
    await ex.close?.();
  }
});
