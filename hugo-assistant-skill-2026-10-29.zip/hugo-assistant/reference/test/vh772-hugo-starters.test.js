// VH-772 (Development 2, 2026-10-20): Hugo's starter suggestions read as invitations rather than empty fields. Read from
// the stylesheet, and the text on the starter's tint measured on the token pairs.
import test from 'node:test';
import assert from 'node:assert/strict';
import { bodyOf, ratio, THEMES, token } from './helpers/stylesheet.js';

const mix = (a, b, p) => '#' + [1, 3, 5].map((i) => Math.round(p * Number.parseInt(a.slice(i, i + 2), 16) + (1 - p) * Number.parseInt(b.slice(i, i + 2), 16)).toString(16).padStart(2, '0')).join('');

test('a Hugo starter is a full-height rounded invitation at the small body size, its text clear on its tint', () => {
  const rule = bodyOf('.hugo-starter');
  assert.match(rule, /min-height: var\(--control-h\); padding: var\(--space-1\) var\(--space-4\); border-radius: var\(--radius-lg\);/);
  assert.match(rule, /font-size: var\(--text-sm\);/);
  for (const [name, where] of THEMES) {
    const r = ratio(token(where, 'text'), mix(token(where, 'accent'), token(where, 'surface-2'), 0.1));
    assert.ok(r >= 4.5, name + ' starter text is ' + r.toFixed(2));
  }
});
