// Hugo's starter chips (public/views/hugo-starters.js): three openings from data already held, with figures
// only where the rows they count are held (PLAN-9.5 I8).

import test from 'node:test';
import assert from 'node:assert/strict';

import { starterChips, familyHeadroom } from '../public/views/hugo-starters.js';

const row = (over) => ({ record: { company: 'X', gdm: 'Not in GDM', product_types: ['SAR imagery'], last_verified: '2026-08-01', ...over } });

test('familyHeadroom names the family with the most vendors not yet in the GDM, deterministically', () => {
  const rows = [row(), row(), row({ product_types: ['EO sensor'] }), row({ product_types: ['SAR imagery'], gdm: 'In GDM' })];
  assert.deepEqual(familyHeadroom(rows), { key: 'SAR', name: 'SAR / radar', count: 2 });
  // A tie breaks on the key, so the same rows always give the same chip.
  assert.equal(familyHeadroom([row({ product_types: ['EO sensor'] }), row()]).key, 'EO');
  assert.equal(familyHeadroom([row({ product_types: [] })]), null);
  assert.equal(familyHeadroom(null), null);
});

test('with the whole set held, the three chips carry figures counted from it', (t) => {
  // `starterChips` counts staleness on the wall clock, and the default row's '2026-08-01' passes 18 months on
  // 2028-01-30, so pin the clock rather than let the "1 record" figure become "3 records" that day.
  t.mock.timers.enable({ apis: ['Date'], now: Date.parse('2026-09-17T00:00:00Z') });
  const rows = [row(), row(), row({ product_types: ['EO sensor'], last_verified: '2019-01-01' })];
  const chips = starterChips({ rows, analytics: { answers: { gap: { region: 'Pacific' } } } });
  assert.equal(chips.length, 3);
  assert.equal(chips[0].label, 'SAR / radar scoped vendors not in the GDM (2)');
  assert.equal(chips[0].sentence, 'the SAR / radar scoped vendors that are not in the GDM');
  assert.equal(chips[1].label, '1 record past 18 months since verification');
  assert.equal(chips[2].label, 'The coverage gap in Pacific, on the map');
  assert.equal(chips[2].sentence, 'the companies covering Pacific, on a map');
});

test('with nothing held, the three chips fall back to the same openings with NO figure in them', () => {
  const chips = starterChips({});
  assert.equal(chips.length, 3);
  // No COUNT: no leading figure and no parenthesised one. The "18 months" window is the verification policy
  // every surface states, not a figure derived from rows, so it may appear.
  for (const c of chips) {
    assert.doesNotMatch(c.label, /(?:^\d)|\(\d+\)|\d+ records?\b/, 'a fallback chip carries no count: ' + c.label);
    assert.ok(c.sentence.length > 10);
  }
  assert.equal(chips[0].label, 'Scoped vendors not in the GDM');
  assert.equal(chips[2].label, 'In GDM vendors, on the map');
  // A held but empty set is a genuine zero, stated as words rather than a bare "0".
  assert.equal(starterChips({ rows: [] })[1].label, 'No records past 18 months since verification');
});
