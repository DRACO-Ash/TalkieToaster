// The Hugo ViewIntent validator. It is the enforcement boundary for every path (deterministic, model, form):
// only descriptor-valid controlled values, canonical countries and known family keys survive; everything else
// is routed to `unmapped`, never invented, never silently kept.

import test from 'node:test';
import assert from 'node:assert/strict';

import { normaliseViewIntent, intentHasFilter, resolveOwners, VIEWS, DUE_WINDOWS } from '../src/hugo/view-intent.js';
import { getDescriptor, domainIds } from '../src/domain/descriptor.js';

const SPACE = getDescriptor('space');
const IDS = domainIds();

test('a fully-mapped Space query keeps only valid values', () => {
  const { intent, unmapped } = normaliseViewIntent({
    domain: 'space',
    filterSpec: {
      countries: ['UK'],
      gdm: ['Not in GDM'],
      sections: ['Spaceflight Safety'],
      families: ['eo', 'SAR'],
    },
    view: 'map',
  }, SPACE, { domainIds: IDS });
  assert.equal(intent.domain, 'space');
  assert.deepEqual(intent.filterSpec.countries, ['United Kingdom']);
  assert.deepEqual(intent.filterSpec.gdm, ['Not in GDM']);
  assert.deepEqual(intent.filterSpec.sections, ['Spaceflight Safety']);
  assert.deepEqual(intent.filterSpec.families, ['EO', 'SAR']);
  assert.equal(intent.view, 'map');
  assert.deepEqual(unmapped, []);
});

test('unknown values route to unmapped and never survive', () => {
  const { intent, unmapped } = normaliseViewIntent({
    filterSpec: {
      countries: ['Atlantis'],
      sections: ['Not a section'],
      families: ['XYZ'],
      gdm: ['made up'],
    },
  }, SPACE, { domainIds: IDS });
  assert.deepEqual(intent.filterSpec.countries, []);
  assert.deepEqual(intent.filterSpec.sections, []);
  assert.deepEqual(intent.filterSpec.families, []);
  assert.deepEqual(intent.filterSpec.gdm, []);
  const fields = unmapped.map((u) => u.field).sort();
  assert.deepEqual(fields, ['countries', 'families', 'gdm', 'sections']);
});

test('an axis the domain does not carry routes to unmapped, not silently applied', () => {
  // `grades` on a readiness-less descriptor proved this until V1.80 deleted the clause outright. GDM is
  // the surviving `needs`-gated clause, so the guard is proved on the mechanism that still exists: a
  // descriptor without the axis reports the clause rather than applying it.
  const noGdm = { ...SPACE, hasGdm: false };
  const { intent, unmapped } = normaliseViewIntent(
    { filterSpec: { gdm: ['In GDM'] } }, noGdm, { domainIds: IDS },
  );
  assert.deepEqual(intent.filterSpec.gdm, []);
  assert.ok(unmapped.some((u) => u.field === 'gdm' && u.value === 'In GDM'));
  // AND THE OTHER VERDICT: the same clause on a descriptor that DOES carry the axis is applied.
  const on = normaliseViewIntent({ filterSpec: { gdm: ['In GDM'] } }, SPACE, { domainIds: IDS });
  assert.deepEqual(on.intent.filterSpec.gdm, ['In GDM']);
});

test('a grade clause is not a clause at all any more, on any domain', () => {
  // Space admitted `grades` until V1.80 removed the readiness axis; the clause was then gated off by
  // `hasReadiness` for one step, and is now deleted from the validator's table entirely. So it is no
  // longer a KNOWN clause with an unmet requirement - it is an unrecognised key, and the whole
  // filterSpec it arrives in must survive it rather than the request failing.
  for (const [name, d] of [['space', SPACE], ['air', getDescriptor('air')]]) {
    const { intent } = normaliseViewIntent(
      { filterSpec: { grades: ['In JCO'], countries: ['United Kingdom'] } }, d, { domainIds: IDS },
    );
    // MEASURED: the key is dropped from the normalised spec rather than emptied, because nothing in
    // `VOCAB_CLAUSES` names it any more. Printed before being written, not carried from the old test.
    assert.equal(intent.filterSpec.grades, undefined, name + ': the clause is gone from the spec');
    assert.deepEqual(intent.filterSpec.countries, ['United Kingdom'], name + ': its neighbours survive');
  }
  // THE OTHER VERDICT, so this can report both things: a clause on an axis the domain DOES carry
  // still passes, with its unknown value reported.
  const { intent, unmapped } = normaliseViewIntent(
    { filterSpec: { gdm: ['In GDM', 'nonsense'] } }, SPACE, { domainIds: IDS },
  );
  assert.deepEqual(intent.filterSpec.gdm, ['In GDM']);
  assert.ok(unmapped.some((u) => u.field === 'gdm' && u.value === 'nonsense'));
});

test('an unregistered domain falls back to the descriptor id', () => {
  const { intent } = normaliseViewIntent({ domain: 'atlantis' }, SPACE, { domainIds: IDS });
  assert.equal(intent.domain, 'space');
});

test('a registered domain is kept', () => {
  const air = getDescriptor('air');
  const { intent } = normaliseViewIntent({ domain: 'air' }, air, { domainIds: IDS });
  assert.equal(intent.domain, 'air');
});

test('an invalid view resolves to empty; valid views pass', () => {
  assert.equal(normaliseViewIntent({ view: 'hologram' }, SPACE, { domainIds: IDS }).intent.view, '');
  for (const v of VIEWS) {
    assert.equal(normaliseViewIntent({ view: v }, SPACE, { domainIds: IDS }).intent.view, v);
  }
});

test('crossDomain flag is honoured from opts and from raw', () => {
  assert.equal(normaliseViewIntent({}, SPACE, { domainIds: IDS, crossDomain: true }).intent.crossDomain, true);
  assert.equal(normaliseViewIntent({ crossDomain: true }, SPACE, { domainIds: IDS }).intent.crossDomain, true);
  assert.equal(normaliseViewIntent({}, SPACE, { domainIds: IDS }).intent.crossDomain, false);
});

test('values dedupe and read from top level or nested filterSpec', () => {
  const nested = normaliseViewIntent({ filterSpec: { sections: ['TacSRT', 'TacSRT'] } }, SPACE, { domainIds: IDS });
  assert.deepEqual(nested.intent.filterSpec.sections, ['TacSRT']);
  const top = normaliseViewIntent({ sections: ['TacSRT'] }, SPACE, { domainIds: IDS });
  assert.deepEqual(top.intent.filterSpec.sections, ['TacSRT']);
});

test('malformed input fails closed to a safe empty intent', () => {
  for (const bad of [null, undefined, 42, 'text', []]) {
    const { intent, unmapped } = normaliseViewIntent(bad, SPACE, { domainIds: IDS });
    assert.equal(intent.domain, 'space');
    assert.equal(intentHasFilter(intent), false);
    assert.deepEqual(unmapped, []);
  }
});

test('intentHasFilter is true only when a clause is populated', () => {
  const empty = normaliseViewIntent({}, SPACE, { domainIds: IDS }).intent;
  assert.equal(intentHasFilter(empty), false);
  const one = normaliseViewIntent({ filterSpec: { gdm: ['In GDM'] } }, SPACE, { domainIds: IDS }).intent;
  assert.equal(intentHasFilter(one), true);
  assert.equal(intentHasFilter(null), false);
});

test('confidence is validated against low/medium/high; anything else drops to empty', () => {
  assert.equal(normaliseViewIntent({ confidence: 'HIGH' }, SPACE, { domainIds: IDS }).intent.confidence, 'high');
  assert.equal(normaliseViewIntent({ confidence: 'medium' }, SPACE, { domainIds: IDS }).intent.confidence, 'medium');
  assert.equal(normaliseViewIntent({ confidence: 'certainly' }, SPACE, { domainIds: IDS }).intent.confidence, '');
  assert.equal(normaliseViewIntent({ confidence: 42 }, SPACE, { domainIds: IDS }).intent.confidence, '');
});

test('the question phrase is carried and capped', () => {
  const q = 'a'.repeat(1000);
  const { intent } = normaliseViewIntent({ question: q }, SPACE, { domainIds: IDS });
  assert.equal(intent.question.length, 400);
});

// --- THE PIPELINE CLAUSES (V1.77 W1-3) --------------------------------------------------------------------
//
// These are the ADVERSARIAL cases the plan asks for. The pipeline clauses reach this validator from three
// places (the deterministic resolver, the model, the confirm surface), and two of them can send anything, so
// every case below is a value a hostile or confused caller could actually send.

test('the pipeline list clauses admit only their own schema vocabulary', () => {
  const { intent, unmapped } = normaliseViewIntent({
    filterSpec: {
      stages: ['contracting', 'CONTRACTING', 'nda', 'promoted-to-live'],
      blockerKinds: ['legal', 'LEGAL', 'unicorn'],
      priorities: ['High', 'high', 'Critical'],
    },
  }, SPACE, { domainIds: IDS });
  // Case is folded for the two lower_snake vocabularies, so "CONTRACTING" is the same stage and dedupes.
  assert.deepEqual(intent.filterSpec.stages, ['contracting', 'nda']);
  assert.deepEqual(intent.filterSpec.blockerKinds, ['legal']);
  // The priority list is title case in the schema, so it matches exactly: "high" is NOT "High", because
  // folding it would admit a value the column's CHECK constraint refuses.
  assert.deepEqual(intent.filterSpec.priorities, ['High']);
  const fields = unmapped.map((u) => u.field + ':' + u.value).sort();
  assert.deepEqual(fields, ['blockerKinds:unicorn', 'priorities:Critical', 'priorities:high', 'stages:promoted-to-live']);
});

test('an owner is an identity, capped and kept, and "me" survives for the route to resolve', () => {
  const { intent } = normaliseViewIntent({
    filterSpec: { owners: ['ada', 'me', '  bob  ', '', 'x'.repeat(500)] },
  }, SPACE, { domainIds: IDS });
  assert.deepEqual(intent.filterSpec.owners.slice(0, 3), ['ada', 'me', 'bob']);
  assert.equal(intent.filterSpec.owners[3].length, 200, 'capped at the value cap, not dropped');
  // 'me' is NOT resolved here: this module has no caller identity and must not guess one.
  assert.ok(intent.filterSpec.owners.includes('me'));
});

test('resolveOwners substitutes the actor for "me", and DROPS it when there is no actor', () => {
  assert.deepEqual(resolveOwners(['ada', 'me'], 'bob@example.gov.uk'), ['ada', 'bob@example.gov.uk']);
  assert.deepEqual(resolveOwners(['ME', ' me '], 'bob'), ['bob'], 'case and padding, deduped to one');
  // Fail closed: an unresolved 'me' reaching the query builder would be matched literally against the owner
  // column. That matches nothing today, but relying on that is relying on an accident.
  assert.deepEqual(resolveOwners(['ada', 'me'], ''), ['ada']);
  assert.deepEqual(resolveOwners(['me'], undefined), []);
  // Totality: a non-array, and entries that are not strings.
  assert.deepEqual(resolveOwners(null, 'bob'), []);
  assert.deepEqual(resolveOwners(['ada', 42, null, {}], 'bob'), ['ada']);
});

test('blocked is a TRISTATE: absent means do not filter, and only a real boolean or its exact string sets it', () => {
  const spec = (raw) => normaliseViewIntent({ filterSpec: raw }, SPACE, { domainIds: IDS }).intent.filterSpec;
  assert.equal(spec({}).blocked, undefined, 'absent is the third state and it must stay absent');
  assert.equal(spec({ blocked: true }).blocked, true);
  assert.equal(spec({ blocked: false }).blocked, false);
  assert.equal(spec({ blocked: 'true' }).blocked, true);
  assert.equal(spec({ blocked: 'false' }).blocked, false);
  // Everything else is REPORTED rather than guessed at. "yes" and 1 are the two a model most plausibly
  // sends, and reading either as true would be inventing the operator's filter.
  for (const junk of ['yes', 'TRUE', 1, 0, {}, []]) {
    const { intent, unmapped } = normaliseViewIntent({ filterSpec: { blocked: junk } }, SPACE, { domainIds: IDS });
    assert.equal(intent.filterSpec.blocked, undefined, String(junk));
    assert.ok(unmapped.some((u) => u.field === 'blocked'), String(junk) + ' must be reported');
  }
});

test('due is a closed set of relative windows, and ageing is a bounded whole number of days', () => {
  const spec = (raw) => normaliseViewIntent({ filterSpec: raw }, SPACE, { domainIds: IDS }).intent.filterSpec;
  for (const window of DUE_WINDOWS) assert.equal(spec({ due: window }).due, window);
  assert.equal(spec({ due: 'OVERDUE' }).due, 'overdue', 'case folded');
  assert.equal(spec({ due: '2026-09-14' }).due, undefined, 'a date is not a window: no clock is read here');
  assert.ok(normaliseViewIntent({ filterSpec: { due: 'whenever' } }, SPACE, { domainIds: IDS })
    .unmapped.some((u) => u.field === 'due'));
  assert.equal(spec({ ageing: 30 }).ageingDays, 30);
  assert.equal(spec({ ageing: '45' }).ageingDays, 45, 'a numeric string is the shape a form sends');
  assert.equal(spec({ ageing: 99999 }).ageingDays, 3650, 'capped rather than refused');
  // A FRACTIONAL DAY IS REFUSED IN BOTH FORMS, and writing this test is what found the inconsistency: the
  // first version read the string path with `parseInt`, which turns "1.5" into 1, while the number 1.5 was
  // refused for not being an integer. The same value was accepted or refused depending on which of the three
  // callers sent it. Neither is a day an operator asked for, so both are refused and reported.
  for (const junk of [0, -5, 'soon', 1.5, '1.5', Number.NaN, '', '  ']) {
    assert.equal(spec({ ageing: junk }).ageingDays, undefined, JSON.stringify(junk));
  }
  for (const junk of [1.5, '1.5', 'soon']) {
    assert.ok(normaliseViewIntent({ filterSpec: { ageing: junk } }, SPACE, { domainIds: IDS })
      .unmapped.some((u) => u.field === 'ageing'), JSON.stringify(junk) + ' must be reported');
  }
});

test('a pipeline-only intent COUNTS as having a filter, including the scalar clauses', () => {
  const has = (raw) => intentHasFilter(normaliseViewIntent({ filterSpec: raw }, SPACE, { domainIds: IDS }).intent);
  assert.equal(has({ stages: ['live'] }), true);
  // The three that are not lists. Before V1.77 this tested arrays only, so an intent whose ONLY filter was
  // "show me what is blocked" reported no filter and the caller fell back to showing everything: the widest
  // possible answer to the narrowest possible question.
  assert.equal(has({ blocked: true }), true);
  assert.equal(has({ blocked: false }), true, 'explicitly NOT blocked is a filter too');
  assert.equal(has({ due: 'overdue' }), true);
  assert.equal(has({ ageing: 30 }), true);
  // And still false for an intent that resolved to nothing at all.
  assert.equal(has({ stages: ['nonsense'], blocked: 'maybe' }), false);
});

test('pipeline is a view a ViewIntent may drive', () => {
  assert.ok(VIEWS.includes('pipeline'));
  assert.equal(normaliseViewIntent({ view: 'pipeline' }, SPACE, { domainIds: IDS }).intent.view, 'pipeline');
});
