// THE MODEL-PATH EVAL (VH-777 Lane T): the real loop, judged on what the operator sees, replayed from recordings that
// the recorder writes and the replay finds by the same key. A task with no recording is NOT RECORDED, never a pass.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { judgeModelTask, replayChat, runHugoModelSuite, loadHugoModelTasks, loadHugoDataset } from '../eval/lib/suites.js';
import { createFileRecorder, createReplayer, MissingRecordingError } from '../eval/lib/recordings.js';
import { createOpenAiChat } from '../src/hugo/openai-chat.js';
import { makePgliteExecutor } from './helpers/pglite-executor.js';

test('a task is judged on the tools it reached for, the record check and what the answer says', () => {
  const out = (tools, ok, answer) => ({ steps: tools.map((tool) => ({ tool })), verification: { ok }, answer });
  assert.deepEqual(judgeModelTask({ expect: { noTools: true, verified: true } }, out([], true, 'Hello')), { ok: true, reasons: [] });
  assert.deepEqual(judgeModelTask({ expect: { noTools: true } }, out(['describe_app'], true, 'Hi')).reasons, ['reached for tools: describe_app']);
  assert.deepEqual(judgeModelTask({ expect: { tools: ['search_help'] } }, out(['describe_app'], true, '')).reasons, ['did not use search_help']);
  assert.deepEqual(judgeModelTask({ expect: { toolsAny: ['get_record', 'query_records'] } }, out(['query_records'], true, '')).ok, true);
  assert.deepEqual(judgeModelTask({ expect: { verified: true } }, out([], false, 'x')).reasons, ['the answer failed the record check']);
  assert.equal(judgeModelTask({ expect: { answerExcludes: 'Zorblax Orbital Ltd supplies' } }, out([], true, 'Zorblax Orbital Ltd supplies radars')).ok, false);
  assert.equal(judgeModelTask({ expect: { answerMatches: '\\bone\\b' } }, out([], true, 'There is one company.')).ok, true);
});

test('the replay finds exactly what the recorder wrote, by the same request, and refuses anything else', async () => {
  const dir = mkdtempSync(path.join(tmpdir(), 'hugo-model-'));
  try {
    const reply = { output: [{ type: 'message', content: [{ type: 'output_text', text: '{"answer":"Hello."}' }] }], usage: { input_tokens: 3, output_tokens: 2 } };
    const chatReply = { choices: [{ message: { role: 'assistant', content: '{"answer":"Hello."}' }, finish_reason: 'stop' }], usage: { prompt_tokens: 3, completion_tokens: 2 } };
    const fetchImpl = async (url) => ({ ok: true, json: async () => (String(url).endsWith('/responses') ? reply : chatReply) });
    const live = createOpenAiChat({ apiKey: 'k', fetchImpl, recorder: createFileRecorder(dir) });
    const req = { system: ['s'], messages: [{ role: 'user', content: 'hi' }] };
    const recorded = await live.chatOnce(req);
    const recordedWithTools = await live.chatOnce({ ...req, tools: [{ type: 'function', function: { name: 't', parameters: { type: 'object', properties: {} } } }] });
    const replayed = replayChat(createReplayer(dir, { provider: 'openai' }));
    assert.deepEqual(await replayed.chatOnce(req), recorded, 'a tool-free turn');
    assert.deepEqual(await replayed.chatOnce({ ...req, tools: [{ type: 'function', function: { name: 't', parameters: { type: 'object', properties: {} } } }] }), recordedWithTools, 'and a tool turn');
    await assert.rejects(replayed.chatOnce({ ...req, messages: [{ role: 'user', content: 'hello' }] }), MissingRecordingError, 'a changed question finds nothing');
  } finally { rmSync(dir, { recursive: true, force: true }); }
});

test('the suite runs every task through the loop, and a task with no recording is not recorded, never passed', async () => {
  const tasks = loadHugoModelTasks();
  assert.deepEqual(tasks.map((t) => t.kind), ['greeting', 'help', 'count', 'lookup', 'fabrication', 'all-domains'], 'the plan\'s 6 cases');
  const executor = await makePgliteExecutor();
  try {
    // A scripted model: a greeting needs no tool; every other task is unrecorded.
    const chat = {
      async chatOnce({ messages }) {
        if (messages[0].content.startsWith('Hello Hugo')) return { message: { role: 'assistant', content: '{"answer":"Hello! I am well, thank you."}' }, usage: {} };
        throw new MissingRecordingError({ hash: '0'.repeat(64), dir: 'x', provider: 'openai' });
      },
    };
    const out = await runHugoModelSuite({ tasks, dataset: loadHugoDataset(), executor, chat });
    assert.deepEqual([out.tasks, out.recorded, out.notRecorded, out.passed], [6, 1, 5, 1]);
    assert.deepEqual(out.failed.map((f) => f.reasons[0]), new Array(5).fill('not recorded'));
  } finally { await executor.close(); }
});
