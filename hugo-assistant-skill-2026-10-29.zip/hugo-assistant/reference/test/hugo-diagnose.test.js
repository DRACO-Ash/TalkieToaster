// HUGO'S PREFLIGHT (owner, 2026-09-17: "hugo still sucks ass - it doesnt work", with BOTH provider keys
// already set).
//
// WHY THIS EXISTS. Hugo has three states and the interface could not tell them apart from the outside,
// because the deterministic tool layer answers plausibly in all three: the process cannot see a key, the
// provider refuses the call, or he is working. A missing environment variable, a wrong model id, a spent
// quota and a blocked egress therefore produce the same shrug - which is how a fault can stand for several
// releases while two people guess at it. This turns the question into a fact.
//
// THE AUTHOR OF THIS CHANGE GUESSED WRONG FIRST, which is the reason the preflight was built rather than
// another fix attempted: a session probe in a container with NO key showed the "model is not available"
// fallback, and that was misread as the owner's fault rather than as an artefact of the test environment.
// The owner's deployment has the key. Nothing in the interface could have told the two apart.
import test from 'node:test';
import assert from 'node:assert/strict';

import { makeHugoDiagnose } from '../src/boot.js';
import { classifyCallerError } from '../src/scan/anthropic-caller.js';

const noop = () => {};
const clock = () => { let t = 1000; return () => { t += 7; return t; }; };

const diagnose = (hugoChat, log = noop) => makeHugoDiagnose({
  hugoChat, classifyCallerError, flushSpend: async () => {}, now: clock(), log,
});

test('NO KEY THE PROCESS CAN SEE is its own diagnosis, not folded into an auth failure', async () => {
  // These send an admin to different places: one is a variable to set, the other a credential to replace.
  const out = await diagnose({ configured: false })();
  assert.deepEqual(out, { ok: false, configured: false, kind: 'not_configured', model: '', latencyMs: 0 });
  // A caller object that exists but cannot chat is the same finding: there is no working model path.
  assert.equal((await diagnose({ configured: true })()).kind, 'not_configured');
});

test('a working provider reports ok, the model in use, and a latency', async () => {
  const out = await diagnose({ configured: true, model: 'gpt-6-astra', chatOnce: async () => ({ message: { content: 'OK' } }) })();
  assert.equal(out.ok, true);
  assert.equal(out.configured, true);
  assert.equal(out.model, 'gpt-6-astra', 'so an operator can see WHICH model answered, not just that one did');
  assert.ok(out.latencyMs > 0);
});

test('the calls the preflight makes are tiny: the first carries NO tools, the second one tool it may not run', async () => {
  // A preflight that spent real money or ran a tool would be a thing an operator hesitates to press, and
  // one that ran tools could fail for a reason that has nothing to do with reachability. VH-777: the second call
  // carries one tool definition so it takes the endpoint a typed answer's turns take, and `none` so no tool runs.
  const seen = [];
  const out = await makeHugoDiagnose({ hugoChat: { configured: true, model: 'm', chatOnce: async (args) => { seen.push(args); return { message: { content: 'OK' } }; } },
    classifyCallerError, flushSpend: async () => {}, now: clock(), log: noop, toolDefs: () => [{ name: 'a' }, { name: 'b' }] })();
  assert.equal(seen.length, 2);
  assert.equal(seen[0].maxTokens, 16);
  assert.equal(seen[0].tools, undefined, 'no tools: this asks whether the provider answers, nothing more');
  assert.equal(seen[0].messages.length, 1);
  assert.deepEqual(seen[1].tools, [{ name: 'a' }], 'one tool definition, not the set');
  assert.equal(seen[1].toolChoice, 'none');
  assert.equal(seen[1].maxTokens, 16);
  assert.equal(out.links.tools.ok, true);
});

// VH-777: "connected (gpt-6-astra), 2728ms" while Hugo would not converse. Every link a turn uses is tried and named.
test('every link is tried and named: the tool turn, and the speech service dialled, off or refused', async () => {
  const chat = (second) => ({ configured: true, model: 'm', chatOnce: async (args) => {
    if (args.tools && second) { throw second; }
    return { message: { content: 'OK' } };
  } });
  const run = (hugoChat, realtime) => makeHugoDiagnose({ hugoChat, classifyCallerError, flushSpend: async () => {}, now: clock(), log: noop, toolDefs: () => [{ name: 'a' }], realtime })();
  const ok = await run(chat(), () => ({ configured: true, model: 'gpt-realtime-2', probe: async () => ({ ok: true, latencyMs: 40 }) }));
  assert.equal(ok.ok, true);
  assert.deepEqual(ok.links.realtime, { ok: true, model: 'gpt-realtime-2', latencyMs: 40 });
  const toolsRefused = await run(chat(Object.assign(new Error('hugo model provider error 404 model_not_found'), { providerStatus: 404 })), () => null);
  assert.equal(toolsRefused.ok, true, 'the first call still answered');
  assert.deepEqual({ ok: toolsRefused.links.tools.ok, kind: toolsRefused.links.tools.kind }, { ok: false, kind: 'model' });
  assert.deepEqual(toolsRefused.links.realtime, { ok: false, off: true, reason: 'not_configured' });
  assert.deepEqual((await run(chat(), () => ({ configured: false, reason: 'unpriced' }))).links.realtime, { ok: false, off: true, reason: 'unpriced' });
  const live = (r) => run(chat(), () => ({ configured: true, model: 'gpt-realtime-2', probe: async () => ({ ok: false, latencyMs: 9, ...r }) })).then((o) => o.links.realtime.kind);
  assert.equal(await live({ upstreamStatus: 401 }), 'auth');
  assert.equal(await live({ upstreamStatus: 404 }), 'model');
  assert.equal(await live({ socketError: 'ENOTFOUND' }), 'egress');
  assert.equal(await live({ timedOut: true }), 'timeout');
  assert.equal(await live({ upstreamCode: 'session_expired' }), 'refused');
  // A first call that fails runs no tool turn: the same key and host would say nothing new.
  const down = await run({ configured: true, model: 'm', chatOnce: async () => { throw Object.assign(new Error('x'), { providerStatus: 401 }); } }, () => null);
  assert.deepEqual(down.links.tools, { ok: false, kind: 'not_run' });
});

test('EVERY WALL IS NAMED, and by the same vocabulary the scan preflight uses', async () => {
  // `providerStatus` is what the OpenAI caller carries. Handed the raw error, the shared classifier reads
  // `status`, finds nothing, and returns `other` for every provider refusal - the least useful answer
  // available, and exactly the near-miss this preflight exists to stop.
  const walls = [
    [401, 'auth', 'the provider rejected the key'],
    [403, 'permission', 'the key is valid but not entitled to this model'],
    [404, 'model', 'the model id is unknown to the account'],
    [429, 'rate_limit', 'the quota is spent'],
    [500, 'provider', 'the provider is broken'],
  ];
  for (const [status, kind, why] of walls) {
    const err = Object.assign(new Error('hugo model provider error ' + status), { providerStatus: status });
    const out = await diagnose({ configured: true, model: 'm', chatOnce: async () => { throw err; } })();
    assert.equal(out.kind, kind, why);
    assert.equal(out.ok, false);
    assert.equal(out.configured, true, 'a key WAS seen: this is a refusal, not an absence');
  }
  // The one with no HTTP status at all: the container could not reach the provider.
  const egress = await diagnose({ configured: true, model: 'm', chatOnce: async () => { throw new Error('fetch failed'); } })();
  assert.equal(egress.kind, 'egress');
});

test('THE KEY NEVER LEAVES, and neither does the provider prose that can quote it back', async () => {
  // A security gate established this split in V1.90: `err.message` is our own label, the HTTP status and a
  // closed-vocabulary provider code, all three of them ours. The provider's sentence can contain a masked
  // credential and lives on `ringDetail`, for the admin fault ring alone. The preflight reports `message`.
  const err = Object.assign(new Error('hugo model provider error 401 invalid_api_key'), {
    providerStatus: 401,
    providerDetail: 'Incorrect API key provided: sk-proj-Ab3xQ********************************',
    ringDetail: 'hugo model provider error 401 invalid_api_key: Incorrect API key provided: sk-proj-Ab3xQ***',
  });
  const out = await diagnose({ configured: true, model: 'm', chatOnce: async () => { throw err; } })();
  assert.equal(out.kind, 'auth');
  assert.equal(out.error, 'hugo model provider error 401 invalid_api_key');
  const payload = JSON.stringify(out);
  assert.doesNotMatch(payload, /sk-proj/, 'no key prefix reaches the response');
  assert.doesNotMatch(payload, /Incorrect API key provided/, 'and neither does the provider prose');
});

test('a diagnosis is logged for the admin, and the preflight never throws', async () => {
  const lines = [];
  const err = Object.assign(new Error('boom'), { providerStatus: 500 });
  const out = await diagnose({ configured: true, model: 'm', chatOnce: async () => { throw err; } }, (level, p) => lines.push([level, p.status, p.kind]))();
  assert.equal(out.ok, false, 'a failed preflight is a RESULT, not an exception: the operator asked a question');
  assert.deepEqual(lines, [['warn', 'diagnose_failed', 'provider']]);
});

// VH-777 Lane V: the server half of the check names which of Hugo's models the key reaches, by name, and whether GPT-Live
// is on and why not. The handshake, sideband, delegated turn and WebRTC link are the browser half's.
test('the check reports the key\'s reach over Hugo\'s models by name, and GPT-Live on or off with its reason', async () => {
  const chat = { configured: true, model: 'gpt-6-astra', chatOnce: async () => ({ message: { content: 'OK' } }) };
  const run = (live) => makeHugoDiagnose({ hugoChat: chat, classifyCallerError, flushSpend: async () => {}, now: clock(), log: noop, live: () => live })();
  const on = await run({ configured: true, model: 'gpt-live-1', brain: 'gpt-6-astra', reachableModels: async () => ({ reached: ['gpt-6-astra'], missing: ['gpt-live-1'] }) });
  assert.deepEqual(on.links.live, { ok: true, model: 'gpt-live-1', brain: 'gpt-6-astra' });
  assert.equal(on.links.models.ok, false, 'a model the key cannot reach is not green');
  assert.deepEqual([on.links.models.reached, on.links.models.missing], [['gpt-6-astra'], ['gpt-live-1']]);
  const off = await run({ configured: false, offReason: 'unpriced', reachableModels: async () => ({ reached: [], missing: [] }) });
  assert.deepEqual(off.links.live, { ok: false, off: true, reason: 'unpriced' });
  const refused = await run({ configured: true, reachableModels: async () => { throw Object.assign(new Error('x'), { status: 401 }); } });
  assert.equal(refused.links.models.kind, 'auth');
  assert.deepEqual((await run(null)).links.live, { ok: false, off: true, reason: 'not_configured' });
});
