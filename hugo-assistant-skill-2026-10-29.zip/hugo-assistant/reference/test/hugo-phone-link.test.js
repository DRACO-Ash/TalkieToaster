// VH-149: SEND THE PHONE LINK BY EMAIL FROM ASK HUGO, the owner's option 1 of 2026-09-23.
//
// The app sends no email: no mail library (package.json holds the model SDK, pg and ws), no mail host, no App Store
// mail add-on, and it does not know the operator's address. So the button opens the operator's OWN mail app with the
// app's address filled in, and they choose who to send it to: no server change, no new secret, no outbound host.
// Hugo on a phone (VH-116 part 2) is the same address, so the link is the app's own origin.

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { phoneLinkMailto } from '../public/views/hugo-intent.js';

test('VH-149: the mail link carries the app\'s own address, encoded, and names no recipient', () => {
  const href = phoneLinkMailto('https://vendor-hunter.apps.bluestaq.com');
  assert.match(href, /^mailto:\?subject=/, 'no recipient: the operator chooses who to send it to');
  const body = decodeURIComponent(new URL(href).searchParams.get('body'));
  assert.match(body, /https:\/\/vendor-hunter\.apps\.bluestaq\.com\/$/);
  assert.match(body, /Ask Hugo/);
  assert.equal(new URL(href).searchParams.get('subject'), 'Ask Hugo on your phone');
  assert.doesNotMatch(href, /[\s<>"]/, 'every character that could break the attribute is encoded');
});

test('VH-149: an origin that is not a web address gives no link, so the line stays hidden', () => {
  for (const bad of ['', 'null', 'file://', 'javascript:alert(1)', 'mailto:x@y', 'https://', undefined, null, 42, 'https://a.example/path?x=1']) {
    assert.equal(phoneLinkMailto(bad), '', String(bad));
  }
  assert.notEqual(phoneLinkMailto('http://127.0.0.1:8080'), '', 'a local run still offers it');
});

test('VH-149: the line ships hidden and is shown only when the link is built', () => {
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  assert.match(html, /<p class="dim hugo-example-line" id="hugo-phone-line" hidden>/);
  assert.match(html, /<a id="hugo-phone-mail" class="link-btn">Email yourself the link<\/a>/);
  const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  assert.match(app, /const mail = phoneLinkMailto\(globalThis\.location\?\.origin\);/);
});
