// VH-318-G: the realtime session's tool runner reaches the web, as the typed route's does, with a per-turn budget
// the relay renews on each operator turn. Both web halves are injected, so nothing here touches a network.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { createVoiceRunner, voiceQueryRunner } from '../src/hugo/voice-runner.js';
import { WEB_MAX_PER_TURN } from '../src/hugo/web-lookup.js';
import { createRealtimeBridge } from '../src/hugo/openai-realtime.js';
import { domainIds } from '../src/domain/descriptor.js';

const PAGE = '<html><head><title>Norss Ltd</title></head><body><p>We operate a sensor network.</p></body></html>';
const fetchDoc = async (url) => ({ ok: true, status: 200, finalUrl: url, contentType: 'text/html', bodyText: PAGE, truncated: false });
const chat = { configured: true, searchWeb: async () => ({ text: 'Norss sells orbital tracks.', citations: [{ url: 'https://norss.co.uk/', title: 'Norss' }] }) };

test('a spoken web question reads a page on EVERY domain, and its source enters the session ledger (VH-318-G)', async () => {
  for (const domain of domainIds()) {
    const runner = createVoiceRunner({ webFetchDocument: fetchDoc, hugoChat: chat, defaultDomain: domain });
    const out = await runner.run('web_lookup', { url: 'https://norss.co.uk/about' });
    assert.equal(out.ok, true, domain + ': ' + JSON.stringify(out));
    assert.equal(out.result.source, 'https://norss.co.uk/about');
    assert.equal(runner.ledger.hasSource('https://norss.co.uk/about'), true, domain + ': the verifier can hold the answer to it');
  }
});

test('a spoken web SEARCH runs on the hosted search half, and says so when the model is not configured', async () => {
  const runner = createVoiceRunner({ webFetchDocument: fetchDoc, hugoChat: chat, defaultDomain: 'air' });
  const found = await runner.run('web_lookup', { question: 'who owns Norss' });
  assert.equal(found.ok, true);
  assert.equal(found.result.sources[0].url, 'https://norss.co.uk/');
  const off = createVoiceRunner({ webFetchDocument: fetchDoc, hugoChat: { configured: false }, defaultDomain: 'air' });
  const refused = await off.run('web_lookup', { question: 'who owns Norss' });
  assert.equal(refused.ok, false);
  assert.match(refused.error, /web search is not configured/);
});

test('the web budget is PER TURN on a session: spent after the cap, renewed by newTurn()', async () => {
  const runner = createVoiceRunner({ webFetchDocument: fetchDoc, hugoChat: chat, defaultDomain: 'land' });
  for (let i = 0; i < WEB_MAX_PER_TURN; i += 1) assert.equal((await runner.run('web_lookup', { url: 'https://norss.co.uk/' + i })).ok, true);
  const spent = await runner.run('web_lookup', { url: 'https://norss.co.uk/x' });
  assert.equal(spent.ok, false);
  assert.match(spent.error, /budget for this turn is spent/);
  runner.newTurn();
  assert.equal((await runner.run('web_lookup', { url: 'https://norss.co.uk/y' })).ok, true, 'a new turn has a new budget');
});

test('the query runner reads Space from the master and a domain from its own store, and an unwired domain reads empty', async () => {
  const calls = [];
  const run = voiceQueryRunner({
    vendorRepo: { queryByIntent: async (spec) => { calls.push(['space', spec]); return { rows: [], total: 1 }; } },
    domainRepoFor: (d) => (d === 'cyber' ? { queryProviders: async (spec) => { calls.push(['cyber', spec]); return { rows: [], total: 2 }; } } : null),
  });
  assert.equal((await run({ domain: 'space', filterSpec: { a: 1 } })).total, 1);
  assert.equal((await run({ domain: 'cyber', filterSpec: { b: 2 } })).total, 2);
  assert.deepEqual(await run({ domain: 'maritime', filterSpec: {} }), { rows: [], total: 0, applied: [], notApplied: [] });
  assert.deepEqual(calls.map((c) => c[0]), ['space', 'cyber']);
});

test('the relay starts a new turn when the upstream commits the operator\'s speech, and a throwing hook cannot end the session', () => {
  let upstream = null;
  let turns = 0;
  const bridge = createRealtimeBridge({ apiKey: 'sk', model: 'gpt-realtime-2', wsFactory: () => { upstream = mkSocket(); return upstream; } });
  const client = mkSocket();
  bridge.connect(client, { onUserTurn: () => { turns += 1; if (turns === 2) throw new Error('boom'); } });
  upstream.emit('open');
  upstream.emit('message', JSON.stringify({ type: 'input_audio_buffer.committed', item_id: 'i1' }));
  upstream.emit('message', JSON.stringify({ type: 'response.output_audio.delta', delta: '' }));
  upstream.emit('message', JSON.stringify({ type: 'input_audio_buffer.committed', item_id: 'i2' }));
  assert.equal(turns, 2);
  assert.equal(client.closed, false);
  assert.equal(client.sent.length, 3, 'every event still reaches the browser');
});

test('the composition root builds the voice runner through Hugo\'s registry (createHugoSession over createVoiceRunner) and renews it per turn (wired, not only built)', () => {
  const src = readFileSync(new URL('../src/index.js', import.meta.url), 'utf8');
  assert.match(src, /createHugoSession\(\{[^}]*webFetchDocument: deps\.webFetchDocument, hugoChat: deps\.hugoChat/);
  assert.match(readFileSync(new URL('../src/hugo/registry.js', import.meta.url), 'utf8'), /const runner = createVoiceRunner\(deps\);/);
  // The upgrade listener that renews it moved beside its gate (VH-665).
  const listener = readFileSync(new URL('../src/hugo/realtime-upgrade-gate.js', import.meta.url), 'utf8');
  assert.match(listener, /onUserTurn: \(\) => runner\.newTurn\(\)/);
});

function mkSocket() {
  const handlers = {};
  return {
    sent: [], closed: false,
    on(ev, cb) { if (!handlers[ev]) { handlers[ev] = []; } handlers[ev].push(cb); return this; },
    send(data) { this.sent.push(data); },
    close() { this.closed = true; },
    emit(ev, data) { for (const cb of handlers[ev] || []) cb(data); },
  };
}
