// VH-199: a domain record reaches the model whole through `get_record`. The planted-field guard in
// test/record-field-coverage.test.js proves every field arrives; this pins the budget half it cannot see,
// because its planted values are short: one record read may carry every product line, while a set read keeps
// the per-row cap that lets fifty rows share a turn.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner } from '../src/hugo/tools.js';

const line = (i) => ({ product_type: `ADS-B Terrestrial variant ${i} with a long descriptive product name`, object_domain: 'air', data_nature: 'raw-sensed', collection_vantage: 'ground', data_delivery: ['feed', 'API'], data_owned: 'crowdsourced-network', data_sensitivity: [], source_status: 'operational', line_eligibility: 'admitted' });
const RECORD = { air_id: 'host:many.example', provider_key: 'host:many.example', name: 'Many Lines (demo)', hq_country: 'Norway', capability_class: ['ADS-B'], lines: Array.from({ length: 20 }, (_, i) => line(i + 1)) };

function runner() {
  const repo = { get: async () => RECORD };
  return createToolRunner({
    runQuery: async () => ({ rows: [RECORD], total: 1 }),
    vendorRepo: {}, domainRepoFor: () => repo, defaultDomain: 'air',
  });
}

test('get_record hands the model every product line of one domain record', async () => {
  const out = await runner().run('get_record', { domain: 'air', id: 'host:many.example' });
  assert.equal(out.ok, true);
  assert.match(out.result.product_lines, /variant 20 with a long/, 'the last of 20 lines arrives');
  assert.equal(out.result.capability_class, 'ADS-B');
});

test('a set read keeps its per-row cap, so fifty rows can share a turn', async () => {
  const out = await runner().run('query_records', { domain: 'air' });
  const row = out.result.records[0];
  assert.ok(JSON.stringify(row).length < 2600, 'bounded near the per-row cap: ' + JSON.stringify(row).length);
  assert.doesNotMatch(String(row.product_lines || ''), /variant 20 with a long/);
});
