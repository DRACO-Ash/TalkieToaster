// VH-865: TALK IS NEVER HIDDEN SILENTLY, AND IT RUNS OVER HUGO'S LIVE VOICE WHEREVER THAT WORKS (owner: "where is my
// feature to use hugo voice - failed - fix it"; the owner's deployment answered the connection check with the live voice
// working end to end and the app's own WebSocket link refused). Every state of the Talk control, the check's wording, and
// Hugo's own answer about his voice.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { talkState, VOICE_KEY_VAR } from '../public/views/hugo-talk-state.js';
import { hugoPreflightLine } from '../public/views/hugo-preflight.js';
import { voiceStateWords, publishVoiceState, appState } from '../src/hugo/knowledge.js';

// The owner's deployment, from its own connection check: voice key, live voice and the relay all configured.
const OWNER = { configured: true, live: true, realtime: true, fault: '' };
const desktop = { capture: true, signedIn: true, probe: 'done', webrtc: true, relay: true };

test('the owner\'s case: signed in with no app token, Talk shows and runs over the live voice', () => {
  assert.deepEqual(talkState({ ...desktop, voice: OWNER, token: false }), { show: true, enabled: true, path: 'live', reason: '' });
  // With a token as well it still prefers the live voice; with no live voice it takes the app's own link.
  assert.equal(talkState({ ...desktop, voice: OWNER, token: true }).path, 'live');
  // VH-873: the app's own link needs no app token either, so with no live voice it takes that, token or none.
  assert.equal(talkState({ ...desktop, voice: { ...OWNER, live: false }, token: false }).path, 'relay');
});

test('every other state shows Talk disabled with the reason and one step, never hidden', () => {
  const off = (s) => { const t = talkState({ ...desktop, token: false, ...s }); assert.equal(t.show, true); assert.equal(t.enabled, false); return t.reason; };
  assert.equal(off({ probe: 'pending', voice: {} }), 'Checking whether Hugo can talk here.');
  assert.equal(off({ voice: { fault: 'unreachable' } }), 'Could not check whether Hugo can talk. Reload the page to try again.');
  assert.equal(off({ voice: { configured: false, fault: 'no-key', canFix: true } }), 'Hugo\'s voice is not set up on this app. Set ' + VOICE_KEY_VAR + ' in the App Store environment, then apply it.');
  assert.equal(off({ voice: { configured: false, fault: 'no-key' } }), 'Hugo\'s voice is not set up on this app. Ask your administrator.');
  assert.equal(off({ voice: { configured: false, fault: 'key-rejected', canFix: true } }), 'Hugo\'s voice key was refused. Replace ' + VOICE_KEY_VAR + ' in the App Store environment, then apply it.');
  assert.equal(off({ voice: { ...OWNER, realtime: false }, webrtc: false, relay: true }), 'This browser cannot open Hugo\'s live voice: it needs WebRTC. Use a current Chrome, Edge, Firefox or Safari.');
  // The relay alone is not configured, and neither is Live.
  assert.match(off({ voice: { configured: true, live: false, realtime: false } }), /^Hugo's live voice is off on this app\. Ask your administrator\.$/);
  assert.match(off({ voice: { configured: true, live: false, realtime: false }, canFix: true }), /live voice is off/);
});

test('Talk is hidden only where it could never work: a browser that cannot capture sound, or no one signed in', () => {
  assert.equal(talkState({ ...desktop, capture: false, voice: OWNER, token: true }).show, false);
  assert.equal(talkState({ ...desktop, signedIn: false, voice: OWNER, token: true }).show, false);
});

test('the shell probes voice for any signed-in operator, and a press on a disabled Talk says why', () => {
  const shell = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const probe = shell.slice(shell.indexOf('function probeHugoVoice() {'), shell.indexOf('async function readHugoVoice() {'));
  assert.match(probe, /if \(signedOutUi\(\)\) return Promise\.resolve\(\);/);
  assert.doesNotMatch(probe, /!state\.token/, 'a platform sign-in holds no bearer and is still signed in');
  // ...having given back the microphone the press asked for (VH-906; the 2.23.0 engineering gate, round one).
  assert.match(shell, /if \(hugoTalkWhy\) \{ releaseHugoMic\(\); toast\(hugoTalkWhy, 'warn'\); return; \}/);
  // VH-873: every voice socket goes through one helper, which never puts an empty token in the subprotocol list.
  assert.match(shell, /const voiceSocket = \(url\) => new WebSocket\(url, state\.token \? \['vh\.bearer', state\.token\] : \['vh\.bearer'\]\);/);
  assert.equal((shell.match(/new WebSocket\(/g) || []).length, 1, 'no voice socket is opened any other way');
  // The owner's desktop (VH-865): with no bearer the Orb never mounted, so the plain rail showed Send and no Talk. Mounting
  // it, the phone's screen and the Live path all ask only that someone is signed in.
  assert.match(shell, /if \(deskOrb && !phoneHugo && !signedOutUi\(\)\) orbMounting = mountOrbHugo\(true\);/);
  assert.match(shell, /if \(!mod \|\| phoneHugo \|\| signedOutUi\(\)\) return;/);
  assert.match(shell, /const live = hugoLiveAvailable && liveSupportedHere\(\) && !signedOutUi\(\);/);
  const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
  assert.match(html, /<output id="hugo-talk-why" class="hugo-talk-why" hidden><\/output>/);
});

test('the connection check: with the live voice working, a refused socket is a note for the platform team, not a fault', () => {
  const res = {
    reached: true, ok: true, configured: true, kind: '', model: 'gpt-6-astra', latencyMs: 1650,
    links: { tools: { ok: true, latencyMs: 1952 }, realtime: { ok: true, model: 'gpt-realtime-2', latencyMs: 1246 }, live: { model: 'gpt-live-1', brain: 'gpt-6-astra' } },
  };
  const voice = { ok: true, connectMs: 1936, ice: 'connected', tool: 'count_records', delegationMs: 3719 };
  const line = hugoPreflightLine(res, { ok: false, why: 'refused' }, voice);
  assert.equal(line.good, true);
  assert.match(line.text, /answered in 1246ms\. Talk runs over his live voice here\. The app's own link, which Talk falls back to, could not open from this browser \(it was refused\): a note for the platform team, whose route must let WebSocket upgrades through to \/api\/v3\/hugo\/realtime\./);
  assert.doesNotMatch(line.text, /Talk and voice will not work/);
  // Without the live voice the refusal is still the fault it was.
  const down = hugoPreflightLine(res, { ok: false, why: 'refused' }, { ok: false, failed: 'webrtc', ice: 'failed', state: 'failed' });
  assert.equal(down.good, false);
  assert.match(down.text, /so Talk and voice will not work here/);
});

test('Hugo answers about his voice from this app\'s own state, naming the setting and never its value', async () => {
  assert.match(voiceStateWords(OWNER), /^Talk is on: press Talk beside Send/);
  assert.match(voiceStateWords({ configured: false }), /OPENAI_API_KEY is not set/);
  assert.match(voiceStateWords({ configured: true, live: false, realtime: true }), /WebSocket upgrades through/);
  assert.match(voiceStateWords({ configured: true, live: false, realtime: false }), /live voice is off/);
  assert.equal(voiceStateWords(null), null);
  try {
    publishVoiceState(() => OWNER);
    const s = await appState({ version: '9.9.9', countDomain: async () => 0 });
    assert.match(s.voice, /^Talk is on/);
    publishVoiceState(null);
    assert.equal((await appState({ version: '9.9.9', countDomain: async () => 0 })).voice, undefined);
  } finally { publishVoiceState(null); }
});
