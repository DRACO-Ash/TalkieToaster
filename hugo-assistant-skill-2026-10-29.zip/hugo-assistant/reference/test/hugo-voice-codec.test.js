// The Hugo voice codec helpers are pure, so they are unit-tested in node (the client monolith they came from
// cannot be). A wrong transform would corrupt the microphone audio or the realtime WebSocket frames, so the
// round-trips and the boundary clamping are the user-visible risk pinned here.
import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { floatToPcm16, pcm16ToFloat, bytesToBase64, base64ToBytes, realtimeVoiceAction, createResampler } from '../public/views/hugo-voice-codec.js';

test('floatToPcm16 -> pcm16ToFloat round-trips within one PCM16 step', () => {
  const input = Float32Array.from([0, 0.5, -0.5, 1, -1, 0.25, -0.25]);
  const back = pcm16ToFloat(floatToPcm16(input));
  assert.equal(back.length, input.length);
  input.forEach((v, i) => {
    assert.ok(Math.abs(back[i] - v) < 1 / 32768 + 1e-6, 'sample ' + i + ': ' + back[i] + ' vs ' + v);
  });
});

test('floatToPcm16 clamps out-of-range samples to the PCM16 rails', () => {
  const bytes = floatToPcm16(Float32Array.from([2, -2]));
  const view = new DataView(bytes.buffer);
  assert.equal(view.getInt16(0, true), 0x7fff, '+2 clamps to full positive');
  assert.equal(view.getInt16(2, true), -0x8000, '-2 clamps to full negative');
});

test('floatToPcm16 emits little-endian, two bytes per sample', () => {
  const bytes = floatToPcm16(Float32Array.from([1]));
  assert.equal(bytes.length, 2);
  assert.equal(bytes[0], 0xff, 'low byte first (little-endian)');
  assert.equal(bytes[1], 0x7f);
});

test('bytesToBase64 -> base64ToBytes round-trips exactly, all byte values', () => {
  const bytes = new Uint8Array(256);
  for (let i = 0; i < 256; i += 1) bytes[i] = i;
  const back = base64ToBytes(bytesToBase64(bytes));
  assert.deepEqual([...back], [...bytes]);
});

test('bytesToBase64 matches a known vector', () => {
  assert.equal(bytesToBase64(Uint8Array.from([104, 105])), 'aGk=', '"hi" encodes to aGk=');
  assert.deepEqual([...base64ToBytes('aGk=')], [104, 105]);
});

test('pcm16ToFloat drops a trailing odd byte rather than reading past the buffer', () => {
  const out = pcm16ToFloat(Uint8Array.from([0, 0, 0]));
  assert.equal(out.length, 1, 'three bytes yield one whole sample, the odd byte ignored');
});

// VH-318-B: the Talk client reads the CURRENT Realtime server event names (openai 7.23.0). The beta names are
// asserted to do nothing, so a client still listening for them is caught rather than silently playing nothing.
test('realtimeVoiceAction plays the current audio delta and shows the current transcripts', () => {
  assert.deepEqual(realtimeVoiceAction({ type: 'response.output_audio.delta', response_id: 'r', item_id: 'i', output_index: 0, content_index: 0, delta: 'AAAA' }), { audio: 'AAAA' });
  assert.deepEqual(realtimeVoiceAction({ type: 'response.output_audio_transcript.delta', delta: 'Hello' }), { transcript: 'Hello' });
  assert.deepEqual(realtimeVoiceAction({ type: 'conversation.item.input_audio_transcription.completed', item_id: 'i', content_index: 0, transcript: 'Which vendors?' }), { heard: 'Which vendors?' });
});

// VH-318-D: the operator's words and Hugo's are different turns on the one rail, and the end of Hugo's spoken
// transcript settles his turn. Run together, the operator's question was appended to Hugo's own bubble.
test('realtimeVoiceAction tells what the operator said from what Hugo says, and marks the end of his turn', () => {
  assert.deepEqual(realtimeVoiceAction({ type: 'conversation.item.input_audio_transcription.completed', transcript: 'Hey' }), { heard: 'Hey' });
  assert.deepEqual(realtimeVoiceAction({ type: 'response.output_audio_transcript.delta', delta: 'Hey' }), { transcript: 'Hey' });
  assert.deepEqual(realtimeVoiceAction({ type: 'response.output_audio_transcript.done', transcript: 'Hey there' }), { done: true });
});

test('realtimeVoiceAction ignores the beta names, unknown events and malformed payloads', () => {
  for (const ev of [
    { type: 'response.audio.delta', delta: 'AAAA' },
    { type: 'response.audio_transcript.delta', delta: 'Hello' },
    { type: 'response.output_audio.delta', delta: 7 },
    { type: 'response.output_audio_transcript.delta', delta: '' },
    { type: 'conversation.item.input_audio_transcription.completed' },
    { type: 'response.done', response: {} },
    {}, null,
  ]) assert.equal(realtimeVoiceAction(ev), null, JSON.stringify(ev));
});

test('the Talk client routes every relayed event through realtimeVoiceAction and names no beta event', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const handler = src.slice(src.indexOf('function onHugoVoiceEvent('), src.indexOf('function playAudioDelta('));
  assert.ok(handler.length > 0 && handler.includes('realtimeVoiceAction(event)'), 'onHugoVoiceEvent classifies through the tested function');
  for (const beta of ['response.audio.delta', 'response.audio_transcript.delta', 'response.text.delta']) {
    assert.equal(src.includes("'" + beta + "'"), false, beta + ' is a beta event name');
  }
});

// THE AUDIO ENGINE IS MADE IN THE PRESS AND RESUMED (VH-764). A browser may start an engine made outside a user gesture
// suspended, and a suspended engine runs no capture: Talk said "Listening" and sent no audio (measured with a probe
// that starts every engine suspended: 0 frames in 3 seconds). So the engine is made before Talk's first await, while
// the press still counts, resumed there, and resumed again when capture starts. Red-before-green: the engine made after
// an await, or either resume removed, fails here; `e2e/probe.mjs` with a suspended engine shows the frames.
test('Talk makes its audio engine before its first await and resumes it, in the press and at capture', () => {
  const src = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  // Code only: a comment that says "await" is not one.
  const start = src.slice(src.indexOf('async function startHugoTalk('), src.indexOf('function startCapture('))
    .split('\n').filter((line) => !line.trim().startsWith('//')).join('\n');
  // VH-906: the Orb's press makes it (`primeHugoMic`) and Talk takes it, else Talk's own press makes it here; either way
  // before the first await, and resumed where it is made.
  const made = start.indexOf('const ctx = mic?.ctx || hugoAudioEngine();');
  const firstAwait = start.indexOf('await ');
  assert.ok(made > 0 && firstAwait > made, 'the engine is made at ' + made + ', the first await is at ' + firstAwait);
  for (const name of ['hugoAudioEngine', 'primeHugoMic']) {
    const at = src.indexOf('function ' + name + '()');
    const body = src.slice(at, src.indexOf('\n}\n', at));
    assert.match(body, /new Ctx\(\) : null;\n\s+ctx\?\.resume\(\)/, name + ' makes the engine and resumes it at once');
  }
  const capture = src.slice(src.indexOf('function startCapture('), src.indexOf('function onHugoVoiceEvent('));
  assert.match(capture, /v\.ctx\.resume\(\)/, 'resumed when capture starts');
});

// THE ENGINE RUNS AT THE DEVICE'S RATE, AND CAPTURE RESAMPLES TO 24 kHz (VH-764). Firefox refuses to connect a microphone
// to an engine at a rate other than the device's (TBC, re-verify: only Chromium runs here), so Talk and the paid listener
// make their engine at the default rate and every frame goes through `createResampler` before it is sent.
const sine = (rate, hz, from, n) => Float32Array.from({ length: n }, (_, i) => Math.sin(2 * Math.PI * hz * (from + i) / rate));

test('createResampler takes 48 kHz and 44.1 kHz frames to 24 kHz, with no sample lost or doubled at a frame edge', () => {
  for (const rate of [48000, 44100, 16000]) {
    const to24k = createResampler(rate);
    const out = [];
    let from = 0;
    for (let f = 0; f < 40; f += 1) { out.push(...to24k(sine(rate, 440, from, 4096))); from += 4096; }
    // The count over 40 frames matches the time those frames cover, to the sample.
    assert.ok(Math.abs(out.length - Math.round(from * 24000 / rate)) <= 1, rate + ': ' + out.length + ' samples for ' + from);
    // And each output sample is the tone at its own 24 kHz instant, edges included.
    const worst = out.reduce((m, v, j) => Math.max(m, Math.abs(v - Math.sin(2 * Math.PI * 440 * j / 24000))), 0);
    assert.ok(worst < 0.01, rate + ': worst error ' + worst);
  }
  const same = createResampler(24000);
  assert.deepEqual([...same(Float32Array.from([0.5, -0.25]))], [0.5, -0.25]);
  assert.equal(createResampler(48000)(new Float32Array(0)).length, 0);
  for (const bad of [0, -1, Number.NaN, undefined]) assert.throws(() => createResampler(bad), RangeError, String(bad));
});

test('Talk and the paid listener make their engine at the device rate and resample every frame they send', () => {
  const app = readFileSync(new URL('../public/app-v3.js', import.meta.url), 'utf8');
  const capture = app.slice(app.indexOf('function startCapture('), app.indexOf('function onHugoVoiceEvent('));
  assert.match(capture, /const to24k = hugoCodec\.createResampler\(v\.ctx\.sampleRate\);/);
  assert.match(capture, /hugoCodec\.floatToPcm16\(to24k\(e\.inputBuffer\.getChannelData\(0\)\)\)/);
  const stream = readFileSync(new URL('../public/views/hugo-stream.js', import.meta.url), 'utf8');
  const listener = stream.slice(stream.indexOf('export async function startLiveListener('));
  assert.match(listener, /ctx = new Ctx\(\);/);
  assert.match(listener, /codec\.floatToPcm16\(to24k\(e\.inputBuffer\.getChannelData\(0\)\)\)/);
  for (const src of [app, stream]) assert.doesNotMatch(src, /sampleRate: 24000/, 'no engine is forced to 24 kHz');
});
