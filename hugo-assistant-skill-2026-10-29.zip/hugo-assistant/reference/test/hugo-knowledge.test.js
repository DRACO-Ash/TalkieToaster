// WHAT HUGO KNOWS ABOUT THE APP ITSELF (VH-777 Lane T): the help and guide search, the app's shape, its state and the
// recent history, each read-only, each naming its source, and each reached through the one tool runner.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { searchHelp, helpPassages, guidePassages, rankPassages, describeApp, appState, recentHistory } from '../src/hugo/knowledge.js';
import { createToolRunner } from '../src/hugo/tools.js';

const VERSION = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).version;
const NO_GUIDE = new URL('./no-such-guide-folder/', import.meta.url);
// The guide this test reads on purpose, which makes it a reader of the records (VH-420), as it should be.
const GUIDE = new URL('../docs/guide/', import.meta.url);

test('the help search finds the passages that answer, each with its source, with or without the guide', async () => {
  const withGuide = await searchHelp('how do I export to Excel', { guideDir: GUIDE });
  assert.ok(withGuide.passages.length > 0 && withGuide.passages.length <= 5);
  assert.ok(withGuide.passages.some((p) => /Export/.test(p.source)), 'an export passage: ' + withGuide.passages.map((p) => p.source).join(' | '));
  assert.ok(withGuide.passages.every((p) => typeof p.source === 'string' && p.source && p.text.length <= 1200));
  assert.ok(withGuide.searched > helpPassages().length, 'the guide chapters are searched too');
  const helpOnly = await searchHelp('how do I export to Excel', { guideDir: NO_GUIDE });
  assert.equal(helpOnly.searched, helpPassages().length, 'an image without the guide still searches the help');
  assert.ok(helpOnly.passages.every((p) => p.source.startsWith('In-app help')));
  assert.deepEqual((await searchHelp('the and for', { guideDir: NO_GUIDE })).passages, [], 'nothing to search for finds nothing');
  assert.deepEqual(rankPassages('zzqx', helpPassages()), []);
  // With no folder named, the image's setting decides; unset, the help alone is searched.
  const before = process.env.HUGO_GUIDE_DIR;
  try {
    delete process.env.HUGO_GUIDE_DIR;
    assert.equal((await searchHelp('export')).searched, helpPassages().length);
    process.env.HUGO_GUIDE_DIR = fileURLToPath(GUIDE);
    assert.equal((await searchHelp('export')).searched, withGuide.searched, 'HUGO_GUIDE_DIR names the guide');
  } finally {
    if (before === undefined) delete process.env.HUGO_GUIDE_DIR; else process.env.HUGO_GUIDE_DIR = before;
  }
});

test('a guide chapter is one passage per heading, and a title outweighs its body', () => {
  const parts = guidePassages('10-x.md', '# One\nalpha beta\n\n## Two\ngamma\n## Empty\n');
  assert.deepEqual(parts.map((p) => [p.title, p.text, p.source]), [['One', 'alpha beta', 'User guide, 10-x.md: One'], ['Two', 'gamma', 'User guide, 10-x.md: Two']]);
  const ranked = rankPassages('gamma', [{ source: 'a', title: 'x', text: 'gamma' }, { source: 'b', title: 'gamma', text: 'y' }]);
  assert.deepEqual(ranked.map((p) => p.source), ['b', 'a']);
});

test('the app\'s shape, its state and its history, with a store that cannot be read said rather than zeroed', async () => {
  const shape = describeApp();
  assert.equal(shape.domains.length, 7);
  assert.equal(shape.views.length, 9);
  assert.ok(shape.views.every((v) => typeof v.purpose === 'string'));
  const countDomain = async (id) => {
    if (id === 'air') throw new Error('down');
    return 4;
  };
  const state = await appState({ countDomain });
  assert.equal(state.version, VERSION);
  assert.equal(state.domains.find((d) => d.domain === 'air').records, null);
  assert.equal(state.domains.find((d) => d.domain === 'space').records, 4);
  const asked = [];
  const row = { occurred_at: '2026-10-26T08:00:00.000Z', actor: 'ada', action: 'update', entity: 'air', entity_id: 'host:x', name: 'X Ltd', detail: { note: 'the changed value' } };
  const repo = { async datasetHistory(q) { asked.push(q); return { rows: [row], total: 1 }; } };
  const h = await recentHistory(repo, { domain: 'air', limit: 99 });
  assert.deepEqual(h.rows, [{ when: '2026-10-26T08:00:00.000Z', actor: 'ada', action: 'update', store: 'air', record: 'host:x', name: 'X Ltd' }]);
  assert.doesNotMatch(JSON.stringify(h), /the changed value/, 'the change\'s values stay out');
  assert.deepEqual(asked[0], { entity: 'air', limit: 25, offset: 0 }, 'bounded at 25, one store\'s trail');
  await recentHistory(repo, { domain: 'space' });
  assert.equal(asked[1].entity, undefined, 'Space reads the dataset-wide trail, as the route does');
  assert.equal(asked[1].limit, 10);
  assert.deepEqual(await recentHistory(null), { rows: [], available: false });
});

test('the runner answers each knowledge tool, and counts each domain through the same query count_records uses', async () => {
  const runQuery = async (intent) => ({ rows: [], total: intent.domain === 'space' ? 12 : 3, applied: [], notApplied: [] });
  const runner = createToolRunner({ runQuery, defaultDomain: 'space', vendorRepo: { datasetHistory: async () => ({ rows: [], total: 0 }) } });
  const help = await runner.run('search_help', { question: 'what is the confidence band' });
  assert.equal(help.ok, true);
  assert.ok(help.result.passages.some((p) => /confidence/i.test(p.title)));
  const state = await runner.run('app_state', {});
  assert.deepEqual([state.ok, state.result.domains.find((d) => d.domain === 'space').records, state.result.domains.find((d) => d.domain === 'land').records], [true, 12, 3]);
  assert.equal((await runner.run('describe_app', {})).result.domains.length, 7);
  assert.equal((await runner.run('recent_history', {})).ok, true);
});
