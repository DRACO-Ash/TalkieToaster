// WS2 route tests: the Hugo single-record update PREVIEW and the Hugo query serving every domain
// from its own store. In-process via createApp with stub repos, so no database is touched.
//   - /hugo/suggest-update requires a source (never-fabricate), routes Space to vendorRepo and a
//     domain to its repo, and maps notFound / invalid / unknown-domain to their status codes. It
//     never writes: the stub repos expose only the preview methods.
//   - /hugo/query serves a single non-Space domain from domainRepoFor(...).queryProviders.

import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../src/app.js';
import { createStaticVerifier } from '../src/auth.js';

const ORIGIN = 'https://vendor-hunter.apps.bluestaq.com';
const verify = createStaticVerifier({ 'agent-tok': { subject: 'ada', roles: ['agent'] } });
const agent = { authorization: 'Bearer agent-tok' };

function listen(handler) { return new Promise((r) => { const s = http.createServer(handler); s.listen(0, '127.0.0.1', () => r(s)); }); }
function request(server, path, { method = 'GET', headers = {}, body } = {}) {
  const { port } = server.address();
  const payload = body === undefined ? null : JSON.stringify(body);
  const allHeaders = payload ? { 'content-type': 'application/json', ...headers } : headers;
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path, method, headers: allHeaders }, (res) => {
      let t = ''; res.on('data', (c) => { t += c; }); res.on('end', () => resolve({ status: res.statusCode, body: t ? JSON.parse(t) : null }));
    });
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

const spaceRepo = {
  previewUpdate: async (id, patch) => {
    if (id === 'VH-none') return { notFound: true };
    if (patch?.grade === 'bad') return { invalid: true, errors: ['grade: not allowed'] };
    return { rev: 4, changes: { before: { grade: 'Potential for JCO' }, after: { grade: 'Ready for JCO' } }, hasChanges: true };
  },
  // Never called by these tests; present so the app boots.
  auditHugoQuery: async () => {},
};

function domainRepoFor(id) {
  if (id !== 'air') return null;
  return {
    previewProviderUpdate: async (rowId, patch) => {
      if (rowId === 'host:none') return { notFound: true };
      if (patch?.fields?.size_band === 'bad') return { invalid: true, errors: ['size_band: not allowed'] };
      return { rev: 2, changes: { before: {}, after: { coverage: 'Global' } }, hasChanges: true };
    },
    queryProviders: async (filterSpec) => ({
      rows: [{ air_id: 'host:x', hq_country: 'Sweden' }], total: 1,
      applied: filterSpec.countries?.length ? ['countries'] : [], notApplied: [],
    }),
  };
}

function app() {
  return createApp({ env: {}, vendorRepo: spaceRepo, domainRepoFor, verify, allowedOrigin: ORIGIN });
}

test('suggest-update requires a source and a record id', async () => {
  const server = await listen(app());
  try {
    assert.equal((await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { id: 'VH-0001', patch: { grade: 'Ready for JCO' } } })).status, 400, 'no source is refused');
    assert.equal((await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { source: 'https://example.gov/x', patch: {} } })).status, 400, 'no id is refused');
  } finally { server.close(); }
});

test('suggest-update previews a Space record and maps notFound / invalid', async () => {
  const server = await listen(app());
  try {
    const ok = await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { domain: 'space', id: 'VH-0001', source: 'https://example.gov/x', patch: { grade: 'Ready for JCO' } } });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.domain, 'space');
    assert.equal(ok.body.source, 'https://example.gov/x');
    assert.equal(ok.body.hasChanges, true);
    assert.equal(ok.body.changes.after.grade, 'Ready for JCO');

    assert.equal((await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { domain: 'space', id: 'VH-none', source: 'https://example.gov/x', patch: { grade: 'Ready for JCO' } } })).status, 404);
    assert.equal((await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { domain: 'space', id: 'VH-0001', source: 'https://example.gov/x', patch: { grade: 'bad' } } })).status, 400);
  } finally { server.close(); }
});

test('suggest-update previews a domain record, and refuses an unknown or absent domain', async () => {
  const server = await listen(app());
  try {
    const ok = await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { domain: 'air', id: 'host:x', source: 'https://example.gov/x', patch: { fields: { coverage: 'Global' } } } });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.domain, 'air');
    assert.equal(ok.body.changes.after.coverage, 'Global');

    // VH-280: an unknown domain is a 400 at the boundary now, and NO domain is a 400 too where it used to
    // preview the Space record of the same id.
    assert.equal((await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { domain: 'nope', id: 'host:x', source: 'https://example.gov/x', patch: {} } })).status, 400);
    const unnamed = await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { id: 'VH-0001', source: 'https://example.gov/x', patch: { grade: 'Ready for JCO' } } });
    assert.equal(unnamed.status, 400);
    assert.match(unnamed.body.error, /^domain is required/);
    assert.equal((await request(server, '/api/v3/hugo/suggest-update', { method: 'POST', headers: agent, body: { domain: 'air', id: 'host:none', source: 'https://example.gov/x', patch: {} } })).status, 404);
  } finally { server.close(); }
});

test('hugo/query serves a single non-Space domain from its own store', async () => {
  const server = await listen(app());
  try {
    const res = await request(server, '/api/v3/hugo/query', { method: 'POST', headers: agent, body: { domain: 'air', filterSpec: { countries: ['Sweden'] } } });
    assert.equal(res.status, 200);
    assert.equal(res.body.domain, 'air');
    assert.equal(res.body.total, 1);
    assert.equal(res.body.rows[0].hq_country, 'Sweden');
    assert.deepEqual(res.body.domainsQueried, ['air'], 'the answer reports the domain it queried');
  } finally { server.close(); }
});
