// VH-777 Lane V, the browser half: Talk on GPT-Live over WebRTC, and the connection check that tries every link Talk
// takes. A fake peer connection stands in for the browser's, so the path, its timeout and each failure are driven here;
// a real browser's WebRTC against OpenAI is the deployed check's to prove, with the key.
import test from 'node:test';
import assert from 'node:assert/strict';

import { startLive, waitConnected, createLiveCaptions, liveFailureText, LIVE_ROUTE, LIVE_END_ROUTE, LIVE_CHECK_ROUTE } from '../public/views/hugo-live.js';
import { checkLiveVoice, hugoPreflightLine } from '../public/views/hugo-preflight.js';

function listeners() {
  const h = {};
  return {
    addEventListener(ev, cb) {
      if (!h[ev]) h[ev] = [];
      h[ev].push(cb);
    },
    removeEventListener(ev, cb) { h[ev] = (h[ev] || []).filter((x) => x !== cb); },
    fire(ev, e = {}) { for (const cb of (h[ev] || []).slice()) cb(e); },
  };
}
function fakePeerClass(behaviour = {}) {
  const made = [];
  class FakePC {
    constructor() {
      Object.assign(this, listeners());
      this.connectionState = 'new';
      this.iceConnectionState = 'new';
      this.tracks = [];
      this.transceivers = [];
      this.closed = false;
      made.push(this);
    }
    addTrack(t) { this.tracks.push(t); }
    addTransceiver(kind, init) { this.transceivers.push({ kind, init }); }
    createDataChannel(label) {
      const dc = Object.assign(listeners(), { label, readyState: 'connecting', sent: [], send(d) { this.sent.push(JSON.parse(d)); } });
      this.dc = dc;
      return dc;
    }
    async createOffer() { return { type: 'offer', sdp: 'v=0\r\nm=audio\r\n' }; }
    async setLocalDescription(d) { this.localDescription = d; }
    async setRemoteDescription(d) {
      this.remoteDescription = d;
      if (behaviour.connect !== false) {
        setImmediate(() => {
          this.iceConnectionState = 'connected';
          this.connectionState = behaviour.failState || 'connected';
          this.fire('connectionstatechange');
          this.dc.readyState = 'open';
          this.dc.fire('open');
        });
      }
    }
    close() { this.closed = true; }
  }
  return { FakePC, made };
}
function mic() {
  const tracks = [{ stopped: false, stop() { this.stopped = true; } }];
  return { tracks, getUserMedia: async () => ({ getTracks: () => tracks }) };
}
function poster(responses = {}) {
  const posts = [];
  const post = async (path, body) => {
    posts.push({ path, body });
    const r = responses[path];
    return typeof r === 'function' ? r(body) : (r ?? { status: 200, body: {} });
  };
  return { post, posts };
}
const OK_OPEN = { status: 201, body: { sessionId: 'live_1', sdp: 'v=0\r\nanswer\r\n', model: 'gpt-live-1', brain: 'gpt-6-astra' } };

test('Talk on Live: microphone in, offer to THIS app, answer set, ready only when the peer and the channel both are', async () => {
  const { FakePC, made } = fakePeerClass();
  const m = mic();
  const { post, posts } = poster({ [LIVE_ROUTE]: OK_OPEN });
  const events = [];
  const audio = {};
  const live = await startLive({ post, RTCPeerConnection: FakePC, getUserMedia: m.getUserMedia, audio, domain: 'all', voice: 'cedar', onEvent: (e) => events.push(e) });
  const pc = made[0];
  assert.equal(pc.dc.label, 'oai-events');
  assert.equal(pc.tracks.length, 1);
  // With this tab's id, so the server keeps one session per operator and tab (2.20.0 round one, security MINOR 4).
  assert.match(posts[0].body.tab, /^[\w-]{8,64}$/);
  assert.deepEqual(posts[0], { path: '/api/v3/hugo/live', body: { sdp: 'v=0\r\nm=audio\r\n', tab: posts[0].body.tab, domain: 'all', voice: 'cedar', check: false } });
  assert.deepEqual(pc.remoteDescription, { type: 'answer', sdp: 'v=0\r\nanswer\r\n' });
  assert.deepEqual(live.connected, { ice: 'connected', state: 'connected' });
  assert.equal(live.sessionId, 'live_1');
  pc.fire('track', { streams: ['remote-stream'] });
  assert.equal(audio.srcObject, 'remote-stream', 'Hugo plays from a MediaStream, no URL');
  pc.dc.fire('message', { data: JSON.stringify({ type: 'session.output_transcript.delta', delta: 'Hi' }) });
  pc.dc.fire('message', { data: 'not json' });
  assert.deepEqual(events, [{ type: 'session.output_transcript.delta', delta: 'Hi' }]);
  live.mute(true);
  assert.deepEqual(pc.dc.sent, [{ type: 'session.input_audio.mute' }], 'the only thing the browser may send');
  await live.end();
  await live.end();
  assert.equal(pc.closed, true);
  assert.equal(m.tracks[0].stopped, true);
  assert.deepEqual(posts.slice(1), [{ path: LIVE_END_ROUTE, body: { sessionId: 'live_1' } }], 'the server is told once');
});

test('a refused microphone is named and nothing is posted', async () => {
  const { FakePC } = fakePeerClass();
  const { post, posts } = poster();
  await assert.rejects(startLive({ post, RTCPeerConnection: FakePC, getUserMedia: async () => { throw Object.assign(new Error('no'), { name: 'NotAllowedError' }); } }), (e) => e.link === 'microphone' && e.name === 'NotAllowedError');
  assert.equal(posts.length, 0);
});

test('a refused offer names the link the server named, and releases the peer and the microphone', async () => {
  const { FakePC, made } = fakePeerClass();
  const m = mic();
  const { post } = poster({ [LIVE_ROUTE]: { status: 502, body: { link: 'sideband', kind: 'timeout' } } });
  await assert.rejects(startLive({ post, RTCPeerConnection: FakePC, getUserMedia: m.getUserMedia }), (e) => e.link === 'sideband' && e.kind === 'timeout' && e.status === 502);
  assert.equal(made[0].closed, true);
  assert.equal(m.tracks[0].stopped, true);
  const plain = poster({ [LIVE_ROUTE]: { status: 'offline', body: null } });
  await assert.rejects(startLive({ post: plain.post, RTCPeerConnection: FakePC, getUserMedia: mic().getUserMedia }), (e) => e.link === 'handshake');
});

test('a WebRTC link that never connects is given up, names its ICE state, and ends the server\'s session', async () => {
  const { FakePC, made } = fakePeerClass({ connect: false });
  const { post, posts } = poster({ [LIVE_ROUTE]: OK_OPEN });
  const err = await startLive({ post, RTCPeerConnection: FakePC, getUserMedia: mic().getUserMedia, timeoutMs: 5 }).catch((e) => e);
  assert.equal(err.link, 'webrtc');
  assert.equal(err.timedOut, true);
  assert.equal(err.ice, 'new');
  assert.equal(made[0].closed, true);
  assert.deepEqual(posts.at(-1), { path: LIVE_END_ROUTE, body: { sessionId: 'live_1' } });
  const { FakePC: Failing } = fakePeerClass({ failState: 'failed' });
  await assert.rejects(startLive({ post, RTCPeerConnection: Failing, getUserMedia: mic().getUserMedia }), (e) => e.link === 'webrtc' && e.state === 'failed' && !e.timedOut);
});

test('a link that drops after connecting is reported once, and not after the operator ended it', async () => {
  const { FakePC, made } = fakePeerClass();
  const drops = [];
  const live = await startLive({ post: poster({ [LIVE_ROUTE]: OK_OPEN }).post, RTCPeerConnection: FakePC, getUserMedia: mic().getUserMedia, onDrop: (s) => drops.push(s) });
  made[0].connectionState = 'failed';
  made[0].fire('connectionstatechange');
  assert.deepEqual(drops, [{ ice: 'connected', state: 'failed' }]);
  await live.end();
  made[0].fire('connectionstatechange');
  assert.equal(drops.length, 1);
});

const tick = () => new Promise((r) => setImmediate(r));
// The browser holds the session's length too (2.20.0 security gate): a session whose server link dropped cannot run past it.
test('the browser ends its own link at the session length the server sent, and says why', async () => {
  const { FakePC, made } = fakePeerClass();
  const drops = [];
  const timers = [];
  const setTimer = (fn, ms) => { const t = { fn, ms }; timers.push(t); return t; };
  const open = { status: 201, body: { ...OK_OPEN.body, maxSessionMs: 1234 } };
  const p = poster({ [LIVE_ROUTE]: open });
  await startLive({ post: p.post, RTCPeerConnection: FakePC, getUserMedia: mic().getUserMedia, onDrop: (s) => drops.push(s), setTimer, clearTimer: () => {}, timeoutMs: 99_999 });
  const limit = timers.find((t) => t.ms === 1234);
  assert.ok(limit, 'a timer at the session length');
  limit.fn();
  await tick();
  assert.equal(made[0].closed, true, 'the peer is closed');
  assert.deepEqual(drops.map((d) => d.reason), ['session_length']);
  assert.ok(p.posts.some((x) => x.path === LIVE_END_ROUTE), 'and the server is told the session ended');
  const none = [];
  await startLive({ post: poster({ [LIVE_ROUTE]: OK_OPEN }).post, RTCPeerConnection: fakePeerClass().FakePC, getUserMedia: mic().getUserMedia, setTimer: (fn, ms) => { none.push(ms); return {}; }, clearTimer: () => {}, timeoutMs: 99_999 });
  assert.deepEqual(none.filter((ms) => ms !== 99_999), [], 'no length sent, no length timer');
});

// AN ENDED SESSION LETS GO OF ITS LENGTH TIMER (2.20.0 round two, engineering MINOR 10): it could not act once ended, but
// it held the finished session's peer and stream until the limit.
test('ending a Live session clears its length timer', async () => {
  const set = [];
  const cleared = [];
  const open = { status: 201, body: { ...OK_OPEN.body, maxSessionMs: 1234 } };
  const live = await startLive({ post: poster({ [LIVE_ROUTE]: open }).post, RTCPeerConnection: fakePeerClass().FakePC, getUserMedia: mic().getUserMedia,
    setTimer: (fn, ms) => { const t = { fn, ms }; set.push(t); return t; }, clearTimer: (t) => cleared.push(t), timeoutMs: 99_999 });
  await live.end();
  assert.ok(cleared.includes(set.find((t) => t.ms === 1234)), 'the length timer is cleared when the session ends');
});

test('the check makes an audio offer with NO microphone, so it needs no permission prompt', async () => {
  const { FakePC, made } = fakePeerClass();
  const { post, posts } = poster({ [LIVE_ROUTE]: OK_OPEN });
  const live = await startLive({ post, RTCPeerConnection: FakePC, getUserMedia: null, check: true, domain: 'space' });
  assert.deepEqual(made[0].transceivers, [{ kind: 'audio', init: { direction: 'sendrecv' } }]);
  assert.equal(posts[0].body.check, true);
  await live.end();
});

test('waitConnected answers on its own when the peer is already connected', async () => {
  const pc = Object.assign(listeners(), { connectionState: 'connected', iceConnectionState: 'completed' });
  const dc = Object.assign(listeners(), { readyState: 'open' });
  assert.deepEqual(await waitConnected(pc, dc, { timeoutMs: 5 }), { ice: 'completed', state: 'connected' });
});

test('captions become the rail\'s actions: the operator\'s words when Hugo starts, his words as they come, settled on quiet', () => {
  const out = [];
  const timers = [];
  const cap = createLiveCaptions({ emit: (a) => out.push(a), setTimer: (fn) => { timers.push(fn); return fn; }, clearTimer: () => {} });
  cap.feed({ type: 'session.input_transcript.delta', delta: 'How many ' });
  cap.feed({ type: 'session.input_transcript.delta', delta: 'vendors?' });
  assert.deepEqual(out, [], 'nothing until Hugo answers: Live marks no turn end');
  cap.feed({ type: 'session.output_transcript.delta', delta: 'There are ' });
  cap.feed({ type: 'session.output_transcript.delta', delta: '42.' });
  assert.deepEqual(out, [{ heard: 'How many vendors?' }, { transcript: 'There are ' }, { transcript: '42.' }]);
  timers.at(-1)();
  assert.deepEqual(out.at(-1), { done: true });
  // Barge-in: the operator speaks over a reply, which settles it at once.
  cap.feed({ type: 'session.output_transcript.delta', delta: 'Next' });
  cap.feed({ type: 'session.input_transcript.delta', delta: 'Stop' });
  assert.deepEqual(out.at(-1), { done: true });
  cap.feed({ type: 'session.closed' });
  assert.equal(out.filter((a) => a.done).length, 2, 'settled once each, never twice');
});

test('each Live failure tells the operator what happened and never promises a fallback that is not there', () => {
  assert.match(liveFailureText({ link: 'microphone' }), /Allow the microphone for this site/);
  assert.match(liveFailureText({ link: 'handshake', status: 429, error: 'daily_cap_reached' }), /spending limit/);
  assert.match(liveFailureText({ link: 'webrtc' }), /could not connect from this network, so Talk is using the app's own link/);
  assert.match(liveFailureText({ link: 'webrtc' }, { fallback: false }), /Check Hugo's connection/);
  assert.match(liveFailureText({ link: 'handshake', kind: 'model' }), /\(handshake, model\)/);
  assert.equal(liveFailureText({ link: 'config' }), '', 'off by settings is silent where the relay answers');
  assert.ok(liveFailureText({ link: 'config' }, { fallback: false }));
});

// WHICH LIMIT A REFUSED TALK MET (VH-902, owner, 2026-10-28: Talk said "today's spending limit" after one 10-second use,
// when the refusal was the 3-a-minute tier). The server names the limit in its body; the notice says which, and only the
// spent day says tomorrow.
test('a refused Talk start says which limit it met, and only the spent day says tomorrow', async () => {
  const { FakePC } = fakePeerClass();
  const { post } = poster({ [LIVE_ROUTE]: { status: 429, body: { error: 'hugo rate limited' } } });
  const err = await startLive({ post, RTCPeerConnection: FakePC, getUserMedia: mic().getUserMedia }).catch((e) => e);
  assert.deepEqual([err.status, err.error], [429, 'hugo rate limited'], 'the server\'s own words travel with the failure');
  const minute = liveFailureText(err);
  assert.match(minute, /in a minute/);
  assert.doesNotMatch(minute, /spending|tomorrow/);
  assert.match(liveFailureText({ link: 'handshake', status: 429, error: 'daily_cap_reached' }), /today's spending limit.*tomorrow/);
  for (const error of ['scan rate limited', 'rate limited', '', undefined]) {
    assert.doesNotMatch(liveFailureText({ link: 'handshake', status: 429, error }), /spending|tomorrow/, String(error));
  }
});

// ---- the check ---------------------------------------------------------------------------------------------

test('the check tries every link and passes only when a spoken turn ran a tool', async () => {
  const { FakePC } = fakePeerClass();
  let t = 0;
  const { post, posts } = poster({ [LIVE_ROUTE]: OK_OPEN, [LIVE_CHECK_ROUTE]: { status: 200, body: { delegation: { ok: true, tool: 'count_records', latencyMs: 812 } } } });
  const out = await checkLiveVoice({ post, RTCPeerConnection: FakePC, domain: 'space', now: () => (t += 100) });
  assert.deepEqual(out, { ok: true, ice: 'connected', state: 'connected', connectMs: 100, tool: 'count_records', delegationMs: 812 });
  assert.deepEqual(posts.map((p) => p.path), [LIVE_ROUTE, LIVE_CHECK_ROUTE, LIVE_END_ROUTE], 'and the check session is ended');
});

test('the check names the first link that broke', async () => {
  const run = async (responses, behaviour) => {
    const { FakePC } = fakePeerClass(behaviour);
    return checkLiveVoice({ post: poster(responses).post, RTCPeerConnection: FakePC, domain: 'space', timeoutMs: 5 });
  };
  assert.deepEqual(await run({ [LIVE_ROUTE]: { status: 502, body: { link: 'handshake', kind: 'model', code: 'model_not_found' } } }),
    { ok: false, failed: 'handshake', kind: 'model', code: 'model_not_found', reason: '', ice: '', state: '', timedOut: false });
  assert.equal((await run({ [LIVE_ROUTE]: { status: 502, body: { link: 'sideband', kind: 'refused' } } })).failed, 'sideband');
  assert.equal((await run({ [LIVE_ROUTE]: { status: 503, body: { link: 'config', reason: 'unpriced' } } })).reason, 'unpriced');
  const rtc = await run({ [LIVE_ROUTE]: OK_OPEN }, { connect: false });
  assert.deepEqual([rtc.failed, rtc.timedOut, rtc.ice], ['webrtc', true, 'new']);
  const brain = await run({ [LIVE_ROUTE]: OK_OPEN, [LIVE_CHECK_ROUTE]: { status: 200, body: { delegation: { ok: false, kind: 'refused', code: 'model_not_found' } } } });
  assert.deepEqual([brain.failed, brain.kind, brain.code], ['delegation', 'refused', 'model_not_found']);
  assert.equal((await run({ [LIVE_ROUTE]: OK_OPEN, [LIVE_CHECK_ROUTE]: { status: 404, body: {} } })).kind, 'not_run');
});

const GREEN_KEY = { reached: true, ok: true, configured: true, kind: '', model: 'gpt-6-astra', latencyMs: 300 };
const withLinks = (extra) => ({ ...GREEN_KEY, links: { tools: { ok: true, latencyMs: 10 }, realtime: { ok: true, model: 'gpt-realtime-2', latencyMs: 20 }, models: { ok: true, reached: ['gpt-live-1', 'gpt-6-astra'], missing: [] }, live: { ok: true, model: 'gpt-live-1', brain: 'gpt-6-astra' }, ...extra } });

test('THE LINE IS NEVER GREEN UNLESS HUGO CAN CONVERSE: a green key with a failing voice link is amber and names it', () => {
  const ok = hugoPreflightLine(withLinks(), { ok: true }, { ok: true, ice: 'connected', connectMs: 640, tool: 'count_records', delegationMs: 900 });
  assert.equal(ok.good, true);
  assert.match(ok.text, /live voice \(gpt-live-1 with gpt-6-astra\) connected in 640ms, ICE connected, and a spoken turn ran count_records in 900ms/);
  const cases = {
    handshake: [{ failed: 'handshake', kind: 'model' }, /OPENAI_LIVE_MODEL/],
    sideband: [{ failed: 'sideband', kind: 'refused' }, /control link/],
    webrtc: [{ failed: 'webrtc', ice: 'checking', state: 'connecting', timedOut: true }, /ICE checking, connecting, timed out/],
    delegation: [{ failed: 'delegation', kind: 'timeout' }, /did not complete a turn with a tool \(timeout\)/],
  };
  for (const [link, [voice, said]] of Object.entries(cases)) {
    const line = hugoPreflightLine(withLinks(), { ok: true }, { ok: false, ...voice });
    assert.equal(line.good, false, link + ' is never green');
    assert.match(line.text, /Hugo is connected/, link + ': the key is still reported as working');
    assert.match(line.text, said, link + ' is named');
  }
});

test('the key\'s reach, a browser with no WebRTC, and Live off each say so', () => {
  const missing = hugoPreflightLine(withLinks({ models: { ok: false, reached: ['gpt-6-astra'], missing: ['gpt-live-1'] } }), { ok: true }, { ok: true, ice: 'connected', tool: 'count_records' });
  assert.equal(missing.good, false);
  assert.match(missing.text, /The key cannot reach gpt-live-1/);
  const noRtc = hugoPreflightLine(withLinks(), { ok: true }, null);
  assert.equal(noRtc.good, false);
  assert.match(noRtc.text, /needs WebRTC/);
  const off = hugoPreflightLine(withLinks({ live: { ok: false, off: true, reason: 'unpriced' } }), { ok: true }, undefined);
  assert.equal(off.good, true, 'Live off by settings leaves the relay\'s verdict standing');
  assert.match(off.text, /live voice is off: a daily spend cap is set/);
  // VH-865 (owner, 28 October: "DO NOT make Talk depend on" the platform's WebSocket route): with Live working, Talk runs
  // over it, so the fallback's refusal is still NAMED, as a note for the platform team, and no longer turns the line red.
  const relayDown = hugoPreflightLine(withLinks(), { ok: false, why: 'timeout' }, { ok: true, ice: 'connected', tool: 'count_records' });
  assert.equal(relayDown.good, true, 'Hugo can converse over Live');
  assert.match(relayDown.text, /could not open from this browser \(it did not answer within 8 seconds\): a note for the platform team/, 'a failing fallback is named, never hidden behind a working Live');
});

test('a connected peer whose data channel never opens is not ready: no captions, no mute, so it times out', async () => {
  const pc = Object.assign(listeners(), { connectionState: 'connected', iceConnectionState: 'connected' });
  const dc = Object.assign(listeners(), { readyState: 'connecting' });
  await assert.rejects(waitConnected(pc, dc, { timeoutMs: 5 }), (e) => e.link === 'webrtc' && e.timedOut === true);
});

// THE MICROPHONE REFUSAL NAMES ITS REAL CAUSE (VH-906, owner, 2026-10-28, an iPhone: "won't work and says it's disabled but
// browser settings say it is enabled"). Only a site permission the browser reports as denied is told to allow it; a
// refusal while the site is allowed, or inside a frame, is the app being open inside another app; no device says so.
test('a refused microphone says why: denied, allowed but refused, framed, or no microphone', () => {
  const text = (extra) => liveFailureText({ link: 'microphone', ...extra });
  assert.match(text({ name: 'NotAllowedError', permission: 'denied' }), /Allow the microphone for this site/);
  for (const permission of ['granted', 'prompt']) {
    const said = text({ name: 'NotAllowedError', permission });
    assert.match(said, /Open the app in Safari or Chrome itself/, permission);
    assert.doesNotMatch(said, /Allow the microphone/, permission + ': the site is allowed, so that advice is wrong');
  }
  assert.match(text({ name: 'NotAllowedError', permission: 'granted', framed: true }), /open inside another app or a frame/);
  assert.match(text({ name: 'SecurityError' }), /open inside another app or a frame/);
  assert.match(text({ name: 'NotFoundError' }), /could not find a working microphone/);
  assert.match(text({ name: 'NotReadableError' }), /in use by another app/);
  // The permission not known (an older browser): both steps, the site's setting first.
  assert.match(text({ name: 'NotAllowedError' }), /Allow the microphone for this site; if it is already allowed, open the app in Safari or Chrome itself/);
});
