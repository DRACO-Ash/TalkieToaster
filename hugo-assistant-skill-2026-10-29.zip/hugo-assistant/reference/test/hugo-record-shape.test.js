// WHAT HUGO CAN SEE OF A RECORD (src/hugo/tools.js `shape`), widened at the owner's instruction on
// 2026-09-19: "Hugo should interact with every element of every schema across all domains".
//
// The defect this closes is not that Hugo answered capability questions badly. It is that
// `query_records` handed the model NINE keys - ref, id, name, domain, country, grade, gdm, section,
// website - so "who does synthetic aperture radar in Europe" was unanswerable BY CONSTRUCTION: the field
// holding the answer was never in the payload, and no amount of prompting could recover it.
//
// The cases below are the ways a widening goes wrong while looking right: it can quietly stay narrow, it
// can become unbounded, it can emit a field the record does not carry, it can be defeated by the second
// row shape, and it can be a hand-written list that drifts from the schema the moment a field is added.

import test from 'node:test';
import assert from 'node:assert/strict';

import { createToolRunner, createLedger, TOOL_MAX_ROWS } from '../src/hugo/tools.js';
import { RECORD_FIELDS } from '../src/domain/tracker.js';
import { AGENT_CAPS } from '../src/hugo/agent.js';

// A record with the fields the old shape dropped, plus the ones it kept, so a test can tell the two apart.
const FULL = {
  vendor_id: 'VH-0001',
  company: 'Example Radar Systems Ltd',
  country: 'Poland',
  grade: 'Ready for JCO',
  gdm: 'Not in GDM',
  section: 'P&D SDA',
  website: 'https://example.invalid/radar',
  capability: 'Synthetic aperture radar tasking and delivery, with an X-band constellation in sun-synchronous orbit, a ground segment in three countries, and an analyst-facing change-detection product delivered within two hours of collection.',
  product_types: ['Synthetic Aperture Radar', 'Radar'],
  missions: ['EMSO'],
  last_verified: '2026-07-11',
  hq: 'Warsaw',
};

// Space's Mission Alignment, held in memory (VH-801): Synthetic Aperture Radar carries EMSO and TacSRT.
const ALIGNMENT = {
  missions: async () => [{ key: 'tacsrt', name: 'TacSRT' }, { key: 'emso', name: 'EMSO' }],
  confirmedMap: async () => new Map([['synthetic aperture radar', ['TacSRT', 'EMSO']]]),
};
const runnerFor = (rows) => createToolRunner({ defaultDomain: 'space',
  runQuery: async () => ({ rows, total: rows.length, applied: [], notApplied: [] }),
  ledger: createLedger(), alignment: ALIGNMENT,
});

test('the caps really did move, so the tests below are not measuring the old world', () => {
  // An assertion that can reach only one verdict measures nothing. These two pin that the widening
  // happened at all; every other test here would pass vacuously against the old numbers.
  assert.equal(TOOL_MAX_ROWS, 50, 'the row ceiling is 50, not the old 10');
  assert.ok(AGENT_CAPS.maxToolCalls >= 24, 'a turn may make enough calls to investigate');
  assert.ok(AGENT_CAPS.maxSteps >= 12);
});

test('a queried record carries the fields the old shape dropped', async () => {
  const runner = runnerFor([{ record: FULL }]);
  const out = await runner.run('query_records', { domain: 'space', filter: {} });
  assert.equal(out.ok, true);
  const row = out.result.records[0];

  // THE FOUR THAT WERE MISSING. Each one is a question an operator actually asks.
  assert.match(row.capability, /Synthetic aperture radar tasking/);
  assert.equal(row.product_types, 'Synthetic Aperture Radar, Radar');
  // VH-801: the vendor's NATO/JCO Missions, read from Mission Alignment for its data types, in the domain's order; the
  // stored list (EMSO alone here) is not handed over.
  assert.equal(row.nato_jco_missions, 'TacSRT, EMSO');
  assert.equal(row.missions, undefined);
  assert.equal(row.last_verified, '2026-07-11');

  // AND THE ONES THAT WERE ALREADY THERE STILL ARE, so this is a widening rather than a swap.
  assert.equal(row.country, 'Poland');
  // VH-401 (owner, 2026-10-06): Hugo neither reads nor says the JCO/NATO readiness grade, so the one field
  // the old shape carried that this one does not is the grade.
  assert.equal(row.grade, undefined, 'the readiness grade is not handed to the model');
  assert.doesNotMatch(JSON.stringify(out.result), /JCO/, 'under any key');
  assert.equal(row.gdm, 'Not in GDM');
  assert.equal(row.website, 'https://example.invalid/radar');
  assert.ok(row.ref, 'the stable reference the answer cites by');
  assert.equal(row.id, 'VH-0001');
  assert.equal(row.name, 'Example Radar Systems Ltd');
});

test('the capability sentence is no longer cut mid-word at 160 characters', async () => {
  // The old per-field cap was 160, and `capability` is the one field that carries what a vendor DOES, so
  // the model was asked to reason about a truncated sentence. Measured: this fixture's capability is
  // longer than the old cap and shorter than the new one, so it can distinguish the two.
  assert.ok(FULL.capability.length > 160, 'the fixture must exceed the OLD cap or this proves nothing');
  const runner = runnerFor([{ record: FULL }]);
  const out = await runner.run('query_records', { domain: 'space', filter: {} });
  assert.equal(out.result.records[0].capability, FULL.capability, 'delivered whole');
});

test('an empty field is omitted, so the payload tracks the record and not the schema', async () => {
  const sparse = { vendor_id: 'VH-0002', company: 'Example Sparse Ltd', country: 'France' };
  const runner = runnerFor([{ record: sparse }]);
  const out = await runner.run('query_records', { domain: 'space', filter: {} });
  const row = out.result.records[0];
  // Widening the FIELD LIST must not widen the PAYLOAD for a record that carries nothing in those fields.
  assert.equal('capability' in row, false);
  assert.equal('product_types' in row, false);
  assert.equal('missions' in row, false);
  // The row is still identifiable, which is the half that must never be dropped.
  assert.equal(row.id, 'VH-0002');
  assert.equal(row.country, 'France');
});

test('one pathological record cannot consume the turn', async () => {
  // Every text field at ten thousand characters. The per-record ceiling must bound the row, and it must
  // truncate the TAIL rather than the identity, because a row nobody can cite is worse than a short one.
  const huge = { vendor_id: 'VH-0003', company: 'Example Huge Ltd', country: 'Germany' };
  for (const key of RECORD_FIELDS) {
    if (['vendor_id', 'company', 'country'].includes(key)) continue;
    huge[key] = 'x'.repeat(10_000);
  }
  const runner = runnerFor([{ record: huge }]);
  const out = await runner.run('query_records', { domain: 'space', filter: {} });
  const row = out.result.records[0];
  const bytes = JSON.stringify(row).length;
  assert.ok(bytes < 4000, 'one record is bounded; measured ' + bytes + ' characters');
  assert.equal(row.id, 'VH-0003', 'the identity survives the ceiling');
  assert.equal(row.name, 'Example Huge Ltd');
});

test('a bare domain row, with no record wrapper, still shapes', async () => {
  // The Space master carries `{ record }`; a domain provider row is flat. A shape that assumed one would
  // filter the master correctly and return nothing useful for every other domain - the "works on one
  // surface" failure the owner's word "robustly" was aimed at.
  const flat = { provider_key: 'air-99', legal_name: 'Example Rotorcraft GmbH', hq_country: 'Germany' };
  const runner = runnerFor([flat]);
  const out = await runner.run('query_records', { domain: 'air', filter: {} });
  const row = out.result.records[0];
  assert.equal(row.id, 'air-99');
  assert.equal(row.name, 'Example Rotorcraft GmbH');
  assert.equal(row.domain, 'air');
});

test('the field list is DERIVED from the schema catalogue, not written out here', () => {
  // The point of the change: a field added to the schema must reach Hugo with no edit to tools.js. This
  // pins the SOURCE rather than the contents, so it keeps holding as the catalogue grows.
  // THE SOURCE IS THE SCHEMA SET, not a list in tools.js. Measured, and the measurement matters: the
  // export catalogue was the first candidate and it does NOT carry `product_types`, so deriving from it
  // would have widened Hugo's view while still hiding the field half the owner's capability questions
  // turn on. RECORD_FIELDS is what validateTrackerRecord accepts and what the store holds.
  for (const expected of ['capability', 'product_types', 'missions', 'last_verified', 'regime_capabilities']) {
    assert.ok(RECORD_FIELDS.has(expected), expected + ' is in the authoritative schema set');
  }
  assert.ok(RECORD_FIELDS.size > 30, 'the schema set is the wide one: ' + RECORD_FIELDS.size + ' fields');
});

// EVERY DOMAIN IS TREATED EQUALLY (owner rule, 2026-09-24). A domain record reaches the model with every field
// (test/record-field-coverage.test.js, 222 of 222); a Space record withheld its structured fields: identifiers,
// ownership, export control, geo, sites, contacts and both JCO detail blocks. Every Space schema field is
// planted here with its own token, in the structure the schema gives it, and every one must reach get_record
// except the spine and the same bookkeeping the domain read holds back.
const BOOKKEEPING = new Set(['vendor_id', 'company', 'lifecycle_status', 'review_state', 'scan_archetype', 'verified_by']);
// VH-401: the readiness grade and the four `jco_*` blocks behind it are held back from the model too. Space-only
// fields, so the domains are still treated equally: no domain record carries them.
const READINESS = new Set(['grade', 'jco_match_pct', 'jco_requirement_matches', 'jco_assessed_at', 'jco_pws_ref', 'jco_loe_scores',
  // VH-801: the stored mission list too; the model reads a vendor's missions from Mission Alignment instead.
  'missions']);
const OBJECT_FIELDS = new Set(['geo', 'identifiers', 'ownership', 'export_control', 'jco_loe_scores']);
const OBJECT_LIST_FIELDS = new Set(['contacts', 'sites', 'jco_requirement_matches']);
test('EQUAL: every Space field reaches the model through get_record, structured ones included', async () => {
  const record = { vendor_id: 'VH-0009', company: 'Equal Treatment Ltd' };
  for (const key of RECORD_FIELDS) {
    if (key in record) continue;
    const token = 'tok_' + key;
    if (OBJECT_FIELDS.has(key)) record[key] = { value: token };
    else if (OBJECT_LIST_FIELDS.has(key)) record[key] = [{ name: token }];
    else record[key] = token;
  }
  const runner = createToolRunner({ defaultDomain: 'space', vendorRepo: { getVendor: async () => ({ record }) }, runQuery: async () => ({ rows: [] }) });
  const out = await runner.run('get_record', { domain: 'space', id: 'VH-0009' });
  assert.equal(out.ok, true);
  const text = JSON.stringify(out.result);
  const missing = [...RECORD_FIELDS].filter((k) => !BOOKKEEPING.has(k) && !READINESS.has(k) && !text.includes('tok_' + k));
  assert.deepEqual(missing, [], 'every Space field the model is not shown, other than bookkeeping and readiness');
  for (const k of READINESS) assert.equal(text.includes('tok_' + k), false, k + ' is the readiness grade or its evidence');
  for (const k of BOOKKEEPING) if (k !== 'vendor_id' && k !== 'company') assert.equal(text.includes('tok_' + k), false, k + ' is bookkeeping');
});
