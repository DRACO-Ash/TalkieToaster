// Hugo's OpenAI chat caller (src/hugo/openai-chat.js). Pure request-shaping against an injected fetch, so no
// network is touched. Covers chatOnce (the preflight's check of the key, and the shared agent loop's turn), the
// hosted web search, the usage mapping into the ledger's shape, and the fail-closed/provider-error paths. The
// streaming reply and the compiler's one-shot completion are retired with their routes (VH-318-F).

import test from 'node:test';
import assert from 'node:assert/strict';
import { createOpenAiChat, redactSecrets } from '../src/hugo/openai-chat.js';

const enc = new TextEncoder();

function jsonResponse(obj, { ok = true, status = 200 } = {}) {
  return { ok, status, json: async () => obj };
}

test('chatOnce without tools posts a chat completion and returns the message with mapped usage', async () => {
  let seen = null;
  const usageSeen = [];
  const chat = createOpenAiChat({
    apiKey: 'sk-test', model: 'gpt-6-astra', onUsage: (u) => usageSeen.push(u),
    fetchImpl: async (url, opts) => { seen = { url, opts }; return jsonResponse({ choices: [{ message: { content: 'the answer' } }], usage: { prompt_tokens: 12, completion_tokens: 5 } }); },
  });
  assert.equal(chat.configured, true);
  const out = await chat.chatOnce({ system: 'you are Hugo', messages: [{ role: 'user', content: 'hi' }] });
  // The endpoint, the bearer auth, and the request body shape.
  assert.equal(seen.url, 'https://api.openai.com/v1/chat/completions');
  assert.equal(seen.opts.headers.authorization, 'Bearer sk-test');
  const body = JSON.parse(seen.opts.body);
  assert.equal(body.model, 'gpt-6-astra');
  assert.equal(body.stream, false);
  // The forward-compatible token cap: `max_completion_tokens` (GPT-5.x reasoning models reject the
  // deprecated `max_tokens`), never the old field.
  assert.equal(body.max_completion_tokens, 2000);
  assert.equal(body.max_tokens, undefined);
  assert.deepEqual(body.messages[0], { role: 'system', content: 'you are Hugo' });
  assert.deepEqual(body.messages[1], { role: 'user', content: 'hi' });
  assert.equal(out.message.content, 'the answer');
  // Usage mapped from OpenAI's field names to the ledger's { input_tokens, output_tokens }.
  assert.deepEqual(out.usage, { input_tokens: 12, output_tokens: 5 });
  assert.deepEqual(usageSeen[0], { input_tokens: 12, output_tokens: 5 });
});

test('an unconfigured caller (no key) reports it and refuses to call out', async () => {
  let called = false;
  const chat = createOpenAiChat({ apiKey: '', fetchImpl: async () => { called = true; return jsonResponse({}); } });
  assert.equal(chat.configured, false);
  await assert.rejects(() => chat.chatOnce({ system: 's', messages: [] }), /not configured/);
  await assert.rejects(() => chat.searchWeb({ query: 'x' }), /not configured/);
  assert.equal('streamChat' in chat || 'streamOnce' in chat, false, 'the retired paths are gone (VH-318-F)');
  assert.equal(called, false);
});

test('a provider error becomes a 502', async () => {
  const chat = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => jsonResponse({}, { ok: false, status: 429 }) });
  await assert.rejects(() => chat.chatOnce({ system: 's', messages: [] }), (e) => e.statusCode === 502 && e.providerStatus === 429);
});

test('the model is env-overridable so "the best OpenAI model" is set by ops, not hardcoded', async () => {
  let body = null;
  const chat = createOpenAiChat({ apiKey: 'sk-test', model: 'gpt-best-2026', fetchImpl: async (u, o) => { body = JSON.parse(o.body); return jsonResponse({ choices: [{ message: { content: 'x' } }] }); } });
  await chat.chatOnce({ system: 's', messages: [] });
  assert.equal(body.model, 'gpt-best-2026');
});

test('the default reasoning model is an id that EXISTS, and it is the one this file names', async () => {
  const prev = process.env.OPENAI_HUGO_MODEL;
  delete process.env.OPENAI_HUGO_MODEL;
  try {
    let body = null;
    const chat = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async (u, o) => { body = JSON.parse(o.body); return jsonResponse({ choices: [{ message: { content: 'x' } }] }); } });
    await chat.chatOnce({ system: 's', messages: [] });
    // The point of this assertion changed with owner defect 9. It used to pin `gpt-6-astra` as "the
    // flagship", and that id does not exist at OpenAI: the test passed for two years against a model the
    // provider answers 400 for, because it only ever checked that the string reached the body. It pins the
    // same mechanism against an id that resolves. What model is BEST is an operations question and is set
    // through OPENAI_HUGO_MODEL, which the test below covers.
    assert.equal(body.model, 'gpt-6-astra');
  } finally {
    if (prev === undefined) delete process.env.OPENAI_HUGO_MODEL; else process.env.OPENAI_HUGO_MODEL = prev;
  }
});

// --- THE HOSTED WEB SEARCH (V1.79) -------------------------------------------------------------------------
// An engineering gate found this whole block untested: every other test injects a fake `searchWeb`, so the
// real request construction and the real annotation walk had never been exercised by any command. That
// matters more than an ordinary coverage gap because the failure is SILENT: if `responseCitations` reads the
// wrong path, it returns [], `web-lookup.js` turns that into "the search returned nothing with a citable
// source", and the discovery half of Hugo's web reach is dead in production while the app reports a tidy,
// plausible error. The changelog states as fact that Hugo reaches the web; this is the half of that claim
// no command had checked.

// A Responses API reply in the shape the provider documents: tool-call items first, then the message, with
// url citations carried as ANNOTATIONS on the content part rather than in the prose.
function responsesReply({ text = 'Norss operates SSA sensors.', annotations = [], usage = { input_tokens: 30, output_tokens: 9 } } = {}) {
  return {
    output: [
      { type: 'web_search_call', id: 'ws_1', status: 'completed' },
      { type: 'message', role: 'assistant', content: [{ type: 'output_text', text, annotations }] },
    ],
    usage,
  };
}

test('searchWeb posts to the RESPONSES endpoint with the hosted web_search tool, and maps usage', async () => {
  let seen = null;
  const usageSeen = [];
  const chat = createOpenAiChat({
    apiKey: 'sk-test', model: 'gpt-6-astra', onUsage: (u) => usageSeen.push(u),
    fetchImpl: async (url, opts) => { seen = { url, opts }; return jsonResponse(responsesReply()); },
  });
  const out = await chat.searchWeb({ query: 'what does Norss sell' });
  // THE ENDPOINT IS NOT chat/completions. The hosted tools live on the Responses API and chat/completions
  // has no equivalent, so a wrong path here is the whole feature.
  assert.equal(seen.url, 'https://api.openai.com/v1/responses');
  assert.equal(seen.opts.headers.authorization, 'Bearer sk-test');
  const body = JSON.parse(seen.opts.body);
  assert.deepEqual(body.tools, [{ type: 'web_search' }]);
  assert.equal(body.tool_choice, 'auto');
  assert.equal(body.model, 'gpt-6-astra');
  assert.equal(body.input, 'what does Norss sell');
  assert.equal(body.max_output_tokens, 2000);
  assert.match(body.instructions, /do not speculate beyond what the sources say/);
  // The query is CAPPED at the boundary, so a 10,000-character question cannot be posted whole.
  assert.equal(out.text, 'Norss operates SSA sensors.');
  assert.deepEqual(out.usage, { input_tokens: 30, output_tokens: 9 });
  assert.deepEqual(usageSeen.at(-1), { input_tokens: 30, output_tokens: 9 });
});

test('the query is capped and a non-string question cannot reach the provider', async () => {
  let body = null;
  const chat = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async (url, opts) => { body = JSON.parse(opts.body); return jsonResponse(responsesReply()); },
  });
  await chat.searchWeb({ query: 'x'.repeat(1000) });
  assert.equal(body.input.length, 400, 'capped at 400 characters');
  await chat.searchWeb({ query: { toString: () => 'not a string' } });
  assert.equal(typeof body.input, 'string');
});

test('CITATIONS COME FROM THE ANNOTATIONS, de-duplicated, never from the prose', async () => {
  // The distinction is the control: a link the model wrote into a sentence but that the search never
  // returned is NOT a source, and the caller refuses a result with no citation. If this walk breaks, every
  // search silently reports "nothing citable".
  const chat = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async () => jsonResponse(responsesReply({
      text: 'See https://invented.example/not-a-source for more.',
      annotations: [
        { type: 'url_citation', url: 'https://norss.co.uk/', title: 'Norss' },
        { type: 'url_citation', url: 'https://gov.uk/x', title: 'Register' },
        { type: 'url_citation', url: 'https://norss.co.uk/', title: 'Norss again' },
        { type: 'file_citation', file_id: 'f1' },
      ],
    })),
  });
  const out = await chat.searchWeb({ query: 'anything' });
  assert.deepEqual(out.citations, [
    { url: 'https://norss.co.uk/', title: 'Norss' },
    { url: 'https://gov.uk/x', title: 'Register' },
  ], 'the repeat is dropped and the annotation with no url contributes nothing');
  assert.ok(!out.citations.some((c) => c.url.includes('invented')), 'a url in the prose is not a citation');
});

test('output_text is used when present, and the content walk is the contract when it is not', async () => {
  const withConvenience = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async () => jsonResponse({ ...responsesReply({ text: 'from the walk' }), output_text: 'from the field' }),
  });
  assert.equal((await withConvenience.searchWeb({ query: 'x' })).text, 'from the field');
  // A reply that carries a tool-call item BEFORE the message is what a real hosted-search response looks
  // like, and the walk has to flatten past it rather than reading output[0].
  const walkOnly = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => jsonResponse(responsesReply({ text: 'from the walk' })) });
  assert.equal((await walkOnly.searchWeb({ query: 'x' })).text, 'from the walk');
});

test('searchWeb fails CLOSED: unconfigured throws, a provider error is a 502, and a junk body is empty', async () => {
  const noKey = createOpenAiChat({ fetchImpl: async () => jsonResponse(responsesReply()) });
  await assert.rejects(() => noKey.searchWeb({ query: 'x' }), /not configured/);
  const erroring = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => jsonResponse({ error: 'nope' }, { ok: false, status: 429 }) });
  await assert.rejects(() => erroring.searchWeb({ query: 'x' }), (e) => e.statusCode === 502 && e.providerStatus === 429);
  // A SHAPE NOBODY EXPECTED must come back as nothing citable rather than throwing: `web-lookup.js` then
  // reports the honest refusal, which is the branch this whole block exists to make measurable.
  const junk = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => jsonResponse({ output: 'not an array' }) });
  const out = await junk.searchWeb({ query: 'x' });
  assert.deepEqual(out.citations, []);
  assert.equal(out.text, '');
  assert.deepEqual(out.usage, { input_tokens: 0, output_tokens: 0 });
});

test('A PROVIDER FAILURE CARRIES ITS STATUS AND CODE IN THE MESSAGE, because the message is all that is recorded', async () => {
  // `src/faults.js` stores `err.message` and nothing else, and the agent route records exactly that, so the
  // fault ring is where an operator reads this without shell access. While the message was a fixed string,
  // a rejected key, an unreachable model id, a spent quota and a provider outage were indistinguishable
  // there - which is the position Hugo was in on 2026-09-11, four candidate causes and no evidence.
  const withBody = (code, status) => ({
    ok: false, status, json: async () => ({}),
    text: async () => JSON.stringify({ error: { message: 'irrelevant prose', code, type: 'invalid_request_error' } }),
  });
  const cases = [
    ['model_not_found', 404, /404 model_not_found/],
    ['invalid_api_key', 401, /401 invalid_api_key/],
    ['insufficient_quota', 429, /429 insufficient_quota/],
  ];
  for (const [code, status, pattern] of cases) {
    const chat = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => withBody(code, status) });
    await assert.rejects(() => chat.chatOnce({ system: 's', messages: [] }), (e) => {
      assert.match(e.message, pattern, code);
      assert.equal(e.providerStatus, status);
      assert.equal(e.providerCode, code);
      // THE PROSE IS ON THE OBJECT AND NOT IN THE MESSAGE, asserted in BOTH directions so this can say
      // either thing: the body above carries 'irrelevant prose', so a message that contained it would fail
      // here and a `providerDetail` that dropped it would fail on the next line.
      assert.ok(!e.message.includes('irrelevant prose'), code + ': provider prose must not reach err.message');
      assert.equal(e.providerDetail, 'irrelevant prose');
      return true;
    });
  }
  // AND THE PROVIDER'S OWN SENTENCE GOES TO `providerDetail`, NEVER TO `message`. This test reversed its
  // position twice in one release and the second reversal is the one that stands, because a security gate
  // measured the cost of the first. Carrying the prose on `message` was meant to tell four
  // malformed-request causes apart on the fault ring; what it actually did was put the provider's text on
  // the WIRE, because `src/app.js` answers `{ error: err.message }` for any error with a `statusCode` and
  // `providerError` sets one. Measured end to end on `POST /api/v3/hugo/agent`, HTTP 200:
  //   "providerReason":"... 401 invalid_api_key: Incorrect API key provided: sk-proj-Ab3xQ****..."
  // The diagnostic value was real and is kept - `providerDetail` still carries the sentence to the fault
  // ring, which is the reader it was for. `message` carries our label, the status and the closed-vocabulary
  // code, and nothing the provider wrote.
  const bare = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => ({ ok: false, status: 503, text: async () => 'upstream unavailable' }) });
  await assert.rejects(() => bare.chatOnce({ system: 's', messages: [] }), (e) => {
    assert.equal(e.message, 'hugo model provider error 503');
    assert.equal(e.providerCode, '');
    return true;
  });
  // A response that cannot be read at all must not turn a provider error into a different error.
  const unreadable = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => ({ ok: false, status: 500, text: async () => { throw new Error('body already consumed'); } }) });
  await assert.rejects(() => unreadable.chatOnce({ system: 's', messages: [] }), (e) => e.message === 'hugo model provider error 500' && e.statusCode === 502);
  // The hosted-search path carries its own label, so the two are told apart on the same ring.
  const search = createOpenAiChat({ apiKey: 'sk-test', fetchImpl: async () => withBody('model_not_found', 404) });
  await assert.rejects(() => search.searchWeb({ query: 'x' }), (e) => e.message === 'hugo search provider error 404 model_not_found');
  // BOUNDED, so a provider that answers with a wall of text cannot flood the ring: 200 characters and no
  // newlines. The assertion can say both things - it is checked against a message longer than the bound.
  const long = 'x'.repeat(600) + ' tail';
  const flood = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async () => ({ ok: false, status: 400, text: async () => JSON.stringify({ error: { message: long, type: 'invalid_request_error' } }) }),
  });
  await assert.rejects(() => flood.chatOnce({ system: 's', messages: [] }), (e) => {
    assert.equal(e.providerDetail.length, 200);
    assert.ok(!e.providerDetail.includes('tail'), 'the tail past the bound is dropped');
    return true;
  });
});

// --- THE TOOL-CALLING TURN GOES TO THE RESPONSES API (owner defect 9, V1.90) ----------------------------

test('a turn WITH tools posts to /responses in the Responses shape, and a turn without stays on chat/completions', async () => {
  const calls = [];
  const responsesReply = {
    output: [
      { type: 'message', content: [{ type: 'output_text', text: 'thinking aloud' }] },
      { type: 'function_call', call_id: 'call_1', name: 'lookup', arguments: '{"q":"BAE"}' },
    ],
    usage: { input_tokens: 11, output_tokens: 7 },
  };
  const chat = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async (url, opts) => {
      calls.push({ url, body: JSON.parse(opts.body) });
      return url.endsWith('/responses')
        ? jsonResponse(responsesReply)
        : jsonResponse({ choices: [{ message: { content: 'plain' }, finish_reason: 'stop' }], usage: { prompt_tokens: 1, completion_tokens: 2 } });
    },
  });

  const TOOLS = [{ type: 'function', function: { name: 'lookup', description: 'find a vendor', parameters: { type: 'object', properties: { q: { type: 'string' } } } } }];
  const withTools = await chat.chatOnce({ system: ['persona', 'pack'], messages: [{ role: 'user', content: 'who is BAE' }], tools: TOOLS });

  // THE ENDPOINT is the whole point of the change: `tools` on /chat/completions is what answers 400.
  assert.ok(calls[0].url.endsWith('/responses'), 'a tool turn must not go to chat/completions, it went to ' + calls[0].url);
  // The Responses shape: flat function fields, `instructions` not a system message, `max_output_tokens`.
  assert.deepEqual(calls[0].body.tools, [{ type: 'function', name: 'lookup', description: 'find a vendor', parameters: { type: 'object', properties: { q: { type: 'string' } } } }]);
  assert.equal(calls[0].body.instructions, 'persona\n\npack');
  assert.deepEqual(calls[0].body.input, [{ role: 'user', content: 'who is BAE' }]);
  assert.ok(!('messages' in calls[0].body), 'the Responses API takes `input`, never `messages`');
  assert.ok(!('max_completion_tokens' in calls[0].body), 'the Responses API takes `max_output_tokens`');

  // The shape handed BACK is unchanged, so src/hugo/agent.js needs no edit.
  assert.equal(withTools.finishReason, 'tool_calls');
  assert.equal(withTools.message.content, 'thinking aloud');
  assert.deepEqual(withTools.message.tool_calls, [{ id: 'call_1', type: 'function', function: { name: 'lookup', arguments: '{"q":"BAE"}' } }]);
  assert.deepEqual(withTools.usage, { input_tokens: 11, output_tokens: 7 });

  // AND THE ASSERTION CAN SAY BOTH THINGS: a tool-free turn still uses chat/completions, which is the half
  // that would make a blanket "everything moved to /responses" change look correct when it is not.
  const plain = await chat.chatOnce({ system: 's', messages: [{ role: 'user', content: 'hello' }] });
  assert.ok(calls[1].url.endsWith('/chat/completions'), 'a tool-free turn belongs on chat/completions');
  assert.equal(plain.finishReason, 'stop');
});

test('a tool RESULT round-trips as a function_call_output paired to its call_id', async () => {
  let body = null;
  const chat = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async (url, opts) => { body = JSON.parse(opts.body); return jsonResponse({ output: [{ type: 'message', content: [{ type: 'output_text', text: 'done' }] }], usage: {} }); },
  });
  await chat.chatOnce({
    system: 's',
    tools: [{ type: 'function', function: { name: 'lookup', parameters: {} } }],
    messages: [
      { role: 'user', content: 'who is BAE' },
      { role: 'assistant', content: '', tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'lookup', arguments: '{}' } }] },
      { role: 'tool', tool_call_id: 'call_1', content: 'BAE Systems, VH-0420' },
    ],
  });
  assert.deepEqual(body.input, [
    { role: 'user', content: 'who is BAE' },
    { type: 'function_call', call_id: 'call_1', name: 'lookup', arguments: '{}' },
    { type: 'function_call_output', call_id: 'call_1', output: 'BAE Systems, VH-0420' },
  ]);
  // An empty assistant content emits NO assistant item: a blank turn between a call and its result is not
  // a message, and the pairing the next turn depends on is call_id to call_id.
  assert.equal(body.input.filter((i) => i.role === 'assistant').length, 0);
});

// --- THE ADMIN RING GETS THE SENTENCE BACK, REDACTED (V1.90, after both gates) -------------------------

test('redactSecrets masks anything credential-shaped and keeps the part that names the cause', () => {
  // WHY THIS EXISTS. Removing the provider's prose from `err.message` closed a measured leak (a security
  // gate drove `sk-proj-...` out of a live HTTP 200) and, an engineering gate found, left the diagnostic
  // recorded NOWHERE, because the fault ring stores `err.message` and nothing read `providerDetail`. The two
  // gates proposed opposite fixes. This is the one that satisfies both: the sentence returns to the
  // admin-only ring with the credential masked.
  const leak = 'Incorrect API key provided: sk-proj-Ab3xQCANARY9999abcdefgh. You can find your API key at '
    + 'https://platform.openai.com/account/api-keys.';
  const red = redactSecrets(leak);
  assert.ok(!red.includes('sk-proj-Ab3xQCANARY9999abcdefgh'), 'the key is gone');
  assert.ok(red.includes('[REDACTED:credential]'), 'and it is marked rather than silently dropped');
  assert.ok(red.includes('Incorrect API key provided'), 'the part that names the cause survives');

  // THE ASSERTION CAN SAY BOTH THINGS: a sentence with no credential in it must come back untouched, or the
  // redactor would be masking the very diagnostic it exists to preserve.
  const clean = 'The model `gpt-6-astra` does not exist or you do not have access to it.';
  assert.equal(redactSecrets(clean), clean, 'a model id is not a credential');
  assert.equal(redactSecrets("Unsupported parameter: 'tools' is not supported with this model."),
    "Unsupported parameter: 'tools' is not supported with this model.");

  // DENY BY SHAPE, NOT BY VENDOR PREFIX: a bearer header quoted back at us is masked whoever minted it.
  assert.ok(!redactSecrets('Authorization: Bearer abc123def456ghi789').includes('abc123def456ghi789'));
  assert.equal(redactSecrets(null), '');
});

test('the error carries a redacted ringDetail for the fault ring and a bare message for the wire', async () => {
  const body = JSON.stringify({ error: { message: 'Incorrect API key provided: sk-proj-CANARY0123456789abc', code: 'invalid_api_key' } });
  const chat = createOpenAiChat({
    apiKey: 'sk-test',
    fetchImpl: async () => ({ ok: false, status: 401, json: async () => ({}), text: async () => body }),
  });
  await assert.rejects(() => chat.chatOnce({ system: 's', messages: [] }), (e) => {
    // The wire half: nothing the provider wrote.
    assert.equal(e.message, 'hugo model provider error 401 invalid_api_key');
    // The ring half: the cause named, the credential masked.
    assert.ok(e.ringDetail.startsWith('hugo model provider error 401 invalid_api_key: '));
    assert.ok(e.ringDetail.includes('Incorrect API key provided'), 'the ring can still tell the four causes apart');
    assert.ok(!e.ringDetail.includes('sk-proj-CANARY0123456789abc'), 'and it carries no credential');
    return true;
  });
});
