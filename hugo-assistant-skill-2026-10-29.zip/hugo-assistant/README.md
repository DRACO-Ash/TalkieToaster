# hugo-assistant

A drop-in Claude Code skill for building a grounded, voice-capable AI assistant ("a Hugo") into a server-backed app.
Taken from Hugo in NATO VENDOR RADAR (Bluestaq Limited), 29 October 2026.

Install: copy this folder into your project's `.claude/skills/`.

| File | Read it when |
|---|---|
| `SKILL.md` | First: the pattern and the rules, with why each exists |
| `SETUP.md` | Setting it up: requirements, accounts, configuration, step-by-step build, verification, troubleshooting, what to replace |
| `env.example` | Configuring: every environment variable with its default (no real values) |
| `BUILD-YOUR-OWN-HUGO.md` | Briefing a team or a manager: the one-page checklist |
| `reference/` | Building: the shipped app's Hugo source (`src/hugo/`, `public/views/hugo-*`), its tests, its evals (synthetic data only) and browser passes, plus wiring extracts from its large shared files |

`reference/` is a worked example, not a library: it is written for that app's data model and must be adapted
(`SETUP.md`, section 6). `reference/SOURCE-COMMIT.txt` names the commit it was taken from.
